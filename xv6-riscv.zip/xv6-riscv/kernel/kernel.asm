
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	00008117          	auipc	sp,0x8
    80000004:	9d010113          	addi	sp,sp,-1584 # 800079d0 <stack0>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	048000ef          	jal	ra,8000005e <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000022:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000026:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002a:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    8000002e:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000032:	577d                	li	a4,-1
    80000034:	177e                	slli	a4,a4,0x3f
    80000036:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    80000038:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003c:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000040:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000044:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    80000048:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 100000);
    8000004c:	6761                	lui	a4,0x18
    8000004e:	6a070713          	addi	a4,a4,1696 # 186a0 <_entry-0x7ffe7960>
    80000052:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000054:	14d79073          	csrw	0x14d,a5
}
    80000058:	6422                	ld	s0,8(sp)
    8000005a:	0141                	addi	sp,sp,16
    8000005c:	8082                	ret

000000008000005e <start>:
{
    8000005e:	1141                	addi	sp,sp,-16
    80000060:	e406                	sd	ra,8(sp)
    80000062:	e022                	sd	s0,0(sp)
    80000064:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    80000066:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    8000006a:	7779                	lui	a4,0xffffe
    8000006c:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdd127>
    80000070:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000072:	6705                	lui	a4,0x1
    80000074:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80000078:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    8000007a:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    8000007e:	00001797          	auipc	a5,0x1
    80000082:	dba78793          	addi	a5,a5,-582 # 80000e38 <main>
    80000086:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    8000008a:	4781                	li	a5,0
    8000008c:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000090:	67c1                	lui	a5,0x10
    80000092:	17fd                	addi	a5,a5,-1
    80000094:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    80000098:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    8000009c:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a0:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000a4:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000a8:	57fd                	li	a5,-1
    800000aa:	83a9                	srli	a5,a5,0xa
    800000ac:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b0:	47bd                	li	a5,15
    800000b2:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000b6:	f67ff0ef          	jal	ra,8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000ba:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000be:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c0:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c2:	30200073          	mret
}
    800000c6:	60a2                	ld	ra,8(sp)
    800000c8:	6402                	ld	s0,0(sp)
    800000ca:	0141                	addi	sp,sp,16
    800000cc:	8082                	ret

00000000800000ce <consolewrite>:
// user write() system calls to the console go here.
// uses sleep() and UART interrupts.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000ce:	7159                	addi	sp,sp,-112
    800000d0:	f486                	sd	ra,104(sp)
    800000d2:	f0a2                	sd	s0,96(sp)
    800000d4:	eca6                	sd	s1,88(sp)
    800000d6:	e8ca                	sd	s2,80(sp)
    800000d8:	e4ce                	sd	s3,72(sp)
    800000da:	e0d2                	sd	s4,64(sp)
    800000dc:	fc56                	sd	s5,56(sp)
    800000de:	f85a                	sd	s6,48(sp)
    800000e0:	f45e                	sd	s7,40(sp)
    800000e2:	f062                	sd	s8,32(sp)
    800000e4:	1880                	addi	s0,sp,112
  char buf[32]; // move batches from user space to uart.
  int i = 0;

  while(i < n){
    800000e6:	04c05463          	blez	a2,8000012e <consolewrite+0x60>
    800000ea:	8a2a                	mv	s4,a0
    800000ec:	8aae                	mv	s5,a1
    800000ee:	89b2                	mv	s3,a2
  int i = 0;
    800000f0:	4901                	li	s2,0
    int nn = sizeof(buf);
    if(nn > n - i)
    800000f2:	4bfd                	li	s7,31
    int nn = sizeof(buf);
    800000f4:	02000c13          	li	s8,32
      nn = n - i;
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    800000f8:	5b7d                	li	s6,-1
    800000fa:	a025                	j	80000122 <consolewrite+0x54>
    800000fc:	86a6                	mv	a3,s1
    800000fe:	01590633          	add	a2,s2,s5
    80000102:	85d2                	mv	a1,s4
    80000104:	f9040513          	addi	a0,s0,-112
    80000108:	2d4020ef          	jal	ra,800023dc <either_copyin>
    8000010c:	03650263          	beq	a0,s6,80000130 <consolewrite+0x62>
      break;
    uartwrite(buf, nn);
    80000110:	85a6                	mv	a1,s1
    80000112:	f9040513          	addi	a0,s0,-112
    80000116:	724000ef          	jal	ra,8000083a <uartwrite>
    i += nn;
    8000011a:	0124893b          	addw	s2,s1,s2
  while(i < n){
    8000011e:	01395963          	bge	s2,s3,80000130 <consolewrite+0x62>
    if(nn > n - i)
    80000122:	412984bb          	subw	s1,s3,s2
    80000126:	fc9bdbe3          	bge	s7,s1,800000fc <consolewrite+0x2e>
    int nn = sizeof(buf);
    8000012a:	84e2                	mv	s1,s8
    8000012c:	bfc1                	j	800000fc <consolewrite+0x2e>
  int i = 0;
    8000012e:	4901                	li	s2,0
  }

  return i;
}
    80000130:	854a                	mv	a0,s2
    80000132:	70a6                	ld	ra,104(sp)
    80000134:	7406                	ld	s0,96(sp)
    80000136:	64e6                	ld	s1,88(sp)
    80000138:	6946                	ld	s2,80(sp)
    8000013a:	69a6                	ld	s3,72(sp)
    8000013c:	6a06                	ld	s4,64(sp)
    8000013e:	7ae2                	ld	s5,56(sp)
    80000140:	7b42                	ld	s6,48(sp)
    80000142:	7ba2                	ld	s7,40(sp)
    80000144:	7c02                	ld	s8,32(sp)
    80000146:	6165                	addi	sp,sp,112
    80000148:	8082                	ret

000000008000014a <consoleread>:
// user_dst indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    8000014a:	7119                	addi	sp,sp,-128
    8000014c:	fc86                	sd	ra,120(sp)
    8000014e:	f8a2                	sd	s0,112(sp)
    80000150:	f4a6                	sd	s1,104(sp)
    80000152:	f0ca                	sd	s2,96(sp)
    80000154:	ecce                	sd	s3,88(sp)
    80000156:	e8d2                	sd	s4,80(sp)
    80000158:	e4d6                	sd	s5,72(sp)
    8000015a:	e0da                	sd	s6,64(sp)
    8000015c:	fc5e                	sd	s7,56(sp)
    8000015e:	f862                	sd	s8,48(sp)
    80000160:	f466                	sd	s9,40(sp)
    80000162:	f06a                	sd	s10,32(sp)
    80000164:	ec6e                	sd	s11,24(sp)
    80000166:	0100                	addi	s0,sp,128
    80000168:	8b2a                	mv	s6,a0
    8000016a:	8aae                	mv	s5,a1
    8000016c:	8a32                	mv	s4,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    8000016e:	00060b9b          	sext.w	s7,a2
  acquire(&cons.lock);
    80000172:	00010517          	auipc	a0,0x10
    80000176:	85e50513          	addi	a0,a0,-1954 # 8000f9d0 <cons>
    8000017a:	241000ef          	jal	ra,80000bba <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    8000017e:	00010497          	auipc	s1,0x10
    80000182:	85248493          	addi	s1,s1,-1966 # 8000f9d0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    80000186:	89a6                	mv	s3,s1
    80000188:	00010917          	auipc	s2,0x10
    8000018c:	8e090913          	addi	s2,s2,-1824 # 8000fa68 <cons+0x98>
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];

    if(c == C('D')){  // end-of-file
    80000190:	4c91                	li	s9,4
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000192:	5d7d                	li	s10,-1
      break;

    dst++;
    --n;

    if(c == '\n'){
    80000194:	4da9                	li	s11,10
  while(n > 0){
    80000196:	07405363          	blez	s4,800001fc <consoleread+0xb2>
    while(cons.r == cons.w){
    8000019a:	0984a783          	lw	a5,152(s1)
    8000019e:	09c4a703          	lw	a4,156(s1)
    800001a2:	02f71163          	bne	a4,a5,800001c4 <consoleread+0x7a>
      if(killed(myproc())){
    800001a6:	6b4010ef          	jal	ra,8000185a <myproc>
    800001aa:	0c4020ef          	jal	ra,8000226e <killed>
    800001ae:	e125                	bnez	a0,8000020e <consoleread+0xc4>
      sleep(&cons.r, &cons.lock);
    800001b0:	85ce                	mv	a1,s3
    800001b2:	854a                	mv	a0,s2
    800001b4:	643010ef          	jal	ra,80001ff6 <sleep>
    while(cons.r == cons.w){
    800001b8:	0984a783          	lw	a5,152(s1)
    800001bc:	09c4a703          	lw	a4,156(s1)
    800001c0:	fef703e3          	beq	a4,a5,800001a6 <consoleread+0x5c>
    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001c4:	0017871b          	addiw	a4,a5,1
    800001c8:	08e4ac23          	sw	a4,152(s1)
    800001cc:	07f7f713          	andi	a4,a5,127
    800001d0:	9726                	add	a4,a4,s1
    800001d2:	01874703          	lbu	a4,24(a4)
    800001d6:	00070c1b          	sext.w	s8,a4
    if(c == C('D')){  // end-of-file
    800001da:	079c0063          	beq	s8,s9,8000023a <consoleread+0xf0>
    cbuf = c;
    800001de:	f8e407a3          	sb	a4,-113(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    800001e2:	4685                	li	a3,1
    800001e4:	f8f40613          	addi	a2,s0,-113
    800001e8:	85d6                	mv	a1,s5
    800001ea:	855a                	mv	a0,s6
    800001ec:	1a6020ef          	jal	ra,80002392 <either_copyout>
    800001f0:	01a50663          	beq	a0,s10,800001fc <consoleread+0xb2>
    dst++;
    800001f4:	0a85                	addi	s5,s5,1
    --n;
    800001f6:	3a7d                	addiw	s4,s4,-1
    if(c == '\n'){
    800001f8:	f9bc1fe3          	bne	s8,s11,80000196 <consoleread+0x4c>
      // a whole line has arrived, return to
      // the user-level read().
      break;
    }
  }
  release(&cons.lock);
    800001fc:	0000f517          	auipc	a0,0xf
    80000200:	7d450513          	addi	a0,a0,2004 # 8000f9d0 <cons>
    80000204:	24f000ef          	jal	ra,80000c52 <release>

  return target - n;
    80000208:	414b853b          	subw	a0,s7,s4
    8000020c:	a801                	j	8000021c <consoleread+0xd2>
        release(&cons.lock);
    8000020e:	0000f517          	auipc	a0,0xf
    80000212:	7c250513          	addi	a0,a0,1986 # 8000f9d0 <cons>
    80000216:	23d000ef          	jal	ra,80000c52 <release>
        return -1;
    8000021a:	557d                	li	a0,-1
}
    8000021c:	70e6                	ld	ra,120(sp)
    8000021e:	7446                	ld	s0,112(sp)
    80000220:	74a6                	ld	s1,104(sp)
    80000222:	7906                	ld	s2,96(sp)
    80000224:	69e6                	ld	s3,88(sp)
    80000226:	6a46                	ld	s4,80(sp)
    80000228:	6aa6                	ld	s5,72(sp)
    8000022a:	6b06                	ld	s6,64(sp)
    8000022c:	7be2                	ld	s7,56(sp)
    8000022e:	7c42                	ld	s8,48(sp)
    80000230:	7ca2                	ld	s9,40(sp)
    80000232:	7d02                	ld	s10,32(sp)
    80000234:	6de2                	ld	s11,24(sp)
    80000236:	6109                	addi	sp,sp,128
    80000238:	8082                	ret
      if(n < target){
    8000023a:	000a071b          	sext.w	a4,s4
    8000023e:	fb777fe3          	bgeu	a4,s7,800001fc <consoleread+0xb2>
        cons.r--;
    80000242:	00010717          	auipc	a4,0x10
    80000246:	82f72323          	sw	a5,-2010(a4) # 8000fa68 <cons+0x98>
    8000024a:	bf4d                	j	800001fc <consoleread+0xb2>

000000008000024c <consputc>:
{
    8000024c:	1141                	addi	sp,sp,-16
    8000024e:	e406                	sd	ra,8(sp)
    80000250:	e022                	sd	s0,0(sp)
    80000252:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000254:	10000793          	li	a5,256
    80000258:	00f50863          	beq	a0,a5,80000268 <consputc+0x1c>
    uartputc_sync(c);
    8000025c:	67c000ef          	jal	ra,800008d8 <uartputc_sync>
}
    80000260:	60a2                	ld	ra,8(sp)
    80000262:	6402                	ld	s0,0(sp)
    80000264:	0141                	addi	sp,sp,16
    80000266:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000268:	4521                	li	a0,8
    8000026a:	66e000ef          	jal	ra,800008d8 <uartputc_sync>
    8000026e:	02000513          	li	a0,32
    80000272:	666000ef          	jal	ra,800008d8 <uartputc_sync>
    80000276:	4521                	li	a0,8
    80000278:	660000ef          	jal	ra,800008d8 <uartputc_sync>
    8000027c:	b7d5                	j	80000260 <consputc+0x14>

000000008000027e <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    8000027e:	1101                	addi	sp,sp,-32
    80000280:	ec06                	sd	ra,24(sp)
    80000282:	e822                	sd	s0,16(sp)
    80000284:	e426                	sd	s1,8(sp)
    80000286:	e04a                	sd	s2,0(sp)
    80000288:	1000                	addi	s0,sp,32
    8000028a:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    8000028c:	0000f517          	auipc	a0,0xf
    80000290:	74450513          	addi	a0,a0,1860 # 8000f9d0 <cons>
    80000294:	127000ef          	jal	ra,80000bba <acquire>

  switch(c){
    80000298:	47d5                	li	a5,21
    8000029a:	0af48063          	beq	s1,a5,8000033a <consoleintr+0xbc>
    8000029e:	0297c663          	blt	a5,s1,800002ca <consoleintr+0x4c>
    800002a2:	47a1                	li	a5,8
    800002a4:	0cf48f63          	beq	s1,a5,80000382 <consoleintr+0x104>
    800002a8:	47c1                	li	a5,16
    800002aa:	10f49063          	bne	s1,a5,800003aa <consoleintr+0x12c>
  case C('P'):  // Print process list.
    procdump();
    800002ae:	178020ef          	jal	ra,80002426 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002b2:	0000f517          	auipc	a0,0xf
    800002b6:	71e50513          	addi	a0,a0,1822 # 8000f9d0 <cons>
    800002ba:	199000ef          	jal	ra,80000c52 <release>
}
    800002be:	60e2                	ld	ra,24(sp)
    800002c0:	6442                	ld	s0,16(sp)
    800002c2:	64a2                	ld	s1,8(sp)
    800002c4:	6902                	ld	s2,0(sp)
    800002c6:	6105                	addi	sp,sp,32
    800002c8:	8082                	ret
  switch(c){
    800002ca:	07f00793          	li	a5,127
    800002ce:	0af48a63          	beq	s1,a5,80000382 <consoleintr+0x104>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002d2:	0000f717          	auipc	a4,0xf
    800002d6:	6fe70713          	addi	a4,a4,1790 # 8000f9d0 <cons>
    800002da:	0a072783          	lw	a5,160(a4)
    800002de:	09872703          	lw	a4,152(a4)
    800002e2:	9f99                	subw	a5,a5,a4
    800002e4:	07f00713          	li	a4,127
    800002e8:	fcf765e3          	bltu	a4,a5,800002b2 <consoleintr+0x34>
      c = (c == '\r') ? '\n' : c;
    800002ec:	47b5                	li	a5,13
    800002ee:	0cf48163          	beq	s1,a5,800003b0 <consoleintr+0x132>
      consputc(c);
    800002f2:	8526                	mv	a0,s1
    800002f4:	f59ff0ef          	jal	ra,8000024c <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800002f8:	0000f797          	auipc	a5,0xf
    800002fc:	6d878793          	addi	a5,a5,1752 # 8000f9d0 <cons>
    80000300:	0a07a683          	lw	a3,160(a5)
    80000304:	0016871b          	addiw	a4,a3,1
    80000308:	0007061b          	sext.w	a2,a4
    8000030c:	0ae7a023          	sw	a4,160(a5)
    80000310:	07f6f693          	andi	a3,a3,127
    80000314:	97b6                	add	a5,a5,a3
    80000316:	00978c23          	sb	s1,24(a5)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    8000031a:	47a9                	li	a5,10
    8000031c:	0af48f63          	beq	s1,a5,800003da <consoleintr+0x15c>
    80000320:	4791                	li	a5,4
    80000322:	0af48c63          	beq	s1,a5,800003da <consoleintr+0x15c>
    80000326:	0000f797          	auipc	a5,0xf
    8000032a:	7427a783          	lw	a5,1858(a5) # 8000fa68 <cons+0x98>
    8000032e:	9f1d                	subw	a4,a4,a5
    80000330:	08000793          	li	a5,128
    80000334:	f6f71fe3          	bne	a4,a5,800002b2 <consoleintr+0x34>
    80000338:	a04d                	j	800003da <consoleintr+0x15c>
    while(cons.e != cons.w &&
    8000033a:	0000f717          	auipc	a4,0xf
    8000033e:	69670713          	addi	a4,a4,1686 # 8000f9d0 <cons>
    80000342:	0a072783          	lw	a5,160(a4)
    80000346:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    8000034a:	0000f497          	auipc	s1,0xf
    8000034e:	68648493          	addi	s1,s1,1670 # 8000f9d0 <cons>
    while(cons.e != cons.w &&
    80000352:	4929                	li	s2,10
    80000354:	f4f70fe3          	beq	a4,a5,800002b2 <consoleintr+0x34>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000358:	37fd                	addiw	a5,a5,-1
    8000035a:	07f7f713          	andi	a4,a5,127
    8000035e:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    80000360:	01874703          	lbu	a4,24(a4)
    80000364:	f52707e3          	beq	a4,s2,800002b2 <consoleintr+0x34>
      cons.e--;
    80000368:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    8000036c:	10000513          	li	a0,256
    80000370:	eddff0ef          	jal	ra,8000024c <consputc>
    while(cons.e != cons.w &&
    80000374:	0a04a783          	lw	a5,160(s1)
    80000378:	09c4a703          	lw	a4,156(s1)
    8000037c:	fcf71ee3          	bne	a4,a5,80000358 <consoleintr+0xda>
    80000380:	bf0d                	j	800002b2 <consoleintr+0x34>
    if(cons.e != cons.w){
    80000382:	0000f717          	auipc	a4,0xf
    80000386:	64e70713          	addi	a4,a4,1614 # 8000f9d0 <cons>
    8000038a:	0a072783          	lw	a5,160(a4)
    8000038e:	09c72703          	lw	a4,156(a4)
    80000392:	f2f700e3          	beq	a4,a5,800002b2 <consoleintr+0x34>
      cons.e--;
    80000396:	37fd                	addiw	a5,a5,-1
    80000398:	0000f717          	auipc	a4,0xf
    8000039c:	6cf72c23          	sw	a5,1752(a4) # 8000fa70 <cons+0xa0>
      consputc(BACKSPACE);
    800003a0:	10000513          	li	a0,256
    800003a4:	ea9ff0ef          	jal	ra,8000024c <consputc>
    800003a8:	b729                	j	800002b2 <consoleintr+0x34>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800003aa:	f00484e3          	beqz	s1,800002b2 <consoleintr+0x34>
    800003ae:	b715                	j	800002d2 <consoleintr+0x54>
      consputc(c);
    800003b0:	4529                	li	a0,10
    800003b2:	e9bff0ef          	jal	ra,8000024c <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003b6:	0000f797          	auipc	a5,0xf
    800003ba:	61a78793          	addi	a5,a5,1562 # 8000f9d0 <cons>
    800003be:	0a07a703          	lw	a4,160(a5)
    800003c2:	0017069b          	addiw	a3,a4,1
    800003c6:	0006861b          	sext.w	a2,a3
    800003ca:	0ad7a023          	sw	a3,160(a5)
    800003ce:	07f77713          	andi	a4,a4,127
    800003d2:	97ba                	add	a5,a5,a4
    800003d4:	4729                	li	a4,10
    800003d6:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    800003da:	0000f797          	auipc	a5,0xf
    800003de:	68c7a923          	sw	a2,1682(a5) # 8000fa6c <cons+0x9c>
        wakeup(&cons.r);
    800003e2:	0000f517          	auipc	a0,0xf
    800003e6:	68650513          	addi	a0,a0,1670 # 8000fa68 <cons+0x98>
    800003ea:	459010ef          	jal	ra,80002042 <wakeup>
    800003ee:	b5d1                	j	800002b2 <consoleintr+0x34>

00000000800003f0 <consoleinit>:

void
consoleinit(void)
{
    800003f0:	1141                	addi	sp,sp,-16
    800003f2:	e406                	sd	ra,8(sp)
    800003f4:	e022                	sd	s0,0(sp)
    800003f6:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    800003f8:	00007597          	auipc	a1,0x7
    800003fc:	c1858593          	addi	a1,a1,-1000 # 80007010 <etext+0x10>
    80000400:	0000f517          	auipc	a0,0xf
    80000404:	5d050513          	addi	a0,a0,1488 # 8000f9d0 <cons>
    80000408:	732000ef          	jal	ra,80000b3a <initlock>

  uartinit();
    8000040c:	3e2000ef          	jal	ra,800007ee <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000410:	00020797          	auipc	a5,0x20
    80000414:	13078793          	addi	a5,a5,304 # 80020540 <devsw>
    80000418:	00000717          	auipc	a4,0x0
    8000041c:	d3270713          	addi	a4,a4,-718 # 8000014a <consoleread>
    80000420:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000422:	00000717          	auipc	a4,0x0
    80000426:	cac70713          	addi	a4,a4,-852 # 800000ce <consolewrite>
    8000042a:	ef98                	sd	a4,24(a5)
}
    8000042c:	60a2                	ld	ra,8(sp)
    8000042e:	6402                	ld	s0,0(sp)
    80000430:	0141                	addi	sp,sp,16
    80000432:	8082                	ret

0000000080000434 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000434:	7139                	addi	sp,sp,-64
    80000436:	fc06                	sd	ra,56(sp)
    80000438:	f822                	sd	s0,48(sp)
    8000043a:	f426                	sd	s1,40(sp)
    8000043c:	f04a                	sd	s2,32(sp)
    8000043e:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    80000440:	c219                	beqz	a2,80000446 <printint+0x12>
    80000442:	06054f63          	bltz	a0,800004c0 <printint+0x8c>
    x = -xx;
  else
    x = xx;
    80000446:	4881                	li	a7,0
    80000448:	fc840693          	addi	a3,s0,-56

  i = 0;
    8000044c:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    8000044e:	00007617          	auipc	a2,0x7
    80000452:	bea60613          	addi	a2,a2,-1046 # 80007038 <digits>
    80000456:	883e                	mv	a6,a5
    80000458:	2785                	addiw	a5,a5,1
    8000045a:	02b57733          	remu	a4,a0,a1
    8000045e:	9732                	add	a4,a4,a2
    80000460:	00074703          	lbu	a4,0(a4)
    80000464:	00e68023          	sb	a4,0(a3)
  } while((x /= base) != 0);
    80000468:	872a                	mv	a4,a0
    8000046a:	02b55533          	divu	a0,a0,a1
    8000046e:	0685                	addi	a3,a3,1
    80000470:	feb773e3          	bgeu	a4,a1,80000456 <printint+0x22>

  if(sign)
    80000474:	00088b63          	beqz	a7,8000048a <printint+0x56>
    buf[i++] = '-';
    80000478:	fe040713          	addi	a4,s0,-32
    8000047c:	97ba                	add	a5,a5,a4
    8000047e:	02d00713          	li	a4,45
    80000482:	fee78423          	sb	a4,-24(a5)
    80000486:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
    8000048a:	02f05563          	blez	a5,800004b4 <printint+0x80>
    8000048e:	fc840713          	addi	a4,s0,-56
    80000492:	00f704b3          	add	s1,a4,a5
    80000496:	fff70913          	addi	s2,a4,-1
    8000049a:	993e                	add	s2,s2,a5
    8000049c:	37fd                	addiw	a5,a5,-1
    8000049e:	1782                	slli	a5,a5,0x20
    800004a0:	9381                	srli	a5,a5,0x20
    800004a2:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    800004a6:	fff4c503          	lbu	a0,-1(s1)
    800004aa:	da3ff0ef          	jal	ra,8000024c <consputc>
  while(--i >= 0)
    800004ae:	14fd                	addi	s1,s1,-1
    800004b0:	ff249be3          	bne	s1,s2,800004a6 <printint+0x72>
}
    800004b4:	70e2                	ld	ra,56(sp)
    800004b6:	7442                	ld	s0,48(sp)
    800004b8:	74a2                	ld	s1,40(sp)
    800004ba:	7902                	ld	s2,32(sp)
    800004bc:	6121                	addi	sp,sp,64
    800004be:	8082                	ret
    x = -xx;
    800004c0:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800004c4:	4885                	li	a7,1
    x = -xx;
    800004c6:	b749                	j	80000448 <printint+0x14>

00000000800004c8 <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004c8:	7131                	addi	sp,sp,-192
    800004ca:	fc86                	sd	ra,120(sp)
    800004cc:	f8a2                	sd	s0,112(sp)
    800004ce:	f4a6                	sd	s1,104(sp)
    800004d0:	f0ca                	sd	s2,96(sp)
    800004d2:	ecce                	sd	s3,88(sp)
    800004d4:	e8d2                	sd	s4,80(sp)
    800004d6:	e4d6                	sd	s5,72(sp)
    800004d8:	e0da                	sd	s6,64(sp)
    800004da:	fc5e                	sd	s7,56(sp)
    800004dc:	f862                	sd	s8,48(sp)
    800004de:	f466                	sd	s9,40(sp)
    800004e0:	f06a                	sd	s10,32(sp)
    800004e2:	ec6e                	sd	s11,24(sp)
    800004e4:	0100                	addi	s0,sp,128
    800004e6:	8a2a                	mv	s4,a0
    800004e8:	e40c                	sd	a1,8(s0)
    800004ea:	e810                	sd	a2,16(s0)
    800004ec:	ec14                	sd	a3,24(s0)
    800004ee:	f018                	sd	a4,32(s0)
    800004f0:	f41c                	sd	a5,40(s0)
    800004f2:	03043823          	sd	a6,48(s0)
    800004f6:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if(panicking == 0)
    800004fa:	00007797          	auipc	a5,0x7
    800004fe:	4aa7a783          	lw	a5,1194(a5) # 800079a4 <panicking>
    80000502:	cb9d                	beqz	a5,80000538 <printf+0x70>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000504:	00840793          	addi	a5,s0,8
    80000508:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    8000050c:	000a4503          	lbu	a0,0(s4)
    80000510:	24050363          	beqz	a0,80000756 <printf+0x28e>
    80000514:	4981                	li	s3,0
    if(cx != '%'){
    80000516:	02500a93          	li	s5,37
    i++;
    c0 = fmt[i+0] & 0xff;
    c1 = c2 = 0;
    if(c0) c1 = fmt[i+1] & 0xff;
    if(c1) c2 = fmt[i+2] & 0xff;
    if(c0 == 'd'){
    8000051a:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if(c0 == 'l' && c1 == 'd'){
    8000051e:	06c00c13          	li	s8,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    80000522:	07500c93          	li	s9,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    80000526:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    8000052a:	07000d93          	li	s11,112
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    8000052e:	00007b97          	auipc	s7,0x7
    80000532:	b0ab8b93          	addi	s7,s7,-1270 # 80007038 <digits>
    80000536:	a01d                	j	8000055c <printf+0x94>
    acquire(&pr.lock);
    80000538:	0000f517          	auipc	a0,0xf
    8000053c:	54050513          	addi	a0,a0,1344 # 8000fa78 <pr>
    80000540:	67a000ef          	jal	ra,80000bba <acquire>
    80000544:	b7c1                	j	80000504 <printf+0x3c>
      consputc(cx);
    80000546:	d07ff0ef          	jal	ra,8000024c <consputc>
      continue;
    8000054a:	84ce                	mv	s1,s3
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    8000054c:	0014899b          	addiw	s3,s1,1
    80000550:	013a07b3          	add	a5,s4,s3
    80000554:	0007c503          	lbu	a0,0(a5)
    80000558:	1e050f63          	beqz	a0,80000756 <printf+0x28e>
    if(cx != '%'){
    8000055c:	ff5515e3          	bne	a0,s5,80000546 <printf+0x7e>
    i++;
    80000560:	0019849b          	addiw	s1,s3,1
    c0 = fmt[i+0] & 0xff;
    80000564:	009a07b3          	add	a5,s4,s1
    80000568:	0007c903          	lbu	s2,0(a5)
    if(c0) c1 = fmt[i+1] & 0xff;
    8000056c:	1e090563          	beqz	s2,80000756 <printf+0x28e>
    80000570:	0017c783          	lbu	a5,1(a5)
    c1 = c2 = 0;
    80000574:	86be                	mv	a3,a5
    if(c1) c2 = fmt[i+2] & 0xff;
    80000576:	c789                	beqz	a5,80000580 <printf+0xb8>
    80000578:	009a0733          	add	a4,s4,s1
    8000057c:	00274683          	lbu	a3,2(a4)
    if(c0 == 'd'){
    80000580:	03690863          	beq	s2,s6,800005b0 <printf+0xe8>
    } else if(c0 == 'l' && c1 == 'd'){
    80000584:	05890263          	beq	s2,s8,800005c8 <printf+0x100>
    } else if(c0 == 'u'){
    80000588:	0d990163          	beq	s2,s9,8000064a <printf+0x182>
    } else if(c0 == 'x'){
    8000058c:	11a90863          	beq	s2,s10,8000069c <printf+0x1d4>
    } else if(c0 == 'p'){
    80000590:	15b90163          	beq	s2,s11,800006d2 <printf+0x20a>
      printptr(va_arg(ap, uint64));
    } else if(c0 == 'c'){
    80000594:	06300793          	li	a5,99
    80000598:	16f90963          	beq	s2,a5,8000070a <printf+0x242>
      consputc(va_arg(ap, uint));
    } else if(c0 == 's'){
    8000059c:	07300793          	li	a5,115
    800005a0:	16f90f63          	beq	s2,a5,8000071e <printf+0x256>
      if((s = va_arg(ap, char*)) == 0)
        s = "(null)";
      for(; *s; s++)
        consputc(*s);
    } else if(c0 == '%'){
    800005a4:	03591c63          	bne	s2,s5,800005dc <printf+0x114>
      consputc('%');
    800005a8:	8556                	mv	a0,s5
    800005aa:	ca3ff0ef          	jal	ra,8000024c <consputc>
    800005ae:	bf79                	j	8000054c <printf+0x84>
      printint(va_arg(ap, int), 10, 1);
    800005b0:	f8843783          	ld	a5,-120(s0)
    800005b4:	00878713          	addi	a4,a5,8
    800005b8:	f8e43423          	sd	a4,-120(s0)
    800005bc:	4605                	li	a2,1
    800005be:	45a9                	li	a1,10
    800005c0:	4388                	lw	a0,0(a5)
    800005c2:	e73ff0ef          	jal	ra,80000434 <printint>
    800005c6:	b759                	j	8000054c <printf+0x84>
    } else if(c0 == 'l' && c1 == 'd'){
    800005c8:	03678163          	beq	a5,s6,800005ea <printf+0x122>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800005cc:	03878d63          	beq	a5,s8,80000606 <printf+0x13e>
    } else if(c0 == 'l' && c1 == 'u'){
    800005d0:	09978a63          	beq	a5,s9,80000664 <printf+0x19c>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    800005d4:	03878b63          	beq	a5,s8,8000060a <printf+0x142>
    } else if(c0 == 'l' && c1 == 'x'){
    800005d8:	0da78f63          	beq	a5,s10,800006b6 <printf+0x1ee>
    } else if(c0 == 0){
      break;
    } else {
      // Print unknown % sequence to draw attention.
      consputc('%');
    800005dc:	8556                	mv	a0,s5
    800005de:	c6fff0ef          	jal	ra,8000024c <consputc>
      consputc(c0);
    800005e2:	854a                	mv	a0,s2
    800005e4:	c69ff0ef          	jal	ra,8000024c <consputc>
    800005e8:	b795                	j	8000054c <printf+0x84>
      printint(va_arg(ap, uint64), 10, 1);
    800005ea:	f8843783          	ld	a5,-120(s0)
    800005ee:	00878713          	addi	a4,a5,8
    800005f2:	f8e43423          	sd	a4,-120(s0)
    800005f6:	4605                	li	a2,1
    800005f8:	45a9                	li	a1,10
    800005fa:	6388                	ld	a0,0(a5)
    800005fc:	e39ff0ef          	jal	ra,80000434 <printint>
      i += 1;
    80000600:	0029849b          	addiw	s1,s3,2
    80000604:	b7a1                	j	8000054c <printf+0x84>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    80000606:	03668463          	beq	a3,s6,8000062e <printf+0x166>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    8000060a:	07968b63          	beq	a3,s9,80000680 <printf+0x1b8>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    8000060e:	fda697e3          	bne	a3,s10,800005dc <printf+0x114>
      printint(va_arg(ap, uint64), 16, 0);
    80000612:	f8843783          	ld	a5,-120(s0)
    80000616:	00878713          	addi	a4,a5,8
    8000061a:	f8e43423          	sd	a4,-120(s0)
    8000061e:	4601                	li	a2,0
    80000620:	45c1                	li	a1,16
    80000622:	6388                	ld	a0,0(a5)
    80000624:	e11ff0ef          	jal	ra,80000434 <printint>
      i += 2;
    80000628:	0039849b          	addiw	s1,s3,3
    8000062c:	b705                	j	8000054c <printf+0x84>
      printint(va_arg(ap, uint64), 10, 1);
    8000062e:	f8843783          	ld	a5,-120(s0)
    80000632:	00878713          	addi	a4,a5,8
    80000636:	f8e43423          	sd	a4,-120(s0)
    8000063a:	4605                	li	a2,1
    8000063c:	45a9                	li	a1,10
    8000063e:	6388                	ld	a0,0(a5)
    80000640:	df5ff0ef          	jal	ra,80000434 <printint>
      i += 2;
    80000644:	0039849b          	addiw	s1,s3,3
    80000648:	b711                	j	8000054c <printf+0x84>
      printint(va_arg(ap, uint32), 10, 0);
    8000064a:	f8843783          	ld	a5,-120(s0)
    8000064e:	00878713          	addi	a4,a5,8
    80000652:	f8e43423          	sd	a4,-120(s0)
    80000656:	4601                	li	a2,0
    80000658:	45a9                	li	a1,10
    8000065a:	0007e503          	lwu	a0,0(a5)
    8000065e:	dd7ff0ef          	jal	ra,80000434 <printint>
    80000662:	b5ed                	j	8000054c <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    80000664:	f8843783          	ld	a5,-120(s0)
    80000668:	00878713          	addi	a4,a5,8
    8000066c:	f8e43423          	sd	a4,-120(s0)
    80000670:	4601                	li	a2,0
    80000672:	45a9                	li	a1,10
    80000674:	6388                	ld	a0,0(a5)
    80000676:	dbfff0ef          	jal	ra,80000434 <printint>
      i += 1;
    8000067a:	0029849b          	addiw	s1,s3,2
    8000067e:	b5f9                	j	8000054c <printf+0x84>
      printint(va_arg(ap, uint64), 10, 0);
    80000680:	f8843783          	ld	a5,-120(s0)
    80000684:	00878713          	addi	a4,a5,8
    80000688:	f8e43423          	sd	a4,-120(s0)
    8000068c:	4601                	li	a2,0
    8000068e:	45a9                	li	a1,10
    80000690:	6388                	ld	a0,0(a5)
    80000692:	da3ff0ef          	jal	ra,80000434 <printint>
      i += 2;
    80000696:	0039849b          	addiw	s1,s3,3
    8000069a:	bd4d                	j	8000054c <printf+0x84>
      printint(va_arg(ap, uint32), 16, 0);
    8000069c:	f8843783          	ld	a5,-120(s0)
    800006a0:	00878713          	addi	a4,a5,8
    800006a4:	f8e43423          	sd	a4,-120(s0)
    800006a8:	4601                	li	a2,0
    800006aa:	45c1                	li	a1,16
    800006ac:	0007e503          	lwu	a0,0(a5)
    800006b0:	d85ff0ef          	jal	ra,80000434 <printint>
    800006b4:	bd61                	j	8000054c <printf+0x84>
      printint(va_arg(ap, uint64), 16, 0);
    800006b6:	f8843783          	ld	a5,-120(s0)
    800006ba:	00878713          	addi	a4,a5,8
    800006be:	f8e43423          	sd	a4,-120(s0)
    800006c2:	4601                	li	a2,0
    800006c4:	45c1                	li	a1,16
    800006c6:	6388                	ld	a0,0(a5)
    800006c8:	d6dff0ef          	jal	ra,80000434 <printint>
      i += 1;
    800006cc:	0029849b          	addiw	s1,s3,2
    800006d0:	bdb5                	j	8000054c <printf+0x84>
      printptr(va_arg(ap, uint64));
    800006d2:	f8843783          	ld	a5,-120(s0)
    800006d6:	00878713          	addi	a4,a5,8
    800006da:	f8e43423          	sd	a4,-120(s0)
    800006de:	0007b983          	ld	s3,0(a5)
  consputc('0');
    800006e2:	03000513          	li	a0,48
    800006e6:	b67ff0ef          	jal	ra,8000024c <consputc>
  consputc('x');
    800006ea:	856a                	mv	a0,s10
    800006ec:	b61ff0ef          	jal	ra,8000024c <consputc>
    800006f0:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006f2:	03c9d793          	srli	a5,s3,0x3c
    800006f6:	97de                	add	a5,a5,s7
    800006f8:	0007c503          	lbu	a0,0(a5)
    800006fc:	b51ff0ef          	jal	ra,8000024c <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    80000700:	0992                	slli	s3,s3,0x4
    80000702:	397d                	addiw	s2,s2,-1
    80000704:	fe0917e3          	bnez	s2,800006f2 <printf+0x22a>
    80000708:	b591                	j	8000054c <printf+0x84>
      consputc(va_arg(ap, uint));
    8000070a:	f8843783          	ld	a5,-120(s0)
    8000070e:	00878713          	addi	a4,a5,8
    80000712:	f8e43423          	sd	a4,-120(s0)
    80000716:	4388                	lw	a0,0(a5)
    80000718:	b35ff0ef          	jal	ra,8000024c <consputc>
    8000071c:	bd05                	j	8000054c <printf+0x84>
      if((s = va_arg(ap, char*)) == 0)
    8000071e:	f8843783          	ld	a5,-120(s0)
    80000722:	00878713          	addi	a4,a5,8
    80000726:	f8e43423          	sd	a4,-120(s0)
    8000072a:	0007b903          	ld	s2,0(a5)
    8000072e:	00090d63          	beqz	s2,80000748 <printf+0x280>
      for(; *s; s++)
    80000732:	00094503          	lbu	a0,0(s2)
    80000736:	e0050be3          	beqz	a0,8000054c <printf+0x84>
        consputc(*s);
    8000073a:	b13ff0ef          	jal	ra,8000024c <consputc>
      for(; *s; s++)
    8000073e:	0905                	addi	s2,s2,1
    80000740:	00094503          	lbu	a0,0(s2)
    80000744:	f97d                	bnez	a0,8000073a <printf+0x272>
    80000746:	b519                	j	8000054c <printf+0x84>
        s = "(null)";
    80000748:	00007917          	auipc	s2,0x7
    8000074c:	8d090913          	addi	s2,s2,-1840 # 80007018 <etext+0x18>
      for(; *s; s++)
    80000750:	02800513          	li	a0,40
    80000754:	b7dd                	j	8000073a <printf+0x272>
    }

  }
  va_end(ap);

  if(panicking == 0)
    80000756:	00007797          	auipc	a5,0x7
    8000075a:	24e7a783          	lw	a5,590(a5) # 800079a4 <panicking>
    8000075e:	c38d                	beqz	a5,80000780 <printf+0x2b8>
    release(&pr.lock);

  return 0;
}
    80000760:	4501                	li	a0,0
    80000762:	70e6                	ld	ra,120(sp)
    80000764:	7446                	ld	s0,112(sp)
    80000766:	74a6                	ld	s1,104(sp)
    80000768:	7906                	ld	s2,96(sp)
    8000076a:	69e6                	ld	s3,88(sp)
    8000076c:	6a46                	ld	s4,80(sp)
    8000076e:	6aa6                	ld	s5,72(sp)
    80000770:	6b06                	ld	s6,64(sp)
    80000772:	7be2                	ld	s7,56(sp)
    80000774:	7c42                	ld	s8,48(sp)
    80000776:	7ca2                	ld	s9,40(sp)
    80000778:	7d02                	ld	s10,32(sp)
    8000077a:	6de2                	ld	s11,24(sp)
    8000077c:	6129                	addi	sp,sp,192
    8000077e:	8082                	ret
    release(&pr.lock);
    80000780:	0000f517          	auipc	a0,0xf
    80000784:	2f850513          	addi	a0,a0,760 # 8000fa78 <pr>
    80000788:	4ca000ef          	jal	ra,80000c52 <release>
  return 0;
    8000078c:	bfd1                	j	80000760 <printf+0x298>

000000008000078e <panic>:

void
panic(char *s)
{
    8000078e:	1101                	addi	sp,sp,-32
    80000790:	ec06                	sd	ra,24(sp)
    80000792:	e822                	sd	s0,16(sp)
    80000794:	e426                	sd	s1,8(sp)
    80000796:	e04a                	sd	s2,0(sp)
    80000798:	1000                	addi	s0,sp,32
    8000079a:	892a                	mv	s2,a0
  panicking = 1;
    8000079c:	4485                	li	s1,1
    8000079e:	00007797          	auipc	a5,0x7
    800007a2:	2097a323          	sw	s1,518(a5) # 800079a4 <panicking>
  printf("panic: ");
    800007a6:	00007517          	auipc	a0,0x7
    800007aa:	87a50513          	addi	a0,a0,-1926 # 80007020 <etext+0x20>
    800007ae:	d1bff0ef          	jal	ra,800004c8 <printf>
  printf("%s\n", s);
    800007b2:	85ca                	mv	a1,s2
    800007b4:	00007517          	auipc	a0,0x7
    800007b8:	87450513          	addi	a0,a0,-1932 # 80007028 <etext+0x28>
    800007bc:	d0dff0ef          	jal	ra,800004c8 <printf>
  panicked = 1; // freeze uart output from other CPUs
    800007c0:	00007797          	auipc	a5,0x7
    800007c4:	1e97a023          	sw	s1,480(a5) # 800079a0 <panicked>
  for(;;)
    800007c8:	a001                	j	800007c8 <panic+0x3a>

00000000800007ca <printfinit>:
    ;
}

void
printfinit(void)
{
    800007ca:	1141                	addi	sp,sp,-16
    800007cc:	e406                	sd	ra,8(sp)
    800007ce:	e022                	sd	s0,0(sp)
    800007d0:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    800007d2:	00007597          	auipc	a1,0x7
    800007d6:	85e58593          	addi	a1,a1,-1954 # 80007030 <etext+0x30>
    800007da:	0000f517          	auipc	a0,0xf
    800007de:	29e50513          	addi	a0,a0,670 # 8000fa78 <pr>
    800007e2:	358000ef          	jal	ra,80000b3a <initlock>
}
    800007e6:	60a2                	ld	ra,8(sp)
    800007e8:	6402                	ld	s0,0(sp)
    800007ea:	0141                	addi	sp,sp,16
    800007ec:	8082                	ret

00000000800007ee <uartinit>:
extern volatile int panicking; // from printf.c
extern volatile int panicked; // from printf.c

void
uartinit(void)
{
    800007ee:	1141                	addi	sp,sp,-16
    800007f0:	e406                	sd	ra,8(sp)
    800007f2:	e022                	sd	s0,0(sp)
    800007f4:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    800007f6:	100007b7          	lui	a5,0x10000
    800007fa:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    800007fe:	f8000713          	li	a4,-128
    80000802:	00e781a3          	sb	a4,3(a5)

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80000806:	470d                	li	a4,3
    80000808:	00e78023          	sb	a4,0(a5)

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    8000080c:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    80000810:	00e781a3          	sb	a4,3(a5)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    80000814:	469d                	li	a3,7
    80000816:	00d78123          	sb	a3,2(a5)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    8000081a:	00e780a3          	sb	a4,1(a5)

  initlock(&tx_lock, "uart");
    8000081e:	00007597          	auipc	a1,0x7
    80000822:	83258593          	addi	a1,a1,-1998 # 80007050 <digits+0x18>
    80000826:	0000f517          	auipc	a0,0xf
    8000082a:	26a50513          	addi	a0,a0,618 # 8000fa90 <tx_lock>
    8000082e:	30c000ef          	jal	ra,80000b3a <initlock>
}
    80000832:	60a2                	ld	ra,8(sp)
    80000834:	6402                	ld	s0,0(sp)
    80000836:	0141                	addi	sp,sp,16
    80000838:	8082                	ret

000000008000083a <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    8000083a:	715d                	addi	sp,sp,-80
    8000083c:	e486                	sd	ra,72(sp)
    8000083e:	e0a2                	sd	s0,64(sp)
    80000840:	fc26                	sd	s1,56(sp)
    80000842:	f84a                	sd	s2,48(sp)
    80000844:	f44e                	sd	s3,40(sp)
    80000846:	f052                	sd	s4,32(sp)
    80000848:	ec56                	sd	s5,24(sp)
    8000084a:	e85a                	sd	s6,16(sp)
    8000084c:	e45e                	sd	s7,8(sp)
    8000084e:	0880                	addi	s0,sp,80
    80000850:	84aa                	mv	s1,a0
    80000852:	8aae                	mv	s5,a1
  acquire(&tx_lock);
    80000854:	0000f517          	auipc	a0,0xf
    80000858:	23c50513          	addi	a0,a0,572 # 8000fa90 <tx_lock>
    8000085c:	35e000ef          	jal	ra,80000bba <acquire>

  int i = 0;
  while(i < n){ 
    80000860:	05505b63          	blez	s5,800008b6 <uartwrite+0x7c>
    80000864:	8a26                	mv	s4,s1
    80000866:	0485                	addi	s1,s1,1
    80000868:	3afd                	addiw	s5,s5,-1
    8000086a:	1a82                	slli	s5,s5,0x20
    8000086c:	020ada93          	srli	s5,s5,0x20
    80000870:	9aa6                	add	s5,s5,s1
    while(tx_busy != 0){
    80000872:	00007497          	auipc	s1,0x7
    80000876:	13a48493          	addi	s1,s1,314 # 800079ac <tx_busy>
      // wait for a UART transmit-complete interrupt
      // to set tx_busy to 0.
      sleep(&tx_chan, &tx_lock);
    8000087a:	0000f997          	auipc	s3,0xf
    8000087e:	21698993          	addi	s3,s3,534 # 8000fa90 <tx_lock>
    80000882:	00007917          	auipc	s2,0x7
    80000886:	12690913          	addi	s2,s2,294 # 800079a8 <tx_chan>
    }   
      
    WriteReg(THR, buf[i]);
    8000088a:	10000bb7          	lui	s7,0x10000
    i += 1;
    tx_busy = 1;
    8000088e:	4b05                	li	s6,1
    80000890:	a005                	j	800008b0 <uartwrite+0x76>
      sleep(&tx_chan, &tx_lock);
    80000892:	85ce                	mv	a1,s3
    80000894:	854a                	mv	a0,s2
    80000896:	760010ef          	jal	ra,80001ff6 <sleep>
    while(tx_busy != 0){
    8000089a:	409c                	lw	a5,0(s1)
    8000089c:	fbfd                	bnez	a5,80000892 <uartwrite+0x58>
    WriteReg(THR, buf[i]);
    8000089e:	000a4783          	lbu	a5,0(s4)
    800008a2:	00fb8023          	sb	a5,0(s7) # 10000000 <_entry-0x70000000>
    tx_busy = 1;
    800008a6:	0164a023          	sw	s6,0(s1)
  while(i < n){ 
    800008aa:	0a05                	addi	s4,s4,1
    800008ac:	015a0563          	beq	s4,s5,800008b6 <uartwrite+0x7c>
    while(tx_busy != 0){
    800008b0:	409c                	lw	a5,0(s1)
    800008b2:	f3e5                	bnez	a5,80000892 <uartwrite+0x58>
    800008b4:	b7ed                	j	8000089e <uartwrite+0x64>
  }

  release(&tx_lock);
    800008b6:	0000f517          	auipc	a0,0xf
    800008ba:	1da50513          	addi	a0,a0,474 # 8000fa90 <tx_lock>
    800008be:	394000ef          	jal	ra,80000c52 <release>
}
    800008c2:	60a6                	ld	ra,72(sp)
    800008c4:	6406                	ld	s0,64(sp)
    800008c6:	74e2                	ld	s1,56(sp)
    800008c8:	7942                	ld	s2,48(sp)
    800008ca:	79a2                	ld	s3,40(sp)
    800008cc:	7a02                	ld	s4,32(sp)
    800008ce:	6ae2                	ld	s5,24(sp)
    800008d0:	6b42                	ld	s6,16(sp)
    800008d2:	6ba2                	ld	s7,8(sp)
    800008d4:	6161                	addi	sp,sp,80
    800008d6:	8082                	ret

00000000800008d8 <uartputc_sync>:
// interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    800008d8:	1101                	addi	sp,sp,-32
    800008da:	ec06                	sd	ra,24(sp)
    800008dc:	e822                	sd	s0,16(sp)
    800008de:	e426                	sd	s1,8(sp)
    800008e0:	1000                	addi	s0,sp,32
    800008e2:	84aa                	mv	s1,a0
  if(panicking == 0)
    800008e4:	00007797          	auipc	a5,0x7
    800008e8:	0c07a783          	lw	a5,192(a5) # 800079a4 <panicking>
    800008ec:	cb89                	beqz	a5,800008fe <uartputc_sync+0x26>
    push_off();

  if(panicked){
    800008ee:	00007797          	auipc	a5,0x7
    800008f2:	0b27a783          	lw	a5,178(a5) # 800079a0 <panicked>
    for(;;)
      ;
  }

  // wait for UART to set Transmit Holding Empty in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800008f6:	10000737          	lui	a4,0x10000
  if(panicked){
    800008fa:	c789                	beqz	a5,80000904 <uartputc_sync+0x2c>
    for(;;)
    800008fc:	a001                	j	800008fc <uartputc_sync+0x24>
    push_off();
    800008fe:	27c000ef          	jal	ra,80000b7a <push_off>
    80000902:	b7f5                	j	800008ee <uartputc_sync+0x16>
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80000904:	00574783          	lbu	a5,5(a4) # 10000005 <_entry-0x6ffffffb>
    80000908:	0ff7f793          	andi	a5,a5,255
    8000090c:	0207f793          	andi	a5,a5,32
    80000910:	dbf5                	beqz	a5,80000904 <uartputc_sync+0x2c>
    ;
  WriteReg(THR, c);
    80000912:	0ff4f793          	andi	a5,s1,255
    80000916:	10000737          	lui	a4,0x10000
    8000091a:	00f70023          	sb	a5,0(a4) # 10000000 <_entry-0x70000000>

  if(panicking == 0)
    8000091e:	00007797          	auipc	a5,0x7
    80000922:	0867a783          	lw	a5,134(a5) # 800079a4 <panicking>
    80000926:	c791                	beqz	a5,80000932 <uartputc_sync+0x5a>
    pop_off();
}
    80000928:	60e2                	ld	ra,24(sp)
    8000092a:	6442                	ld	s0,16(sp)
    8000092c:	64a2                	ld	s1,8(sp)
    8000092e:	6105                	addi	sp,sp,32
    80000930:	8082                	ret
    pop_off();
    80000932:	2cc000ef          	jal	ra,80000bfe <pop_off>
}
    80000936:	bfcd                	j	80000928 <uartputc_sync+0x50>

0000000080000938 <uartgetc>:

// try to read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    80000938:	1141                	addi	sp,sp,-16
    8000093a:	e422                	sd	s0,8(sp)
    8000093c:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & LSR_RX_READY){
    8000093e:	100007b7          	lui	a5,0x10000
    80000942:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80000946:	8b85                	andi	a5,a5,1
    80000948:	cb91                	beqz	a5,8000095c <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    8000094a:	100007b7          	lui	a5,0x10000
    8000094e:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
    80000952:	0ff57513          	andi	a0,a0,255
  } else {
    return -1;
  }
}
    80000956:	6422                	ld	s0,8(sp)
    80000958:	0141                	addi	sp,sp,16
    8000095a:	8082                	ret
    return -1;
    8000095c:	557d                	li	a0,-1
    8000095e:	bfe5                	j	80000956 <uartgetc+0x1e>

0000000080000960 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    80000960:	1101                	addi	sp,sp,-32
    80000962:	ec06                	sd	ra,24(sp)
    80000964:	e822                	sd	s0,16(sp)
    80000966:	e426                	sd	s1,8(sp)
    80000968:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    8000096a:	100004b7          	lui	s1,0x10000
    8000096e:	0024c783          	lbu	a5,2(s1) # 10000002 <_entry-0x6ffffffe>

  acquire(&tx_lock);
    80000972:	0000f517          	auipc	a0,0xf
    80000976:	11e50513          	addi	a0,a0,286 # 8000fa90 <tx_lock>
    8000097a:	240000ef          	jal	ra,80000bba <acquire>
  if(ReadReg(LSR) & LSR_TX_IDLE){
    8000097e:	0054c783          	lbu	a5,5(s1)
    80000982:	0ff7f793          	andi	a5,a5,255
    80000986:	0207f793          	andi	a5,a5,32
    8000098a:	ef99                	bnez	a5,800009a8 <uartintr+0x48>
    // UART finished transmitting; wake up sending thread.
    tx_busy = 0;
    wakeup(&tx_chan);
  }
  release(&tx_lock);
    8000098c:	0000f517          	auipc	a0,0xf
    80000990:	10450513          	addi	a0,a0,260 # 8000fa90 <tx_lock>
    80000994:	2be000ef          	jal	ra,80000c52 <release>

  // read and process incoming characters, if any.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80000998:	54fd                	li	s1,-1
    int c = uartgetc();
    8000099a:	f9fff0ef          	jal	ra,80000938 <uartgetc>
    if(c == -1)
    8000099e:	02950063          	beq	a0,s1,800009be <uartintr+0x5e>
      break;
    consoleintr(c);
    800009a2:	8ddff0ef          	jal	ra,8000027e <consoleintr>
  while(1){
    800009a6:	bfd5                	j	8000099a <uartintr+0x3a>
    tx_busy = 0;
    800009a8:	00007797          	auipc	a5,0x7
    800009ac:	0007a223          	sw	zero,4(a5) # 800079ac <tx_busy>
    wakeup(&tx_chan);
    800009b0:	00007517          	auipc	a0,0x7
    800009b4:	ff850513          	addi	a0,a0,-8 # 800079a8 <tx_chan>
    800009b8:	68a010ef          	jal	ra,80002042 <wakeup>
    800009bc:	bfc1                	j	8000098c <uartintr+0x2c>
  }
}
    800009be:	60e2                	ld	ra,24(sp)
    800009c0:	6442                	ld	s0,16(sp)
    800009c2:	64a2                	ld	s1,8(sp)
    800009c4:	6105                	addi	sp,sp,32
    800009c6:	8082                	ret

00000000800009c8 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    800009c8:	1101                	addi	sp,sp,-32
    800009ca:	ec06                	sd	ra,24(sp)
    800009cc:	e822                	sd	s0,16(sp)
    800009ce:	e426                	sd	s1,8(sp)
    800009d0:	e04a                	sd	s2,0(sp)
    800009d2:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    800009d4:	03451793          	slli	a5,a0,0x34
    800009d8:	e7a9                	bnez	a5,80000a22 <kfree+0x5a>
    800009da:	84aa                	mv	s1,a0
    800009dc:	00021797          	auipc	a5,0x21
    800009e0:	cfc78793          	addi	a5,a5,-772 # 800216d8 <end>
    800009e4:	02f56f63          	bltu	a0,a5,80000a22 <kfree+0x5a>
    800009e8:	47c5                	li	a5,17
    800009ea:	07ee                	slli	a5,a5,0x1b
    800009ec:	02f57b63          	bgeu	a0,a5,80000a22 <kfree+0x5a>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    800009f0:	6605                	lui	a2,0x1
    800009f2:	4585                	li	a1,1
    800009f4:	29a000ef          	jal	ra,80000c8e <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    800009f8:	0000f917          	auipc	s2,0xf
    800009fc:	0b090913          	addi	s2,s2,176 # 8000faa8 <kmem>
    80000a00:	854a                	mv	a0,s2
    80000a02:	1b8000ef          	jal	ra,80000bba <acquire>
  r->next = kmem.freelist;
    80000a06:	01893783          	ld	a5,24(s2)
    80000a0a:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a0c:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a10:	854a                	mv	a0,s2
    80000a12:	240000ef          	jal	ra,80000c52 <release>
}
    80000a16:	60e2                	ld	ra,24(sp)
    80000a18:	6442                	ld	s0,16(sp)
    80000a1a:	64a2                	ld	s1,8(sp)
    80000a1c:	6902                	ld	s2,0(sp)
    80000a1e:	6105                	addi	sp,sp,32
    80000a20:	8082                	ret
    panic("kfree");
    80000a22:	00006517          	auipc	a0,0x6
    80000a26:	63650513          	addi	a0,a0,1590 # 80007058 <digits+0x20>
    80000a2a:	d65ff0ef          	jal	ra,8000078e <panic>

0000000080000a2e <freerange>:
{
    80000a2e:	7179                	addi	sp,sp,-48
    80000a30:	f406                	sd	ra,40(sp)
    80000a32:	f022                	sd	s0,32(sp)
    80000a34:	ec26                	sd	s1,24(sp)
    80000a36:	e84a                	sd	s2,16(sp)
    80000a38:	e44e                	sd	s3,8(sp)
    80000a3a:	e052                	sd	s4,0(sp)
    80000a3c:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000a3e:	6785                	lui	a5,0x1
    80000a40:	fff78493          	addi	s1,a5,-1 # fff <_entry-0x7ffff001>
    80000a44:	94aa                	add	s1,s1,a0
    80000a46:	757d                	lui	a0,0xfffff
    80000a48:	8ce9                	and	s1,s1,a0
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a4a:	94be                	add	s1,s1,a5
    80000a4c:	0095ec63          	bltu	a1,s1,80000a64 <freerange+0x36>
    80000a50:	892e                	mv	s2,a1
    kfree(p);
    80000a52:	7a7d                	lui	s4,0xfffff
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a54:	6985                	lui	s3,0x1
    kfree(p);
    80000a56:	01448533          	add	a0,s1,s4
    80000a5a:	f6fff0ef          	jal	ra,800009c8 <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000a5e:	94ce                	add	s1,s1,s3
    80000a60:	fe997be3          	bgeu	s2,s1,80000a56 <freerange+0x28>
}
    80000a64:	70a2                	ld	ra,40(sp)
    80000a66:	7402                	ld	s0,32(sp)
    80000a68:	64e2                	ld	s1,24(sp)
    80000a6a:	6942                	ld	s2,16(sp)
    80000a6c:	69a2                	ld	s3,8(sp)
    80000a6e:	6a02                	ld	s4,0(sp)
    80000a70:	6145                	addi	sp,sp,48
    80000a72:	8082                	ret

0000000080000a74 <kinit>:
{
    80000a74:	1141                	addi	sp,sp,-16
    80000a76:	e406                	sd	ra,8(sp)
    80000a78:	e022                	sd	s0,0(sp)
    80000a7a:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000a7c:	00006597          	auipc	a1,0x6
    80000a80:	5e458593          	addi	a1,a1,1508 # 80007060 <digits+0x28>
    80000a84:	0000f517          	auipc	a0,0xf
    80000a88:	02450513          	addi	a0,a0,36 # 8000faa8 <kmem>
    80000a8c:	0ae000ef          	jal	ra,80000b3a <initlock>
  freerange(end, (void*)PHYSTOP);
    80000a90:	45c5                	li	a1,17
    80000a92:	05ee                	slli	a1,a1,0x1b
    80000a94:	00021517          	auipc	a0,0x21
    80000a98:	c4450513          	addi	a0,a0,-956 # 800216d8 <end>
    80000a9c:	f93ff0ef          	jal	ra,80000a2e <freerange>
}
    80000aa0:	60a2                	ld	ra,8(sp)
    80000aa2:	6402                	ld	s0,0(sp)
    80000aa4:	0141                	addi	sp,sp,16
    80000aa6:	8082                	ret

0000000080000aa8 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000aa8:	1101                	addi	sp,sp,-32
    80000aaa:	ec06                	sd	ra,24(sp)
    80000aac:	e822                	sd	s0,16(sp)
    80000aae:	e426                	sd	s1,8(sp)
    80000ab0:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000ab2:	0000f497          	auipc	s1,0xf
    80000ab6:	ff648493          	addi	s1,s1,-10 # 8000faa8 <kmem>
    80000aba:	8526                	mv	a0,s1
    80000abc:	0fe000ef          	jal	ra,80000bba <acquire>
  r = kmem.freelist;
    80000ac0:	6c84                	ld	s1,24(s1)
  if(r)
    80000ac2:	c485                	beqz	s1,80000aea <kalloc+0x42>
    kmem.freelist = r->next;
    80000ac4:	609c                	ld	a5,0(s1)
    80000ac6:	0000f517          	auipc	a0,0xf
    80000aca:	fe250513          	addi	a0,a0,-30 # 8000faa8 <kmem>
    80000ace:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000ad0:	182000ef          	jal	ra,80000c52 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000ad4:	6605                	lui	a2,0x1
    80000ad6:	4595                	li	a1,5
    80000ad8:	8526                	mv	a0,s1
    80000ada:	1b4000ef          	jal	ra,80000c8e <memset>
  return (void*)r;
}
    80000ade:	8526                	mv	a0,s1
    80000ae0:	60e2                	ld	ra,24(sp)
    80000ae2:	6442                	ld	s0,16(sp)
    80000ae4:	64a2                	ld	s1,8(sp)
    80000ae6:	6105                	addi	sp,sp,32
    80000ae8:	8082                	ret
  release(&kmem.lock);
    80000aea:	0000f517          	auipc	a0,0xf
    80000aee:	fbe50513          	addi	a0,a0,-66 # 8000faa8 <kmem>
    80000af2:	160000ef          	jal	ra,80000c52 <release>
  if(r)
    80000af6:	b7e5                	j	80000ade <kalloc+0x36>

0000000080000af8 <meminfo>:
*/
// Returns the amount of free memory in bytes
// by counting free pages in kmem.freelist and multiplying by PGSIZE.
uint64
meminfo(void)
{
    80000af8:	1101                	addi	sp,sp,-32
    80000afa:	ec06                	sd	ra,24(sp)
    80000afc:	e822                	sd	s0,16(sp)
    80000afe:	e426                	sd	s1,8(sp)
    80000b00:	1000                	addi	s0,sp,32
  struct run *r;
  uint64 count = 0;

  acquire(&kmem.lock);
    80000b02:	0000f497          	auipc	s1,0xf
    80000b06:	fa648493          	addi	s1,s1,-90 # 8000faa8 <kmem>
    80000b0a:	8526                	mv	a0,s1
    80000b0c:	0ae000ef          	jal	ra,80000bba <acquire>
  r = kmem.freelist;
    80000b10:	6c9c                	ld	a5,24(s1)
  while(r) {
    80000b12:	c395                	beqz	a5,80000b36 <meminfo+0x3e>
  uint64 count = 0;
    80000b14:	4481                	li	s1,0
    count++;
    80000b16:	0485                	addi	s1,s1,1
    r = r->next;
    80000b18:	639c                	ld	a5,0(a5)
  while(r) {
    80000b1a:	fff5                	bnez	a5,80000b16 <meminfo+0x1e>
  }
  release(&kmem.lock);
    80000b1c:	0000f517          	auipc	a0,0xf
    80000b20:	f8c50513          	addi	a0,a0,-116 # 8000faa8 <kmem>
    80000b24:	12e000ef          	jal	ra,80000c52 <release>

  return count * PGSIZE;
}
    80000b28:	00c49513          	slli	a0,s1,0xc
    80000b2c:	60e2                	ld	ra,24(sp)
    80000b2e:	6442                	ld	s0,16(sp)
    80000b30:	64a2                	ld	s1,8(sp)
    80000b32:	6105                	addi	sp,sp,32
    80000b34:	8082                	ret
  uint64 count = 0;
    80000b36:	4481                	li	s1,0
    80000b38:	b7d5                	j	80000b1c <meminfo+0x24>

0000000080000b3a <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b3a:	1141                	addi	sp,sp,-16
    80000b3c:	e422                	sd	s0,8(sp)
    80000b3e:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b40:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b42:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b46:	00053823          	sd	zero,16(a0)
}
    80000b4a:	6422                	ld	s0,8(sp)
    80000b4c:	0141                	addi	sp,sp,16
    80000b4e:	8082                	ret

0000000080000b50 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000b50:	411c                	lw	a5,0(a0)
    80000b52:	e399                	bnez	a5,80000b58 <holding+0x8>
    80000b54:	4501                	li	a0,0
  return r;
}
    80000b56:	8082                	ret
{
    80000b58:	1101                	addi	sp,sp,-32
    80000b5a:	ec06                	sd	ra,24(sp)
    80000b5c:	e822                	sd	s0,16(sp)
    80000b5e:	e426                	sd	s1,8(sp)
    80000b60:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000b62:	6904                	ld	s1,16(a0)
    80000b64:	4db000ef          	jal	ra,8000183e <mycpu>
    80000b68:	40a48533          	sub	a0,s1,a0
    80000b6c:	00153513          	seqz	a0,a0
}
    80000b70:	60e2                	ld	ra,24(sp)
    80000b72:	6442                	ld	s0,16(sp)
    80000b74:	64a2                	ld	s1,8(sp)
    80000b76:	6105                	addi	sp,sp,32
    80000b78:	8082                	ret

0000000080000b7a <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000b7a:	1101                	addi	sp,sp,-32
    80000b7c:	ec06                	sd	ra,24(sp)
    80000b7e:	e822                	sd	s0,16(sp)
    80000b80:	e426                	sd	s1,8(sp)
    80000b82:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000b84:	100024f3          	csrr	s1,sstatus
    80000b88:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000b8c:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000b8e:	10079073          	csrw	sstatus,a5

  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  intr_off();

  if(mycpu()->noff == 0)
    80000b92:	4ad000ef          	jal	ra,8000183e <mycpu>
    80000b96:	5d3c                	lw	a5,120(a0)
    80000b98:	cb99                	beqz	a5,80000bae <push_off+0x34>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000b9a:	4a5000ef          	jal	ra,8000183e <mycpu>
    80000b9e:	5d3c                	lw	a5,120(a0)
    80000ba0:	2785                	addiw	a5,a5,1
    80000ba2:	dd3c                	sw	a5,120(a0)
}
    80000ba4:	60e2                	ld	ra,24(sp)
    80000ba6:	6442                	ld	s0,16(sp)
    80000ba8:	64a2                	ld	s1,8(sp)
    80000baa:	6105                	addi	sp,sp,32
    80000bac:	8082                	ret
    mycpu()->intena = old;
    80000bae:	491000ef          	jal	ra,8000183e <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000bb2:	8085                	srli	s1,s1,0x1
    80000bb4:	8885                	andi	s1,s1,1
    80000bb6:	dd64                	sw	s1,124(a0)
    80000bb8:	b7cd                	j	80000b9a <push_off+0x20>

0000000080000bba <acquire>:
{
    80000bba:	1101                	addi	sp,sp,-32
    80000bbc:	ec06                	sd	ra,24(sp)
    80000bbe:	e822                	sd	s0,16(sp)
    80000bc0:	e426                	sd	s1,8(sp)
    80000bc2:	1000                	addi	s0,sp,32
    80000bc4:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000bc6:	fb5ff0ef          	jal	ra,80000b7a <push_off>
  if(holding(lk))
    80000bca:	8526                	mv	a0,s1
    80000bcc:	f85ff0ef          	jal	ra,80000b50 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000bd0:	4705                	li	a4,1
  if(holding(lk))
    80000bd2:	e105                	bnez	a0,80000bf2 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000bd4:	87ba                	mv	a5,a4
    80000bd6:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000bda:	2781                	sext.w	a5,a5
    80000bdc:	ffe5                	bnez	a5,80000bd4 <acquire+0x1a>
  __sync_synchronize();
    80000bde:	0ff0000f          	fence
  lk->cpu = mycpu();
    80000be2:	45d000ef          	jal	ra,8000183e <mycpu>
    80000be6:	e888                	sd	a0,16(s1)
}
    80000be8:	60e2                	ld	ra,24(sp)
    80000bea:	6442                	ld	s0,16(sp)
    80000bec:	64a2                	ld	s1,8(sp)
    80000bee:	6105                	addi	sp,sp,32
    80000bf0:	8082                	ret
    panic("acquire");
    80000bf2:	00006517          	auipc	a0,0x6
    80000bf6:	47650513          	addi	a0,a0,1142 # 80007068 <digits+0x30>
    80000bfa:	b95ff0ef          	jal	ra,8000078e <panic>

0000000080000bfe <pop_off>:

void
pop_off(void)
{
    80000bfe:	1141                	addi	sp,sp,-16
    80000c00:	e406                	sd	ra,8(sp)
    80000c02:	e022                	sd	s0,0(sp)
    80000c04:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c06:	439000ef          	jal	ra,8000183e <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c0a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c0e:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000c10:	e78d                	bnez	a5,80000c3a <pop_off+0x3c>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000c12:	5d3c                	lw	a5,120(a0)
    80000c14:	02f05963          	blez	a5,80000c46 <pop_off+0x48>
    panic("pop_off");
  c->noff -= 1;
    80000c18:	37fd                	addiw	a5,a5,-1
    80000c1a:	0007871b          	sext.w	a4,a5
    80000c1e:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000c20:	eb09                	bnez	a4,80000c32 <pop_off+0x34>
    80000c22:	5d7c                	lw	a5,124(a0)
    80000c24:	c799                	beqz	a5,80000c32 <pop_off+0x34>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c26:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000c2a:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c2e:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000c32:	60a2                	ld	ra,8(sp)
    80000c34:	6402                	ld	s0,0(sp)
    80000c36:	0141                	addi	sp,sp,16
    80000c38:	8082                	ret
    panic("pop_off - interruptible");
    80000c3a:	00006517          	auipc	a0,0x6
    80000c3e:	43650513          	addi	a0,a0,1078 # 80007070 <digits+0x38>
    80000c42:	b4dff0ef          	jal	ra,8000078e <panic>
    panic("pop_off");
    80000c46:	00006517          	auipc	a0,0x6
    80000c4a:	44250513          	addi	a0,a0,1090 # 80007088 <digits+0x50>
    80000c4e:	b41ff0ef          	jal	ra,8000078e <panic>

0000000080000c52 <release>:
{
    80000c52:	1101                	addi	sp,sp,-32
    80000c54:	ec06                	sd	ra,24(sp)
    80000c56:	e822                	sd	s0,16(sp)
    80000c58:	e426                	sd	s1,8(sp)
    80000c5a:	1000                	addi	s0,sp,32
    80000c5c:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000c5e:	ef3ff0ef          	jal	ra,80000b50 <holding>
    80000c62:	c105                	beqz	a0,80000c82 <release+0x30>
  lk->cpu = 0;
    80000c64:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000c68:	0ff0000f          	fence
  __sync_lock_release(&lk->locked);
    80000c6c:	0f50000f          	fence	iorw,ow
    80000c70:	0804a02f          	amoswap.w	zero,zero,(s1)
  pop_off();
    80000c74:	f8bff0ef          	jal	ra,80000bfe <pop_off>
}
    80000c78:	60e2                	ld	ra,24(sp)
    80000c7a:	6442                	ld	s0,16(sp)
    80000c7c:	64a2                	ld	s1,8(sp)
    80000c7e:	6105                	addi	sp,sp,32
    80000c80:	8082                	ret
    panic("release");
    80000c82:	00006517          	auipc	a0,0x6
    80000c86:	40e50513          	addi	a0,a0,1038 # 80007090 <digits+0x58>
    80000c8a:	b05ff0ef          	jal	ra,8000078e <panic>

0000000080000c8e <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000c8e:	1141                	addi	sp,sp,-16
    80000c90:	e422                	sd	s0,8(sp)
    80000c92:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000c94:	ce09                	beqz	a2,80000cae <memset+0x20>
    80000c96:	87aa                	mv	a5,a0
    80000c98:	fff6071b          	addiw	a4,a2,-1
    80000c9c:	1702                	slli	a4,a4,0x20
    80000c9e:	9301                	srli	a4,a4,0x20
    80000ca0:	0705                	addi	a4,a4,1
    80000ca2:	972a                	add	a4,a4,a0
    cdst[i] = c;
    80000ca4:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000ca8:	0785                	addi	a5,a5,1
    80000caa:	fee79de3          	bne	a5,a4,80000ca4 <memset+0x16>
  }
  return dst;
}
    80000cae:	6422                	ld	s0,8(sp)
    80000cb0:	0141                	addi	sp,sp,16
    80000cb2:	8082                	ret

0000000080000cb4 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000cb4:	1141                	addi	sp,sp,-16
    80000cb6:	e422                	sd	s0,8(sp)
    80000cb8:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000cba:	ca05                	beqz	a2,80000cea <memcmp+0x36>
    80000cbc:	fff6069b          	addiw	a3,a2,-1
    80000cc0:	1682                	slli	a3,a3,0x20
    80000cc2:	9281                	srli	a3,a3,0x20
    80000cc4:	0685                	addi	a3,a3,1
    80000cc6:	96aa                	add	a3,a3,a0
    if(*s1 != *s2)
    80000cc8:	00054783          	lbu	a5,0(a0)
    80000ccc:	0005c703          	lbu	a4,0(a1)
    80000cd0:	00e79863          	bne	a5,a4,80000ce0 <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000cd4:	0505                	addi	a0,a0,1
    80000cd6:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000cd8:	fed518e3          	bne	a0,a3,80000cc8 <memcmp+0x14>
  }

  return 0;
    80000cdc:	4501                	li	a0,0
    80000cde:	a019                	j	80000ce4 <memcmp+0x30>
      return *s1 - *s2;
    80000ce0:	40e7853b          	subw	a0,a5,a4
}
    80000ce4:	6422                	ld	s0,8(sp)
    80000ce6:	0141                	addi	sp,sp,16
    80000ce8:	8082                	ret
  return 0;
    80000cea:	4501                	li	a0,0
    80000cec:	bfe5                	j	80000ce4 <memcmp+0x30>

0000000080000cee <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000cee:	1141                	addi	sp,sp,-16
    80000cf0:	e422                	sd	s0,8(sp)
    80000cf2:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000cf4:	ca0d                	beqz	a2,80000d26 <memmove+0x38>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000cf6:	00a5f963          	bgeu	a1,a0,80000d08 <memmove+0x1a>
    80000cfa:	02061693          	slli	a3,a2,0x20
    80000cfe:	9281                	srli	a3,a3,0x20
    80000d00:	00d58733          	add	a4,a1,a3
    80000d04:	02e56463          	bltu	a0,a4,80000d2c <memmove+0x3e>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000d08:	fff6079b          	addiw	a5,a2,-1
    80000d0c:	1782                	slli	a5,a5,0x20
    80000d0e:	9381                	srli	a5,a5,0x20
    80000d10:	0785                	addi	a5,a5,1
    80000d12:	97ae                	add	a5,a5,a1
    80000d14:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d16:	0585                	addi	a1,a1,1
    80000d18:	0705                	addi	a4,a4,1
    80000d1a:	fff5c683          	lbu	a3,-1(a1)
    80000d1e:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000d22:	fef59ae3          	bne	a1,a5,80000d16 <memmove+0x28>

  return dst;
}
    80000d26:	6422                	ld	s0,8(sp)
    80000d28:	0141                	addi	sp,sp,16
    80000d2a:	8082                	ret
    d += n;
    80000d2c:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000d2e:	fff6079b          	addiw	a5,a2,-1
    80000d32:	1782                	slli	a5,a5,0x20
    80000d34:	9381                	srli	a5,a5,0x20
    80000d36:	fff7c793          	not	a5,a5
    80000d3a:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000d3c:	177d                	addi	a4,a4,-1
    80000d3e:	16fd                	addi	a3,a3,-1
    80000d40:	00074603          	lbu	a2,0(a4)
    80000d44:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000d48:	fef71ae3          	bne	a4,a5,80000d3c <memmove+0x4e>
    80000d4c:	bfe9                	j	80000d26 <memmove+0x38>

0000000080000d4e <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000d4e:	1141                	addi	sp,sp,-16
    80000d50:	e406                	sd	ra,8(sp)
    80000d52:	e022                	sd	s0,0(sp)
    80000d54:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000d56:	f99ff0ef          	jal	ra,80000cee <memmove>
}
    80000d5a:	60a2                	ld	ra,8(sp)
    80000d5c:	6402                	ld	s0,0(sp)
    80000d5e:	0141                	addi	sp,sp,16
    80000d60:	8082                	ret

0000000080000d62 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000d62:	1141                	addi	sp,sp,-16
    80000d64:	e422                	sd	s0,8(sp)
    80000d66:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000d68:	ce11                	beqz	a2,80000d84 <strncmp+0x22>
    80000d6a:	00054783          	lbu	a5,0(a0)
    80000d6e:	cf89                	beqz	a5,80000d88 <strncmp+0x26>
    80000d70:	0005c703          	lbu	a4,0(a1)
    80000d74:	00f71a63          	bne	a4,a5,80000d88 <strncmp+0x26>
    n--, p++, q++;
    80000d78:	367d                	addiw	a2,a2,-1
    80000d7a:	0505                	addi	a0,a0,1
    80000d7c:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000d7e:	f675                	bnez	a2,80000d6a <strncmp+0x8>
  if(n == 0)
    return 0;
    80000d80:	4501                	li	a0,0
    80000d82:	a809                	j	80000d94 <strncmp+0x32>
    80000d84:	4501                	li	a0,0
    80000d86:	a039                	j	80000d94 <strncmp+0x32>
  if(n == 0)
    80000d88:	ca09                	beqz	a2,80000d9a <strncmp+0x38>
  return (uchar)*p - (uchar)*q;
    80000d8a:	00054503          	lbu	a0,0(a0)
    80000d8e:	0005c783          	lbu	a5,0(a1)
    80000d92:	9d1d                	subw	a0,a0,a5
}
    80000d94:	6422                	ld	s0,8(sp)
    80000d96:	0141                	addi	sp,sp,16
    80000d98:	8082                	ret
    return 0;
    80000d9a:	4501                	li	a0,0
    80000d9c:	bfe5                	j	80000d94 <strncmp+0x32>

0000000080000d9e <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000d9e:	1141                	addi	sp,sp,-16
    80000da0:	e422                	sd	s0,8(sp)
    80000da2:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000da4:	872a                	mv	a4,a0
    80000da6:	8832                	mv	a6,a2
    80000da8:	367d                	addiw	a2,a2,-1
    80000daa:	01005963          	blez	a6,80000dbc <strncpy+0x1e>
    80000dae:	0705                	addi	a4,a4,1
    80000db0:	0005c783          	lbu	a5,0(a1)
    80000db4:	fef70fa3          	sb	a5,-1(a4)
    80000db8:	0585                	addi	a1,a1,1
    80000dba:	f7f5                	bnez	a5,80000da6 <strncpy+0x8>
    ;
  while(n-- > 0)
    80000dbc:	00c05d63          	blez	a2,80000dd6 <strncpy+0x38>
    80000dc0:	86ba                	mv	a3,a4
    *s++ = 0;
    80000dc2:	0685                	addi	a3,a3,1
    80000dc4:	fe068fa3          	sb	zero,-1(a3)
  while(n-- > 0)
    80000dc8:	fff6c793          	not	a5,a3
    80000dcc:	9fb9                	addw	a5,a5,a4
    80000dce:	010787bb          	addw	a5,a5,a6
    80000dd2:	fef048e3          	bgtz	a5,80000dc2 <strncpy+0x24>
  return os;
}
    80000dd6:	6422                	ld	s0,8(sp)
    80000dd8:	0141                	addi	sp,sp,16
    80000dda:	8082                	ret

0000000080000ddc <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000ddc:	1141                	addi	sp,sp,-16
    80000dde:	e422                	sd	s0,8(sp)
    80000de0:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000de2:	02c05363          	blez	a2,80000e08 <safestrcpy+0x2c>
    80000de6:	fff6069b          	addiw	a3,a2,-1
    80000dea:	1682                	slli	a3,a3,0x20
    80000dec:	9281                	srli	a3,a3,0x20
    80000dee:	96ae                	add	a3,a3,a1
    80000df0:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000df2:	00d58963          	beq	a1,a3,80000e04 <safestrcpy+0x28>
    80000df6:	0585                	addi	a1,a1,1
    80000df8:	0785                	addi	a5,a5,1
    80000dfa:	fff5c703          	lbu	a4,-1(a1)
    80000dfe:	fee78fa3          	sb	a4,-1(a5)
    80000e02:	fb65                	bnez	a4,80000df2 <safestrcpy+0x16>
    ;
  *s = 0;
    80000e04:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e08:	6422                	ld	s0,8(sp)
    80000e0a:	0141                	addi	sp,sp,16
    80000e0c:	8082                	ret

0000000080000e0e <strlen>:

int
strlen(const char *s)
{
    80000e0e:	1141                	addi	sp,sp,-16
    80000e10:	e422                	sd	s0,8(sp)
    80000e12:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000e14:	00054783          	lbu	a5,0(a0)
    80000e18:	cf91                	beqz	a5,80000e34 <strlen+0x26>
    80000e1a:	0505                	addi	a0,a0,1
    80000e1c:	87aa                	mv	a5,a0
    80000e1e:	4685                	li	a3,1
    80000e20:	9e89                	subw	a3,a3,a0
    80000e22:	00f6853b          	addw	a0,a3,a5
    80000e26:	0785                	addi	a5,a5,1
    80000e28:	fff7c703          	lbu	a4,-1(a5)
    80000e2c:	fb7d                	bnez	a4,80000e22 <strlen+0x14>
    ;
  return n;
}
    80000e2e:	6422                	ld	s0,8(sp)
    80000e30:	0141                	addi	sp,sp,16
    80000e32:	8082                	ret
  for(n = 0; s[n]; n++)
    80000e34:	4501                	li	a0,0
    80000e36:	bfe5                	j	80000e2e <strlen+0x20>

0000000080000e38 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000e38:	1141                	addi	sp,sp,-16
    80000e3a:	e406                	sd	ra,8(sp)
    80000e3c:	e022                	sd	s0,0(sp)
    80000e3e:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000e40:	1ef000ef          	jal	ra,8000182e <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000e44:	00007717          	auipc	a4,0x7
    80000e48:	b6c70713          	addi	a4,a4,-1172 # 800079b0 <started>
  if(cpuid() == 0){
    80000e4c:	c51d                	beqz	a0,80000e7a <main+0x42>
    while(started == 0)
    80000e4e:	431c                	lw	a5,0(a4)
    80000e50:	2781                	sext.w	a5,a5
    80000e52:	dff5                	beqz	a5,80000e4e <main+0x16>
      ;
    __sync_synchronize();
    80000e54:	0ff0000f          	fence
    printf("hart %d starting\n", cpuid());
    80000e58:	1d7000ef          	jal	ra,8000182e <cpuid>
    80000e5c:	85aa                	mv	a1,a0
    80000e5e:	00006517          	auipc	a0,0x6
    80000e62:	25250513          	addi	a0,a0,594 # 800070b0 <digits+0x78>
    80000e66:	e62ff0ef          	jal	ra,800004c8 <printf>
    kvminithart();    // turn on paging
    80000e6a:	080000ef          	jal	ra,80000eea <kvminithart>
    trapinithart();   // install kernel trap vector
    80000e6e:	1e1010ef          	jal	ra,8000284e <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000e72:	1c3040ef          	jal	ra,80005834 <plicinithart>
  }

  scheduler();        
    80000e76:	69f000ef          	jal	ra,80001d14 <scheduler>
    consoleinit();
    80000e7a:	d76ff0ef          	jal	ra,800003f0 <consoleinit>
    printfinit();
    80000e7e:	94dff0ef          	jal	ra,800007ca <printfinit>
    printf("\n");
    80000e82:	00006517          	auipc	a0,0x6
    80000e86:	23e50513          	addi	a0,a0,574 # 800070c0 <digits+0x88>
    80000e8a:	e3eff0ef          	jal	ra,800004c8 <printf>
    printf("xv6 kernel is booting\n");
    80000e8e:	00006517          	auipc	a0,0x6
    80000e92:	20a50513          	addi	a0,a0,522 # 80007098 <digits+0x60>
    80000e96:	e32ff0ef          	jal	ra,800004c8 <printf>
    printf("\n");
    80000e9a:	00006517          	auipc	a0,0x6
    80000e9e:	22650513          	addi	a0,a0,550 # 800070c0 <digits+0x88>
    80000ea2:	e26ff0ef          	jal	ra,800004c8 <printf>
    kinit();         // physical page allocator
    80000ea6:	bcfff0ef          	jal	ra,80000a74 <kinit>
    kvminit();       // create kernel page table
    80000eaa:	2ca000ef          	jal	ra,80001174 <kvminit>
    kvminithart();   // turn on paging
    80000eae:	03c000ef          	jal	ra,80000eea <kvminithart>
    procinit();      // process table
    80000eb2:	0d5000ef          	jal	ra,80001786 <procinit>
    trapinit();      // trap vectors
    80000eb6:	175010ef          	jal	ra,8000282a <trapinit>
    trapinithart();  // install kernel trap vector
    80000eba:	195010ef          	jal	ra,8000284e <trapinithart>
    plicinit();      // set up interrupt controller
    80000ebe:	161040ef          	jal	ra,8000581e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000ec2:	173040ef          	jal	ra,80005834 <plicinithart>
    binit();         // buffer cache
    80000ec6:	11a020ef          	jal	ra,80002fe0 <binit>
    iinit();         // inode table
    80000eca:	68e020ef          	jal	ra,80003558 <iinit>
    fileinit();      // file table
    80000ece:	56e030ef          	jal	ra,8000443c <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000ed2:	253040ef          	jal	ra,80005924 <virtio_disk_init>
    userinit();      // first user process
    80000ed6:	467000ef          	jal	ra,80001b3c <userinit>
    __sync_synchronize();
    80000eda:	0ff0000f          	fence
    started = 1;
    80000ede:	4785                	li	a5,1
    80000ee0:	00007717          	auipc	a4,0x7
    80000ee4:	acf72823          	sw	a5,-1328(a4) # 800079b0 <started>
    80000ee8:	b779                	j	80000e76 <main+0x3e>

0000000080000eea <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000eea:	1141                	addi	sp,sp,-16
    80000eec:	e422                	sd	s0,8(sp)
    80000eee:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000ef0:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000ef4:	00007797          	auipc	a5,0x7
    80000ef8:	ac47b783          	ld	a5,-1340(a5) # 800079b8 <kernel_pagetable>
    80000efc:	83b1                	srli	a5,a5,0xc
    80000efe:	577d                	li	a4,-1
    80000f00:	177e                	slli	a4,a4,0x3f
    80000f02:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000f04:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000f08:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000f0c:	6422                	ld	s0,8(sp)
    80000f0e:	0141                	addi	sp,sp,16
    80000f10:	8082                	ret

0000000080000f12 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000f12:	7139                	addi	sp,sp,-64
    80000f14:	fc06                	sd	ra,56(sp)
    80000f16:	f822                	sd	s0,48(sp)
    80000f18:	f426                	sd	s1,40(sp)
    80000f1a:	f04a                	sd	s2,32(sp)
    80000f1c:	ec4e                	sd	s3,24(sp)
    80000f1e:	e852                	sd	s4,16(sp)
    80000f20:	e456                	sd	s5,8(sp)
    80000f22:	e05a                	sd	s6,0(sp)
    80000f24:	0080                	addi	s0,sp,64
    80000f26:	84aa                	mv	s1,a0
    80000f28:	89ae                	mv	s3,a1
    80000f2a:	8ab2                	mv	s5,a2
  if(va >= MAXVA)
    80000f2c:	57fd                	li	a5,-1
    80000f2e:	83e9                	srli	a5,a5,0x1a
    80000f30:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000f32:	4b31                	li	s6,12
  if(va >= MAXVA)
    80000f34:	02b7fc63          	bgeu	a5,a1,80000f6c <walk+0x5a>
    panic("walk");
    80000f38:	00006517          	auipc	a0,0x6
    80000f3c:	19050513          	addi	a0,a0,400 # 800070c8 <digits+0x90>
    80000f40:	84fff0ef          	jal	ra,8000078e <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000f44:	060a8263          	beqz	s5,80000fa8 <walk+0x96>
    80000f48:	b61ff0ef          	jal	ra,80000aa8 <kalloc>
    80000f4c:	84aa                	mv	s1,a0
    80000f4e:	c139                	beqz	a0,80000f94 <walk+0x82>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000f50:	6605                	lui	a2,0x1
    80000f52:	4581                	li	a1,0
    80000f54:	d3bff0ef          	jal	ra,80000c8e <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000f58:	00c4d793          	srli	a5,s1,0xc
    80000f5c:	07aa                	slli	a5,a5,0xa
    80000f5e:	0017e793          	ori	a5,a5,1
    80000f62:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    80000f66:	3a5d                	addiw	s4,s4,-9
    80000f68:	036a0063          	beq	s4,s6,80000f88 <walk+0x76>
    pte_t *pte = &pagetable[PX(level, va)];
    80000f6c:	0149d933          	srl	s2,s3,s4
    80000f70:	1ff97913          	andi	s2,s2,511
    80000f74:	090e                	slli	s2,s2,0x3
    80000f76:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000f78:	00093483          	ld	s1,0(s2)
    80000f7c:	0014f793          	andi	a5,s1,1
    80000f80:	d3f1                	beqz	a5,80000f44 <walk+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000f82:	80a9                	srli	s1,s1,0xa
    80000f84:	04b2                	slli	s1,s1,0xc
    80000f86:	b7c5                	j	80000f66 <walk+0x54>
    }
  }
  return &pagetable[PX(0, va)];
    80000f88:	00c9d513          	srli	a0,s3,0xc
    80000f8c:	1ff57513          	andi	a0,a0,511
    80000f90:	050e                	slli	a0,a0,0x3
    80000f92:	9526                	add	a0,a0,s1
}
    80000f94:	70e2                	ld	ra,56(sp)
    80000f96:	7442                	ld	s0,48(sp)
    80000f98:	74a2                	ld	s1,40(sp)
    80000f9a:	7902                	ld	s2,32(sp)
    80000f9c:	69e2                	ld	s3,24(sp)
    80000f9e:	6a42                	ld	s4,16(sp)
    80000fa0:	6aa2                	ld	s5,8(sp)
    80000fa2:	6b02                	ld	s6,0(sp)
    80000fa4:	6121                	addi	sp,sp,64
    80000fa6:	8082                	ret
        return 0;
    80000fa8:	4501                	li	a0,0
    80000faa:	b7ed                	j	80000f94 <walk+0x82>

0000000080000fac <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    80000fac:	57fd                	li	a5,-1
    80000fae:	83e9                	srli	a5,a5,0x1a
    80000fb0:	00b7f463          	bgeu	a5,a1,80000fb8 <walkaddr+0xc>
    return 0;
    80000fb4:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000fb6:	8082                	ret
{
    80000fb8:	1141                	addi	sp,sp,-16
    80000fba:	e406                	sd	ra,8(sp)
    80000fbc:	e022                	sd	s0,0(sp)
    80000fbe:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000fc0:	4601                	li	a2,0
    80000fc2:	f51ff0ef          	jal	ra,80000f12 <walk>
  if(pte == 0)
    80000fc6:	c105                	beqz	a0,80000fe6 <walkaddr+0x3a>
  if((*pte & PTE_V) == 0)
    80000fc8:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    80000fca:	0117f693          	andi	a3,a5,17
    80000fce:	4745                	li	a4,17
    return 0;
    80000fd0:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80000fd2:	00e68663          	beq	a3,a4,80000fde <walkaddr+0x32>
}
    80000fd6:	60a2                	ld	ra,8(sp)
    80000fd8:	6402                	ld	s0,0(sp)
    80000fda:	0141                	addi	sp,sp,16
    80000fdc:	8082                	ret
  pa = PTE2PA(*pte);
    80000fde:	00a7d513          	srli	a0,a5,0xa
    80000fe2:	0532                	slli	a0,a0,0xc
  return pa;
    80000fe4:	bfcd                	j	80000fd6 <walkaddr+0x2a>
    return 0;
    80000fe6:	4501                	li	a0,0
    80000fe8:	b7fd                	j	80000fd6 <walkaddr+0x2a>

0000000080000fea <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80000fea:	715d                	addi	sp,sp,-80
    80000fec:	e486                	sd	ra,72(sp)
    80000fee:	e0a2                	sd	s0,64(sp)
    80000ff0:	fc26                	sd	s1,56(sp)
    80000ff2:	f84a                	sd	s2,48(sp)
    80000ff4:	f44e                	sd	s3,40(sp)
    80000ff6:	f052                	sd	s4,32(sp)
    80000ff8:	ec56                	sd	s5,24(sp)
    80000ffa:	e85a                	sd	s6,16(sp)
    80000ffc:	e45e                	sd	s7,8(sp)
    80000ffe:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001000:	03459793          	slli	a5,a1,0x34
    80001004:	e385                	bnez	a5,80001024 <mappages+0x3a>
    80001006:	8aaa                	mv	s5,a0
    80001008:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    8000100a:	03461793          	slli	a5,a2,0x34
    8000100e:	e38d                	bnez	a5,80001030 <mappages+0x46>
    panic("mappages: size not aligned");

  if(size == 0)
    80001010:	c615                	beqz	a2,8000103c <mappages+0x52>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    80001012:	79fd                	lui	s3,0xfffff
    80001014:	964e                	add	a2,a2,s3
    80001016:	00b609b3          	add	s3,a2,a1
  a = va;
    8000101a:	892e                	mv	s2,a1
    8000101c:	40b68a33          	sub	s4,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    80001020:	6b85                	lui	s7,0x1
    80001022:	a815                	j	80001056 <mappages+0x6c>
    panic("mappages: va not aligned");
    80001024:	00006517          	auipc	a0,0x6
    80001028:	0ac50513          	addi	a0,a0,172 # 800070d0 <digits+0x98>
    8000102c:	f62ff0ef          	jal	ra,8000078e <panic>
    panic("mappages: size not aligned");
    80001030:	00006517          	auipc	a0,0x6
    80001034:	0c050513          	addi	a0,a0,192 # 800070f0 <digits+0xb8>
    80001038:	f56ff0ef          	jal	ra,8000078e <panic>
    panic("mappages: size");
    8000103c:	00006517          	auipc	a0,0x6
    80001040:	0d450513          	addi	a0,a0,212 # 80007110 <digits+0xd8>
    80001044:	f4aff0ef          	jal	ra,8000078e <panic>
      panic("mappages: remap");
    80001048:	00006517          	auipc	a0,0x6
    8000104c:	0d850513          	addi	a0,a0,216 # 80007120 <digits+0xe8>
    80001050:	f3eff0ef          	jal	ra,8000078e <panic>
    a += PGSIZE;
    80001054:	995e                	add	s2,s2,s7
  for(;;){
    80001056:	012a04b3          	add	s1,s4,s2
    if((pte = walk(pagetable, a, 1)) == 0)
    8000105a:	4605                	li	a2,1
    8000105c:	85ca                	mv	a1,s2
    8000105e:	8556                	mv	a0,s5
    80001060:	eb3ff0ef          	jal	ra,80000f12 <walk>
    80001064:	cd19                	beqz	a0,80001082 <mappages+0x98>
    if(*pte & PTE_V)
    80001066:	611c                	ld	a5,0(a0)
    80001068:	8b85                	andi	a5,a5,1
    8000106a:	fff9                	bnez	a5,80001048 <mappages+0x5e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    8000106c:	80b1                	srli	s1,s1,0xc
    8000106e:	04aa                	slli	s1,s1,0xa
    80001070:	0164e4b3          	or	s1,s1,s6
    80001074:	0014e493          	ori	s1,s1,1
    80001078:	e104                	sd	s1,0(a0)
    if(a == last)
    8000107a:	fd391de3          	bne	s2,s3,80001054 <mappages+0x6a>
    pa += PGSIZE;
  }
  return 0;
    8000107e:	4501                	li	a0,0
    80001080:	a011                	j	80001084 <mappages+0x9a>
      return -1;
    80001082:	557d                	li	a0,-1
}
    80001084:	60a6                	ld	ra,72(sp)
    80001086:	6406                	ld	s0,64(sp)
    80001088:	74e2                	ld	s1,56(sp)
    8000108a:	7942                	ld	s2,48(sp)
    8000108c:	79a2                	ld	s3,40(sp)
    8000108e:	7a02                	ld	s4,32(sp)
    80001090:	6ae2                	ld	s5,24(sp)
    80001092:	6b42                	ld	s6,16(sp)
    80001094:	6ba2                	ld	s7,8(sp)
    80001096:	6161                	addi	sp,sp,80
    80001098:	8082                	ret

000000008000109a <kvmmap>:
{
    8000109a:	1141                	addi	sp,sp,-16
    8000109c:	e406                	sd	ra,8(sp)
    8000109e:	e022                	sd	s0,0(sp)
    800010a0:	0800                	addi	s0,sp,16
    800010a2:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    800010a4:	86b2                	mv	a3,a2
    800010a6:	863e                	mv	a2,a5
    800010a8:	f43ff0ef          	jal	ra,80000fea <mappages>
    800010ac:	e509                	bnez	a0,800010b6 <kvmmap+0x1c>
}
    800010ae:	60a2                	ld	ra,8(sp)
    800010b0:	6402                	ld	s0,0(sp)
    800010b2:	0141                	addi	sp,sp,16
    800010b4:	8082                	ret
    panic("kvmmap");
    800010b6:	00006517          	auipc	a0,0x6
    800010ba:	07a50513          	addi	a0,a0,122 # 80007130 <digits+0xf8>
    800010be:	ed0ff0ef          	jal	ra,8000078e <panic>

00000000800010c2 <kvmmake>:
{
    800010c2:	1101                	addi	sp,sp,-32
    800010c4:	ec06                	sd	ra,24(sp)
    800010c6:	e822                	sd	s0,16(sp)
    800010c8:	e426                	sd	s1,8(sp)
    800010ca:	e04a                	sd	s2,0(sp)
    800010cc:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    800010ce:	9dbff0ef          	jal	ra,80000aa8 <kalloc>
    800010d2:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    800010d4:	6605                	lui	a2,0x1
    800010d6:	4581                	li	a1,0
    800010d8:	bb7ff0ef          	jal	ra,80000c8e <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    800010dc:	4719                	li	a4,6
    800010de:	6685                	lui	a3,0x1
    800010e0:	10000637          	lui	a2,0x10000
    800010e4:	100005b7          	lui	a1,0x10000
    800010e8:	8526                	mv	a0,s1
    800010ea:	fb1ff0ef          	jal	ra,8000109a <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800010ee:	4719                	li	a4,6
    800010f0:	6685                	lui	a3,0x1
    800010f2:	10001637          	lui	a2,0x10001
    800010f6:	100015b7          	lui	a1,0x10001
    800010fa:	8526                	mv	a0,s1
    800010fc:	f9fff0ef          	jal	ra,8000109a <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    80001100:	4719                	li	a4,6
    80001102:	040006b7          	lui	a3,0x4000
    80001106:	0c000637          	lui	a2,0xc000
    8000110a:	0c0005b7          	lui	a1,0xc000
    8000110e:	8526                	mv	a0,s1
    80001110:	f8bff0ef          	jal	ra,8000109a <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    80001114:	00006917          	auipc	s2,0x6
    80001118:	eec90913          	addi	s2,s2,-276 # 80007000 <etext>
    8000111c:	4729                	li	a4,10
    8000111e:	80006697          	auipc	a3,0x80006
    80001122:	ee268693          	addi	a3,a3,-286 # 7000 <_entry-0x7fff9000>
    80001126:	4605                	li	a2,1
    80001128:	067e                	slli	a2,a2,0x1f
    8000112a:	85b2                	mv	a1,a2
    8000112c:	8526                	mv	a0,s1
    8000112e:	f6dff0ef          	jal	ra,8000109a <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    80001132:	4719                	li	a4,6
    80001134:	46c5                	li	a3,17
    80001136:	06ee                	slli	a3,a3,0x1b
    80001138:	412686b3          	sub	a3,a3,s2
    8000113c:	864a                	mv	a2,s2
    8000113e:	85ca                	mv	a1,s2
    80001140:	8526                	mv	a0,s1
    80001142:	f59ff0ef          	jal	ra,8000109a <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80001146:	4729                	li	a4,10
    80001148:	6685                	lui	a3,0x1
    8000114a:	00005617          	auipc	a2,0x5
    8000114e:	eb660613          	addi	a2,a2,-330 # 80006000 <_trampoline>
    80001152:	040005b7          	lui	a1,0x4000
    80001156:	15fd                	addi	a1,a1,-1
    80001158:	05b2                	slli	a1,a1,0xc
    8000115a:	8526                	mv	a0,s1
    8000115c:	f3fff0ef          	jal	ra,8000109a <kvmmap>
  proc_mapstacks(kpgtbl);
    80001160:	8526                	mv	a0,s1
    80001162:	59a000ef          	jal	ra,800016fc <proc_mapstacks>
}
    80001166:	8526                	mv	a0,s1
    80001168:	60e2                	ld	ra,24(sp)
    8000116a:	6442                	ld	s0,16(sp)
    8000116c:	64a2                	ld	s1,8(sp)
    8000116e:	6902                	ld	s2,0(sp)
    80001170:	6105                	addi	sp,sp,32
    80001172:	8082                	ret

0000000080001174 <kvminit>:
{
    80001174:	1141                	addi	sp,sp,-16
    80001176:	e406                	sd	ra,8(sp)
    80001178:	e022                	sd	s0,0(sp)
    8000117a:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    8000117c:	f47ff0ef          	jal	ra,800010c2 <kvmmake>
    80001180:	00007797          	auipc	a5,0x7
    80001184:	82a7bc23          	sd	a0,-1992(a5) # 800079b8 <kernel_pagetable>
}
    80001188:	60a2                	ld	ra,8(sp)
    8000118a:	6402                	ld	s0,0(sp)
    8000118c:	0141                	addi	sp,sp,16
    8000118e:	8082                	ret

0000000080001190 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001190:	1101                	addi	sp,sp,-32
    80001192:	ec06                	sd	ra,24(sp)
    80001194:	e822                	sd	s0,16(sp)
    80001196:	e426                	sd	s1,8(sp)
    80001198:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    8000119a:	90fff0ef          	jal	ra,80000aa8 <kalloc>
    8000119e:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800011a0:	c509                	beqz	a0,800011aa <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    800011a2:	6605                	lui	a2,0x1
    800011a4:	4581                	li	a1,0
    800011a6:	ae9ff0ef          	jal	ra,80000c8e <memset>
  return pagetable;
}
    800011aa:	8526                	mv	a0,s1
    800011ac:	60e2                	ld	ra,24(sp)
    800011ae:	6442                	ld	s0,16(sp)
    800011b0:	64a2                	ld	s1,8(sp)
    800011b2:	6105                	addi	sp,sp,32
    800011b4:	8082                	ret

00000000800011b6 <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    800011b6:	7139                	addi	sp,sp,-64
    800011b8:	fc06                	sd	ra,56(sp)
    800011ba:	f822                	sd	s0,48(sp)
    800011bc:	f426                	sd	s1,40(sp)
    800011be:	f04a                	sd	s2,32(sp)
    800011c0:	ec4e                	sd	s3,24(sp)
    800011c2:	e852                	sd	s4,16(sp)
    800011c4:	e456                	sd	s5,8(sp)
    800011c6:	e05a                	sd	s6,0(sp)
    800011c8:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    800011ca:	03459793          	slli	a5,a1,0x34
    800011ce:	e785                	bnez	a5,800011f6 <uvmunmap+0x40>
    800011d0:	8a2a                	mv	s4,a0
    800011d2:	892e                	mv	s2,a1
    800011d4:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800011d6:	0632                	slli	a2,a2,0xc
    800011d8:	00b609b3          	add	s3,a2,a1
    800011dc:	6b05                	lui	s6,0x1
    800011de:	0335ec63          	bltu	a1,s3,80001216 <uvmunmap+0x60>
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
  }
}
    800011e2:	70e2                	ld	ra,56(sp)
    800011e4:	7442                	ld	s0,48(sp)
    800011e6:	74a2                	ld	s1,40(sp)
    800011e8:	7902                	ld	s2,32(sp)
    800011ea:	69e2                	ld	s3,24(sp)
    800011ec:	6a42                	ld	s4,16(sp)
    800011ee:	6aa2                	ld	s5,8(sp)
    800011f0:	6b02                	ld	s6,0(sp)
    800011f2:	6121                	addi	sp,sp,64
    800011f4:	8082                	ret
    panic("uvmunmap: not aligned");
    800011f6:	00006517          	auipc	a0,0x6
    800011fa:	f4250513          	addi	a0,a0,-190 # 80007138 <digits+0x100>
    800011fe:	d90ff0ef          	jal	ra,8000078e <panic>
      uint64 pa = PTE2PA(*pte);
    80001202:	83a9                	srli	a5,a5,0xa
      kfree((void*)pa);
    80001204:	00c79513          	slli	a0,a5,0xc
    80001208:	fc0ff0ef          	jal	ra,800009c8 <kfree>
    *pte = 0;
    8000120c:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001210:	995a                	add	s2,s2,s6
    80001212:	fd3978e3          	bgeu	s2,s3,800011e2 <uvmunmap+0x2c>
    if((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    80001216:	4601                	li	a2,0
    80001218:	85ca                	mv	a1,s2
    8000121a:	8552                	mv	a0,s4
    8000121c:	cf7ff0ef          	jal	ra,80000f12 <walk>
    80001220:	84aa                	mv	s1,a0
    80001222:	d57d                	beqz	a0,80001210 <uvmunmap+0x5a>
    if((*pte & PTE_V) == 0)  // has physical page been allocated?
    80001224:	611c                	ld	a5,0(a0)
    80001226:	0017f713          	andi	a4,a5,1
    8000122a:	d37d                	beqz	a4,80001210 <uvmunmap+0x5a>
    if(do_free){
    8000122c:	fe0a80e3          	beqz	s5,8000120c <uvmunmap+0x56>
    80001230:	bfc9                	j	80001202 <uvmunmap+0x4c>

0000000080001232 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    80001232:	1101                	addi	sp,sp,-32
    80001234:	ec06                	sd	ra,24(sp)
    80001236:	e822                	sd	s0,16(sp)
    80001238:	e426                	sd	s1,8(sp)
    8000123a:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    8000123c:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    8000123e:	00b67d63          	bgeu	a2,a1,80001258 <uvmdealloc+0x26>
    80001242:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    80001244:	6785                	lui	a5,0x1
    80001246:	17fd                	addi	a5,a5,-1
    80001248:	00f60733          	add	a4,a2,a5
    8000124c:	767d                	lui	a2,0xfffff
    8000124e:	8f71                	and	a4,a4,a2
    80001250:	97ae                	add	a5,a5,a1
    80001252:	8ff1                	and	a5,a5,a2
    80001254:	00f76863          	bltu	a4,a5,80001264 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    80001258:	8526                	mv	a0,s1
    8000125a:	60e2                	ld	ra,24(sp)
    8000125c:	6442                	ld	s0,16(sp)
    8000125e:	64a2                	ld	s1,8(sp)
    80001260:	6105                	addi	sp,sp,32
    80001262:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    80001264:	8f99                	sub	a5,a5,a4
    80001266:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    80001268:	4685                	li	a3,1
    8000126a:	0007861b          	sext.w	a2,a5
    8000126e:	85ba                	mv	a1,a4
    80001270:	f47ff0ef          	jal	ra,800011b6 <uvmunmap>
    80001274:	b7d5                	j	80001258 <uvmdealloc+0x26>

0000000080001276 <uvmalloc>:
  if(newsz < oldsz)
    80001276:	08b66963          	bltu	a2,a1,80001308 <uvmalloc+0x92>
{
    8000127a:	7139                	addi	sp,sp,-64
    8000127c:	fc06                	sd	ra,56(sp)
    8000127e:	f822                	sd	s0,48(sp)
    80001280:	f426                	sd	s1,40(sp)
    80001282:	f04a                	sd	s2,32(sp)
    80001284:	ec4e                	sd	s3,24(sp)
    80001286:	e852                	sd	s4,16(sp)
    80001288:	e456                	sd	s5,8(sp)
    8000128a:	e05a                	sd	s6,0(sp)
    8000128c:	0080                	addi	s0,sp,64
    8000128e:	8aaa                	mv	s5,a0
    80001290:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80001292:	6985                	lui	s3,0x1
    80001294:	19fd                	addi	s3,s3,-1
    80001296:	95ce                	add	a1,a1,s3
    80001298:	79fd                	lui	s3,0xfffff
    8000129a:	0135f9b3          	and	s3,a1,s3
  for(a = oldsz; a < newsz; a += PGSIZE){
    8000129e:	06c9f763          	bgeu	s3,a2,8000130c <uvmalloc+0x96>
    800012a2:	894e                	mv	s2,s3
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800012a4:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800012a8:	801ff0ef          	jal	ra,80000aa8 <kalloc>
    800012ac:	84aa                	mv	s1,a0
    if(mem == 0){
    800012ae:	c11d                	beqz	a0,800012d4 <uvmalloc+0x5e>
    memset(mem, 0, PGSIZE);
    800012b0:	6605                	lui	a2,0x1
    800012b2:	4581                	li	a1,0
    800012b4:	9dbff0ef          	jal	ra,80000c8e <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800012b8:	875a                	mv	a4,s6
    800012ba:	86a6                	mv	a3,s1
    800012bc:	6605                	lui	a2,0x1
    800012be:	85ca                	mv	a1,s2
    800012c0:	8556                	mv	a0,s5
    800012c2:	d29ff0ef          	jal	ra,80000fea <mappages>
    800012c6:	e51d                	bnez	a0,800012f4 <uvmalloc+0x7e>
  for(a = oldsz; a < newsz; a += PGSIZE){
    800012c8:	6785                	lui	a5,0x1
    800012ca:	993e                	add	s2,s2,a5
    800012cc:	fd496ee3          	bltu	s2,s4,800012a8 <uvmalloc+0x32>
  return newsz;
    800012d0:	8552                	mv	a0,s4
    800012d2:	a039                	j	800012e0 <uvmalloc+0x6a>
      uvmdealloc(pagetable, a, oldsz);
    800012d4:	864e                	mv	a2,s3
    800012d6:	85ca                	mv	a1,s2
    800012d8:	8556                	mv	a0,s5
    800012da:	f59ff0ef          	jal	ra,80001232 <uvmdealloc>
      return 0;
    800012de:	4501                	li	a0,0
}
    800012e0:	70e2                	ld	ra,56(sp)
    800012e2:	7442                	ld	s0,48(sp)
    800012e4:	74a2                	ld	s1,40(sp)
    800012e6:	7902                	ld	s2,32(sp)
    800012e8:	69e2                	ld	s3,24(sp)
    800012ea:	6a42                	ld	s4,16(sp)
    800012ec:	6aa2                	ld	s5,8(sp)
    800012ee:	6b02                	ld	s6,0(sp)
    800012f0:	6121                	addi	sp,sp,64
    800012f2:	8082                	ret
      kfree(mem);
    800012f4:	8526                	mv	a0,s1
    800012f6:	ed2ff0ef          	jal	ra,800009c8 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    800012fa:	864e                	mv	a2,s3
    800012fc:	85ca                	mv	a1,s2
    800012fe:	8556                	mv	a0,s5
    80001300:	f33ff0ef          	jal	ra,80001232 <uvmdealloc>
      return 0;
    80001304:	4501                	li	a0,0
    80001306:	bfe9                	j	800012e0 <uvmalloc+0x6a>
    return oldsz;
    80001308:	852e                	mv	a0,a1
}
    8000130a:	8082                	ret
  return newsz;
    8000130c:	8532                	mv	a0,a2
    8000130e:	bfc9                	j	800012e0 <uvmalloc+0x6a>

0000000080001310 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    80001310:	7179                	addi	sp,sp,-48
    80001312:	f406                	sd	ra,40(sp)
    80001314:	f022                	sd	s0,32(sp)
    80001316:	ec26                	sd	s1,24(sp)
    80001318:	e84a                	sd	s2,16(sp)
    8000131a:	e44e                	sd	s3,8(sp)
    8000131c:	e052                	sd	s4,0(sp)
    8000131e:	1800                	addi	s0,sp,48
    80001320:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    80001322:	84aa                	mv	s1,a0
    80001324:	6905                	lui	s2,0x1
    80001326:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001328:	4985                	li	s3,1
    8000132a:	a811                	j	8000133e <freewalk+0x2e>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    8000132c:	8129                	srli	a0,a0,0xa
      freewalk((pagetable_t)child);
    8000132e:	0532                	slli	a0,a0,0xc
    80001330:	fe1ff0ef          	jal	ra,80001310 <freewalk>
      pagetable[i] = 0;
    80001334:	0004b023          	sd	zero,0(s1)
  for(int i = 0; i < 512; i++){
    80001338:	04a1                	addi	s1,s1,8
    8000133a:	01248f63          	beq	s1,s2,80001358 <freewalk+0x48>
    pte_t pte = pagetable[i];
    8000133e:	6088                	ld	a0,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001340:	00f57793          	andi	a5,a0,15
    80001344:	ff3784e3          	beq	a5,s3,8000132c <freewalk+0x1c>
    } else if(pte & PTE_V){
    80001348:	8905                	andi	a0,a0,1
    8000134a:	d57d                	beqz	a0,80001338 <freewalk+0x28>
      panic("freewalk: leaf");
    8000134c:	00006517          	auipc	a0,0x6
    80001350:	e0450513          	addi	a0,a0,-508 # 80007150 <digits+0x118>
    80001354:	c3aff0ef          	jal	ra,8000078e <panic>
    }
  }
  kfree((void*)pagetable);
    80001358:	8552                	mv	a0,s4
    8000135a:	e6eff0ef          	jal	ra,800009c8 <kfree>
}
    8000135e:	70a2                	ld	ra,40(sp)
    80001360:	7402                	ld	s0,32(sp)
    80001362:	64e2                	ld	s1,24(sp)
    80001364:	6942                	ld	s2,16(sp)
    80001366:	69a2                	ld	s3,8(sp)
    80001368:	6a02                	ld	s4,0(sp)
    8000136a:	6145                	addi	sp,sp,48
    8000136c:	8082                	ret

000000008000136e <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    8000136e:	1101                	addi	sp,sp,-32
    80001370:	ec06                	sd	ra,24(sp)
    80001372:	e822                	sd	s0,16(sp)
    80001374:	e426                	sd	s1,8(sp)
    80001376:	1000                	addi	s0,sp,32
    80001378:	84aa                	mv	s1,a0
  if(sz > 0)
    8000137a:	e989                	bnez	a1,8000138c <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    8000137c:	8526                	mv	a0,s1
    8000137e:	f93ff0ef          	jal	ra,80001310 <freewalk>
}
    80001382:	60e2                	ld	ra,24(sp)
    80001384:	6442                	ld	s0,16(sp)
    80001386:	64a2                	ld	s1,8(sp)
    80001388:	6105                	addi	sp,sp,32
    8000138a:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    8000138c:	6605                	lui	a2,0x1
    8000138e:	167d                	addi	a2,a2,-1
    80001390:	962e                	add	a2,a2,a1
    80001392:	4685                	li	a3,1
    80001394:	8231                	srli	a2,a2,0xc
    80001396:	4581                	li	a1,0
    80001398:	e1fff0ef          	jal	ra,800011b6 <uvmunmap>
    8000139c:	b7c5                	j	8000137c <uvmfree+0xe>

000000008000139e <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    8000139e:	ce49                	beqz	a2,80001438 <uvmcopy+0x9a>
{
    800013a0:	715d                	addi	sp,sp,-80
    800013a2:	e486                	sd	ra,72(sp)
    800013a4:	e0a2                	sd	s0,64(sp)
    800013a6:	fc26                	sd	s1,56(sp)
    800013a8:	f84a                	sd	s2,48(sp)
    800013aa:	f44e                	sd	s3,40(sp)
    800013ac:	f052                	sd	s4,32(sp)
    800013ae:	ec56                	sd	s5,24(sp)
    800013b0:	e85a                	sd	s6,16(sp)
    800013b2:	e45e                	sd	s7,8(sp)
    800013b4:	0880                	addi	s0,sp,80
    800013b6:	8aaa                	mv	s5,a0
    800013b8:	8b2e                	mv	s6,a1
    800013ba:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    800013bc:	4481                	li	s1,0
    800013be:	a029                	j	800013c8 <uvmcopy+0x2a>
    800013c0:	6785                	lui	a5,0x1
    800013c2:	94be                	add	s1,s1,a5
    800013c4:	0544fe63          	bgeu	s1,s4,80001420 <uvmcopy+0x82>
    if((pte = walk(old, i, 0)) == 0)
    800013c8:	4601                	li	a2,0
    800013ca:	85a6                	mv	a1,s1
    800013cc:	8556                	mv	a0,s5
    800013ce:	b45ff0ef          	jal	ra,80000f12 <walk>
    800013d2:	d57d                	beqz	a0,800013c0 <uvmcopy+0x22>
      continue;   // page table entry hasn't been allocated
    if((*pte & PTE_V) == 0)
    800013d4:	6118                	ld	a4,0(a0)
    800013d6:	00177793          	andi	a5,a4,1
    800013da:	d3fd                	beqz	a5,800013c0 <uvmcopy+0x22>
      continue;   // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    800013dc:	00a75593          	srli	a1,a4,0xa
    800013e0:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    800013e4:	3ff77913          	andi	s2,a4,1023
    if((mem = kalloc()) == 0)
    800013e8:	ec0ff0ef          	jal	ra,80000aa8 <kalloc>
    800013ec:	89aa                	mv	s3,a0
    800013ee:	c105                	beqz	a0,8000140e <uvmcopy+0x70>
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    800013f0:	6605                	lui	a2,0x1
    800013f2:	85de                	mv	a1,s7
    800013f4:	8fbff0ef          	jal	ra,80000cee <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    800013f8:	874a                	mv	a4,s2
    800013fa:	86ce                	mv	a3,s3
    800013fc:	6605                	lui	a2,0x1
    800013fe:	85a6                	mv	a1,s1
    80001400:	855a                	mv	a0,s6
    80001402:	be9ff0ef          	jal	ra,80000fea <mappages>
    80001406:	dd4d                	beqz	a0,800013c0 <uvmcopy+0x22>
      kfree(mem);
    80001408:	854e                	mv	a0,s3
    8000140a:	dbeff0ef          	jal	ra,800009c8 <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    8000140e:	4685                	li	a3,1
    80001410:	00c4d613          	srli	a2,s1,0xc
    80001414:	4581                	li	a1,0
    80001416:	855a                	mv	a0,s6
    80001418:	d9fff0ef          	jal	ra,800011b6 <uvmunmap>
  return -1;
    8000141c:	557d                	li	a0,-1
    8000141e:	a011                	j	80001422 <uvmcopy+0x84>
  return 0;
    80001420:	4501                	li	a0,0
}
    80001422:	60a6                	ld	ra,72(sp)
    80001424:	6406                	ld	s0,64(sp)
    80001426:	74e2                	ld	s1,56(sp)
    80001428:	7942                	ld	s2,48(sp)
    8000142a:	79a2                	ld	s3,40(sp)
    8000142c:	7a02                	ld	s4,32(sp)
    8000142e:	6ae2                	ld	s5,24(sp)
    80001430:	6b42                	ld	s6,16(sp)
    80001432:	6ba2                	ld	s7,8(sp)
    80001434:	6161                	addi	sp,sp,80
    80001436:	8082                	ret
  return 0;
    80001438:	4501                	li	a0,0
}
    8000143a:	8082                	ret

000000008000143c <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    8000143c:	1141                	addi	sp,sp,-16
    8000143e:	e406                	sd	ra,8(sp)
    80001440:	e022                	sd	s0,0(sp)
    80001442:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    80001444:	4601                	li	a2,0
    80001446:	acdff0ef          	jal	ra,80000f12 <walk>
  if(pte == 0)
    8000144a:	c901                	beqz	a0,8000145a <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    8000144c:	611c                	ld	a5,0(a0)
    8000144e:	9bbd                	andi	a5,a5,-17
    80001450:	e11c                	sd	a5,0(a0)
}
    80001452:	60a2                	ld	ra,8(sp)
    80001454:	6402                	ld	s0,0(sp)
    80001456:	0141                	addi	sp,sp,16
    80001458:	8082                	ret
    panic("uvmclear");
    8000145a:	00006517          	auipc	a0,0x6
    8000145e:	d0650513          	addi	a0,a0,-762 # 80007160 <digits+0x128>
    80001462:	b2cff0ef          	jal	ra,8000078e <panic>

0000000080001466 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80001466:	c2d5                	beqz	a3,8000150a <copyinstr+0xa4>
{
    80001468:	715d                	addi	sp,sp,-80
    8000146a:	e486                	sd	ra,72(sp)
    8000146c:	e0a2                	sd	s0,64(sp)
    8000146e:	fc26                	sd	s1,56(sp)
    80001470:	f84a                	sd	s2,48(sp)
    80001472:	f44e                	sd	s3,40(sp)
    80001474:	f052                	sd	s4,32(sp)
    80001476:	ec56                	sd	s5,24(sp)
    80001478:	e85a                	sd	s6,16(sp)
    8000147a:	e45e                	sd	s7,8(sp)
    8000147c:	0880                	addi	s0,sp,80
    8000147e:	8a2a                	mv	s4,a0
    80001480:	8b2e                	mv	s6,a1
    80001482:	8bb2                	mv	s7,a2
    80001484:	84b6                	mv	s1,a3
    va0 = PGROUNDDOWN(srcva);
    80001486:	7afd                	lui	s5,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80001488:	6985                	lui	s3,0x1
    8000148a:	a035                	j	800014b6 <copyinstr+0x50>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    8000148c:	00078023          	sb	zero,0(a5) # 1000 <_entry-0x7ffff000>
    80001490:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80001492:	0017b793          	seqz	a5,a5
    80001496:	40f00533          	neg	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    8000149a:	60a6                	ld	ra,72(sp)
    8000149c:	6406                	ld	s0,64(sp)
    8000149e:	74e2                	ld	s1,56(sp)
    800014a0:	7942                	ld	s2,48(sp)
    800014a2:	79a2                	ld	s3,40(sp)
    800014a4:	7a02                	ld	s4,32(sp)
    800014a6:	6ae2                	ld	s5,24(sp)
    800014a8:	6b42                	ld	s6,16(sp)
    800014aa:	6ba2                	ld	s7,8(sp)
    800014ac:	6161                	addi	sp,sp,80
    800014ae:	8082                	ret
    srcva = va0 + PGSIZE;
    800014b0:	01390bb3          	add	s7,s2,s3
  while(got_null == 0 && max > 0){
    800014b4:	c4b9                	beqz	s1,80001502 <copyinstr+0x9c>
    va0 = PGROUNDDOWN(srcva);
    800014b6:	015bf933          	and	s2,s7,s5
    pa0 = walkaddr(pagetable, va0);
    800014ba:	85ca                	mv	a1,s2
    800014bc:	8552                	mv	a0,s4
    800014be:	aefff0ef          	jal	ra,80000fac <walkaddr>
    if(pa0 == 0)
    800014c2:	c131                	beqz	a0,80001506 <copyinstr+0xa0>
    n = PGSIZE - (srcva - va0);
    800014c4:	41790833          	sub	a6,s2,s7
    800014c8:	984e                	add	a6,a6,s3
    if(n > max)
    800014ca:	0104f363          	bgeu	s1,a6,800014d0 <copyinstr+0x6a>
    800014ce:	8826                	mv	a6,s1
    char *p = (char *) (pa0 + (srcva - va0));
    800014d0:	955e                	add	a0,a0,s7
    800014d2:	41250533          	sub	a0,a0,s2
    while(n > 0){
    800014d6:	fc080de3          	beqz	a6,800014b0 <copyinstr+0x4a>
    800014da:	985a                	add	a6,a6,s6
    800014dc:	87da                	mv	a5,s6
      if(*p == '\0'){
    800014de:	41650633          	sub	a2,a0,s6
    800014e2:	14fd                	addi	s1,s1,-1
    800014e4:	9b26                	add	s6,s6,s1
    800014e6:	00f60733          	add	a4,a2,a5
    800014ea:	00074703          	lbu	a4,0(a4)
    800014ee:	df59                	beqz	a4,8000148c <copyinstr+0x26>
        *dst = *p;
    800014f0:	00e78023          	sb	a4,0(a5)
      --max;
    800014f4:	40fb04b3          	sub	s1,s6,a5
      dst++;
    800014f8:	0785                	addi	a5,a5,1
    while(n > 0){
    800014fa:	ff0796e3          	bne	a5,a6,800014e6 <copyinstr+0x80>
      dst++;
    800014fe:	8b42                	mv	s6,a6
    80001500:	bf45                	j	800014b0 <copyinstr+0x4a>
    80001502:	4781                	li	a5,0
    80001504:	b779                	j	80001492 <copyinstr+0x2c>
      return -1;
    80001506:	557d                	li	a0,-1
    80001508:	bf49                	j	8000149a <copyinstr+0x34>
  int got_null = 0;
    8000150a:	4781                	li	a5,0
  if(got_null){
    8000150c:	0017b793          	seqz	a5,a5
    80001510:	40f00533          	neg	a0,a5
}
    80001514:	8082                	ret

0000000080001516 <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    80001516:	1141                	addi	sp,sp,-16
    80001518:	e406                	sd	ra,8(sp)
    8000151a:	e022                	sd	s0,0(sp)
    8000151c:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    8000151e:	4601                	li	a2,0
    80001520:	9f3ff0ef          	jal	ra,80000f12 <walk>
  if (pte == 0) {
    80001524:	c519                	beqz	a0,80001532 <ismapped+0x1c>
    return 0;
  }
  if (*pte & PTE_V){
    80001526:	6108                	ld	a0,0(a0)
    return 0;
    80001528:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    8000152a:	60a2                	ld	ra,8(sp)
    8000152c:	6402                	ld	s0,0(sp)
    8000152e:	0141                	addi	sp,sp,16
    80001530:	8082                	ret
    return 0;
    80001532:	4501                	li	a0,0
    80001534:	bfdd                	j	8000152a <ismapped+0x14>

0000000080001536 <vmfault>:
{
    80001536:	7179                	addi	sp,sp,-48
    80001538:	f406                	sd	ra,40(sp)
    8000153a:	f022                	sd	s0,32(sp)
    8000153c:	ec26                	sd	s1,24(sp)
    8000153e:	e84a                	sd	s2,16(sp)
    80001540:	e44e                	sd	s3,8(sp)
    80001542:	e052                	sd	s4,0(sp)
    80001544:	1800                	addi	s0,sp,48
    80001546:	89aa                	mv	s3,a0
    80001548:	84ae                	mv	s1,a1
  struct proc *p = myproc();
    8000154a:	310000ef          	jal	ra,8000185a <myproc>
  if (va >= p->sz)
    8000154e:	653c                	ld	a5,72(a0)
    80001550:	00f4ec63          	bltu	s1,a5,80001568 <vmfault+0x32>
    return 0;
    80001554:	4981                	li	s3,0
}
    80001556:	854e                	mv	a0,s3
    80001558:	70a2                	ld	ra,40(sp)
    8000155a:	7402                	ld	s0,32(sp)
    8000155c:	64e2                	ld	s1,24(sp)
    8000155e:	6942                	ld	s2,16(sp)
    80001560:	69a2                	ld	s3,8(sp)
    80001562:	6a02                	ld	s4,0(sp)
    80001564:	6145                	addi	sp,sp,48
    80001566:	8082                	ret
    80001568:	892a                	mv	s2,a0
  va = PGROUNDDOWN(va);
    8000156a:	75fd                	lui	a1,0xfffff
    8000156c:	8ced                	and	s1,s1,a1
  if(ismapped(pagetable, va)) {
    8000156e:	85a6                	mv	a1,s1
    80001570:	854e                	mv	a0,s3
    80001572:	fa5ff0ef          	jal	ra,80001516 <ismapped>
    return 0;
    80001576:	4981                	li	s3,0
  if(ismapped(pagetable, va)) {
    80001578:	fd79                	bnez	a0,80001556 <vmfault+0x20>
  mem = (uint64) kalloc();
    8000157a:	d2eff0ef          	jal	ra,80000aa8 <kalloc>
    8000157e:	8a2a                	mv	s4,a0
  if(mem == 0)
    80001580:	d979                	beqz	a0,80001556 <vmfault+0x20>
  mem = (uint64) kalloc();
    80001582:	89aa                	mv	s3,a0
  memset((void *) mem, 0, PGSIZE);
    80001584:	6605                	lui	a2,0x1
    80001586:	4581                	li	a1,0
    80001588:	f06ff0ef          	jal	ra,80000c8e <memset>
  if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W|PTE_U|PTE_R) != 0) {
    8000158c:	4759                	li	a4,22
    8000158e:	86d2                	mv	a3,s4
    80001590:	6605                	lui	a2,0x1
    80001592:	85a6                	mv	a1,s1
    80001594:	05093503          	ld	a0,80(s2) # 1050 <_entry-0x7fffefb0>
    80001598:	a53ff0ef          	jal	ra,80000fea <mappages>
    8000159c:	dd4d                	beqz	a0,80001556 <vmfault+0x20>
    kfree((void *)mem);
    8000159e:	8552                	mv	a0,s4
    800015a0:	c28ff0ef          	jal	ra,800009c8 <kfree>
    return 0;
    800015a4:	4981                	li	s3,0
    800015a6:	bf45                	j	80001556 <vmfault+0x20>

00000000800015a8 <copyout>:
  while(len > 0){
    800015a8:	cec1                	beqz	a3,80001640 <copyout+0x98>
{
    800015aa:	711d                	addi	sp,sp,-96
    800015ac:	ec86                	sd	ra,88(sp)
    800015ae:	e8a2                	sd	s0,80(sp)
    800015b0:	e4a6                	sd	s1,72(sp)
    800015b2:	e0ca                	sd	s2,64(sp)
    800015b4:	fc4e                	sd	s3,56(sp)
    800015b6:	f852                	sd	s4,48(sp)
    800015b8:	f456                	sd	s5,40(sp)
    800015ba:	f05a                	sd	s6,32(sp)
    800015bc:	ec5e                	sd	s7,24(sp)
    800015be:	e862                	sd	s8,16(sp)
    800015c0:	e466                	sd	s9,8(sp)
    800015c2:	e06a                	sd	s10,0(sp)
    800015c4:	1080                	addi	s0,sp,96
    800015c6:	8c2a                	mv	s8,a0
    800015c8:	8b2e                	mv	s6,a1
    800015ca:	8bb2                	mv	s7,a2
    800015cc:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    800015ce:	74fd                	lui	s1,0xfffff
    800015d0:	8ced                	and	s1,s1,a1
    if(va0 >= MAXVA)
    800015d2:	57fd                	li	a5,-1
    800015d4:	83e9                	srli	a5,a5,0x1a
    800015d6:	0697e763          	bltu	a5,s1,80001644 <copyout+0x9c>
    800015da:	6d05                	lui	s10,0x1
    800015dc:	8cbe                	mv	s9,a5
    800015de:	a015                	j	80001602 <copyout+0x5a>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    800015e0:	409b0533          	sub	a0,s6,s1
    800015e4:	0009861b          	sext.w	a2,s3
    800015e8:	85de                	mv	a1,s7
    800015ea:	954a                	add	a0,a0,s2
    800015ec:	f02ff0ef          	jal	ra,80000cee <memmove>
    len -= n;
    800015f0:	413a0a33          	sub	s4,s4,s3
    src += n;
    800015f4:	9bce                	add	s7,s7,s3
  while(len > 0){
    800015f6:	040a0363          	beqz	s4,8000163c <copyout+0x94>
    if(va0 >= MAXVA)
    800015fa:	055ce763          	bltu	s9,s5,80001648 <copyout+0xa0>
    va0 = PGROUNDDOWN(dstva);
    800015fe:	84d6                	mv	s1,s5
    dstva = va0 + PGSIZE;
    80001600:	8b56                	mv	s6,s5
    pa0 = walkaddr(pagetable, va0);
    80001602:	85a6                	mv	a1,s1
    80001604:	8562                	mv	a0,s8
    80001606:	9a7ff0ef          	jal	ra,80000fac <walkaddr>
    8000160a:	892a                	mv	s2,a0
    if(pa0 == 0) {
    8000160c:	e901                	bnez	a0,8000161c <copyout+0x74>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    8000160e:	4601                	li	a2,0
    80001610:	85a6                	mv	a1,s1
    80001612:	8562                	mv	a0,s8
    80001614:	f23ff0ef          	jal	ra,80001536 <vmfault>
    80001618:	892a                	mv	s2,a0
    8000161a:	c90d                	beqz	a0,8000164c <copyout+0xa4>
    pte = walk(pagetable, va0, 0);
    8000161c:	4601                	li	a2,0
    8000161e:	85a6                	mv	a1,s1
    80001620:	8562                	mv	a0,s8
    80001622:	8f1ff0ef          	jal	ra,80000f12 <walk>
    if((*pte & PTE_W) == 0)
    80001626:	611c                	ld	a5,0(a0)
    80001628:	8b91                	andi	a5,a5,4
    8000162a:	c39d                	beqz	a5,80001650 <copyout+0xa8>
    n = PGSIZE - (dstva - va0);
    8000162c:	01a48ab3          	add	s5,s1,s10
    80001630:	416a89b3          	sub	s3,s5,s6
    if(n > len)
    80001634:	fb3a76e3          	bgeu	s4,s3,800015e0 <copyout+0x38>
    80001638:	89d2                	mv	s3,s4
    8000163a:	b75d                	j	800015e0 <copyout+0x38>
  return 0;
    8000163c:	4501                	li	a0,0
    8000163e:	a811                	j	80001652 <copyout+0xaa>
    80001640:	4501                	li	a0,0
}
    80001642:	8082                	ret
      return -1;
    80001644:	557d                	li	a0,-1
    80001646:	a031                	j	80001652 <copyout+0xaa>
    80001648:	557d                	li	a0,-1
    8000164a:	a021                	j	80001652 <copyout+0xaa>
        return -1;
    8000164c:	557d                	li	a0,-1
    8000164e:	a011                	j	80001652 <copyout+0xaa>
      return -1;
    80001650:	557d                	li	a0,-1
}
    80001652:	60e6                	ld	ra,88(sp)
    80001654:	6446                	ld	s0,80(sp)
    80001656:	64a6                	ld	s1,72(sp)
    80001658:	6906                	ld	s2,64(sp)
    8000165a:	79e2                	ld	s3,56(sp)
    8000165c:	7a42                	ld	s4,48(sp)
    8000165e:	7aa2                	ld	s5,40(sp)
    80001660:	7b02                	ld	s6,32(sp)
    80001662:	6be2                	ld	s7,24(sp)
    80001664:	6c42                	ld	s8,16(sp)
    80001666:	6ca2                	ld	s9,8(sp)
    80001668:	6d02                	ld	s10,0(sp)
    8000166a:	6125                	addi	sp,sp,96
    8000166c:	8082                	ret

000000008000166e <copyin>:
  while(len > 0){
    8000166e:	c6c9                	beqz	a3,800016f8 <copyin+0x8a>
{
    80001670:	715d                	addi	sp,sp,-80
    80001672:	e486                	sd	ra,72(sp)
    80001674:	e0a2                	sd	s0,64(sp)
    80001676:	fc26                	sd	s1,56(sp)
    80001678:	f84a                	sd	s2,48(sp)
    8000167a:	f44e                	sd	s3,40(sp)
    8000167c:	f052                	sd	s4,32(sp)
    8000167e:	ec56                	sd	s5,24(sp)
    80001680:	e85a                	sd	s6,16(sp)
    80001682:	e45e                	sd	s7,8(sp)
    80001684:	e062                	sd	s8,0(sp)
    80001686:	0880                	addi	s0,sp,80
    80001688:	8baa                	mv	s7,a0
    8000168a:	8aae                	mv	s5,a1
    8000168c:	8932                	mv	s2,a2
    8000168e:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(srcva);
    80001690:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    80001692:	6b05                	lui	s6,0x1
    80001694:	a035                	j	800016c0 <copyin+0x52>
    80001696:	412984b3          	sub	s1,s3,s2
    8000169a:	94da                	add	s1,s1,s6
    if(n > len)
    8000169c:	009a7363          	bgeu	s4,s1,800016a2 <copyin+0x34>
    800016a0:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    800016a2:	413905b3          	sub	a1,s2,s3
    800016a6:	0004861b          	sext.w	a2,s1
    800016aa:	95aa                	add	a1,a1,a0
    800016ac:	8556                	mv	a0,s5
    800016ae:	e40ff0ef          	jal	ra,80000cee <memmove>
    len -= n;
    800016b2:	409a0a33          	sub	s4,s4,s1
    dst += n;
    800016b6:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    800016b8:	01698933          	add	s2,s3,s6
  while(len > 0){
    800016bc:	020a0163          	beqz	s4,800016de <copyin+0x70>
    va0 = PGROUNDDOWN(srcva);
    800016c0:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    800016c4:	85ce                	mv	a1,s3
    800016c6:	855e                	mv	a0,s7
    800016c8:	8e5ff0ef          	jal	ra,80000fac <walkaddr>
    if(pa0 == 0) {
    800016cc:	f569                	bnez	a0,80001696 <copyin+0x28>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    800016ce:	4601                	li	a2,0
    800016d0:	85ce                	mv	a1,s3
    800016d2:	855e                	mv	a0,s7
    800016d4:	e63ff0ef          	jal	ra,80001536 <vmfault>
    800016d8:	fd5d                	bnez	a0,80001696 <copyin+0x28>
        return -1;
    800016da:	557d                	li	a0,-1
    800016dc:	a011                	j	800016e0 <copyin+0x72>
  return 0;
    800016de:	4501                	li	a0,0
}
    800016e0:	60a6                	ld	ra,72(sp)
    800016e2:	6406                	ld	s0,64(sp)
    800016e4:	74e2                	ld	s1,56(sp)
    800016e6:	7942                	ld	s2,48(sp)
    800016e8:	79a2                	ld	s3,40(sp)
    800016ea:	7a02                	ld	s4,32(sp)
    800016ec:	6ae2                	ld	s5,24(sp)
    800016ee:	6b42                	ld	s6,16(sp)
    800016f0:	6ba2                	ld	s7,8(sp)
    800016f2:	6c02                	ld	s8,0(sp)
    800016f4:	6161                	addi	sp,sp,80
    800016f6:	8082                	ret
  return 0;
    800016f8:	4501                	li	a0,0
}
    800016fa:	8082                	ret

00000000800016fc <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    800016fc:	7139                	addi	sp,sp,-64
    800016fe:	fc06                	sd	ra,56(sp)
    80001700:	f822                	sd	s0,48(sp)
    80001702:	f426                	sd	s1,40(sp)
    80001704:	f04a                	sd	s2,32(sp)
    80001706:	ec4e                	sd	s3,24(sp)
    80001708:	e852                	sd	s4,16(sp)
    8000170a:	e456                	sd	s5,8(sp)
    8000170c:	e05a                	sd	s6,0(sp)
    8000170e:	0080                	addi	s0,sp,64
    80001710:	89aa                	mv	s3,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    80001712:	0000e497          	auipc	s1,0xe
    80001716:	7e648493          	addi	s1,s1,2022 # 8000fef8 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    8000171a:	8b26                	mv	s6,s1
    8000171c:	00006a97          	auipc	s5,0x6
    80001720:	8e4a8a93          	addi	s5,s5,-1820 # 80007000 <etext>
    80001724:	04000937          	lui	s2,0x4000
    80001728:	197d                	addi	s2,s2,-1
    8000172a:	0932                	slli	s2,s2,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    8000172c:	00015a17          	auipc	s4,0x15
    80001730:	bcca0a13          	addi	s4,s4,-1076 # 800162f8 <tickslock>
    char *pa = kalloc();
    80001734:	b74ff0ef          	jal	ra,80000aa8 <kalloc>
    80001738:	862a                	mv	a2,a0
    if(pa == 0)
    8000173a:	c121                	beqz	a0,8000177a <proc_mapstacks+0x7e>
    uint64 va = KSTACK((int) (p - proc));
    8000173c:	416485b3          	sub	a1,s1,s6
    80001740:	8591                	srai	a1,a1,0x4
    80001742:	000ab783          	ld	a5,0(s5)
    80001746:	02f585b3          	mul	a1,a1,a5
    8000174a:	2585                	addiw	a1,a1,1
    8000174c:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80001750:	4719                	li	a4,6
    80001752:	6685                	lui	a3,0x1
    80001754:	40b905b3          	sub	a1,s2,a1
    80001758:	854e                	mv	a0,s3
    8000175a:	941ff0ef          	jal	ra,8000109a <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000175e:	19048493          	addi	s1,s1,400
    80001762:	fd4499e3          	bne	s1,s4,80001734 <proc_mapstacks+0x38>
  }
}
    80001766:	70e2                	ld	ra,56(sp)
    80001768:	7442                	ld	s0,48(sp)
    8000176a:	74a2                	ld	s1,40(sp)
    8000176c:	7902                	ld	s2,32(sp)
    8000176e:	69e2                	ld	s3,24(sp)
    80001770:	6a42                	ld	s4,16(sp)
    80001772:	6aa2                	ld	s5,8(sp)
    80001774:	6b02                	ld	s6,0(sp)
    80001776:	6121                	addi	sp,sp,64
    80001778:	8082                	ret
      panic("kalloc");
    8000177a:	00006517          	auipc	a0,0x6
    8000177e:	9f650513          	addi	a0,a0,-1546 # 80007170 <digits+0x138>
    80001782:	80cff0ef          	jal	ra,8000078e <panic>

0000000080001786 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80001786:	7139                	addi	sp,sp,-64
    80001788:	fc06                	sd	ra,56(sp)
    8000178a:	f822                	sd	s0,48(sp)
    8000178c:	f426                	sd	s1,40(sp)
    8000178e:	f04a                	sd	s2,32(sp)
    80001790:	ec4e                	sd	s3,24(sp)
    80001792:	e852                	sd	s4,16(sp)
    80001794:	e456                	sd	s5,8(sp)
    80001796:	e05a                	sd	s6,0(sp)
    80001798:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    8000179a:	00006597          	auipc	a1,0x6
    8000179e:	9de58593          	addi	a1,a1,-1570 # 80007178 <digits+0x140>
    800017a2:	0000e517          	auipc	a0,0xe
    800017a6:	32650513          	addi	a0,a0,806 # 8000fac8 <pid_lock>
    800017aa:	b90ff0ef          	jal	ra,80000b3a <initlock>
  initlock(&wait_lock, "wait_lock");
    800017ae:	00006597          	auipc	a1,0x6
    800017b2:	9d258593          	addi	a1,a1,-1582 # 80007180 <digits+0x148>
    800017b6:	0000e517          	auipc	a0,0xe
    800017ba:	32a50513          	addi	a0,a0,810 # 8000fae0 <wait_lock>
    800017be:	b7cff0ef          	jal	ra,80000b3a <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    800017c2:	0000e497          	auipc	s1,0xe
    800017c6:	73648493          	addi	s1,s1,1846 # 8000fef8 <proc>
      initlock(&p->lock, "proc");
    800017ca:	00006b17          	auipc	s6,0x6
    800017ce:	9c6b0b13          	addi	s6,s6,-1594 # 80007190 <digits+0x158>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    800017d2:	8aa6                	mv	s5,s1
    800017d4:	00006a17          	auipc	s4,0x6
    800017d8:	82ca0a13          	addi	s4,s4,-2004 # 80007000 <etext>
    800017dc:	04000937          	lui	s2,0x4000
    800017e0:	197d                	addi	s2,s2,-1
    800017e2:	0932                	slli	s2,s2,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    800017e4:	00015997          	auipc	s3,0x15
    800017e8:	b1498993          	addi	s3,s3,-1260 # 800162f8 <tickslock>
      initlock(&p->lock, "proc");
    800017ec:	85da                	mv	a1,s6
    800017ee:	8526                	mv	a0,s1
    800017f0:	b4aff0ef          	jal	ra,80000b3a <initlock>
      p->state = UNUSED;
    800017f4:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    800017f8:	415487b3          	sub	a5,s1,s5
    800017fc:	8791                	srai	a5,a5,0x4
    800017fe:	000a3703          	ld	a4,0(s4)
    80001802:	02e787b3          	mul	a5,a5,a4
    80001806:	2785                	addiw	a5,a5,1
    80001808:	00d7979b          	slliw	a5,a5,0xd
    8000180c:	40f907b3          	sub	a5,s2,a5
    80001810:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80001812:	19048493          	addi	s1,s1,400
    80001816:	fd349be3          	bne	s1,s3,800017ec <procinit+0x66>
  }
}
    8000181a:	70e2                	ld	ra,56(sp)
    8000181c:	7442                	ld	s0,48(sp)
    8000181e:	74a2                	ld	s1,40(sp)
    80001820:	7902                	ld	s2,32(sp)
    80001822:	69e2                	ld	s3,24(sp)
    80001824:	6a42                	ld	s4,16(sp)
    80001826:	6aa2                	ld	s5,8(sp)
    80001828:	6b02                	ld	s6,0(sp)
    8000182a:	6121                	addi	sp,sp,64
    8000182c:	8082                	ret

000000008000182e <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    8000182e:	1141                	addi	sp,sp,-16
    80001830:	e422                	sd	s0,8(sp)
    80001832:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80001834:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80001836:	2501                	sext.w	a0,a0
    80001838:	6422                	ld	s0,8(sp)
    8000183a:	0141                	addi	sp,sp,16
    8000183c:	8082                	ret

000000008000183e <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    8000183e:	1141                	addi	sp,sp,-16
    80001840:	e422                	sd	s0,8(sp)
    80001842:	0800                	addi	s0,sp,16
    80001844:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80001846:	2781                	sext.w	a5,a5
    80001848:	079e                	slli	a5,a5,0x7
  return c;
}
    8000184a:	0000e517          	auipc	a0,0xe
    8000184e:	2ae50513          	addi	a0,a0,686 # 8000faf8 <cpus>
    80001852:	953e                	add	a0,a0,a5
    80001854:	6422                	ld	s0,8(sp)
    80001856:	0141                	addi	sp,sp,16
    80001858:	8082                	ret

000000008000185a <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    8000185a:	1101                	addi	sp,sp,-32
    8000185c:	ec06                	sd	ra,24(sp)
    8000185e:	e822                	sd	s0,16(sp)
    80001860:	e426                	sd	s1,8(sp)
    80001862:	1000                	addi	s0,sp,32
  push_off();
    80001864:	b16ff0ef          	jal	ra,80000b7a <push_off>
    80001868:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    8000186a:	2781                	sext.w	a5,a5
    8000186c:	079e                	slli	a5,a5,0x7
    8000186e:	0000e717          	auipc	a4,0xe
    80001872:	25a70713          	addi	a4,a4,602 # 8000fac8 <pid_lock>
    80001876:	97ba                	add	a5,a5,a4
    80001878:	7b84                	ld	s1,48(a5)
  pop_off();
    8000187a:	b84ff0ef          	jal	ra,80000bfe <pop_off>
  return p;
}
    8000187e:	8526                	mv	a0,s1
    80001880:	60e2                	ld	ra,24(sp)
    80001882:	6442                	ld	s0,16(sp)
    80001884:	64a2                	ld	s1,8(sp)
    80001886:	6105                	addi	sp,sp,32
    80001888:	8082                	ret

000000008000188a <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    8000188a:	7179                	addi	sp,sp,-48
    8000188c:	f406                	sd	ra,40(sp)
    8000188e:	f022                	sd	s0,32(sp)
    80001890:	ec26                	sd	s1,24(sp)
    80001892:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    80001894:	fc7ff0ef          	jal	ra,8000185a <myproc>
    80001898:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    8000189a:	bb8ff0ef          	jal	ra,80000c52 <release>

  if (first) {
    8000189e:	00006797          	auipc	a5,0x6
    800018a2:	0f27a783          	lw	a5,242(a5) # 80007990 <first.1722>
    800018a6:	cf8d                	beqz	a5,800018e0 <forkret+0x56>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    800018a8:	4505                	li	a0,1
    800018aa:	15e020ef          	jal	ra,80003a08 <fsinit>

    first = 0;
    800018ae:	00006797          	auipc	a5,0x6
    800018b2:	0e07a123          	sw	zero,226(a5) # 80007990 <first.1722>
    // ensure other cores see first=0.
    __sync_synchronize();
    800018b6:	0ff0000f          	fence

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){ "/init", 0 });
    800018ba:	00006517          	auipc	a0,0x6
    800018be:	8de50513          	addi	a0,a0,-1826 # 80007198 <digits+0x160>
    800018c2:	fca43823          	sd	a0,-48(s0)
    800018c6:	fc043c23          	sd	zero,-40(s0)
    800018ca:	fd040593          	addi	a1,s0,-48
    800018ce:	1f0030ef          	jal	ra,80004abe <kexec>
    800018d2:	6cbc                	ld	a5,88(s1)
    800018d4:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    800018d6:	6cbc                	ld	a5,88(s1)
    800018d8:	7bb8                	ld	a4,112(a5)
    800018da:	57fd                	li	a5,-1
    800018dc:	02f70d63          	beq	a4,a5,80001916 <forkret+0x8c>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    800018e0:	787000ef          	jal	ra,80002866 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    800018e4:	68a8                	ld	a0,80(s1)
    800018e6:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    800018e8:	04000737          	lui	a4,0x4000
    800018ec:	00004797          	auipc	a5,0x4
    800018f0:	7b078793          	addi	a5,a5,1968 # 8000609c <userret>
    800018f4:	00004697          	auipc	a3,0x4
    800018f8:	70c68693          	addi	a3,a3,1804 # 80006000 <_trampoline>
    800018fc:	8f95                	sub	a5,a5,a3
    800018fe:	177d                	addi	a4,a4,-1
    80001900:	0732                	slli	a4,a4,0xc
    80001902:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001904:	577d                	li	a4,-1
    80001906:	177e                	slli	a4,a4,0x3f
    80001908:	8d59                	or	a0,a0,a4
    8000190a:	9782                	jalr	a5
}
    8000190c:	70a2                	ld	ra,40(sp)
    8000190e:	7402                	ld	s0,32(sp)
    80001910:	64e2                	ld	s1,24(sp)
    80001912:	6145                	addi	sp,sp,48
    80001914:	8082                	ret
      panic("exec");
    80001916:	00006517          	auipc	a0,0x6
    8000191a:	88a50513          	addi	a0,a0,-1910 # 800071a0 <digits+0x168>
    8000191e:	e71fe0ef          	jal	ra,8000078e <panic>

0000000080001922 <allocpid>:
{
    80001922:	1101                	addi	sp,sp,-32
    80001924:	ec06                	sd	ra,24(sp)
    80001926:	e822                	sd	s0,16(sp)
    80001928:	e426                	sd	s1,8(sp)
    8000192a:	e04a                	sd	s2,0(sp)
    8000192c:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    8000192e:	0000e917          	auipc	s2,0xe
    80001932:	19a90913          	addi	s2,s2,410 # 8000fac8 <pid_lock>
    80001936:	854a                	mv	a0,s2
    80001938:	a82ff0ef          	jal	ra,80000bba <acquire>
  pid = nextpid;
    8000193c:	00006797          	auipc	a5,0x6
    80001940:	05878793          	addi	a5,a5,88 # 80007994 <nextpid>
    80001944:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001946:	0014871b          	addiw	a4,s1,1
    8000194a:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    8000194c:	854a                	mv	a0,s2
    8000194e:	b04ff0ef          	jal	ra,80000c52 <release>
}
    80001952:	8526                	mv	a0,s1
    80001954:	60e2                	ld	ra,24(sp)
    80001956:	6442                	ld	s0,16(sp)
    80001958:	64a2                	ld	s1,8(sp)
    8000195a:	6902                	ld	s2,0(sp)
    8000195c:	6105                	addi	sp,sp,32
    8000195e:	8082                	ret

0000000080001960 <proc_pagetable>:
{
    80001960:	1101                	addi	sp,sp,-32
    80001962:	ec06                	sd	ra,24(sp)
    80001964:	e822                	sd	s0,16(sp)
    80001966:	e426                	sd	s1,8(sp)
    80001968:	e04a                	sd	s2,0(sp)
    8000196a:	1000                	addi	s0,sp,32
    8000196c:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    8000196e:	823ff0ef          	jal	ra,80001190 <uvmcreate>
    80001972:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001974:	cd05                	beqz	a0,800019ac <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80001976:	4729                	li	a4,10
    80001978:	00004697          	auipc	a3,0x4
    8000197c:	68868693          	addi	a3,a3,1672 # 80006000 <_trampoline>
    80001980:	6605                	lui	a2,0x1
    80001982:	040005b7          	lui	a1,0x4000
    80001986:	15fd                	addi	a1,a1,-1
    80001988:	05b2                	slli	a1,a1,0xc
    8000198a:	e60ff0ef          	jal	ra,80000fea <mappages>
    8000198e:	02054663          	bltz	a0,800019ba <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001992:	4719                	li	a4,6
    80001994:	05893683          	ld	a3,88(s2)
    80001998:	6605                	lui	a2,0x1
    8000199a:	020005b7          	lui	a1,0x2000
    8000199e:	15fd                	addi	a1,a1,-1
    800019a0:	05b6                	slli	a1,a1,0xd
    800019a2:	8526                	mv	a0,s1
    800019a4:	e46ff0ef          	jal	ra,80000fea <mappages>
    800019a8:	00054f63          	bltz	a0,800019c6 <proc_pagetable+0x66>
}
    800019ac:	8526                	mv	a0,s1
    800019ae:	60e2                	ld	ra,24(sp)
    800019b0:	6442                	ld	s0,16(sp)
    800019b2:	64a2                	ld	s1,8(sp)
    800019b4:	6902                	ld	s2,0(sp)
    800019b6:	6105                	addi	sp,sp,32
    800019b8:	8082                	ret
    uvmfree(pagetable, 0);
    800019ba:	4581                	li	a1,0
    800019bc:	8526                	mv	a0,s1
    800019be:	9b1ff0ef          	jal	ra,8000136e <uvmfree>
    return 0;
    800019c2:	4481                	li	s1,0
    800019c4:	b7e5                	j	800019ac <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    800019c6:	4681                	li	a3,0
    800019c8:	4605                	li	a2,1
    800019ca:	040005b7          	lui	a1,0x4000
    800019ce:	15fd                	addi	a1,a1,-1
    800019d0:	05b2                	slli	a1,a1,0xc
    800019d2:	8526                	mv	a0,s1
    800019d4:	fe2ff0ef          	jal	ra,800011b6 <uvmunmap>
    uvmfree(pagetable, 0);
    800019d8:	4581                	li	a1,0
    800019da:	8526                	mv	a0,s1
    800019dc:	993ff0ef          	jal	ra,8000136e <uvmfree>
    return 0;
    800019e0:	4481                	li	s1,0
    800019e2:	b7e9                	j	800019ac <proc_pagetable+0x4c>

00000000800019e4 <proc_freepagetable>:
{
    800019e4:	1101                	addi	sp,sp,-32
    800019e6:	ec06                	sd	ra,24(sp)
    800019e8:	e822                	sd	s0,16(sp)
    800019ea:	e426                	sd	s1,8(sp)
    800019ec:	e04a                	sd	s2,0(sp)
    800019ee:	1000                	addi	s0,sp,32
    800019f0:	84aa                	mv	s1,a0
    800019f2:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    800019f4:	4681                	li	a3,0
    800019f6:	4605                	li	a2,1
    800019f8:	040005b7          	lui	a1,0x4000
    800019fc:	15fd                	addi	a1,a1,-1
    800019fe:	05b2                	slli	a1,a1,0xc
    80001a00:	fb6ff0ef          	jal	ra,800011b6 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001a04:	4681                	li	a3,0
    80001a06:	4605                	li	a2,1
    80001a08:	020005b7          	lui	a1,0x2000
    80001a0c:	15fd                	addi	a1,a1,-1
    80001a0e:	05b6                	slli	a1,a1,0xd
    80001a10:	8526                	mv	a0,s1
    80001a12:	fa4ff0ef          	jal	ra,800011b6 <uvmunmap>
  uvmfree(pagetable, sz);
    80001a16:	85ca                	mv	a1,s2
    80001a18:	8526                	mv	a0,s1
    80001a1a:	955ff0ef          	jal	ra,8000136e <uvmfree>
}
    80001a1e:	60e2                	ld	ra,24(sp)
    80001a20:	6442                	ld	s0,16(sp)
    80001a22:	64a2                	ld	s1,8(sp)
    80001a24:	6902                	ld	s2,0(sp)
    80001a26:	6105                	addi	sp,sp,32
    80001a28:	8082                	ret

0000000080001a2a <freeproc>:
{
    80001a2a:	1101                	addi	sp,sp,-32
    80001a2c:	ec06                	sd	ra,24(sp)
    80001a2e:	e822                	sd	s0,16(sp)
    80001a30:	e426                	sd	s1,8(sp)
    80001a32:	1000                	addi	s0,sp,32
    80001a34:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001a36:	6d28                	ld	a0,88(a0)
    80001a38:	c119                	beqz	a0,80001a3e <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001a3a:	f8ffe0ef          	jal	ra,800009c8 <kfree>
  p->trapframe = 0;
    80001a3e:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001a42:	68a8                	ld	a0,80(s1)
    80001a44:	c501                	beqz	a0,80001a4c <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001a46:	64ac                	ld	a1,72(s1)
    80001a48:	f9dff0ef          	jal	ra,800019e4 <proc_freepagetable>
  p->pagetable = 0;
    80001a4c:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001a50:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001a54:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001a58:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001a5c:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001a60:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001a64:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001a68:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001a6c:	0004ac23          	sw	zero,24(s1)
}
    80001a70:	60e2                	ld	ra,24(sp)
    80001a72:	6442                	ld	s0,16(sp)
    80001a74:	64a2                	ld	s1,8(sp)
    80001a76:	6105                	addi	sp,sp,32
    80001a78:	8082                	ret

0000000080001a7a <allocproc>:
{
    80001a7a:	1101                	addi	sp,sp,-32
    80001a7c:	ec06                	sd	ra,24(sp)
    80001a7e:	e822                	sd	s0,16(sp)
    80001a80:	e426                	sd	s1,8(sp)
    80001a82:	e04a                	sd	s2,0(sp)
    80001a84:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001a86:	0000e497          	auipc	s1,0xe
    80001a8a:	47248493          	addi	s1,s1,1138 # 8000fef8 <proc>
    80001a8e:	00015917          	auipc	s2,0x15
    80001a92:	86a90913          	addi	s2,s2,-1942 # 800162f8 <tickslock>
    acquire(&p->lock);
    80001a96:	8526                	mv	a0,s1
    80001a98:	922ff0ef          	jal	ra,80000bba <acquire>
    if(p->state == UNUSED) {
    80001a9c:	4c9c                	lw	a5,24(s1)
    80001a9e:	cb91                	beqz	a5,80001ab2 <allocproc+0x38>
      release(&p->lock);
    80001aa0:	8526                	mv	a0,s1
    80001aa2:	9b0ff0ef          	jal	ra,80000c52 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001aa6:	19048493          	addi	s1,s1,400
    80001aaa:	ff2496e3          	bne	s1,s2,80001a96 <allocproc+0x1c>
  return 0;
    80001aae:	4481                	li	s1,0
    80001ab0:	a8b9                	j	80001b0e <allocproc+0x94>
  p->pid = allocpid();
    80001ab2:	e71ff0ef          	jal	ra,80001922 <allocpid>
    80001ab6:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001ab8:	4785                	li	a5,1
    80001aba:	cc9c                	sw	a5,24(s1)
  p->runtime     = 0;
    80001abc:	1604b823          	sd	zero,368(s1)
  p->vruntime    = 0;
    80001ac0:	1604bc23          	sd	zero,376(s1)
  p->vdeadline   = 0;
    80001ac4:	1804b023          	sd	zero,384(s1)
  p->timeslice   = 5;
    80001ac8:	4715                	li	a4,5
    80001aca:	18e4a423          	sw	a4,392(s1)
  p->is_eligible = 1;
    80001ace:	18f4a623          	sw	a5,396(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001ad2:	fd7fe0ef          	jal	ra,80000aa8 <kalloc>
    80001ad6:	892a                	mv	s2,a0
    80001ad8:	eca8                	sd	a0,88(s1)
    80001ada:	c129                	beqz	a0,80001b1c <allocproc+0xa2>
  p->pagetable = proc_pagetable(p);
    80001adc:	8526                	mv	a0,s1
    80001ade:	e83ff0ef          	jal	ra,80001960 <proc_pagetable>
    80001ae2:	892a                	mv	s2,a0
    80001ae4:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001ae6:	c139                	beqz	a0,80001b2c <allocproc+0xb2>
  memset(&p->context, 0, sizeof(p->context));
    80001ae8:	07000613          	li	a2,112
    80001aec:	4581                	li	a1,0
    80001aee:	06048513          	addi	a0,s1,96
    80001af2:	99cff0ef          	jal	ra,80000c8e <memset>
  p->context.ra = (uint64)forkret;
    80001af6:	00000797          	auipc	a5,0x0
    80001afa:	d9478793          	addi	a5,a5,-620 # 8000188a <forkret>
    80001afe:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001b00:	60bc                	ld	a5,64(s1)
    80001b02:	6705                	lui	a4,0x1
    80001b04:	97ba                	add	a5,a5,a4
    80001b06:	f4bc                	sd	a5,104(s1)
  p->nice = 20;
    80001b08:	47d1                	li	a5,20
    80001b0a:	16f4a423          	sw	a5,360(s1)
}
    80001b0e:	8526                	mv	a0,s1
    80001b10:	60e2                	ld	ra,24(sp)
    80001b12:	6442                	ld	s0,16(sp)
    80001b14:	64a2                	ld	s1,8(sp)
    80001b16:	6902                	ld	s2,0(sp)
    80001b18:	6105                	addi	sp,sp,32
    80001b1a:	8082                	ret
    freeproc(p);
    80001b1c:	8526                	mv	a0,s1
    80001b1e:	f0dff0ef          	jal	ra,80001a2a <freeproc>
    release(&p->lock);
    80001b22:	8526                	mv	a0,s1
    80001b24:	92eff0ef          	jal	ra,80000c52 <release>
    return 0;
    80001b28:	84ca                	mv	s1,s2
    80001b2a:	b7d5                	j	80001b0e <allocproc+0x94>
    freeproc(p);
    80001b2c:	8526                	mv	a0,s1
    80001b2e:	efdff0ef          	jal	ra,80001a2a <freeproc>
    release(&p->lock);
    80001b32:	8526                	mv	a0,s1
    80001b34:	91eff0ef          	jal	ra,80000c52 <release>
    return 0;
    80001b38:	84ca                	mv	s1,s2
    80001b3a:	bfd1                	j	80001b0e <allocproc+0x94>

0000000080001b3c <userinit>:
{
    80001b3c:	1101                	addi	sp,sp,-32
    80001b3e:	ec06                	sd	ra,24(sp)
    80001b40:	e822                	sd	s0,16(sp)
    80001b42:	e426                	sd	s1,8(sp)
    80001b44:	1000                	addi	s0,sp,32
  p = allocproc();
    80001b46:	f35ff0ef          	jal	ra,80001a7a <allocproc>
    80001b4a:	84aa                	mv	s1,a0
  initproc = p;
    80001b4c:	00006797          	auipc	a5,0x6
    80001b50:	e6a7ba23          	sd	a0,-396(a5) # 800079c0 <initproc>
  p->cwd = namei("/");
    80001b54:	00005517          	auipc	a0,0x5
    80001b58:	65450513          	addi	a0,a0,1620 # 800071a8 <digits+0x170>
    80001b5c:	3aa020ef          	jal	ra,80003f06 <namei>
    80001b60:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001b64:	478d                	li	a5,3
    80001b66:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001b68:	8526                	mv	a0,s1
    80001b6a:	8e8ff0ef          	jal	ra,80000c52 <release>
}
    80001b6e:	60e2                	ld	ra,24(sp)
    80001b70:	6442                	ld	s0,16(sp)
    80001b72:	64a2                	ld	s1,8(sp)
    80001b74:	6105                	addi	sp,sp,32
    80001b76:	8082                	ret

0000000080001b78 <growproc>:
{
    80001b78:	1101                	addi	sp,sp,-32
    80001b7a:	ec06                	sd	ra,24(sp)
    80001b7c:	e822                	sd	s0,16(sp)
    80001b7e:	e426                	sd	s1,8(sp)
    80001b80:	e04a                	sd	s2,0(sp)
    80001b82:	1000                	addi	s0,sp,32
    80001b84:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001b86:	cd5ff0ef          	jal	ra,8000185a <myproc>
    80001b8a:	892a                	mv	s2,a0
  sz = p->sz;
    80001b8c:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001b8e:	02905963          	blez	s1,80001bc0 <growproc+0x48>
    if(sz + n > TRAPFRAME) {
    80001b92:	00b48633          	add	a2,s1,a1
    80001b96:	020007b7          	lui	a5,0x2000
    80001b9a:	17fd                	addi	a5,a5,-1
    80001b9c:	07b6                	slli	a5,a5,0xd
    80001b9e:	02c7ea63          	bltu	a5,a2,80001bd2 <growproc+0x5a>
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001ba2:	4691                	li	a3,4
    80001ba4:	6928                	ld	a0,80(a0)
    80001ba6:	ed0ff0ef          	jal	ra,80001276 <uvmalloc>
    80001baa:	85aa                	mv	a1,a0
    80001bac:	c50d                	beqz	a0,80001bd6 <growproc+0x5e>
  p->sz = sz;
    80001bae:	04b93423          	sd	a1,72(s2)
  return 0;
    80001bb2:	4501                	li	a0,0
}
    80001bb4:	60e2                	ld	ra,24(sp)
    80001bb6:	6442                	ld	s0,16(sp)
    80001bb8:	64a2                	ld	s1,8(sp)
    80001bba:	6902                	ld	s2,0(sp)
    80001bbc:	6105                	addi	sp,sp,32
    80001bbe:	8082                	ret
  } else if(n < 0){
    80001bc0:	fe04d7e3          	bgez	s1,80001bae <growproc+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001bc4:	00b48633          	add	a2,s1,a1
    80001bc8:	6928                	ld	a0,80(a0)
    80001bca:	e68ff0ef          	jal	ra,80001232 <uvmdealloc>
    80001bce:	85aa                	mv	a1,a0
    80001bd0:	bff9                	j	80001bae <growproc+0x36>
      return -1;
    80001bd2:	557d                	li	a0,-1
    80001bd4:	b7c5                	j	80001bb4 <growproc+0x3c>
      return -1;
    80001bd6:	557d                	li	a0,-1
    80001bd8:	bff1                	j	80001bb4 <growproc+0x3c>

0000000080001bda <kfork>:
{
    80001bda:	7179                	addi	sp,sp,-48
    80001bdc:	f406                	sd	ra,40(sp)
    80001bde:	f022                	sd	s0,32(sp)
    80001be0:	ec26                	sd	s1,24(sp)
    80001be2:	e84a                	sd	s2,16(sp)
    80001be4:	e44e                	sd	s3,8(sp)
    80001be6:	e052                	sd	s4,0(sp)
    80001be8:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001bea:	c71ff0ef          	jal	ra,8000185a <myproc>
    80001bee:	89aa                	mv	s3,a0
  if((np = allocproc()) == 0){
    80001bf0:	e8bff0ef          	jal	ra,80001a7a <allocproc>
    80001bf4:	10050e63          	beqz	a0,80001d10 <kfork+0x136>
    80001bf8:	892a                	mv	s2,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001bfa:	0489b603          	ld	a2,72(s3)
    80001bfe:	692c                	ld	a1,80(a0)
    80001c00:	0509b503          	ld	a0,80(s3)
    80001c04:	f9aff0ef          	jal	ra,8000139e <uvmcopy>
    80001c08:	04054663          	bltz	a0,80001c54 <kfork+0x7a>
  np->sz = p->sz;
    80001c0c:	0489b783          	ld	a5,72(s3)
    80001c10:	04f93423          	sd	a5,72(s2)
  *(np->trapframe) = *(p->trapframe);
    80001c14:	0589b683          	ld	a3,88(s3)
    80001c18:	87b6                	mv	a5,a3
    80001c1a:	05893703          	ld	a4,88(s2)
    80001c1e:	12068693          	addi	a3,a3,288
    80001c22:	0007b803          	ld	a6,0(a5) # 2000000 <_entry-0x7e000000>
    80001c26:	6788                	ld	a0,8(a5)
    80001c28:	6b8c                	ld	a1,16(a5)
    80001c2a:	6f90                	ld	a2,24(a5)
    80001c2c:	01073023          	sd	a6,0(a4) # 1000 <_entry-0x7ffff000>
    80001c30:	e708                	sd	a0,8(a4)
    80001c32:	eb0c                	sd	a1,16(a4)
    80001c34:	ef10                	sd	a2,24(a4)
    80001c36:	02078793          	addi	a5,a5,32
    80001c3a:	02070713          	addi	a4,a4,32
    80001c3e:	fed792e3          	bne	a5,a3,80001c22 <kfork+0x48>
  np->trapframe->a0 = 0;
    80001c42:	05893783          	ld	a5,88(s2)
    80001c46:	0607b823          	sd	zero,112(a5)
    80001c4a:	0d000493          	li	s1,208
  for(i = 0; i < NOFILE; i++)
    80001c4e:	15000a13          	li	s4,336
    80001c52:	a00d                	j	80001c74 <kfork+0x9a>
    freeproc(np);
    80001c54:	854a                	mv	a0,s2
    80001c56:	dd5ff0ef          	jal	ra,80001a2a <freeproc>
    release(&np->lock);
    80001c5a:	854a                	mv	a0,s2
    80001c5c:	ff7fe0ef          	jal	ra,80000c52 <release>
    return -1;
    80001c60:	5a7d                	li	s4,-1
    80001c62:	a871                	j	80001cfe <kfork+0x124>
      np->ofile[i] = filedup(p->ofile[i]);
    80001c64:	05b020ef          	jal	ra,800044be <filedup>
    80001c68:	009907b3          	add	a5,s2,s1
    80001c6c:	e388                	sd	a0,0(a5)
  for(i = 0; i < NOFILE; i++)
    80001c6e:	04a1                	addi	s1,s1,8
    80001c70:	01448763          	beq	s1,s4,80001c7e <kfork+0xa4>
    if(p->ofile[i])
    80001c74:	009987b3          	add	a5,s3,s1
    80001c78:	6388                	ld	a0,0(a5)
    80001c7a:	f56d                	bnez	a0,80001c64 <kfork+0x8a>
    80001c7c:	bfcd                	j	80001c6e <kfork+0x94>
  np->cwd = idup(p->cwd);
    80001c7e:	1509b503          	ld	a0,336(s3)
    80001c82:	261010ef          	jal	ra,800036e2 <idup>
    80001c86:	14a93823          	sd	a0,336(s2)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001c8a:	4641                	li	a2,16
    80001c8c:	15898593          	addi	a1,s3,344
    80001c90:	15890513          	addi	a0,s2,344
    80001c94:	948ff0ef          	jal	ra,80000ddc <safestrcpy>
  np->nice = p->nice;
    80001c98:	1689a703          	lw	a4,360(s3)
    80001c9c:	16e92423          	sw	a4,360(s2)
  np->vruntime = p->vruntime;
    80001ca0:	1789b603          	ld	a2,376(s3)
    80001ca4:	16c93c23          	sd	a2,376(s2)
  np->vdeadline = np->vruntime + (uint64)5 * 1024 * 1000 / (uint64)nice_to_weight[np->nice];
    80001ca8:	070a                	slli	a4,a4,0x2
    80001caa:	00005697          	auipc	a3,0x5
    80001cae:	65668693          	addi	a3,a3,1622 # 80007300 <nice_to_weight>
    80001cb2:	9736                	add	a4,a4,a3
    80001cb4:	4318                	lw	a4,0(a4)
    80001cb6:	004e27b7          	lui	a5,0x4e2
    80001cba:	02e7d7b3          	divu	a5,a5,a4
    80001cbe:	97b2                	add	a5,a5,a2
    80001cc0:	18f93023          	sd	a5,384(s2)
  np->is_eligible = 1;
    80001cc4:	4785                	li	a5,1
    80001cc6:	18f92623          	sw	a5,396(s2)
  pid = np->pid;
    80001cca:	03092a03          	lw	s4,48(s2)
  release(&np->lock);
    80001cce:	854a                	mv	a0,s2
    80001cd0:	f83fe0ef          	jal	ra,80000c52 <release>
  acquire(&wait_lock);
    80001cd4:	0000e497          	auipc	s1,0xe
    80001cd8:	e0c48493          	addi	s1,s1,-500 # 8000fae0 <wait_lock>
    80001cdc:	8526                	mv	a0,s1
    80001cde:	eddfe0ef          	jal	ra,80000bba <acquire>
  np->parent = p;
    80001ce2:	03393c23          	sd	s3,56(s2)
  release(&wait_lock);
    80001ce6:	8526                	mv	a0,s1
    80001ce8:	f6bfe0ef          	jal	ra,80000c52 <release>
  acquire(&np->lock);
    80001cec:	854a                	mv	a0,s2
    80001cee:	ecdfe0ef          	jal	ra,80000bba <acquire>
  np->state = RUNNABLE;
    80001cf2:	478d                	li	a5,3
    80001cf4:	00f92c23          	sw	a5,24(s2)
  release(&np->lock);
    80001cf8:	854a                	mv	a0,s2
    80001cfa:	f59fe0ef          	jal	ra,80000c52 <release>
}
    80001cfe:	8552                	mv	a0,s4
    80001d00:	70a2                	ld	ra,40(sp)
    80001d02:	7402                	ld	s0,32(sp)
    80001d04:	64e2                	ld	s1,24(sp)
    80001d06:	6942                	ld	s2,16(sp)
    80001d08:	69a2                	ld	s3,8(sp)
    80001d0a:	6a02                	ld	s4,0(sp)
    80001d0c:	6145                	addi	sp,sp,48
    80001d0e:	8082                	ret
    return -1;
    80001d10:	5a7d                	li	s4,-1
    80001d12:	b7f5                	j	80001cfe <kfork+0x124>

0000000080001d14 <scheduler>:
{
    80001d14:	7159                	addi	sp,sp,-112
    80001d16:	f486                	sd	ra,104(sp)
    80001d18:	f0a2                	sd	s0,96(sp)
    80001d1a:	eca6                	sd	s1,88(sp)
    80001d1c:	e8ca                	sd	s2,80(sp)
    80001d1e:	e4ce                	sd	s3,72(sp)
    80001d20:	e0d2                	sd	s4,64(sp)
    80001d22:	fc56                	sd	s5,56(sp)
    80001d24:	f85a                	sd	s6,48(sp)
    80001d26:	f45e                	sd	s7,40(sp)
    80001d28:	f062                	sd	s8,32(sp)
    80001d2a:	ec66                	sd	s9,24(sp)
    80001d2c:	e86a                	sd	s10,16(sp)
    80001d2e:	e46e                	sd	s11,8(sp)
    80001d30:	1880                	addi	s0,sp,112
    80001d32:	8792                	mv	a5,tp
  int id = r_tp();
    80001d34:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001d36:	00779693          	slli	a3,a5,0x7
    80001d3a:	0000e717          	auipc	a4,0xe
    80001d3e:	d8e70713          	addi	a4,a4,-626 # 8000fac8 <pid_lock>
    80001d42:	9736                	add	a4,a4,a3
    80001d44:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &selected->context);
    80001d48:	0000e717          	auipc	a4,0xe
    80001d4c:	db870713          	addi	a4,a4,-584 # 8000fb00 <cpus+0x8>
    80001d50:	00e68db3          	add	s11,a3,a4
    uint64 v0 = (uint64)-1;
    80001d54:	5b7d                	li	s6,-1
      if(p->state == RUNNABLE || p->state == RUNNING) {
    80001d56:	4985                	li	s3,1
    for(p = proc; p < &proc[NPROC]; p++) {
    80001d58:	00014917          	auipc	s2,0x14
    80001d5c:	5a090913          	addi	s2,s2,1440 # 800162f8 <tickslock>
        uint64 w = (uint64)nice_to_weight[p->nice];
    80001d60:	00005a97          	auipc	s5,0x5
    80001d64:	5a0a8a93          	addi	s5,s5,1440 # 80007300 <nice_to_weight>
        c->proc = selected;
    80001d68:	0000eb97          	auipc	s7,0xe
    80001d6c:	d60b8b93          	addi	s7,s7,-672 # 8000fac8 <pid_lock>
    80001d70:	9bb6                	add	s7,s7,a3
    80001d72:	a80d                	j	80001da4 <scheduler+0x90>
      release(&p->lock);
    80001d74:	8526                	mv	a0,s1
    80001d76:	eddfe0ef          	jal	ra,80000c52 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001d7a:	19048493          	addi	s1,s1,400
    80001d7e:	01248f63          	beq	s1,s2,80001d9c <scheduler+0x88>
      acquire(&p->lock);
    80001d82:	8526                	mv	a0,s1
    80001d84:	e37fe0ef          	jal	ra,80000bba <acquire>
      if(p->state == RUNNABLE || p->state == RUNNING) {
    80001d88:	4c9c                	lw	a5,24(s1)
    80001d8a:	37f5                	addiw	a5,a5,-3
    80001d8c:	fef9e4e3          	bltu	s3,a5,80001d74 <scheduler+0x60>
        if(p->vruntime < v0)
    80001d90:	1784b783          	ld	a5,376(s1)
    80001d94:	ff47f0e3          	bgeu	a5,s4,80001d74 <scheduler+0x60>
    80001d98:	8a3e                	mv	s4,a5
    80001d9a:	bfe9                	j	80001d74 <scheduler+0x60>
    if(v0 == (uint64)-1) {
    80001d9c:	036a1563          	bne	s4,s6,80001dc6 <scheduler+0xb2>
      asm volatile("wfi");
    80001da0:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001da4:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001da8:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001dac:	10079073          	csrw	sstatus,a5
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001db0:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001db4:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001db6:	10079073          	csrw	sstatus,a5
    uint64 v0 = (uint64)-1;
    80001dba:	8a5a                	mv	s4,s6
    for(p = proc; p < &proc[NPROC]; p++) {
    80001dbc:	0000e497          	auipc	s1,0xe
    80001dc0:	13c48493          	addi	s1,s1,316 # 8000fef8 <proc>
    80001dc4:	bf7d                	j	80001d82 <scheduler+0x6e>
    uint64 weighted_sum = 0;
    80001dc6:	4c81                	li	s9,0
    uint64 sum_w = 0;
    80001dc8:	4c01                	li	s8,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001dca:	0000e497          	auipc	s1,0xe
    80001dce:	12e48493          	addi	s1,s1,302 # 8000fef8 <proc>
        uint64 diff = (p->vruntime >= v0) ? (p->vruntime - v0) : 0;
    80001dd2:	4d01                	li	s10,0
    80001dd4:	a821                	j	80001dec <scheduler+0xd8>
        weighted_sum += diff * w;
    80001dd6:	02e787b3          	mul	a5,a5,a4
    80001dda:	9cbe                	add	s9,s9,a5
        sum_w += w;
    80001ddc:	9c3a                	add	s8,s8,a4
      release(&p->lock);
    80001dde:	8526                	mv	a0,s1
    80001de0:	e73fe0ef          	jal	ra,80000c52 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001de4:	19048493          	addi	s1,s1,400
    80001de8:	03248663          	beq	s1,s2,80001e14 <scheduler+0x100>
      acquire(&p->lock);
    80001dec:	8526                	mv	a0,s1
    80001dee:	dcdfe0ef          	jal	ra,80000bba <acquire>
      if(p->state == RUNNABLE || p->state == RUNNING) {
    80001df2:	4c9c                	lw	a5,24(s1)
    80001df4:	37f5                	addiw	a5,a5,-3
    80001df6:	fef9e4e3          	bltu	s3,a5,80001dde <scheduler+0xca>
        uint64 w = (uint64)nice_to_weight[p->nice];
    80001dfa:	1684a783          	lw	a5,360(s1)
    80001dfe:	078a                	slli	a5,a5,0x2
    80001e00:	97d6                	add	a5,a5,s5
    80001e02:	4398                	lw	a4,0(a5)
        uint64 diff = (p->vruntime >= v0) ? (p->vruntime - v0) : 0;
    80001e04:	1784b683          	ld	a3,376(s1)
    80001e08:	87ea                	mv	a5,s10
    80001e0a:	fd46e6e3          	bltu	a3,s4,80001dd6 <scheduler+0xc2>
    80001e0e:	414687b3          	sub	a5,a3,s4
    80001e12:	b7d1                	j	80001dd6 <scheduler+0xc2>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001e14:	0000e497          	auipc	s1,0xe
    80001e18:	0e448493          	addi	s1,s1,228 # 8000fef8 <proc>
          p->is_eligible = 1;
    80001e1c:	4d05                	li	s10,1
    80001e1e:	a811                	j	80001e32 <scheduler+0x11e>
    80001e20:	19a4a623          	sw	s10,396(s1)
      release(&p->lock);
    80001e24:	8526                	mv	a0,s1
    80001e26:	e2dfe0ef          	jal	ra,80000c52 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001e2a:	19048493          	addi	s1,s1,400
    80001e2e:	03248663          	beq	s1,s2,80001e5a <scheduler+0x146>
      acquire(&p->lock);
    80001e32:	8526                	mv	a0,s1
    80001e34:	d87fe0ef          	jal	ra,80000bba <acquire>
      if(p->state == RUNNABLE || p->state == RUNNING) {
    80001e38:	4c9c                	lw	a5,24(s1)
    80001e3a:	37f5                	addiw	a5,a5,-3
    80001e3c:	fef9e4e3          	bltu	s3,a5,80001e24 <scheduler+0x110>
        uint64 diff = (p->vruntime >= v0) ? (p->vruntime - v0) : 0;
    80001e40:	1784b783          	ld	a5,376(s1)
    80001e44:	fd47eee3          	bltu	a5,s4,80001e20 <scheduler+0x10c>
    80001e48:	414787b3          	sub	a5,a5,s4
        if(diff * sum_w <= weighted_sum)
    80001e4c:	038787b3          	mul	a5,a5,s8
    80001e50:	fcfcf8e3          	bgeu	s9,a5,80001e20 <scheduler+0x10c>
          p->is_eligible = 0;
    80001e54:	1804a623          	sw	zero,396(s1)
    80001e58:	b7f1                	j	80001e24 <scheduler+0x110>
    uint64 min_vdeadline = (uint64)-1;
    80001e5a:	8cda                	mv	s9,s6
    struct proc *selected = 0;
    80001e5c:	4c01                	li	s8,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001e5e:	0000e497          	auipc	s1,0xe
    80001e62:	09a48493          	addi	s1,s1,154 # 8000fef8 <proc>
      if(p->state == RUNNABLE && p->is_eligible) {
    80001e66:	4a0d                	li	s4,3
    80001e68:	a801                	j	80001e78 <scheduler+0x164>
      release(&p->lock);
    80001e6a:	8526                	mv	a0,s1
    80001e6c:	de7fe0ef          	jal	ra,80000c52 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001e70:	19048493          	addi	s1,s1,400
    80001e74:	03248263          	beq	s1,s2,80001e98 <scheduler+0x184>
      acquire(&p->lock);
    80001e78:	8526                	mv	a0,s1
    80001e7a:	d41fe0ef          	jal	ra,80000bba <acquire>
      if(p->state == RUNNABLE && p->is_eligible) {
    80001e7e:	4c9c                	lw	a5,24(s1)
    80001e80:	ff4795e3          	bne	a5,s4,80001e6a <scheduler+0x156>
    80001e84:	18c4a783          	lw	a5,396(s1)
    80001e88:	d3ed                	beqz	a5,80001e6a <scheduler+0x156>
        if(p->vdeadline < min_vdeadline) {
    80001e8a:	1804b783          	ld	a5,384(s1)
    80001e8e:	fd97fee3          	bgeu	a5,s9,80001e6a <scheduler+0x156>
          min_vdeadline = p->vdeadline;
    80001e92:	8cbe                	mv	s9,a5
        if(p->vdeadline < min_vdeadline) {
    80001e94:	8c26                	mv	s8,s1
    80001e96:	bfd1                	j	80001e6a <scheduler+0x156>
    if(selected == 0) {
    80001e98:	000c0f63          	beqz	s8,80001eb6 <scheduler+0x1a2>
      acquire(&selected->lock);
    80001e9c:	84e2                	mv	s1,s8
    80001e9e:	8562                	mv	a0,s8
    80001ea0:	d1bfe0ef          	jal	ra,80000bba <acquire>
      if(selected->state == RUNNABLE) {
    80001ea4:	018c2703          	lw	a4,24(s8) # fffffffffffff018 <end+0xffffffff7ffdd940>
    80001ea8:	478d                	li	a5,3
    80001eaa:	04f70663          	beq	a4,a5,80001ef6 <scheduler+0x1e2>
      release(&selected->lock);
    80001eae:	8526                	mv	a0,s1
    80001eb0:	da3fe0ef          	jal	ra,80000c52 <release>
    80001eb4:	bdc5                	j	80001da4 <scheduler+0x90>
      min_vdeadline = (uint64)-1;
    80001eb6:	8cda                	mv	s9,s6
      for(p = proc; p < &proc[NPROC]; p++) {
    80001eb8:	0000e497          	auipc	s1,0xe
    80001ebc:	04048493          	addi	s1,s1,64 # 8000fef8 <proc>
        if(p->state == RUNNABLE) {
    80001ec0:	4a0d                	li	s4,3
    80001ec2:	a801                	j	80001ed2 <scheduler+0x1be>
        release(&p->lock);
    80001ec4:	8526                	mv	a0,s1
    80001ec6:	d8dfe0ef          	jal	ra,80000c52 <release>
      for(p = proc; p < &proc[NPROC]; p++) {
    80001eca:	19048493          	addi	s1,s1,400
    80001ece:	01248f63          	beq	s1,s2,80001eec <scheduler+0x1d8>
        acquire(&p->lock);
    80001ed2:	8526                	mv	a0,s1
    80001ed4:	ce7fe0ef          	jal	ra,80000bba <acquire>
        if(p->state == RUNNABLE) {
    80001ed8:	4c9c                	lw	a5,24(s1)
    80001eda:	ff4795e3          	bne	a5,s4,80001ec4 <scheduler+0x1b0>
          if(p->vdeadline < min_vdeadline) {
    80001ede:	1804b783          	ld	a5,384(s1)
    80001ee2:	ff97f1e3          	bgeu	a5,s9,80001ec4 <scheduler+0x1b0>
            min_vdeadline = p->vdeadline;
    80001ee6:	8cbe                	mv	s9,a5
          if(p->vdeadline < min_vdeadline) {
    80001ee8:	8c26                	mv	s8,s1
    80001eea:	bfe9                	j	80001ec4 <scheduler+0x1b0>
    if(selected != 0) {
    80001eec:	fa0c18e3          	bnez	s8,80001e9c <scheduler+0x188>
      asm volatile("wfi");
    80001ef0:	10500073          	wfi
    80001ef4:	bd45                	j	80001da4 <scheduler+0x90>
        selected->state = RUNNING;
    80001ef6:	4791                	li	a5,4
    80001ef8:	00fc2c23          	sw	a5,24(s8)
        c->proc = selected;
    80001efc:	038bb823          	sd	s8,48(s7)
        swtch(&c->context, &selected->context);
    80001f00:	060c0593          	addi	a1,s8,96
    80001f04:	856e                	mv	a0,s11
    80001f06:	0bb000ef          	jal	ra,800027c0 <swtch>
        c->proc = 0;
    80001f0a:	020bb823          	sd	zero,48(s7)
    80001f0e:	b745                	j	80001eae <scheduler+0x19a>

0000000080001f10 <sched>:
{
    80001f10:	7179                	addi	sp,sp,-48
    80001f12:	f406                	sd	ra,40(sp)
    80001f14:	f022                	sd	s0,32(sp)
    80001f16:	ec26                	sd	s1,24(sp)
    80001f18:	e84a                	sd	s2,16(sp)
    80001f1a:	e44e                	sd	s3,8(sp)
    80001f1c:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001f1e:	93dff0ef          	jal	ra,8000185a <myproc>
    80001f22:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001f24:	c2dfe0ef          	jal	ra,80000b50 <holding>
    80001f28:	c92d                	beqz	a0,80001f9a <sched+0x8a>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001f2a:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001f2c:	2781                	sext.w	a5,a5
    80001f2e:	079e                	slli	a5,a5,0x7
    80001f30:	0000e717          	auipc	a4,0xe
    80001f34:	b9870713          	addi	a4,a4,-1128 # 8000fac8 <pid_lock>
    80001f38:	97ba                	add	a5,a5,a4
    80001f3a:	0a87a703          	lw	a4,168(a5) # 4e20a8 <_entry-0x7fb1df58>
    80001f3e:	4785                	li	a5,1
    80001f40:	06f71363          	bne	a4,a5,80001fa6 <sched+0x96>
  if(p->state == RUNNING)
    80001f44:	4c98                	lw	a4,24(s1)
    80001f46:	4791                	li	a5,4
    80001f48:	06f70563          	beq	a4,a5,80001fb2 <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001f4c:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001f50:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001f52:	e7b5                	bnez	a5,80001fbe <sched+0xae>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001f54:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001f56:	0000e917          	auipc	s2,0xe
    80001f5a:	b7290913          	addi	s2,s2,-1166 # 8000fac8 <pid_lock>
    80001f5e:	2781                	sext.w	a5,a5
    80001f60:	079e                	slli	a5,a5,0x7
    80001f62:	97ca                	add	a5,a5,s2
    80001f64:	0ac7a983          	lw	s3,172(a5)
    80001f68:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001f6a:	2781                	sext.w	a5,a5
    80001f6c:	079e                	slli	a5,a5,0x7
    80001f6e:	0000e597          	auipc	a1,0xe
    80001f72:	b9258593          	addi	a1,a1,-1134 # 8000fb00 <cpus+0x8>
    80001f76:	95be                	add	a1,a1,a5
    80001f78:	06048513          	addi	a0,s1,96
    80001f7c:	045000ef          	jal	ra,800027c0 <swtch>
    80001f80:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001f82:	2781                	sext.w	a5,a5
    80001f84:	079e                	slli	a5,a5,0x7
    80001f86:	97ca                	add	a5,a5,s2
    80001f88:	0b37a623          	sw	s3,172(a5)
}
    80001f8c:	70a2                	ld	ra,40(sp)
    80001f8e:	7402                	ld	s0,32(sp)
    80001f90:	64e2                	ld	s1,24(sp)
    80001f92:	6942                	ld	s2,16(sp)
    80001f94:	69a2                	ld	s3,8(sp)
    80001f96:	6145                	addi	sp,sp,48
    80001f98:	8082                	ret
    panic("sched p->lock");
    80001f9a:	00005517          	auipc	a0,0x5
    80001f9e:	21650513          	addi	a0,a0,534 # 800071b0 <digits+0x178>
    80001fa2:	fecfe0ef          	jal	ra,8000078e <panic>
    panic("sched locks");
    80001fa6:	00005517          	auipc	a0,0x5
    80001faa:	21a50513          	addi	a0,a0,538 # 800071c0 <digits+0x188>
    80001fae:	fe0fe0ef          	jal	ra,8000078e <panic>
    panic("sched RUNNING");
    80001fb2:	00005517          	auipc	a0,0x5
    80001fb6:	21e50513          	addi	a0,a0,542 # 800071d0 <digits+0x198>
    80001fba:	fd4fe0ef          	jal	ra,8000078e <panic>
    panic("sched interruptible");
    80001fbe:	00005517          	auipc	a0,0x5
    80001fc2:	22250513          	addi	a0,a0,546 # 800071e0 <digits+0x1a8>
    80001fc6:	fc8fe0ef          	jal	ra,8000078e <panic>

0000000080001fca <yield>:
{
    80001fca:	1101                	addi	sp,sp,-32
    80001fcc:	ec06                	sd	ra,24(sp)
    80001fce:	e822                	sd	s0,16(sp)
    80001fd0:	e426                	sd	s1,8(sp)
    80001fd2:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001fd4:	887ff0ef          	jal	ra,8000185a <myproc>
    80001fd8:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001fda:	be1fe0ef          	jal	ra,80000bba <acquire>
  p->state = RUNNABLE;
    80001fde:	478d                	li	a5,3
    80001fe0:	cc9c                	sw	a5,24(s1)
  sched();
    80001fe2:	f2fff0ef          	jal	ra,80001f10 <sched>
  release(&p->lock);
    80001fe6:	8526                	mv	a0,s1
    80001fe8:	c6bfe0ef          	jal	ra,80000c52 <release>
}
    80001fec:	60e2                	ld	ra,24(sp)
    80001fee:	6442                	ld	s0,16(sp)
    80001ff0:	64a2                	ld	s1,8(sp)
    80001ff2:	6105                	addi	sp,sp,32
    80001ff4:	8082                	ret

0000000080001ff6 <sleep>:

// Sleep on channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001ff6:	7179                	addi	sp,sp,-48
    80001ff8:	f406                	sd	ra,40(sp)
    80001ffa:	f022                	sd	s0,32(sp)
    80001ffc:	ec26                	sd	s1,24(sp)
    80001ffe:	e84a                	sd	s2,16(sp)
    80002000:	e44e                	sd	s3,8(sp)
    80002002:	1800                	addi	s0,sp,48
    80002004:	89aa                	mv	s3,a0
    80002006:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002008:	853ff0ef          	jal	ra,8000185a <myproc>
    8000200c:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    8000200e:	badfe0ef          	jal	ra,80000bba <acquire>
  release(lk);
    80002012:	854a                	mv	a0,s2
    80002014:	c3ffe0ef          	jal	ra,80000c52 <release>

  // Go to sleep.
  p->chan = chan;
    80002018:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    8000201c:	4789                	li	a5,2
    8000201e:	cc9c                	sw	a5,24(s1)

  sched();
    80002020:	ef1ff0ef          	jal	ra,80001f10 <sched>

  // Tidy up.
  p->chan = 0;
    80002024:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80002028:	8526                	mv	a0,s1
    8000202a:	c29fe0ef          	jal	ra,80000c52 <release>
  acquire(lk);
    8000202e:	854a                	mv	a0,s2
    80002030:	b8bfe0ef          	jal	ra,80000bba <acquire>
}
    80002034:	70a2                	ld	ra,40(sp)
    80002036:	7402                	ld	s0,32(sp)
    80002038:	64e2                	ld	s1,24(sp)
    8000203a:	6942                	ld	s2,16(sp)
    8000203c:	69a2                	ld	s3,8(sp)
    8000203e:	6145                	addi	sp,sp,48
    80002040:	8082                	ret

0000000080002042 <wakeup>:

// Wake up all processes sleeping on channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    80002042:	711d                	addi	sp,sp,-96
    80002044:	ec86                	sd	ra,88(sp)
    80002046:	e8a2                	sd	s0,80(sp)
    80002048:	e4a6                	sd	s1,72(sp)
    8000204a:	e0ca                	sd	s2,64(sp)
    8000204c:	fc4e                	sd	s3,56(sp)
    8000204e:	f852                	sd	s4,48(sp)
    80002050:	f456                	sd	s5,40(sp)
    80002052:	f05a                	sd	s6,32(sp)
    80002054:	ec5e                	sd	s7,24(sp)
    80002056:	e862                	sd	s8,16(sp)
    80002058:	e466                	sd	s9,8(sp)
    8000205a:	1080                	addi	s0,sp,96
    8000205c:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    8000205e:	0000e497          	auipc	s1,0xe
    80002062:	e9a48493          	addi	s1,s1,-358 # 8000fef8 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80002066:	4989                	li	s3,2
        p->state = RUNNABLE;
    80002068:	4c8d                	li	s9,3
        p->timeslice = 5;
    8000206a:	4c15                	li	s8,5
        p->vdeadline = p->vruntime + (uint64)5 * 1024 * 1000 / (uint64)nice_to_weight[p->nice];
    8000206c:	00005b97          	auipc	s7,0x5
    80002070:	294b8b93          	addi	s7,s7,660 # 80007300 <nice_to_weight>
    80002074:	004e2b37          	lui	s6,0x4e2
        p->is_eligible = 1;
    80002078:	4a85                	li	s5,1
  for(p = proc; p < &proc[NPROC]; p++) {
    8000207a:	00014917          	auipc	s2,0x14
    8000207e:	27e90913          	addi	s2,s2,638 # 800162f8 <tickslock>
    80002082:	a815                	j	800020b6 <wakeup+0x74>
        p->state = RUNNABLE;
    80002084:	0194ac23          	sw	s9,24(s1)
        p->timeslice = 5;
    80002088:	1984a423          	sw	s8,392(s1)
        p->vdeadline = p->vruntime + (uint64)5 * 1024 * 1000 / (uint64)nice_to_weight[p->nice];
    8000208c:	1684a783          	lw	a5,360(s1)
    80002090:	078a                	slli	a5,a5,0x2
    80002092:	97de                	add	a5,a5,s7
    80002094:	439c                	lw	a5,0(a5)
    80002096:	02fb57b3          	divu	a5,s6,a5
    8000209a:	1784b703          	ld	a4,376(s1)
    8000209e:	97ba                	add	a5,a5,a4
    800020a0:	18f4b023          	sd	a5,384(s1)
        p->is_eligible = 1;
    800020a4:	1954a623          	sw	s5,396(s1)
      }
      release(&p->lock);
    800020a8:	8526                	mv	a0,s1
    800020aa:	ba9fe0ef          	jal	ra,80000c52 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    800020ae:	19048493          	addi	s1,s1,400
    800020b2:	03248063          	beq	s1,s2,800020d2 <wakeup+0x90>
    if(p != myproc()){
    800020b6:	fa4ff0ef          	jal	ra,8000185a <myproc>
    800020ba:	fea48ae3          	beq	s1,a0,800020ae <wakeup+0x6c>
      acquire(&p->lock);
    800020be:	8526                	mv	a0,s1
    800020c0:	afbfe0ef          	jal	ra,80000bba <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    800020c4:	4c9c                	lw	a5,24(s1)
    800020c6:	ff3791e3          	bne	a5,s3,800020a8 <wakeup+0x66>
    800020ca:	709c                	ld	a5,32(s1)
    800020cc:	fd479ee3          	bne	a5,s4,800020a8 <wakeup+0x66>
    800020d0:	bf55                	j	80002084 <wakeup+0x42>
    }
  }
}
    800020d2:	60e6                	ld	ra,88(sp)
    800020d4:	6446                	ld	s0,80(sp)
    800020d6:	64a6                	ld	s1,72(sp)
    800020d8:	6906                	ld	s2,64(sp)
    800020da:	79e2                	ld	s3,56(sp)
    800020dc:	7a42                	ld	s4,48(sp)
    800020de:	7aa2                	ld	s5,40(sp)
    800020e0:	7b02                	ld	s6,32(sp)
    800020e2:	6be2                	ld	s7,24(sp)
    800020e4:	6c42                	ld	s8,16(sp)
    800020e6:	6ca2                	ld	s9,8(sp)
    800020e8:	6125                	addi	sp,sp,96
    800020ea:	8082                	ret

00000000800020ec <reparent>:
{
    800020ec:	7179                	addi	sp,sp,-48
    800020ee:	f406                	sd	ra,40(sp)
    800020f0:	f022                	sd	s0,32(sp)
    800020f2:	ec26                	sd	s1,24(sp)
    800020f4:	e84a                	sd	s2,16(sp)
    800020f6:	e44e                	sd	s3,8(sp)
    800020f8:	e052                	sd	s4,0(sp)
    800020fa:	1800                	addi	s0,sp,48
    800020fc:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    800020fe:	0000e497          	auipc	s1,0xe
    80002102:	dfa48493          	addi	s1,s1,-518 # 8000fef8 <proc>
      pp->parent = initproc;
    80002106:	00006a17          	auipc	s4,0x6
    8000210a:	8baa0a13          	addi	s4,s4,-1862 # 800079c0 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000210e:	00014997          	auipc	s3,0x14
    80002112:	1ea98993          	addi	s3,s3,490 # 800162f8 <tickslock>
    80002116:	a029                	j	80002120 <reparent+0x34>
    80002118:	19048493          	addi	s1,s1,400
    8000211c:	01348b63          	beq	s1,s3,80002132 <reparent+0x46>
    if(pp->parent == p){
    80002120:	7c9c                	ld	a5,56(s1)
    80002122:	ff279be3          	bne	a5,s2,80002118 <reparent+0x2c>
      pp->parent = initproc;
    80002126:	000a3503          	ld	a0,0(s4)
    8000212a:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    8000212c:	f17ff0ef          	jal	ra,80002042 <wakeup>
    80002130:	b7e5                	j	80002118 <reparent+0x2c>
}
    80002132:	70a2                	ld	ra,40(sp)
    80002134:	7402                	ld	s0,32(sp)
    80002136:	64e2                	ld	s1,24(sp)
    80002138:	6942                	ld	s2,16(sp)
    8000213a:	69a2                	ld	s3,8(sp)
    8000213c:	6a02                	ld	s4,0(sp)
    8000213e:	6145                	addi	sp,sp,48
    80002140:	8082                	ret

0000000080002142 <kexit>:
{
    80002142:	7179                	addi	sp,sp,-48
    80002144:	f406                	sd	ra,40(sp)
    80002146:	f022                	sd	s0,32(sp)
    80002148:	ec26                	sd	s1,24(sp)
    8000214a:	e84a                	sd	s2,16(sp)
    8000214c:	e44e                	sd	s3,8(sp)
    8000214e:	e052                	sd	s4,0(sp)
    80002150:	1800                	addi	s0,sp,48
    80002152:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80002154:	f06ff0ef          	jal	ra,8000185a <myproc>
    80002158:	89aa                	mv	s3,a0
  if(p == initproc)
    8000215a:	00006797          	auipc	a5,0x6
    8000215e:	8667b783          	ld	a5,-1946(a5) # 800079c0 <initproc>
    80002162:	0d050493          	addi	s1,a0,208
    80002166:	15050913          	addi	s2,a0,336
    8000216a:	00a79f63          	bne	a5,a0,80002188 <kexit+0x46>
    panic("init exiting");
    8000216e:	00005517          	auipc	a0,0x5
    80002172:	08a50513          	addi	a0,a0,138 # 800071f8 <digits+0x1c0>
    80002176:	e18fe0ef          	jal	ra,8000078e <panic>
      fileclose(f);
    8000217a:	38a020ef          	jal	ra,80004504 <fileclose>
      p->ofile[fd] = 0;
    8000217e:	0004b023          	sd	zero,0(s1)
  for(int fd = 0; fd < NOFILE; fd++){
    80002182:	04a1                	addi	s1,s1,8
    80002184:	01248563          	beq	s1,s2,8000218e <kexit+0x4c>
    if(p->ofile[fd]){
    80002188:	6088                	ld	a0,0(s1)
    8000218a:	f965                	bnez	a0,8000217a <kexit+0x38>
    8000218c:	bfdd                	j	80002182 <kexit+0x40>
  begin_op();
    8000218e:	769010ef          	jal	ra,800040f6 <begin_op>
  iput(p->cwd);
    80002192:	1509b503          	ld	a0,336(s3)
    80002196:	700010ef          	jal	ra,80003896 <iput>
  end_op();
    8000219a:	7cd010ef          	jal	ra,80004166 <end_op>
  p->cwd = 0;
    8000219e:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    800021a2:	0000e497          	auipc	s1,0xe
    800021a6:	93e48493          	addi	s1,s1,-1730 # 8000fae0 <wait_lock>
    800021aa:	8526                	mv	a0,s1
    800021ac:	a0ffe0ef          	jal	ra,80000bba <acquire>
  reparent(p);
    800021b0:	854e                	mv	a0,s3
    800021b2:	f3bff0ef          	jal	ra,800020ec <reparent>
  wakeup(p->parent);
    800021b6:	0389b503          	ld	a0,56(s3)
    800021ba:	e89ff0ef          	jal	ra,80002042 <wakeup>
  acquire(&p->lock);
    800021be:	854e                	mv	a0,s3
    800021c0:	9fbfe0ef          	jal	ra,80000bba <acquire>
  p->xstate = status;
    800021c4:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800021c8:	4795                	li	a5,5
    800021ca:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800021ce:	8526                	mv	a0,s1
    800021d0:	a83fe0ef          	jal	ra,80000c52 <release>
  sched();
    800021d4:	d3dff0ef          	jal	ra,80001f10 <sched>
  panic("zombie exit");
    800021d8:	00005517          	auipc	a0,0x5
    800021dc:	03050513          	addi	a0,a0,48 # 80007208 <digits+0x1d0>
    800021e0:	daefe0ef          	jal	ra,8000078e <panic>

00000000800021e4 <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    800021e4:	7179                	addi	sp,sp,-48
    800021e6:	f406                	sd	ra,40(sp)
    800021e8:	f022                	sd	s0,32(sp)
    800021ea:	ec26                	sd	s1,24(sp)
    800021ec:	e84a                	sd	s2,16(sp)
    800021ee:	e44e                	sd	s3,8(sp)
    800021f0:	1800                	addi	s0,sp,48
    800021f2:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    800021f4:	0000e497          	auipc	s1,0xe
    800021f8:	d0448493          	addi	s1,s1,-764 # 8000fef8 <proc>
    800021fc:	00014997          	auipc	s3,0x14
    80002200:	0fc98993          	addi	s3,s3,252 # 800162f8 <tickslock>
    acquire(&p->lock);
    80002204:	8526                	mv	a0,s1
    80002206:	9b5fe0ef          	jal	ra,80000bba <acquire>
    if(p->pid == pid){
    8000220a:	589c                	lw	a5,48(s1)
    8000220c:	01278b63          	beq	a5,s2,80002222 <kkill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80002210:	8526                	mv	a0,s1
    80002212:	a41fe0ef          	jal	ra,80000c52 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    80002216:	19048493          	addi	s1,s1,400
    8000221a:	ff3495e3          	bne	s1,s3,80002204 <kkill+0x20>
  }
  return -1;
    8000221e:	557d                	li	a0,-1
    80002220:	a819                	j	80002236 <kkill+0x52>
      p->killed = 1;
    80002222:	4785                	li	a5,1
    80002224:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    80002226:	4c98                	lw	a4,24(s1)
    80002228:	4789                	li	a5,2
    8000222a:	00f70d63          	beq	a4,a5,80002244 <kkill+0x60>
      release(&p->lock);
    8000222e:	8526                	mv	a0,s1
    80002230:	a23fe0ef          	jal	ra,80000c52 <release>
      return 0;
    80002234:	4501                	li	a0,0
}
    80002236:	70a2                	ld	ra,40(sp)
    80002238:	7402                	ld	s0,32(sp)
    8000223a:	64e2                	ld	s1,24(sp)
    8000223c:	6942                	ld	s2,16(sp)
    8000223e:	69a2                	ld	s3,8(sp)
    80002240:	6145                	addi	sp,sp,48
    80002242:	8082                	ret
        p->state = RUNNABLE;
    80002244:	478d                	li	a5,3
    80002246:	cc9c                	sw	a5,24(s1)
    80002248:	b7dd                	j	8000222e <kkill+0x4a>

000000008000224a <setkilled>:

void
setkilled(struct proc *p)
{
    8000224a:	1101                	addi	sp,sp,-32
    8000224c:	ec06                	sd	ra,24(sp)
    8000224e:	e822                	sd	s0,16(sp)
    80002250:	e426                	sd	s1,8(sp)
    80002252:	1000                	addi	s0,sp,32
    80002254:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002256:	965fe0ef          	jal	ra,80000bba <acquire>
  p->killed = 1;
    8000225a:	4785                	li	a5,1
    8000225c:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    8000225e:	8526                	mv	a0,s1
    80002260:	9f3fe0ef          	jal	ra,80000c52 <release>
}
    80002264:	60e2                	ld	ra,24(sp)
    80002266:	6442                	ld	s0,16(sp)
    80002268:	64a2                	ld	s1,8(sp)
    8000226a:	6105                	addi	sp,sp,32
    8000226c:	8082                	ret

000000008000226e <killed>:

int
killed(struct proc *p)
{
    8000226e:	1101                	addi	sp,sp,-32
    80002270:	ec06                	sd	ra,24(sp)
    80002272:	e822                	sd	s0,16(sp)
    80002274:	e426                	sd	s1,8(sp)
    80002276:	e04a                	sd	s2,0(sp)
    80002278:	1000                	addi	s0,sp,32
    8000227a:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    8000227c:	93ffe0ef          	jal	ra,80000bba <acquire>
  k = p->killed;
    80002280:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    80002284:	8526                	mv	a0,s1
    80002286:	9cdfe0ef          	jal	ra,80000c52 <release>
  return k;
}
    8000228a:	854a                	mv	a0,s2
    8000228c:	60e2                	ld	ra,24(sp)
    8000228e:	6442                	ld	s0,16(sp)
    80002290:	64a2                	ld	s1,8(sp)
    80002292:	6902                	ld	s2,0(sp)
    80002294:	6105                	addi	sp,sp,32
    80002296:	8082                	ret

0000000080002298 <kwait>:
{
    80002298:	715d                	addi	sp,sp,-80
    8000229a:	e486                	sd	ra,72(sp)
    8000229c:	e0a2                	sd	s0,64(sp)
    8000229e:	fc26                	sd	s1,56(sp)
    800022a0:	f84a                	sd	s2,48(sp)
    800022a2:	f44e                	sd	s3,40(sp)
    800022a4:	f052                	sd	s4,32(sp)
    800022a6:	ec56                	sd	s5,24(sp)
    800022a8:	e85a                	sd	s6,16(sp)
    800022aa:	e45e                	sd	s7,8(sp)
    800022ac:	e062                	sd	s8,0(sp)
    800022ae:	0880                	addi	s0,sp,80
    800022b0:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    800022b2:	da8ff0ef          	jal	ra,8000185a <myproc>
    800022b6:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800022b8:	0000e517          	auipc	a0,0xe
    800022bc:	82850513          	addi	a0,a0,-2008 # 8000fae0 <wait_lock>
    800022c0:	8fbfe0ef          	jal	ra,80000bba <acquire>
    havekids = 0;
    800022c4:	4b81                	li	s7,0
        if(pp->state == ZOMBIE){
    800022c6:	4a15                	li	s4,5
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800022c8:	00014997          	auipc	s3,0x14
    800022cc:	03098993          	addi	s3,s3,48 # 800162f8 <tickslock>
        havekids = 1;
    800022d0:	4a85                	li	s5,1
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800022d2:	0000ec17          	auipc	s8,0xe
    800022d6:	80ec0c13          	addi	s8,s8,-2034 # 8000fae0 <wait_lock>
    havekids = 0;
    800022da:	875e                	mv	a4,s7
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800022dc:	0000e497          	auipc	s1,0xe
    800022e0:	c1c48493          	addi	s1,s1,-996 # 8000fef8 <proc>
    800022e4:	a899                	j	8000233a <kwait+0xa2>
          pid = pp->pid;
    800022e6:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    800022ea:	000b0c63          	beqz	s6,80002302 <kwait+0x6a>
    800022ee:	4691                	li	a3,4
    800022f0:	02c48613          	addi	a2,s1,44
    800022f4:	85da                	mv	a1,s6
    800022f6:	05093503          	ld	a0,80(s2)
    800022fa:	aaeff0ef          	jal	ra,800015a8 <copyout>
    800022fe:	00054f63          	bltz	a0,8000231c <kwait+0x84>
          freeproc(pp);
    80002302:	8526                	mv	a0,s1
    80002304:	f26ff0ef          	jal	ra,80001a2a <freeproc>
          release(&pp->lock);
    80002308:	8526                	mv	a0,s1
    8000230a:	949fe0ef          	jal	ra,80000c52 <release>
          release(&wait_lock);
    8000230e:	0000d517          	auipc	a0,0xd
    80002312:	7d250513          	addi	a0,a0,2002 # 8000fae0 <wait_lock>
    80002316:	93dfe0ef          	jal	ra,80000c52 <release>
          return pid;
    8000231a:	a891                	j	8000236e <kwait+0xd6>
            release(&pp->lock);
    8000231c:	8526                	mv	a0,s1
    8000231e:	935fe0ef          	jal	ra,80000c52 <release>
            release(&wait_lock);
    80002322:	0000d517          	auipc	a0,0xd
    80002326:	7be50513          	addi	a0,a0,1982 # 8000fae0 <wait_lock>
    8000232a:	929fe0ef          	jal	ra,80000c52 <release>
            return -1;
    8000232e:	59fd                	li	s3,-1
    80002330:	a83d                	j	8000236e <kwait+0xd6>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002332:	19048493          	addi	s1,s1,400
    80002336:	03348063          	beq	s1,s3,80002356 <kwait+0xbe>
      if(pp->parent == p){
    8000233a:	7c9c                	ld	a5,56(s1)
    8000233c:	ff279be3          	bne	a5,s2,80002332 <kwait+0x9a>
        acquire(&pp->lock);
    80002340:	8526                	mv	a0,s1
    80002342:	879fe0ef          	jal	ra,80000bba <acquire>
        if(pp->state == ZOMBIE){
    80002346:	4c9c                	lw	a5,24(s1)
    80002348:	f9478fe3          	beq	a5,s4,800022e6 <kwait+0x4e>
        release(&pp->lock);
    8000234c:	8526                	mv	a0,s1
    8000234e:	905fe0ef          	jal	ra,80000c52 <release>
        havekids = 1;
    80002352:	8756                	mv	a4,s5
    80002354:	bff9                	j	80002332 <kwait+0x9a>
    if(!havekids || killed(p)){
    80002356:	c709                	beqz	a4,80002360 <kwait+0xc8>
    80002358:	854a                	mv	a0,s2
    8000235a:	f15ff0ef          	jal	ra,8000226e <killed>
    8000235e:	c50d                	beqz	a0,80002388 <kwait+0xf0>
      release(&wait_lock);
    80002360:	0000d517          	auipc	a0,0xd
    80002364:	78050513          	addi	a0,a0,1920 # 8000fae0 <wait_lock>
    80002368:	8ebfe0ef          	jal	ra,80000c52 <release>
      return -1;
    8000236c:	59fd                	li	s3,-1
}
    8000236e:	854e                	mv	a0,s3
    80002370:	60a6                	ld	ra,72(sp)
    80002372:	6406                	ld	s0,64(sp)
    80002374:	74e2                	ld	s1,56(sp)
    80002376:	7942                	ld	s2,48(sp)
    80002378:	79a2                	ld	s3,40(sp)
    8000237a:	7a02                	ld	s4,32(sp)
    8000237c:	6ae2                	ld	s5,24(sp)
    8000237e:	6b42                	ld	s6,16(sp)
    80002380:	6ba2                	ld	s7,8(sp)
    80002382:	6c02                	ld	s8,0(sp)
    80002384:	6161                	addi	sp,sp,80
    80002386:	8082                	ret
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002388:	85e2                	mv	a1,s8
    8000238a:	854a                	mv	a0,s2
    8000238c:	c6bff0ef          	jal	ra,80001ff6 <sleep>
    havekids = 0;
    80002390:	b7a9                	j	800022da <kwait+0x42>

0000000080002392 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002392:	7179                	addi	sp,sp,-48
    80002394:	f406                	sd	ra,40(sp)
    80002396:	f022                	sd	s0,32(sp)
    80002398:	ec26                	sd	s1,24(sp)
    8000239a:	e84a                	sd	s2,16(sp)
    8000239c:	e44e                	sd	s3,8(sp)
    8000239e:	e052                	sd	s4,0(sp)
    800023a0:	1800                	addi	s0,sp,48
    800023a2:	84aa                	mv	s1,a0
    800023a4:	892e                	mv	s2,a1
    800023a6:	89b2                	mv	s3,a2
    800023a8:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800023aa:	cb0ff0ef          	jal	ra,8000185a <myproc>
  if(user_dst){
    800023ae:	cc99                	beqz	s1,800023cc <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    800023b0:	86d2                	mv	a3,s4
    800023b2:	864e                	mv	a2,s3
    800023b4:	85ca                	mv	a1,s2
    800023b6:	6928                	ld	a0,80(a0)
    800023b8:	9f0ff0ef          	jal	ra,800015a8 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    800023bc:	70a2                	ld	ra,40(sp)
    800023be:	7402                	ld	s0,32(sp)
    800023c0:	64e2                	ld	s1,24(sp)
    800023c2:	6942                	ld	s2,16(sp)
    800023c4:	69a2                	ld	s3,8(sp)
    800023c6:	6a02                	ld	s4,0(sp)
    800023c8:	6145                	addi	sp,sp,48
    800023ca:	8082                	ret
    memmove((char *)dst, src, len);
    800023cc:	000a061b          	sext.w	a2,s4
    800023d0:	85ce                	mv	a1,s3
    800023d2:	854a                	mv	a0,s2
    800023d4:	91bfe0ef          	jal	ra,80000cee <memmove>
    return 0;
    800023d8:	8526                	mv	a0,s1
    800023da:	b7cd                	j	800023bc <either_copyout+0x2a>

00000000800023dc <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800023dc:	7179                	addi	sp,sp,-48
    800023de:	f406                	sd	ra,40(sp)
    800023e0:	f022                	sd	s0,32(sp)
    800023e2:	ec26                	sd	s1,24(sp)
    800023e4:	e84a                	sd	s2,16(sp)
    800023e6:	e44e                	sd	s3,8(sp)
    800023e8:	e052                	sd	s4,0(sp)
    800023ea:	1800                	addi	s0,sp,48
    800023ec:	892a                	mv	s2,a0
    800023ee:	84ae                	mv	s1,a1
    800023f0:	89b2                	mv	s3,a2
    800023f2:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    800023f4:	c66ff0ef          	jal	ra,8000185a <myproc>
  if(user_src){
    800023f8:	cc99                	beqz	s1,80002416 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    800023fa:	86d2                	mv	a3,s4
    800023fc:	864e                	mv	a2,s3
    800023fe:	85ca                	mv	a1,s2
    80002400:	6928                	ld	a0,80(a0)
    80002402:	a6cff0ef          	jal	ra,8000166e <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80002406:	70a2                	ld	ra,40(sp)
    80002408:	7402                	ld	s0,32(sp)
    8000240a:	64e2                	ld	s1,24(sp)
    8000240c:	6942                	ld	s2,16(sp)
    8000240e:	69a2                	ld	s3,8(sp)
    80002410:	6a02                	ld	s4,0(sp)
    80002412:	6145                	addi	sp,sp,48
    80002414:	8082                	ret
    memmove(dst, (char*)src, len);
    80002416:	000a061b          	sext.w	a2,s4
    8000241a:	85ce                	mv	a1,s3
    8000241c:	854a                	mv	a0,s2
    8000241e:	8d1fe0ef          	jal	ra,80000cee <memmove>
    return 0;
    80002422:	8526                	mv	a0,s1
    80002424:	b7cd                	j	80002406 <either_copyin+0x2a>

0000000080002426 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80002426:	715d                	addi	sp,sp,-80
    80002428:	e486                	sd	ra,72(sp)
    8000242a:	e0a2                	sd	s0,64(sp)
    8000242c:	fc26                	sd	s1,56(sp)
    8000242e:	f84a                	sd	s2,48(sp)
    80002430:	f44e                	sd	s3,40(sp)
    80002432:	f052                	sd	s4,32(sp)
    80002434:	ec56                	sd	s5,24(sp)
    80002436:	e85a                	sd	s6,16(sp)
    80002438:	e45e                	sd	s7,8(sp)
    8000243a:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    8000243c:	00005517          	auipc	a0,0x5
    80002440:	c8450513          	addi	a0,a0,-892 # 800070c0 <digits+0x88>
    80002444:	884fe0ef          	jal	ra,800004c8 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002448:	0000e497          	auipc	s1,0xe
    8000244c:	c0848493          	addi	s1,s1,-1016 # 80010050 <proc+0x158>
    80002450:	00014917          	auipc	s2,0x14
    80002454:	00090913          	mv	s2,s2
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002458:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    8000245a:	00005997          	auipc	s3,0x5
    8000245e:	dbe98993          	addi	s3,s3,-578 # 80007218 <digits+0x1e0>
    printf("%d %s %s", p->pid, state, p->name);
    80002462:	00005a97          	auipc	s5,0x5
    80002466:	dbea8a93          	addi	s5,s5,-578 # 80007220 <digits+0x1e8>
    printf("\n");
    8000246a:	00005a17          	auipc	s4,0x5
    8000246e:	c56a0a13          	addi	s4,s4,-938 # 800070c0 <digits+0x88>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002472:	00005b97          	auipc	s7,0x5
    80002476:	e8eb8b93          	addi	s7,s7,-370 # 80007300 <nice_to_weight>
    8000247a:	a829                	j	80002494 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    8000247c:	ed86a583          	lw	a1,-296(a3)
    80002480:	8556                	mv	a0,s5
    80002482:	846fe0ef          	jal	ra,800004c8 <printf>
    printf("\n");
    80002486:	8552                	mv	a0,s4
    80002488:	840fe0ef          	jal	ra,800004c8 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    8000248c:	19048493          	addi	s1,s1,400
    80002490:	03248163          	beq	s1,s2,800024b2 <procdump+0x8c>
    if(p->state == UNUSED)
    80002494:	86a6                	mv	a3,s1
    80002496:	ec04a783          	lw	a5,-320(s1)
    8000249a:	dbed                	beqz	a5,8000248c <procdump+0x66>
      state = "???";
    8000249c:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000249e:	fcfb6fe3          	bltu	s6,a5,8000247c <procdump+0x56>
    800024a2:	1782                	slli	a5,a5,0x20
    800024a4:	9381                	srli	a5,a5,0x20
    800024a6:	078e                	slli	a5,a5,0x3
    800024a8:	97de                	add	a5,a5,s7
    800024aa:	73d0                	ld	a2,160(a5)
    800024ac:	fa61                	bnez	a2,8000247c <procdump+0x56>
      state = "???";
    800024ae:	864e                	mv	a2,s3
    800024b0:	b7f1                	j	8000247c <procdump+0x56>
  }
}
    800024b2:	60a6                	ld	ra,72(sp)
    800024b4:	6406                	ld	s0,64(sp)
    800024b6:	74e2                	ld	s1,56(sp)
    800024b8:	7942                	ld	s2,48(sp)
    800024ba:	79a2                	ld	s3,40(sp)
    800024bc:	7a02                	ld	s4,32(sp)
    800024be:	6ae2                	ld	s5,24(sp)
    800024c0:	6b42                	ld	s6,16(sp)
    800024c2:	6ba2                	ld	s7,8(sp)
    800024c4:	6161                	addi	sp,sp,80
    800024c6:	8082                	ret

00000000800024c8 <getnice>:
*/
// Reads and returns the nice value of the process with the given pid.
// Returns -1 if no matching process is found.
int
getnice(int pid)
{ 
    800024c8:	7179                	addi	sp,sp,-48
    800024ca:	f406                	sd	ra,40(sp)
    800024cc:	f022                	sd	s0,32(sp)
    800024ce:	ec26                	sd	s1,24(sp)
    800024d0:	e84a                	sd	s2,16(sp)
    800024d2:	e44e                	sd	s3,8(sp)
    800024d4:	1800                	addi	s0,sp,48
  if(pid <= 0) return -1;
    800024d6:	04a05763          	blez	a0,80002524 <getnice+0x5c>
    800024da:	892a                	mv	s2,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    800024dc:	0000e497          	auipc	s1,0xe
    800024e0:	a1c48493          	addi	s1,s1,-1508 # 8000fef8 <proc>
    800024e4:	00014997          	auipc	s3,0x14
    800024e8:	e1498993          	addi	s3,s3,-492 # 800162f8 <tickslock>
    acquire(&p->lock);
    800024ec:	8526                	mv	a0,s1
    800024ee:	eccfe0ef          	jal	ra,80000bba <acquire>
    if(p->pid == pid) {
    800024f2:	589c                	lw	a5,48(s1)
    800024f4:	01278b63          	beq	a5,s2,8000250a <getnice+0x42>
      int nice = p->nice;
      release(&p->lock);
      return nice;
    }
    release(&p->lock);
    800024f8:	8526                	mv	a0,s1
    800024fa:	f58fe0ef          	jal	ra,80000c52 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    800024fe:	19048493          	addi	s1,s1,400
    80002502:	ff3495e3          	bne	s1,s3,800024ec <getnice+0x24>
  }
  
  return -1;
    80002506:	597d                	li	s2,-1
    80002508:	a031                	j	80002514 <getnice+0x4c>
      int nice = p->nice;
    8000250a:	1684a903          	lw	s2,360(s1)
      release(&p->lock);
    8000250e:	8526                	mv	a0,s1
    80002510:	f42fe0ef          	jal	ra,80000c52 <release>
}
    80002514:	854a                	mv	a0,s2
    80002516:	70a2                	ld	ra,40(sp)
    80002518:	7402                	ld	s0,32(sp)
    8000251a:	64e2                	ld	s1,24(sp)
    8000251c:	6942                	ld	s2,16(sp)
    8000251e:	69a2                	ld	s3,8(sp)
    80002520:	6145                	addi	sp,sp,48
    80002522:	8082                	ret
  if(pid <= 0) return -1;
    80002524:	597d                	li	s2,-1
    80002526:	b7fd                	j	80002514 <getnice+0x4c>

0000000080002528 <setnice>:
// Sets the nice value of the process with the given pid.
// Returns 0 on success, -1 if pid not found or value is out of range(0~39).
int
setnice(int pid, int value)
{ 
  if(pid <= 0) return -1;
    80002528:	08a05c63          	blez	a0,800025c0 <setnice+0x98>
{ 
    8000252c:	7179                	addi	sp,sp,-48
    8000252e:	f406                	sd	ra,40(sp)
    80002530:	f022                	sd	s0,32(sp)
    80002532:	ec26                	sd	s1,24(sp)
    80002534:	e84a                	sd	s2,16(sp)
    80002536:	e44e                	sd	s3,8(sp)
    80002538:	e052                	sd	s4,0(sp)
    8000253a:	1800                	addi	s0,sp,48
    8000253c:	892a                	mv	s2,a0
    8000253e:	8a2e                	mv	s4,a1
  struct proc *p;

  if(value < 0 || value > 39)
    80002540:	0005879b          	sext.w	a5,a1
    80002544:	02700713          	li	a4,39
    80002548:	06f76e63          	bltu	a4,a5,800025c4 <setnice+0x9c>
    return -1;

  for(p = proc; p < &proc[NPROC]; p++) {
    8000254c:	0000e497          	auipc	s1,0xe
    80002550:	9ac48493          	addi	s1,s1,-1620 # 8000fef8 <proc>
    80002554:	00014997          	auipc	s3,0x14
    80002558:	da498993          	addi	s3,s3,-604 # 800162f8 <tickslock>
    acquire(&p->lock);
    8000255c:	8526                	mv	a0,s1
    8000255e:	e5cfe0ef          	jal	ra,80000bba <acquire>
    if(p->pid == pid) {
    80002562:	589c                	lw	a5,48(s1)
    80002564:	01278b63          	beq	a5,s2,8000257a <setnice+0x52>
      p->nice = value;
      p->vdeadline = p->vruntime + (uint64)p->timeslice * 1024 * 1000 / (uint64)nice_to_weight[p->nice];
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80002568:	8526                	mv	a0,s1
    8000256a:	ee8fe0ef          	jal	ra,80000c52 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000256e:	19048493          	addi	s1,s1,400
    80002572:	ff3495e3          	bne	s1,s3,8000255c <setnice+0x34>
  }

  return -1;
    80002576:	557d                	li	a0,-1
    80002578:	a825                	j	800025b0 <setnice+0x88>
      p->nice = value;
    8000257a:	1744a423          	sw	s4,360(s1)
      p->vdeadline = p->vruntime + (uint64)p->timeslice * 1024 * 1000 / (uint64)nice_to_weight[p->nice];
    8000257e:	1884a783          	lw	a5,392(s1)
    80002582:	000fa737          	lui	a4,0xfa
    80002586:	02e787b3          	mul	a5,a5,a4
    8000258a:	0a0a                	slli	s4,s4,0x2
    8000258c:	00005717          	auipc	a4,0x5
    80002590:	d7470713          	addi	a4,a4,-652 # 80007300 <nice_to_weight>
    80002594:	9a3a                	add	s4,s4,a4
    80002596:	000a2703          	lw	a4,0(s4)
    8000259a:	02e7d7b3          	divu	a5,a5,a4
    8000259e:	1784b703          	ld	a4,376(s1)
    800025a2:	97ba                	add	a5,a5,a4
    800025a4:	18f4b023          	sd	a5,384(s1)
      release(&p->lock);
    800025a8:	8526                	mv	a0,s1
    800025aa:	ea8fe0ef          	jal	ra,80000c52 <release>
      return 0;
    800025ae:	4501                	li	a0,0
}
    800025b0:	70a2                	ld	ra,40(sp)
    800025b2:	7402                	ld	s0,32(sp)
    800025b4:	64e2                	ld	s1,24(sp)
    800025b6:	6942                	ld	s2,16(sp)
    800025b8:	69a2                	ld	s3,8(sp)
    800025ba:	6a02                	ld	s4,0(sp)
    800025bc:	6145                	addi	sp,sp,48
    800025be:	8082                	ret
  if(pid <= 0) return -1;
    800025c0:	557d                	li	a0,-1
}
    800025c2:	8082                	ret
    return -1;
    800025c4:	557d                	li	a0,-1
    800025c6:	b7ed                	j	800025b0 <setnice+0x88>

00000000800025c8 <ps>:
*/
// Prints process information (name, pid, state, priority).
// If pid is 0, prints all processes. Otherwise prints only the matching process.
void
ps(int pid)
{
    800025c8:	7159                	addi	sp,sp,-112
    800025ca:	f486                	sd	ra,104(sp)
    800025cc:	f0a2                	sd	s0,96(sp)
    800025ce:	eca6                	sd	s1,88(sp)
    800025d0:	e8ca                	sd	s2,80(sp)
    800025d2:	e4ce                	sd	s3,72(sp)
    800025d4:	e0d2                	sd	s4,64(sp)
    800025d6:	fc56                	sd	s5,56(sp)
    800025d8:	f85a                	sd	s6,48(sp)
    800025da:	f45e                	sd	s7,40(sp)
    800025dc:	f062                	sd	s8,32(sp)
    800025de:	ec66                	sd	s9,24(sp)
    800025e0:	e86a                	sd	s10,16(sp)
    800025e2:	e46e                	sd	s11,8(sp)
    800025e4:	1880                	addi	s0,sp,112
    800025e6:	89aa                	mv	s3,a0
  struct proc *p;
  extern uint ticks;

  printf("name\tpid\tstate\t\tnice\truntime/w\truntime\t\tvruntime\tvdeadline\teligible\ttick\n");
    800025e8:	00005517          	auipc	a0,0x5
    800025ec:	c8050513          	addi	a0,a0,-896 # 80007268 <digits+0x230>
    800025f0:	ed9fd0ef          	jal	ra,800004c8 <printf>

  for(p = proc; p < &proc[NPROC]; p++) {
    800025f4:	0000e497          	auipc	s1,0xe
    800025f8:	90448493          	addi	s1,s1,-1788 # 8000fef8 <proc>
      if(p->state == UNUSED) {
        release(&p->lock);
        continue;
      }
      char *state;
      if(p->state == SLEEPING)      state = "SLEEPING";
    800025fc:	00005c17          	auipc	s8,0x5
    80002600:	c44c0c13          	addi	s8,s8,-956 # 80007240 <digits+0x208>
      else if(p->state == RUNNABLE) state = "RUNNABLE";
      else if(p->state == RUNNING)  state = "RUNNING";
      else if(p->state == ZOMBIE)   state = "ZOMBIE";
      else                          state = "USED";

      uint64 w = (uint64)nice_to_weight[p->nice];
    80002604:	00005b97          	auipc	s7,0x5
    80002608:	cfcb8b93          	addi	s7,s7,-772 # 80007300 <nice_to_weight>
      printf("%d\t", (int)rw);
      printf("%d\t", (int)p->runtime);
      printf("%d\t", (int)p->vruntime);
      printf("%d\t", (int)p->vdeadline);
      printf("%d\t", p->is_eligible);
      printf("%d\n", (int)((uint64)ticks * 1000));
    8000260c:	00005b17          	auipc	s6,0x5
    80002610:	3bcb0b13          	addi	s6,s6,956 # 800079c8 <ticks>
      else if(p->state == RUNNABLE) state = "RUNNABLE";
    80002614:	00005c97          	auipc	s9,0x5
    80002618:	c3cc8c93          	addi	s9,s9,-964 # 80007250 <digits+0x218>
      else if(p->state == RUNNING)  state = "RUNNING";
    8000261c:	00005d17          	auipc	s10,0x5
    80002620:	c14d0d13          	addi	s10,s10,-1004 # 80007230 <digits+0x1f8>
      else if(p->state == ZOMBIE)   state = "ZOMBIE";
    80002624:	00005d97          	auipc	s11,0x5
    80002628:	c14d8d93          	addi	s11,s11,-1004 # 80007238 <digits+0x200>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000262c:	00014a97          	auipc	s5,0x14
    80002630:	ccca8a93          	addi	s5,s5,-820 # 800162f8 <tickslock>
    80002634:	a05d                	j	800026da <ps+0x112>
        release(&p->lock);
    80002636:	8526                	mv	a0,s1
    80002638:	e1afe0ef          	jal	ra,80000c52 <release>
        continue;
    8000263c:	a859                	j	800026d2 <ps+0x10a>
      uint64 w = (uint64)nice_to_weight[p->nice];
    8000263e:	1684a703          	lw	a4,360(s1)
    80002642:	00271793          	slli	a5,a4,0x2
    80002646:	97de                	add	a5,a5,s7
    80002648:	439c                	lw	a5,0(a5)
      uint64 rw = p->runtime / w;
    8000264a:	1704b903          	ld	s2,368(s1)
    8000264e:	02f95933          	divu	s2,s2,a5
      printf("%s\t%d\t%s\t%d\t", p->name, p->pid, state, p->nice);
    80002652:	5890                	lw	a2,48(s1)
    80002654:	158a0593          	addi	a1,s4,344
    80002658:	00005517          	auipc	a0,0x5
    8000265c:	c6050513          	addi	a0,a0,-928 # 800072b8 <digits+0x280>
    80002660:	e69fd0ef          	jal	ra,800004c8 <printf>
      printf("%d\t", (int)rw);
    80002664:	0009059b          	sext.w	a1,s2
    80002668:	00005517          	auipc	a0,0x5
    8000266c:	c6050513          	addi	a0,a0,-928 # 800072c8 <digits+0x290>
    80002670:	e59fd0ef          	jal	ra,800004c8 <printf>
      printf("%d\t", (int)p->runtime);
    80002674:	1704a583          	lw	a1,368(s1)
    80002678:	00005517          	auipc	a0,0x5
    8000267c:	c5050513          	addi	a0,a0,-944 # 800072c8 <digits+0x290>
    80002680:	e49fd0ef          	jal	ra,800004c8 <printf>
      printf("%d\t", (int)p->vruntime);
    80002684:	1784a583          	lw	a1,376(s1)
    80002688:	00005517          	auipc	a0,0x5
    8000268c:	c4050513          	addi	a0,a0,-960 # 800072c8 <digits+0x290>
    80002690:	e39fd0ef          	jal	ra,800004c8 <printf>
      printf("%d\t", (int)p->vdeadline);
    80002694:	1804a583          	lw	a1,384(s1)
    80002698:	00005517          	auipc	a0,0x5
    8000269c:	c3050513          	addi	a0,a0,-976 # 800072c8 <digits+0x290>
    800026a0:	e29fd0ef          	jal	ra,800004c8 <printf>
      printf("%d\t", p->is_eligible);
    800026a4:	18c4a583          	lw	a1,396(s1)
    800026a8:	00005517          	auipc	a0,0x5
    800026ac:	c2050513          	addi	a0,a0,-992 # 800072c8 <digits+0x290>
    800026b0:	e19fd0ef          	jal	ra,800004c8 <printf>
      printf("%d\n", (int)((uint64)ticks * 1000));
    800026b4:	000b2783          	lw	a5,0(s6)
    800026b8:	3e800593          	li	a1,1000
    800026bc:	02f585bb          	mulw	a1,a1,a5
    800026c0:	00005517          	auipc	a0,0x5
    800026c4:	e5050513          	addi	a0,a0,-432 # 80007510 <states.1772+0x170>
    800026c8:	e01fd0ef          	jal	ra,800004c8 <printf>
    }
    release(&p->lock);
    800026cc:	8526                	mv	a0,s1
    800026ce:	d84fe0ef          	jal	ra,80000c52 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    800026d2:	19048493          	addi	s1,s1,400
    800026d6:	05548263          	beq	s1,s5,8000271a <ps+0x152>
    acquire(&p->lock);
    800026da:	8a26                	mv	s4,s1
    800026dc:	8526                	mv	a0,s1
    800026de:	cdcfe0ef          	jal	ra,80000bba <acquire>
    if(pid == 0 || p->pid == pid) {
    800026e2:	00098563          	beqz	s3,800026ec <ps+0x124>
    800026e6:	589c                	lw	a5,48(s1)
    800026e8:	ff3792e3          	bne	a5,s3,800026cc <ps+0x104>
      if(p->state == UNUSED) {
    800026ec:	4c9c                	lw	a5,24(s1)
    800026ee:	d7a1                	beqz	a5,80002636 <ps+0x6e>
      if(p->state == SLEEPING)      state = "SLEEPING";
    800026f0:	4709                	li	a4,2
    800026f2:	86e2                	mv	a3,s8
    800026f4:	f4e785e3          	beq	a5,a4,8000263e <ps+0x76>
      else if(p->state == RUNNABLE) state = "RUNNABLE";
    800026f8:	470d                	li	a4,3
    800026fa:	86e6                	mv	a3,s9
    800026fc:	f4e781e3          	beq	a5,a4,8000263e <ps+0x76>
      else if(p->state == RUNNING)  state = "RUNNING";
    80002700:	4711                	li	a4,4
    80002702:	86ea                	mv	a3,s10
    80002704:	f2e78de3          	beq	a5,a4,8000263e <ps+0x76>
      else if(p->state == ZOMBIE)   state = "ZOMBIE";
    80002708:	4715                	li	a4,5
    8000270a:	86ee                	mv	a3,s11
    8000270c:	f2e789e3          	beq	a5,a4,8000263e <ps+0x76>
      else                          state = "USED";
    80002710:	00005697          	auipc	a3,0x5
    80002714:	b5068693          	addi	a3,a3,-1200 # 80007260 <digits+0x228>
    80002718:	b71d                	j	8000263e <ps+0x76>
  }
}
    8000271a:	70a6                	ld	ra,104(sp)
    8000271c:	7406                	ld	s0,96(sp)
    8000271e:	64e6                	ld	s1,88(sp)
    80002720:	6946                	ld	s2,80(sp)
    80002722:	69a6                	ld	s3,72(sp)
    80002724:	6a06                	ld	s4,64(sp)
    80002726:	7ae2                	ld	s5,56(sp)
    80002728:	7b42                	ld	s6,48(sp)
    8000272a:	7ba2                	ld	s7,40(sp)
    8000272c:	7c02                	ld	s8,32(sp)
    8000272e:	6ce2                	ld	s9,24(sp)
    80002730:	6d42                	ld	s10,16(sp)
    80002732:	6da2                	ld	s11,8(sp)
    80002734:	6165                	addi	sp,sp,112
    80002736:	8082                	ret

0000000080002738 <waitpid>:
*/
// Suspends execution until the specified child process terminates.
// Returns 0 on success, -1 if pid not found or caller is not the parent.
int
waitpid(int pid)
{
    80002738:	7179                	addi	sp,sp,-48
    8000273a:	f406                	sd	ra,40(sp)
    8000273c:	f022                	sd	s0,32(sp)
    8000273e:	ec26                	sd	s1,24(sp)
    80002740:	e84a                	sd	s2,16(sp)
    80002742:	e44e                	sd	s3,8(sp)
    80002744:	e052                	sd	s4,0(sp)
    80002746:	1800                	addi	s0,sp,48
    80002748:	892a                	mv	s2,a0
  struct proc *p;
  struct proc *curr = myproc();
    8000274a:	910ff0ef          	jal	ra,8000185a <myproc>
    8000274e:	8a2a                	mv	s4,a0

  for(p = proc; p < &proc[NPROC]; p++) {
    80002750:	0000d497          	auipc	s1,0xd
    80002754:	7a848493          	addi	s1,s1,1960 # 8000fef8 <proc>
    80002758:	00014997          	auipc	s3,0x14
    8000275c:	ba098993          	addi	s3,s3,-1120 # 800162f8 <tickslock>
    acquire(&p->lock);
    80002760:	8526                	mv	a0,s1
    80002762:	c58fe0ef          	jal	ra,80000bba <acquire>
    if(p->pid == pid) {
    80002766:	589c                	lw	a5,48(s1)
    80002768:	01278b63          	beq	a5,s2,8000277e <waitpid+0x46>
        sleep(curr, &p->lock);
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    8000276c:	8526                	mv	a0,s1
    8000276e:	ce4fe0ef          	jal	ra,80000c52 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80002772:	19048493          	addi	s1,s1,400
    80002776:	ff3495e3          	bne	s1,s3,80002760 <waitpid+0x28>
  }

  return -1;
    8000277a:	557d                	li	a0,-1
    8000277c:	a02d                	j	800027a6 <waitpid+0x6e>
      if(p->parent != curr) {
    8000277e:	7c9c                	ld	a5,56(s1)
    80002780:	03479b63          	bne	a5,s4,800027b6 <waitpid+0x7e>
      while(p->state != ZOMBIE && p->state != UNUSED) {
    80002784:	4c9c                	lw	a5,24(s1)
    80002786:	4715                	li	a4,5
    80002788:	4915                	li	s2,5
    8000278a:	00e78a63          	beq	a5,a4,8000279e <waitpid+0x66>
    8000278e:	cb81                	beqz	a5,8000279e <waitpid+0x66>
        sleep(curr, &p->lock);
    80002790:	85a6                	mv	a1,s1
    80002792:	8552                	mv	a0,s4
    80002794:	863ff0ef          	jal	ra,80001ff6 <sleep>
      while(p->state != ZOMBIE && p->state != UNUSED) {
    80002798:	4c9c                	lw	a5,24(s1)
    8000279a:	ff279ae3          	bne	a5,s2,8000278e <waitpid+0x56>
      release(&p->lock);
    8000279e:	8526                	mv	a0,s1
    800027a0:	cb2fe0ef          	jal	ra,80000c52 <release>
      return 0;
    800027a4:	4501                	li	a0,0
}
    800027a6:	70a2                	ld	ra,40(sp)
    800027a8:	7402                	ld	s0,32(sp)
    800027aa:	64e2                	ld	s1,24(sp)
    800027ac:	6942                	ld	s2,16(sp)
    800027ae:	69a2                	ld	s3,8(sp)
    800027b0:	6a02                	ld	s4,0(sp)
    800027b2:	6145                	addi	sp,sp,48
    800027b4:	8082                	ret
        release(&p->lock);
    800027b6:	8526                	mv	a0,s1
    800027b8:	c9afe0ef          	jal	ra,80000c52 <release>
        return -1;
    800027bc:	557d                	li	a0,-1
    800027be:	b7e5                	j	800027a6 <waitpid+0x6e>

00000000800027c0 <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    800027c0:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    800027c4:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    800027c8:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    800027ca:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    800027cc:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    800027d0:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    800027d4:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    800027d8:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    800027dc:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    800027e0:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    800027e4:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    800027e8:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    800027ec:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    800027f0:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    800027f4:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    800027f8:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    800027fc:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    800027fe:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    80002800:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    80002804:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    80002808:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    8000280c:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    80002810:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    80002814:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    80002818:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    8000281c:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    80002820:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    80002824:	0685bd83          	ld	s11,104(a1)
        
        ret
    80002828:	8082                	ret

000000008000282a <trapinit>:

extern int devintr();

void
trapinit(void)
{
    8000282a:	1141                	addi	sp,sp,-16
    8000282c:	e406                	sd	ra,8(sp)
    8000282e:	e022                	sd	s0,0(sp)
    80002830:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80002832:	00005597          	auipc	a1,0x5
    80002836:	b9e58593          	addi	a1,a1,-1122 # 800073d0 <states.1772+0x30>
    8000283a:	00014517          	auipc	a0,0x14
    8000283e:	abe50513          	addi	a0,a0,-1346 # 800162f8 <tickslock>
    80002842:	af8fe0ef          	jal	ra,80000b3a <initlock>
}
    80002846:	60a2                	ld	ra,8(sp)
    80002848:	6402                	ld	s0,0(sp)
    8000284a:	0141                	addi	sp,sp,16
    8000284c:	8082                	ret

000000008000284e <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    8000284e:	1141                	addi	sp,sp,-16
    80002850:	e422                	sd	s0,8(sp)
    80002852:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002854:	00003797          	auipc	a5,0x3
    80002858:	f6c78793          	addi	a5,a5,-148 # 800057c0 <kernelvec>
    8000285c:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80002860:	6422                	ld	s0,8(sp)
    80002862:	0141                	addi	sp,sp,16
    80002864:	8082                	ret

0000000080002866 <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    80002866:	1141                	addi	sp,sp,-16
    80002868:	e406                	sd	ra,8(sp)
    8000286a:	e022                	sd	s0,0(sp)
    8000286c:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    8000286e:	fedfe0ef          	jal	ra,8000185a <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002872:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80002876:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002878:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    8000287c:	04000737          	lui	a4,0x4000
    80002880:	00003797          	auipc	a5,0x3
    80002884:	78078793          	addi	a5,a5,1920 # 80006000 <_trampoline>
    80002888:	00003697          	auipc	a3,0x3
    8000288c:	77868693          	addi	a3,a3,1912 # 80006000 <_trampoline>
    80002890:	8f95                	sub	a5,a5,a3
    80002892:	177d                	addi	a4,a4,-1
    80002894:	0732                	slli	a4,a4,0xc
    80002896:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002898:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    8000289c:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    8000289e:	18002773          	csrr	a4,satp
    800028a2:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    800028a4:	6d38                	ld	a4,88(a0)
    800028a6:	613c                	ld	a5,64(a0)
    800028a8:	6685                	lui	a3,0x1
    800028aa:	97b6                	add	a5,a5,a3
    800028ac:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    800028ae:	6d3c                	ld	a5,88(a0)
    800028b0:	00000717          	auipc	a4,0x0
    800028b4:	0f270713          	addi	a4,a4,242 # 800029a2 <usertrap>
    800028b8:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    800028ba:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    800028bc:	8712                	mv	a4,tp
    800028be:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800028c0:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    800028c4:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    800028c8:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800028cc:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    800028d0:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    800028d2:	6f9c                	ld	a5,24(a5)
    800028d4:	14179073          	csrw	sepc,a5
}
    800028d8:	60a2                	ld	ra,8(sp)
    800028da:	6402                	ld	s0,0(sp)
    800028dc:	0141                	addi	sp,sp,16
    800028de:	8082                	ret

00000000800028e0 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800028e0:	1101                	addi	sp,sp,-32
    800028e2:	ec06                	sd	ra,24(sp)
    800028e4:	e822                	sd	s0,16(sp)
    800028e6:	e426                	sd	s1,8(sp)
    800028e8:	1000                	addi	s0,sp,32
  if(cpuid() == 0){
    800028ea:	f45fe0ef          	jal	ra,8000182e <cpuid>
    800028ee:	cd11                	beqz	a0,8000290a <clockintr+0x2a>
  asm volatile("csrr %0, time" : "=r" (x) );
    800028f0:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 100000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 100000);
    800028f4:	6761                	lui	a4,0x18
    800028f6:	6a070713          	addi	a4,a4,1696 # 186a0 <_entry-0x7ffe7960>
    800028fa:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    800028fc:	14d79073          	csrw	0x14d,a5
}
    80002900:	60e2                	ld	ra,24(sp)
    80002902:	6442                	ld	s0,16(sp)
    80002904:	64a2                	ld	s1,8(sp)
    80002906:	6105                	addi	sp,sp,32
    80002908:	8082                	ret
    acquire(&tickslock);
    8000290a:	00014497          	auipc	s1,0x14
    8000290e:	9ee48493          	addi	s1,s1,-1554 # 800162f8 <tickslock>
    80002912:	8526                	mv	a0,s1
    80002914:	aa6fe0ef          	jal	ra,80000bba <acquire>
    ticks++;
    80002918:	00005517          	auipc	a0,0x5
    8000291c:	0b050513          	addi	a0,a0,176 # 800079c8 <ticks>
    80002920:	411c                	lw	a5,0(a0)
    80002922:	2785                	addiw	a5,a5,1
    80002924:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    80002926:	f1cff0ef          	jal	ra,80002042 <wakeup>
    release(&tickslock);
    8000292a:	8526                	mv	a0,s1
    8000292c:	b26fe0ef          	jal	ra,80000c52 <release>
    80002930:	b7c1                	j	800028f0 <clockintr+0x10>

0000000080002932 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80002932:	1101                	addi	sp,sp,-32
    80002934:	ec06                	sd	ra,24(sp)
    80002936:	e822                	sd	s0,16(sp)
    80002938:	e426                	sd	s1,8(sp)
    8000293a:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000293c:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    80002940:	57fd                	li	a5,-1
    80002942:	17fe                	slli	a5,a5,0x3f
    80002944:	07a5                	addi	a5,a5,9
    80002946:	00f70d63          	beq	a4,a5,80002960 <devintr+0x2e>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    8000294a:	57fd                	li	a5,-1
    8000294c:	17fe                	slli	a5,a5,0x3f
    8000294e:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80002950:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80002952:	04f70463          	beq	a4,a5,8000299a <devintr+0x68>
  }
}
    80002956:	60e2                	ld	ra,24(sp)
    80002958:	6442                	ld	s0,16(sp)
    8000295a:	64a2                	ld	s1,8(sp)
    8000295c:	6105                	addi	sp,sp,32
    8000295e:	8082                	ret
    int irq = plic_claim();
    80002960:	709020ef          	jal	ra,80005868 <plic_claim>
    80002964:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80002966:	47a9                	li	a5,10
    80002968:	02f50363          	beq	a0,a5,8000298e <devintr+0x5c>
    } else if(irq == VIRTIO0_IRQ){
    8000296c:	4785                	li	a5,1
    8000296e:	02f50363          	beq	a0,a5,80002994 <devintr+0x62>
    return 1;
    80002972:	4505                	li	a0,1
    } else if(irq){
    80002974:	d0ed                	beqz	s1,80002956 <devintr+0x24>
      printf("unexpected interrupt irq=%d\n", irq);
    80002976:	85a6                	mv	a1,s1
    80002978:	00005517          	auipc	a0,0x5
    8000297c:	a6050513          	addi	a0,a0,-1440 # 800073d8 <states.1772+0x38>
    80002980:	b49fd0ef          	jal	ra,800004c8 <printf>
      plic_complete(irq);
    80002984:	8526                	mv	a0,s1
    80002986:	703020ef          	jal	ra,80005888 <plic_complete>
    return 1;
    8000298a:	4505                	li	a0,1
    8000298c:	b7e9                	j	80002956 <devintr+0x24>
      uartintr();
    8000298e:	fd3fd0ef          	jal	ra,80000960 <uartintr>
    80002992:	bfcd                	j	80002984 <devintr+0x52>
      virtio_disk_intr();
    80002994:	3ba030ef          	jal	ra,80005d4e <virtio_disk_intr>
    80002998:	b7f5                	j	80002984 <devintr+0x52>
    clockintr();
    8000299a:	f47ff0ef          	jal	ra,800028e0 <clockintr>
    return 2;
    8000299e:	4509                	li	a0,2
    800029a0:	bf5d                	j	80002956 <devintr+0x24>

00000000800029a2 <usertrap>:
{
    800029a2:	1101                	addi	sp,sp,-32
    800029a4:	ec06                	sd	ra,24(sp)
    800029a6:	e822                	sd	s0,16(sp)
    800029a8:	e426                	sd	s1,8(sp)
    800029aa:	e04a                	sd	s2,0(sp)
    800029ac:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800029ae:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    800029b2:	1007f793          	andi	a5,a5,256
    800029b6:	eba5                	bnez	a5,80002a26 <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r" (x));
    800029b8:	00003797          	auipc	a5,0x3
    800029bc:	e0878793          	addi	a5,a5,-504 # 800057c0 <kernelvec>
    800029c0:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    800029c4:	e97fe0ef          	jal	ra,8000185a <myproc>
    800029c8:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    800029ca:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800029cc:	14102773          	csrr	a4,sepc
    800029d0:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    800029d2:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    800029d6:	47a1                	li	a5,8
    800029d8:	04f70d63          	beq	a4,a5,80002a32 <usertrap+0x90>
  } else if((which_dev = devintr()) != 0){
    800029dc:	f57ff0ef          	jal	ra,80002932 <devintr>
    800029e0:	892a                	mv	s2,a0
    800029e2:	e945                	bnez	a0,80002a92 <usertrap+0xf0>
    800029e4:	14202773          	csrr	a4,scause
  } else if((r_scause() == 15 || r_scause() == 13) &&
    800029e8:	47bd                	li	a5,15
    800029ea:	08f70863          	beq	a4,a5,80002a7a <usertrap+0xd8>
    800029ee:	14202773          	csrr	a4,scause
    800029f2:	47b5                	li	a5,13
    800029f4:	08f70363          	beq	a4,a5,80002a7a <usertrap+0xd8>
    800029f8:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    800029fc:	5890                	lw	a2,48(s1)
    800029fe:	00005517          	auipc	a0,0x5
    80002a02:	a1a50513          	addi	a0,a0,-1510 # 80007418 <states.1772+0x78>
    80002a06:	ac3fd0ef          	jal	ra,800004c8 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002a0a:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002a0e:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80002a12:	00005517          	auipc	a0,0x5
    80002a16:	a3650513          	addi	a0,a0,-1482 # 80007448 <states.1772+0xa8>
    80002a1a:	aaffd0ef          	jal	ra,800004c8 <printf>
    setkilled(p);
    80002a1e:	8526                	mv	a0,s1
    80002a20:	82bff0ef          	jal	ra,8000224a <setkilled>
    80002a24:	a035                	j	80002a50 <usertrap+0xae>
    panic("usertrap: not from user mode");
    80002a26:	00005517          	auipc	a0,0x5
    80002a2a:	9d250513          	addi	a0,a0,-1582 # 800073f8 <states.1772+0x58>
    80002a2e:	d61fd0ef          	jal	ra,8000078e <panic>
    if(killed(p))
    80002a32:	83dff0ef          	jal	ra,8000226e <killed>
    80002a36:	ed15                	bnez	a0,80002a72 <usertrap+0xd0>
    p->trapframe->epc += 4;
    80002a38:	6cb8                	ld	a4,88(s1)
    80002a3a:	6f1c                	ld	a5,24(a4)
    80002a3c:	0791                	addi	a5,a5,4
    80002a3e:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002a40:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80002a44:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002a48:	10079073          	csrw	sstatus,a5
    syscall();
    80002a4c:	2a0000ef          	jal	ra,80002cec <syscall>
  if(killed(p))
    80002a50:	8526                	mv	a0,s1
    80002a52:	81dff0ef          	jal	ra,8000226e <killed>
    80002a56:	e139                	bnez	a0,80002a9c <usertrap+0xfa>
  prepare_return();
    80002a58:	e0fff0ef          	jal	ra,80002866 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80002a5c:	68a8                	ld	a0,80(s1)
    80002a5e:	8131                	srli	a0,a0,0xc
    80002a60:	57fd                	li	a5,-1
    80002a62:	17fe                	slli	a5,a5,0x3f
    80002a64:	8d5d                	or	a0,a0,a5
}
    80002a66:	60e2                	ld	ra,24(sp)
    80002a68:	6442                	ld	s0,16(sp)
    80002a6a:	64a2                	ld	s1,8(sp)
    80002a6c:	6902                	ld	s2,0(sp)
    80002a6e:	6105                	addi	sp,sp,32
    80002a70:	8082                	ret
      kexit(-1);
    80002a72:	557d                	li	a0,-1
    80002a74:	eceff0ef          	jal	ra,80002142 <kexit>
    80002a78:	b7c1                	j	80002a38 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002a7a:	143025f3          	csrr	a1,stval
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002a7e:	14202673          	csrr	a2,scause
            vmfault(p->pagetable, r_stval(), (r_scause() == 13)? 1 : 0) != 0) {
    80002a82:	164d                	addi	a2,a2,-13
    80002a84:	00163613          	seqz	a2,a2
    80002a88:	68a8                	ld	a0,80(s1)
    80002a8a:	aadfe0ef          	jal	ra,80001536 <vmfault>
  } else if((r_scause() == 15 || r_scause() == 13) &&
    80002a8e:	f169                	bnez	a0,80002a50 <usertrap+0xae>
    80002a90:	b7a5                	j	800029f8 <usertrap+0x56>
  if(killed(p))
    80002a92:	8526                	mv	a0,s1
    80002a94:	fdaff0ef          	jal	ra,8000226e <killed>
    80002a98:	c511                	beqz	a0,80002aa4 <usertrap+0x102>
    80002a9a:	a011                	j	80002a9e <usertrap+0xfc>
    80002a9c:	4901                	li	s2,0
    kexit(-1);
    80002a9e:	557d                	li	a0,-1
    80002aa0:	ea2ff0ef          	jal	ra,80002142 <kexit>
  if(which_dev == 2) {
    80002aa4:	4789                	li	a5,2
    80002aa6:	faf919e3          	bne	s2,a5,80002a58 <usertrap+0xb6>
    p->runtime += 1000;
    80002aaa:	1704b783          	ld	a5,368(s1)
    80002aae:	3e878793          	addi	a5,a5,1000
    80002ab2:	16f4b823          	sd	a5,368(s1)
    p->vruntime += (uint64)1024 * 1000 / nice_to_weight[p->nice];
    80002ab6:	1684a783          	lw	a5,360(s1)
    80002aba:	00279713          	slli	a4,a5,0x2
    80002abe:	00005797          	auipc	a5,0x5
    80002ac2:	84278793          	addi	a5,a5,-1982 # 80007300 <nice_to_weight>
    80002ac6:	97ba                	add	a5,a5,a4
    80002ac8:	4394                	lw	a3,0(a5)
    80002aca:	000fa7b7          	lui	a5,0xfa
    80002ace:	02d7d7b3          	divu	a5,a5,a3
    80002ad2:	1784b703          	ld	a4,376(s1)
    80002ad6:	97ba                	add	a5,a5,a4
    80002ad8:	16f4bc23          	sd	a5,376(s1)
    p->timeslice--;
    80002adc:	1884a703          	lw	a4,392(s1)
    80002ae0:	377d                	addiw	a4,a4,-1
    80002ae2:	0007061b          	sext.w	a2,a4
    if(p->timeslice <= 0) {
    80002ae6:	00c05563          	blez	a2,80002af0 <usertrap+0x14e>
    p->timeslice--;
    80002aea:	18e4a423          	sw	a4,392(s1)
    80002aee:	b7ad                	j	80002a58 <usertrap+0xb6>
        p->timeslice = 5;
    80002af0:	4715                	li	a4,5
    80002af2:	18e4a423          	sw	a4,392(s1)
        p->vdeadline = p->vruntime + (uint64)5 * 1024 * 1000 / nice_to_weight[p->nice];
    80002af6:	004e2737          	lui	a4,0x4e2
    80002afa:	02d756b3          	divu	a3,a4,a3
    80002afe:	97b6                	add	a5,a5,a3
    80002b00:	18f4b023          	sd	a5,384(s1)
        yield();
    80002b04:	cc6ff0ef          	jal	ra,80001fca <yield>
    80002b08:	bf81                	j	80002a58 <usertrap+0xb6>

0000000080002b0a <kerneltrap>:
{
    80002b0a:	7179                	addi	sp,sp,-48
    80002b0c:	f406                	sd	ra,40(sp)
    80002b0e:	f022                	sd	s0,32(sp)
    80002b10:	ec26                	sd	s1,24(sp)
    80002b12:	e84a                	sd	s2,16(sp)
    80002b14:	e44e                	sd	s3,8(sp)
    80002b16:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002b18:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002b1c:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002b20:	142029f3          	csrr	s3,scause
  if((sstatus & SSTATUS_SPP) == 0)
    80002b24:	1004f793          	andi	a5,s1,256
    80002b28:	c795                	beqz	a5,80002b54 <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002b2a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002b2e:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80002b30:	eb85                	bnez	a5,80002b60 <kerneltrap+0x56>
  if((which_dev = devintr()) == 0){
    80002b32:	e01ff0ef          	jal	ra,80002932 <devintr>
    80002b36:	c91d                	beqz	a0,80002b6c <kerneltrap+0x62>
  if(which_dev == 2 && myproc() != 0)
    80002b38:	4789                	li	a5,2
    80002b3a:	04f50a63          	beq	a0,a5,80002b8e <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80002b3e:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002b42:	10049073          	csrw	sstatus,s1
}
    80002b46:	70a2                	ld	ra,40(sp)
    80002b48:	7402                	ld	s0,32(sp)
    80002b4a:	64e2                	ld	s1,24(sp)
    80002b4c:	6942                	ld	s2,16(sp)
    80002b4e:	69a2                	ld	s3,8(sp)
    80002b50:	6145                	addi	sp,sp,48
    80002b52:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002b54:	00005517          	auipc	a0,0x5
    80002b58:	91c50513          	addi	a0,a0,-1764 # 80007470 <states.1772+0xd0>
    80002b5c:	c33fd0ef          	jal	ra,8000078e <panic>
    panic("kerneltrap: interrupts enabled");
    80002b60:	00005517          	auipc	a0,0x5
    80002b64:	93850513          	addi	a0,a0,-1736 # 80007498 <states.1772+0xf8>
    80002b68:	c27fd0ef          	jal	ra,8000078e <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002b6c:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002b70:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80002b74:	85ce                	mv	a1,s3
    80002b76:	00005517          	auipc	a0,0x5
    80002b7a:	94250513          	addi	a0,a0,-1726 # 800074b8 <states.1772+0x118>
    80002b7e:	94bfd0ef          	jal	ra,800004c8 <printf>
    panic("kerneltrap");
    80002b82:	00005517          	auipc	a0,0x5
    80002b86:	95e50513          	addi	a0,a0,-1698 # 800074e0 <states.1772+0x140>
    80002b8a:	c05fd0ef          	jal	ra,8000078e <panic>
  if(which_dev == 2 && myproc() != 0)
    80002b8e:	ccdfe0ef          	jal	ra,8000185a <myproc>
    80002b92:	d555                	beqz	a0,80002b3e <kerneltrap+0x34>
    yield();
    80002b94:	c36ff0ef          	jal	ra,80001fca <yield>
    80002b98:	b75d                	j	80002b3e <kerneltrap+0x34>

0000000080002b9a <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002b9a:	1101                	addi	sp,sp,-32
    80002b9c:	ec06                	sd	ra,24(sp)
    80002b9e:	e822                	sd	s0,16(sp)
    80002ba0:	e426                	sd	s1,8(sp)
    80002ba2:	1000                	addi	s0,sp,32
    80002ba4:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002ba6:	cb5fe0ef          	jal	ra,8000185a <myproc>
  switch (n) {
    80002baa:	4795                	li	a5,5
    80002bac:	0497e163          	bltu	a5,s1,80002bee <argraw+0x54>
    80002bb0:	048a                	slli	s1,s1,0x2
    80002bb2:	00005717          	auipc	a4,0x5
    80002bb6:	96670713          	addi	a4,a4,-1690 # 80007518 <states.1772+0x178>
    80002bba:	94ba                	add	s1,s1,a4
    80002bbc:	409c                	lw	a5,0(s1)
    80002bbe:	97ba                	add	a5,a5,a4
    80002bc0:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002bc2:	6d3c                	ld	a5,88(a0)
    80002bc4:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002bc6:	60e2                	ld	ra,24(sp)
    80002bc8:	6442                	ld	s0,16(sp)
    80002bca:	64a2                	ld	s1,8(sp)
    80002bcc:	6105                	addi	sp,sp,32
    80002bce:	8082                	ret
    return p->trapframe->a1;
    80002bd0:	6d3c                	ld	a5,88(a0)
    80002bd2:	7fa8                	ld	a0,120(a5)
    80002bd4:	bfcd                	j	80002bc6 <argraw+0x2c>
    return p->trapframe->a2;
    80002bd6:	6d3c                	ld	a5,88(a0)
    80002bd8:	63c8                	ld	a0,128(a5)
    80002bda:	b7f5                	j	80002bc6 <argraw+0x2c>
    return p->trapframe->a3;
    80002bdc:	6d3c                	ld	a5,88(a0)
    80002bde:	67c8                	ld	a0,136(a5)
    80002be0:	b7dd                	j	80002bc6 <argraw+0x2c>
    return p->trapframe->a4;
    80002be2:	6d3c                	ld	a5,88(a0)
    80002be4:	6bc8                	ld	a0,144(a5)
    80002be6:	b7c5                	j	80002bc6 <argraw+0x2c>
    return p->trapframe->a5;
    80002be8:	6d3c                	ld	a5,88(a0)
    80002bea:	6fc8                	ld	a0,152(a5)
    80002bec:	bfe9                	j	80002bc6 <argraw+0x2c>
  panic("argraw");
    80002bee:	00005517          	auipc	a0,0x5
    80002bf2:	90250513          	addi	a0,a0,-1790 # 800074f0 <states.1772+0x150>
    80002bf6:	b99fd0ef          	jal	ra,8000078e <panic>

0000000080002bfa <fetchaddr>:
{
    80002bfa:	1101                	addi	sp,sp,-32
    80002bfc:	ec06                	sd	ra,24(sp)
    80002bfe:	e822                	sd	s0,16(sp)
    80002c00:	e426                	sd	s1,8(sp)
    80002c02:	e04a                	sd	s2,0(sp)
    80002c04:	1000                	addi	s0,sp,32
    80002c06:	84aa                	mv	s1,a0
    80002c08:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002c0a:	c51fe0ef          	jal	ra,8000185a <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002c0e:	653c                	ld	a5,72(a0)
    80002c10:	02f4f663          	bgeu	s1,a5,80002c3c <fetchaddr+0x42>
    80002c14:	00848713          	addi	a4,s1,8
    80002c18:	02e7e463          	bltu	a5,a4,80002c40 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80002c1c:	46a1                	li	a3,8
    80002c1e:	8626                	mv	a2,s1
    80002c20:	85ca                	mv	a1,s2
    80002c22:	6928                	ld	a0,80(a0)
    80002c24:	a4bfe0ef          	jal	ra,8000166e <copyin>
    80002c28:	00a03533          	snez	a0,a0
    80002c2c:	40a00533          	neg	a0,a0
}
    80002c30:	60e2                	ld	ra,24(sp)
    80002c32:	6442                	ld	s0,16(sp)
    80002c34:	64a2                	ld	s1,8(sp)
    80002c36:	6902                	ld	s2,0(sp)
    80002c38:	6105                	addi	sp,sp,32
    80002c3a:	8082                	ret
    return -1;
    80002c3c:	557d                	li	a0,-1
    80002c3e:	bfcd                	j	80002c30 <fetchaddr+0x36>
    80002c40:	557d                	li	a0,-1
    80002c42:	b7fd                	j	80002c30 <fetchaddr+0x36>

0000000080002c44 <fetchstr>:
{
    80002c44:	7179                	addi	sp,sp,-48
    80002c46:	f406                	sd	ra,40(sp)
    80002c48:	f022                	sd	s0,32(sp)
    80002c4a:	ec26                	sd	s1,24(sp)
    80002c4c:	e84a                	sd	s2,16(sp)
    80002c4e:	e44e                	sd	s3,8(sp)
    80002c50:	1800                	addi	s0,sp,48
    80002c52:	892a                	mv	s2,a0
    80002c54:	84ae                	mv	s1,a1
    80002c56:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    80002c58:	c03fe0ef          	jal	ra,8000185a <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80002c5c:	86ce                	mv	a3,s3
    80002c5e:	864a                	mv	a2,s2
    80002c60:	85a6                	mv	a1,s1
    80002c62:	6928                	ld	a0,80(a0)
    80002c64:	803fe0ef          	jal	ra,80001466 <copyinstr>
    80002c68:	00054c63          	bltz	a0,80002c80 <fetchstr+0x3c>
  return strlen(buf);
    80002c6c:	8526                	mv	a0,s1
    80002c6e:	9a0fe0ef          	jal	ra,80000e0e <strlen>
}
    80002c72:	70a2                	ld	ra,40(sp)
    80002c74:	7402                	ld	s0,32(sp)
    80002c76:	64e2                	ld	s1,24(sp)
    80002c78:	6942                	ld	s2,16(sp)
    80002c7a:	69a2                	ld	s3,8(sp)
    80002c7c:	6145                	addi	sp,sp,48
    80002c7e:	8082                	ret
    return -1;
    80002c80:	557d                	li	a0,-1
    80002c82:	bfc5                	j	80002c72 <fetchstr+0x2e>

0000000080002c84 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002c84:	1101                	addi	sp,sp,-32
    80002c86:	ec06                	sd	ra,24(sp)
    80002c88:	e822                	sd	s0,16(sp)
    80002c8a:	e426                	sd	s1,8(sp)
    80002c8c:	1000                	addi	s0,sp,32
    80002c8e:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002c90:	f0bff0ef          	jal	ra,80002b9a <argraw>
    80002c94:	c088                	sw	a0,0(s1)
}
    80002c96:	60e2                	ld	ra,24(sp)
    80002c98:	6442                	ld	s0,16(sp)
    80002c9a:	64a2                	ld	s1,8(sp)
    80002c9c:	6105                	addi	sp,sp,32
    80002c9e:	8082                	ret

0000000080002ca0 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002ca0:	1101                	addi	sp,sp,-32
    80002ca2:	ec06                	sd	ra,24(sp)
    80002ca4:	e822                	sd	s0,16(sp)
    80002ca6:	e426                	sd	s1,8(sp)
    80002ca8:	1000                	addi	s0,sp,32
    80002caa:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002cac:	eefff0ef          	jal	ra,80002b9a <argraw>
    80002cb0:	e088                	sd	a0,0(s1)
}
    80002cb2:	60e2                	ld	ra,24(sp)
    80002cb4:	6442                	ld	s0,16(sp)
    80002cb6:	64a2                	ld	s1,8(sp)
    80002cb8:	6105                	addi	sp,sp,32
    80002cba:	8082                	ret

0000000080002cbc <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002cbc:	7179                	addi	sp,sp,-48
    80002cbe:	f406                	sd	ra,40(sp)
    80002cc0:	f022                	sd	s0,32(sp)
    80002cc2:	ec26                	sd	s1,24(sp)
    80002cc4:	e84a                	sd	s2,16(sp)
    80002cc6:	1800                	addi	s0,sp,48
    80002cc8:	84ae                	mv	s1,a1
    80002cca:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80002ccc:	fd840593          	addi	a1,s0,-40
    80002cd0:	fd1ff0ef          	jal	ra,80002ca0 <argaddr>
  return fetchstr(addr, buf, max);
    80002cd4:	864a                	mv	a2,s2
    80002cd6:	85a6                	mv	a1,s1
    80002cd8:	fd843503          	ld	a0,-40(s0)
    80002cdc:	f69ff0ef          	jal	ra,80002c44 <fetchstr>
}
    80002ce0:	70a2                	ld	ra,40(sp)
    80002ce2:	7402                	ld	s0,32(sp)
    80002ce4:	64e2                	ld	s1,24(sp)
    80002ce6:	6942                	ld	s2,16(sp)
    80002ce8:	6145                	addi	sp,sp,48
    80002cea:	8082                	ret

0000000080002cec <syscall>:
[SYS_waitpid]  sys_waitpid,
};

void
syscall(void)
{
    80002cec:	1101                	addi	sp,sp,-32
    80002cee:	ec06                	sd	ra,24(sp)
    80002cf0:	e822                	sd	s0,16(sp)
    80002cf2:	e426                	sd	s1,8(sp)
    80002cf4:	e04a                	sd	s2,0(sp)
    80002cf6:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002cf8:	b63fe0ef          	jal	ra,8000185a <myproc>
    80002cfc:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002cfe:	05853903          	ld	s2,88(a0)
    80002d02:	0a893783          	ld	a5,168(s2) # 800164f8 <bcache+0x1e8>
    80002d06:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002d0a:	37fd                	addiw	a5,a5,-1
    80002d0c:	4765                	li	a4,25
    80002d0e:	00f76f63          	bltu	a4,a5,80002d2c <syscall+0x40>
    80002d12:	00369713          	slli	a4,a3,0x3
    80002d16:	00005797          	auipc	a5,0x5
    80002d1a:	81a78793          	addi	a5,a5,-2022 # 80007530 <syscalls>
    80002d1e:	97ba                	add	a5,a5,a4
    80002d20:	639c                	ld	a5,0(a5)
    80002d22:	c789                	beqz	a5,80002d2c <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002d24:	9782                	jalr	a5
    80002d26:	06a93823          	sd	a0,112(s2)
    80002d2a:	a829                	j	80002d44 <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002d2c:	15848613          	addi	a2,s1,344
    80002d30:	588c                	lw	a1,48(s1)
    80002d32:	00004517          	auipc	a0,0x4
    80002d36:	7c650513          	addi	a0,a0,1990 # 800074f8 <states.1772+0x158>
    80002d3a:	f8efd0ef          	jal	ra,800004c8 <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002d3e:	6cbc                	ld	a5,88(s1)
    80002d40:	577d                	li	a4,-1
    80002d42:	fbb8                	sd	a4,112(a5)
  }
}
    80002d44:	60e2                	ld	ra,24(sp)
    80002d46:	6442                	ld	s0,16(sp)
    80002d48:	64a2                	ld	s1,8(sp)
    80002d4a:	6902                	ld	s2,0(sp)
    80002d4c:	6105                	addi	sp,sp,32
    80002d4e:	8082                	ret

0000000080002d50 <sys_exit>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    80002d50:	1101                	addi	sp,sp,-32
    80002d52:	ec06                	sd	ra,24(sp)
    80002d54:	e822                	sd	s0,16(sp)
    80002d56:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002d58:	fec40593          	addi	a1,s0,-20
    80002d5c:	4501                	li	a0,0
    80002d5e:	f27ff0ef          	jal	ra,80002c84 <argint>
  kexit(n);
    80002d62:	fec42503          	lw	a0,-20(s0)
    80002d66:	bdcff0ef          	jal	ra,80002142 <kexit>
  return 0;  // not reached
}
    80002d6a:	4501                	li	a0,0
    80002d6c:	60e2                	ld	ra,24(sp)
    80002d6e:	6442                	ld	s0,16(sp)
    80002d70:	6105                	addi	sp,sp,32
    80002d72:	8082                	ret

0000000080002d74 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002d74:	1141                	addi	sp,sp,-16
    80002d76:	e406                	sd	ra,8(sp)
    80002d78:	e022                	sd	s0,0(sp)
    80002d7a:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002d7c:	adffe0ef          	jal	ra,8000185a <myproc>
}
    80002d80:	5908                	lw	a0,48(a0)
    80002d82:	60a2                	ld	ra,8(sp)
    80002d84:	6402                	ld	s0,0(sp)
    80002d86:	0141                	addi	sp,sp,16
    80002d88:	8082                	ret

0000000080002d8a <sys_fork>:

uint64
sys_fork(void)
{
    80002d8a:	1141                	addi	sp,sp,-16
    80002d8c:	e406                	sd	ra,8(sp)
    80002d8e:	e022                	sd	s0,0(sp)
    80002d90:	0800                	addi	s0,sp,16
  return kfork();
    80002d92:	e49fe0ef          	jal	ra,80001bda <kfork>
}
    80002d96:	60a2                	ld	ra,8(sp)
    80002d98:	6402                	ld	s0,0(sp)
    80002d9a:	0141                	addi	sp,sp,16
    80002d9c:	8082                	ret

0000000080002d9e <sys_wait>:

uint64
sys_wait(void)
{
    80002d9e:	1101                	addi	sp,sp,-32
    80002da0:	ec06                	sd	ra,24(sp)
    80002da2:	e822                	sd	s0,16(sp)
    80002da4:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002da6:	fe840593          	addi	a1,s0,-24
    80002daa:	4501                	li	a0,0
    80002dac:	ef5ff0ef          	jal	ra,80002ca0 <argaddr>
  return kwait(p);
    80002db0:	fe843503          	ld	a0,-24(s0)
    80002db4:	ce4ff0ef          	jal	ra,80002298 <kwait>
}
    80002db8:	60e2                	ld	ra,24(sp)
    80002dba:	6442                	ld	s0,16(sp)
    80002dbc:	6105                	addi	sp,sp,32
    80002dbe:	8082                	ret

0000000080002dc0 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002dc0:	7179                	addi	sp,sp,-48
    80002dc2:	f406                	sd	ra,40(sp)
    80002dc4:	f022                	sd	s0,32(sp)
    80002dc6:	ec26                	sd	s1,24(sp)
    80002dc8:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80002dca:	fd840593          	addi	a1,s0,-40
    80002dce:	4501                	li	a0,0
    80002dd0:	eb5ff0ef          	jal	ra,80002c84 <argint>
  argint(1, &t);
    80002dd4:	fdc40593          	addi	a1,s0,-36
    80002dd8:	4505                	li	a0,1
    80002dda:	eabff0ef          	jal	ra,80002c84 <argint>
  addr = myproc()->sz;
    80002dde:	a7dfe0ef          	jal	ra,8000185a <myproc>
    80002de2:	6524                	ld	s1,72(a0)

  if(t == SBRK_EAGER || n < 0) {
    80002de4:	fdc42703          	lw	a4,-36(s0)
    80002de8:	4785                	li	a5,1
    80002dea:	02f70763          	beq	a4,a5,80002e18 <sys_sbrk+0x58>
    80002dee:	fd842783          	lw	a5,-40(s0)
    80002df2:	0207c363          	bltz	a5,80002e18 <sys_sbrk+0x58>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if(addr + n < addr)
    80002df6:	97a6                	add	a5,a5,s1
    80002df8:	0297ee63          	bltu	a5,s1,80002e34 <sys_sbrk+0x74>
      return -1;
    if(addr + n > TRAPFRAME)
    80002dfc:	02000737          	lui	a4,0x2000
    80002e00:	177d                	addi	a4,a4,-1
    80002e02:	0736                	slli	a4,a4,0xd
    80002e04:	02f76a63          	bltu	a4,a5,80002e38 <sys_sbrk+0x78>
      return -1;
    myproc()->sz += n;
    80002e08:	a53fe0ef          	jal	ra,8000185a <myproc>
    80002e0c:	fd842703          	lw	a4,-40(s0)
    80002e10:	653c                	ld	a5,72(a0)
    80002e12:	97ba                	add	a5,a5,a4
    80002e14:	e53c                	sd	a5,72(a0)
    80002e16:	a039                	j	80002e24 <sys_sbrk+0x64>
    if(growproc(n) < 0) {
    80002e18:	fd842503          	lw	a0,-40(s0)
    80002e1c:	d5dfe0ef          	jal	ra,80001b78 <growproc>
    80002e20:	00054863          	bltz	a0,80002e30 <sys_sbrk+0x70>
  }
  return addr;
}
    80002e24:	8526                	mv	a0,s1
    80002e26:	70a2                	ld	ra,40(sp)
    80002e28:	7402                	ld	s0,32(sp)
    80002e2a:	64e2                	ld	s1,24(sp)
    80002e2c:	6145                	addi	sp,sp,48
    80002e2e:	8082                	ret
      return -1;
    80002e30:	54fd                	li	s1,-1
    80002e32:	bfcd                	j	80002e24 <sys_sbrk+0x64>
      return -1;
    80002e34:	54fd                	li	s1,-1
    80002e36:	b7fd                	j	80002e24 <sys_sbrk+0x64>
      return -1;
    80002e38:	54fd                	li	s1,-1
    80002e3a:	b7ed                	j	80002e24 <sys_sbrk+0x64>

0000000080002e3c <sys_pause>:

uint64
sys_pause(void)
{
    80002e3c:	7139                	addi	sp,sp,-64
    80002e3e:	fc06                	sd	ra,56(sp)
    80002e40:	f822                	sd	s0,48(sp)
    80002e42:	f426                	sd	s1,40(sp)
    80002e44:	f04a                	sd	s2,32(sp)
    80002e46:	ec4e                	sd	s3,24(sp)
    80002e48:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002e4a:	fcc40593          	addi	a1,s0,-52
    80002e4e:	4501                	li	a0,0
    80002e50:	e35ff0ef          	jal	ra,80002c84 <argint>
  if(n < 0)
    80002e54:	fcc42783          	lw	a5,-52(s0)
    80002e58:	0607c563          	bltz	a5,80002ec2 <sys_pause+0x86>
    n = 0;
  acquire(&tickslock);
    80002e5c:	00013517          	auipc	a0,0x13
    80002e60:	49c50513          	addi	a0,a0,1180 # 800162f8 <tickslock>
    80002e64:	d57fd0ef          	jal	ra,80000bba <acquire>
  ticks0 = ticks;
    80002e68:	00005917          	auipc	s2,0x5
    80002e6c:	b6092903          	lw	s2,-1184(s2) # 800079c8 <ticks>
  while(ticks - ticks0 < n){
    80002e70:	fcc42783          	lw	a5,-52(s0)
    80002e74:	cb8d                	beqz	a5,80002ea6 <sys_pause+0x6a>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002e76:	00013997          	auipc	s3,0x13
    80002e7a:	48298993          	addi	s3,s3,1154 # 800162f8 <tickslock>
    80002e7e:	00005497          	auipc	s1,0x5
    80002e82:	b4a48493          	addi	s1,s1,-1206 # 800079c8 <ticks>
    if(killed(myproc())){
    80002e86:	9d5fe0ef          	jal	ra,8000185a <myproc>
    80002e8a:	be4ff0ef          	jal	ra,8000226e <killed>
    80002e8e:	ed0d                	bnez	a0,80002ec8 <sys_pause+0x8c>
    sleep(&ticks, &tickslock);
    80002e90:	85ce                	mv	a1,s3
    80002e92:	8526                	mv	a0,s1
    80002e94:	962ff0ef          	jal	ra,80001ff6 <sleep>
  while(ticks - ticks0 < n){
    80002e98:	409c                	lw	a5,0(s1)
    80002e9a:	412787bb          	subw	a5,a5,s2
    80002e9e:	fcc42703          	lw	a4,-52(s0)
    80002ea2:	fee7e2e3          	bltu	a5,a4,80002e86 <sys_pause+0x4a>
  }
  release(&tickslock);
    80002ea6:	00013517          	auipc	a0,0x13
    80002eaa:	45250513          	addi	a0,a0,1106 # 800162f8 <tickslock>
    80002eae:	da5fd0ef          	jal	ra,80000c52 <release>
  return 0;
    80002eb2:	4501                	li	a0,0
}
    80002eb4:	70e2                	ld	ra,56(sp)
    80002eb6:	7442                	ld	s0,48(sp)
    80002eb8:	74a2                	ld	s1,40(sp)
    80002eba:	7902                	ld	s2,32(sp)
    80002ebc:	69e2                	ld	s3,24(sp)
    80002ebe:	6121                	addi	sp,sp,64
    80002ec0:	8082                	ret
    n = 0;
    80002ec2:	fc042623          	sw	zero,-52(s0)
    80002ec6:	bf59                	j	80002e5c <sys_pause+0x20>
      release(&tickslock);
    80002ec8:	00013517          	auipc	a0,0x13
    80002ecc:	43050513          	addi	a0,a0,1072 # 800162f8 <tickslock>
    80002ed0:	d83fd0ef          	jal	ra,80000c52 <release>
      return -1;
    80002ed4:	557d                	li	a0,-1
    80002ed6:	bff9                	j	80002eb4 <sys_pause+0x78>

0000000080002ed8 <sys_kill>:

uint64
sys_kill(void)
{
    80002ed8:	1101                	addi	sp,sp,-32
    80002eda:	ec06                	sd	ra,24(sp)
    80002edc:	e822                	sd	s0,16(sp)
    80002ede:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002ee0:	fec40593          	addi	a1,s0,-20
    80002ee4:	4501                	li	a0,0
    80002ee6:	d9fff0ef          	jal	ra,80002c84 <argint>
  return kkill(pid);
    80002eea:	fec42503          	lw	a0,-20(s0)
    80002eee:	af6ff0ef          	jal	ra,800021e4 <kkill>
}
    80002ef2:	60e2                	ld	ra,24(sp)
    80002ef4:	6442                	ld	s0,16(sp)
    80002ef6:	6105                	addi	sp,sp,32
    80002ef8:	8082                	ret

0000000080002efa <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002efa:	1101                	addi	sp,sp,-32
    80002efc:	ec06                	sd	ra,24(sp)
    80002efe:	e822                	sd	s0,16(sp)
    80002f00:	e426                	sd	s1,8(sp)
    80002f02:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002f04:	00013517          	auipc	a0,0x13
    80002f08:	3f450513          	addi	a0,a0,1012 # 800162f8 <tickslock>
    80002f0c:	caffd0ef          	jal	ra,80000bba <acquire>
  xticks = ticks;
    80002f10:	00005497          	auipc	s1,0x5
    80002f14:	ab84a483          	lw	s1,-1352(s1) # 800079c8 <ticks>
  release(&tickslock);
    80002f18:	00013517          	auipc	a0,0x13
    80002f1c:	3e050513          	addi	a0,a0,992 # 800162f8 <tickslock>
    80002f20:	d33fd0ef          	jal	ra,80000c52 <release>
  return xticks;
}
    80002f24:	02049513          	slli	a0,s1,0x20
    80002f28:	9101                	srli	a0,a0,0x20
    80002f2a:	60e2                	ld	ra,24(sp)
    80002f2c:	6442                	ld	s0,16(sp)
    80002f2e:	64a2                	ld	s1,8(sp)
    80002f30:	6105                	addi	sp,sp,32
    80002f32:	8082                	ret

0000000080002f34 <sys_getnice>:


uint64
sys_getnice(void)
{
    80002f34:	1101                	addi	sp,sp,-32
    80002f36:	ec06                	sd	ra,24(sp)
    80002f38:	e822                	sd	s0,16(sp)
    80002f3a:	1000                	addi	s0,sp,32
  int pid;
  argint(0, &pid);
    80002f3c:	fec40593          	addi	a1,s0,-20
    80002f40:	4501                	li	a0,0
    80002f42:	d43ff0ef          	jal	ra,80002c84 <argint>
  return getnice(pid);
    80002f46:	fec42503          	lw	a0,-20(s0)
    80002f4a:	d7eff0ef          	jal	ra,800024c8 <getnice>
}
    80002f4e:	60e2                	ld	ra,24(sp)
    80002f50:	6442                	ld	s0,16(sp)
    80002f52:	6105                	addi	sp,sp,32
    80002f54:	8082                	ret

0000000080002f56 <sys_setnice>:

uint64
sys_setnice(void)
{
    80002f56:	1101                	addi	sp,sp,-32
    80002f58:	ec06                	sd	ra,24(sp)
    80002f5a:	e822                	sd	s0,16(sp)
    80002f5c:	1000                	addi	s0,sp,32
  int pid, value;
  argint(0, &pid);
    80002f5e:	fec40593          	addi	a1,s0,-20
    80002f62:	4501                	li	a0,0
    80002f64:	d21ff0ef          	jal	ra,80002c84 <argint>
  argint(1, &value);
    80002f68:	fe840593          	addi	a1,s0,-24
    80002f6c:	4505                	li	a0,1
    80002f6e:	d17ff0ef          	jal	ra,80002c84 <argint>
  return setnice(pid, value);
    80002f72:	fe842583          	lw	a1,-24(s0)
    80002f76:	fec42503          	lw	a0,-20(s0)
    80002f7a:	daeff0ef          	jal	ra,80002528 <setnice>
}
    80002f7e:	60e2                	ld	ra,24(sp)
    80002f80:	6442                	ld	s0,16(sp)
    80002f82:	6105                	addi	sp,sp,32
    80002f84:	8082                	ret

0000000080002f86 <sys_ps>:

uint64
sys_ps(void)
{
    80002f86:	1101                	addi	sp,sp,-32
    80002f88:	ec06                	sd	ra,24(sp)
    80002f8a:	e822                	sd	s0,16(sp)
    80002f8c:	1000                	addi	s0,sp,32
  int pid;
  argint(0, &pid);
    80002f8e:	fec40593          	addi	a1,s0,-20
    80002f92:	4501                	li	a0,0
    80002f94:	cf1ff0ef          	jal	ra,80002c84 <argint>
  ps(pid);
    80002f98:	fec42503          	lw	a0,-20(s0)
    80002f9c:	e2cff0ef          	jal	ra,800025c8 <ps>
  return 0;
}
    80002fa0:	4501                	li	a0,0
    80002fa2:	60e2                	ld	ra,24(sp)
    80002fa4:	6442                	ld	s0,16(sp)
    80002fa6:	6105                	addi	sp,sp,32
    80002fa8:	8082                	ret

0000000080002faa <sys_meminfo>:

uint64
sys_meminfo(void)
{
    80002faa:	1141                	addi	sp,sp,-16
    80002fac:	e406                	sd	ra,8(sp)
    80002fae:	e022                	sd	s0,0(sp)
    80002fb0:	0800                	addi	s0,sp,16
  return meminfo();
    80002fb2:	b47fd0ef          	jal	ra,80000af8 <meminfo>
}
    80002fb6:	60a2                	ld	ra,8(sp)
    80002fb8:	6402                	ld	s0,0(sp)
    80002fba:	0141                	addi	sp,sp,16
    80002fbc:	8082                	ret

0000000080002fbe <sys_waitpid>:

uint64
sys_waitpid(void)
{
    80002fbe:	1101                	addi	sp,sp,-32
    80002fc0:	ec06                	sd	ra,24(sp)
    80002fc2:	e822                	sd	s0,16(sp)
    80002fc4:	1000                	addi	s0,sp,32
  int pid;
  argint(0, &pid);
    80002fc6:	fec40593          	addi	a1,s0,-20
    80002fca:	4501                	li	a0,0
    80002fcc:	cb9ff0ef          	jal	ra,80002c84 <argint>
  return waitpid(pid);
    80002fd0:	fec42503          	lw	a0,-20(s0)
    80002fd4:	f64ff0ef          	jal	ra,80002738 <waitpid>
    80002fd8:	60e2                	ld	ra,24(sp)
    80002fda:	6442                	ld	s0,16(sp)
    80002fdc:	6105                	addi	sp,sp,32
    80002fde:	8082                	ret

0000000080002fe0 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002fe0:	7179                	addi	sp,sp,-48
    80002fe2:	f406                	sd	ra,40(sp)
    80002fe4:	f022                	sd	s0,32(sp)
    80002fe6:	ec26                	sd	s1,24(sp)
    80002fe8:	e84a                	sd	s2,16(sp)
    80002fea:	e44e                	sd	s3,8(sp)
    80002fec:	e052                	sd	s4,0(sp)
    80002fee:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002ff0:	00004597          	auipc	a1,0x4
    80002ff4:	61858593          	addi	a1,a1,1560 # 80007608 <syscalls+0xd8>
    80002ff8:	00013517          	auipc	a0,0x13
    80002ffc:	31850513          	addi	a0,a0,792 # 80016310 <bcache>
    80003000:	b3bfd0ef          	jal	ra,80000b3a <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80003004:	0001b797          	auipc	a5,0x1b
    80003008:	30c78793          	addi	a5,a5,780 # 8001e310 <bcache+0x8000>
    8000300c:	0001b717          	auipc	a4,0x1b
    80003010:	56c70713          	addi	a4,a4,1388 # 8001e578 <bcache+0x8268>
    80003014:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80003018:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    8000301c:	00013497          	auipc	s1,0x13
    80003020:	30c48493          	addi	s1,s1,780 # 80016328 <bcache+0x18>
    b->next = bcache.head.next;
    80003024:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80003026:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80003028:	00004a17          	auipc	s4,0x4
    8000302c:	5e8a0a13          	addi	s4,s4,1512 # 80007610 <syscalls+0xe0>
    b->next = bcache.head.next;
    80003030:	2b893783          	ld	a5,696(s2)
    80003034:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80003036:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    8000303a:	85d2                	mv	a1,s4
    8000303c:	01048513          	addi	a0,s1,16
    80003040:	2fe010ef          	jal	ra,8000433e <initsleeplock>
    bcache.head.next->prev = b;
    80003044:	2b893783          	ld	a5,696(s2)
    80003048:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    8000304a:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    8000304e:	45848493          	addi	s1,s1,1112
    80003052:	fd349fe3          	bne	s1,s3,80003030 <binit+0x50>
  }
}
    80003056:	70a2                	ld	ra,40(sp)
    80003058:	7402                	ld	s0,32(sp)
    8000305a:	64e2                	ld	s1,24(sp)
    8000305c:	6942                	ld	s2,16(sp)
    8000305e:	69a2                	ld	s3,8(sp)
    80003060:	6a02                	ld	s4,0(sp)
    80003062:	6145                	addi	sp,sp,48
    80003064:	8082                	ret

0000000080003066 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80003066:	7179                	addi	sp,sp,-48
    80003068:	f406                	sd	ra,40(sp)
    8000306a:	f022                	sd	s0,32(sp)
    8000306c:	ec26                	sd	s1,24(sp)
    8000306e:	e84a                	sd	s2,16(sp)
    80003070:	e44e                	sd	s3,8(sp)
    80003072:	1800                	addi	s0,sp,48
    80003074:	89aa                	mv	s3,a0
    80003076:	892e                	mv	s2,a1
  acquire(&bcache.lock);
    80003078:	00013517          	auipc	a0,0x13
    8000307c:	29850513          	addi	a0,a0,664 # 80016310 <bcache>
    80003080:	b3bfd0ef          	jal	ra,80000bba <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80003084:	0001b497          	auipc	s1,0x1b
    80003088:	5444b483          	ld	s1,1348(s1) # 8001e5c8 <bcache+0x82b8>
    8000308c:	0001b797          	auipc	a5,0x1b
    80003090:	4ec78793          	addi	a5,a5,1260 # 8001e578 <bcache+0x8268>
    80003094:	02f48b63          	beq	s1,a5,800030ca <bread+0x64>
    80003098:	873e                	mv	a4,a5
    8000309a:	a021                	j	800030a2 <bread+0x3c>
    8000309c:	68a4                	ld	s1,80(s1)
    8000309e:	02e48663          	beq	s1,a4,800030ca <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    800030a2:	449c                	lw	a5,8(s1)
    800030a4:	ff379ce3          	bne	a5,s3,8000309c <bread+0x36>
    800030a8:	44dc                	lw	a5,12(s1)
    800030aa:	ff2799e3          	bne	a5,s2,8000309c <bread+0x36>
      b->refcnt++;
    800030ae:	40bc                	lw	a5,64(s1)
    800030b0:	2785                	addiw	a5,a5,1
    800030b2:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    800030b4:	00013517          	auipc	a0,0x13
    800030b8:	25c50513          	addi	a0,a0,604 # 80016310 <bcache>
    800030bc:	b97fd0ef          	jal	ra,80000c52 <release>
      acquiresleep(&b->lock);
    800030c0:	01048513          	addi	a0,s1,16
    800030c4:	2b0010ef          	jal	ra,80004374 <acquiresleep>
      return b;
    800030c8:	a889                	j	8000311a <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    800030ca:	0001b497          	auipc	s1,0x1b
    800030ce:	4f64b483          	ld	s1,1270(s1) # 8001e5c0 <bcache+0x82b0>
    800030d2:	0001b797          	auipc	a5,0x1b
    800030d6:	4a678793          	addi	a5,a5,1190 # 8001e578 <bcache+0x8268>
    800030da:	00f48863          	beq	s1,a5,800030ea <bread+0x84>
    800030de:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    800030e0:	40bc                	lw	a5,64(s1)
    800030e2:	cb91                	beqz	a5,800030f6 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    800030e4:	64a4                	ld	s1,72(s1)
    800030e6:	fee49de3          	bne	s1,a4,800030e0 <bread+0x7a>
  panic("bget: no buffers");
    800030ea:	00004517          	auipc	a0,0x4
    800030ee:	52e50513          	addi	a0,a0,1326 # 80007618 <syscalls+0xe8>
    800030f2:	e9cfd0ef          	jal	ra,8000078e <panic>
      b->dev = dev;
    800030f6:	0134a423          	sw	s3,8(s1)
      b->blockno = blockno;
    800030fa:	0124a623          	sw	s2,12(s1)
      b->valid = 0;
    800030fe:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80003102:	4785                	li	a5,1
    80003104:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80003106:	00013517          	auipc	a0,0x13
    8000310a:	20a50513          	addi	a0,a0,522 # 80016310 <bcache>
    8000310e:	b45fd0ef          	jal	ra,80000c52 <release>
      acquiresleep(&b->lock);
    80003112:	01048513          	addi	a0,s1,16
    80003116:	25e010ef          	jal	ra,80004374 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    8000311a:	409c                	lw	a5,0(s1)
    8000311c:	cb89                	beqz	a5,8000312e <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    8000311e:	8526                	mv	a0,s1
    80003120:	70a2                	ld	ra,40(sp)
    80003122:	7402                	ld	s0,32(sp)
    80003124:	64e2                	ld	s1,24(sp)
    80003126:	6942                	ld	s2,16(sp)
    80003128:	69a2                	ld	s3,8(sp)
    8000312a:	6145                	addi	sp,sp,48
    8000312c:	8082                	ret
    virtio_disk_rw(b, 0);
    8000312e:	4581                	li	a1,0
    80003130:	8526                	mv	a0,s1
    80003132:	1af020ef          	jal	ra,80005ae0 <virtio_disk_rw>
    b->valid = 1;
    80003136:	4785                	li	a5,1
    80003138:	c09c                	sw	a5,0(s1)
  return b;
    8000313a:	b7d5                	j	8000311e <bread+0xb8>

000000008000313c <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    8000313c:	1101                	addi	sp,sp,-32
    8000313e:	ec06                	sd	ra,24(sp)
    80003140:	e822                	sd	s0,16(sp)
    80003142:	e426                	sd	s1,8(sp)
    80003144:	1000                	addi	s0,sp,32
    80003146:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80003148:	0541                	addi	a0,a0,16
    8000314a:	2a8010ef          	jal	ra,800043f2 <holdingsleep>
    8000314e:	c911                	beqz	a0,80003162 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80003150:	4585                	li	a1,1
    80003152:	8526                	mv	a0,s1
    80003154:	18d020ef          	jal	ra,80005ae0 <virtio_disk_rw>
}
    80003158:	60e2                	ld	ra,24(sp)
    8000315a:	6442                	ld	s0,16(sp)
    8000315c:	64a2                	ld	s1,8(sp)
    8000315e:	6105                	addi	sp,sp,32
    80003160:	8082                	ret
    panic("bwrite");
    80003162:	00004517          	auipc	a0,0x4
    80003166:	4ce50513          	addi	a0,a0,1230 # 80007630 <syscalls+0x100>
    8000316a:	e24fd0ef          	jal	ra,8000078e <panic>

000000008000316e <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    8000316e:	1101                	addi	sp,sp,-32
    80003170:	ec06                	sd	ra,24(sp)
    80003172:	e822                	sd	s0,16(sp)
    80003174:	e426                	sd	s1,8(sp)
    80003176:	e04a                	sd	s2,0(sp)
    80003178:	1000                	addi	s0,sp,32
    8000317a:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    8000317c:	01050913          	addi	s2,a0,16
    80003180:	854a                	mv	a0,s2
    80003182:	270010ef          	jal	ra,800043f2 <holdingsleep>
    80003186:	c13d                	beqz	a0,800031ec <brelse+0x7e>
    panic("brelse");

  releasesleep(&b->lock);
    80003188:	854a                	mv	a0,s2
    8000318a:	230010ef          	jal	ra,800043ba <releasesleep>

  acquire(&bcache.lock);
    8000318e:	00013517          	auipc	a0,0x13
    80003192:	18250513          	addi	a0,a0,386 # 80016310 <bcache>
    80003196:	a25fd0ef          	jal	ra,80000bba <acquire>
  b->refcnt--;
    8000319a:	40bc                	lw	a5,64(s1)
    8000319c:	37fd                	addiw	a5,a5,-1
    8000319e:	0007871b          	sext.w	a4,a5
    800031a2:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    800031a4:	eb05                	bnez	a4,800031d4 <brelse+0x66>
    // no one is waiting for it.
    b->next->prev = b->prev;
    800031a6:	68bc                	ld	a5,80(s1)
    800031a8:	64b8                	ld	a4,72(s1)
    800031aa:	e7b8                	sd	a4,72(a5)
    b->prev->next = b->next;
    800031ac:	64bc                	ld	a5,72(s1)
    800031ae:	68b8                	ld	a4,80(s1)
    800031b0:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    800031b2:	0001b797          	auipc	a5,0x1b
    800031b6:	15e78793          	addi	a5,a5,350 # 8001e310 <bcache+0x8000>
    800031ba:	2b87b703          	ld	a4,696(a5)
    800031be:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    800031c0:	0001b717          	auipc	a4,0x1b
    800031c4:	3b870713          	addi	a4,a4,952 # 8001e578 <bcache+0x8268>
    800031c8:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    800031ca:	2b87b703          	ld	a4,696(a5)
    800031ce:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    800031d0:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    800031d4:	00013517          	auipc	a0,0x13
    800031d8:	13c50513          	addi	a0,a0,316 # 80016310 <bcache>
    800031dc:	a77fd0ef          	jal	ra,80000c52 <release>
}
    800031e0:	60e2                	ld	ra,24(sp)
    800031e2:	6442                	ld	s0,16(sp)
    800031e4:	64a2                	ld	s1,8(sp)
    800031e6:	6902                	ld	s2,0(sp)
    800031e8:	6105                	addi	sp,sp,32
    800031ea:	8082                	ret
    panic("brelse");
    800031ec:	00004517          	auipc	a0,0x4
    800031f0:	44c50513          	addi	a0,a0,1100 # 80007638 <syscalls+0x108>
    800031f4:	d9afd0ef          	jal	ra,8000078e <panic>

00000000800031f8 <bpin>:

void
bpin(struct buf *b) {
    800031f8:	1101                	addi	sp,sp,-32
    800031fa:	ec06                	sd	ra,24(sp)
    800031fc:	e822                	sd	s0,16(sp)
    800031fe:	e426                	sd	s1,8(sp)
    80003200:	1000                	addi	s0,sp,32
    80003202:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80003204:	00013517          	auipc	a0,0x13
    80003208:	10c50513          	addi	a0,a0,268 # 80016310 <bcache>
    8000320c:	9affd0ef          	jal	ra,80000bba <acquire>
  b->refcnt++;
    80003210:	40bc                	lw	a5,64(s1)
    80003212:	2785                	addiw	a5,a5,1
    80003214:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80003216:	00013517          	auipc	a0,0x13
    8000321a:	0fa50513          	addi	a0,a0,250 # 80016310 <bcache>
    8000321e:	a35fd0ef          	jal	ra,80000c52 <release>
}
    80003222:	60e2                	ld	ra,24(sp)
    80003224:	6442                	ld	s0,16(sp)
    80003226:	64a2                	ld	s1,8(sp)
    80003228:	6105                	addi	sp,sp,32
    8000322a:	8082                	ret

000000008000322c <bunpin>:

void
bunpin(struct buf *b) {
    8000322c:	1101                	addi	sp,sp,-32
    8000322e:	ec06                	sd	ra,24(sp)
    80003230:	e822                	sd	s0,16(sp)
    80003232:	e426                	sd	s1,8(sp)
    80003234:	1000                	addi	s0,sp,32
    80003236:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80003238:	00013517          	auipc	a0,0x13
    8000323c:	0d850513          	addi	a0,a0,216 # 80016310 <bcache>
    80003240:	97bfd0ef          	jal	ra,80000bba <acquire>
  b->refcnt--;
    80003244:	40bc                	lw	a5,64(s1)
    80003246:	37fd                	addiw	a5,a5,-1
    80003248:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    8000324a:	00013517          	auipc	a0,0x13
    8000324e:	0c650513          	addi	a0,a0,198 # 80016310 <bcache>
    80003252:	a01fd0ef          	jal	ra,80000c52 <release>
}
    80003256:	60e2                	ld	ra,24(sp)
    80003258:	6442                	ld	s0,16(sp)
    8000325a:	64a2                	ld	s1,8(sp)
    8000325c:	6105                	addi	sp,sp,32
    8000325e:	8082                	ret

0000000080003260 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80003260:	1101                	addi	sp,sp,-32
    80003262:	ec06                	sd	ra,24(sp)
    80003264:	e822                	sd	s0,16(sp)
    80003266:	e426                	sd	s1,8(sp)
    80003268:	e04a                	sd	s2,0(sp)
    8000326a:	1000                	addi	s0,sp,32
    8000326c:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    8000326e:	00d5d59b          	srliw	a1,a1,0xd
    80003272:	0001b797          	auipc	a5,0x1b
    80003276:	77a7a783          	lw	a5,1914(a5) # 8001e9ec <sb+0x1c>
    8000327a:	9dbd                	addw	a1,a1,a5
    8000327c:	debff0ef          	jal	ra,80003066 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80003280:	0074f713          	andi	a4,s1,7
    80003284:	4785                	li	a5,1
    80003286:	00e797bb          	sllw	a5,a5,a4
  if((bp->data[bi/8] & m) == 0)
    8000328a:	14ce                	slli	s1,s1,0x33
    8000328c:	90d9                	srli	s1,s1,0x36
    8000328e:	00950733          	add	a4,a0,s1
    80003292:	05874703          	lbu	a4,88(a4)
    80003296:	00e7f6b3          	and	a3,a5,a4
    8000329a:	c29d                	beqz	a3,800032c0 <bfree+0x60>
    8000329c:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    8000329e:	94aa                	add	s1,s1,a0
    800032a0:	fff7c793          	not	a5,a5
    800032a4:	8ff9                	and	a5,a5,a4
    800032a6:	04f48c23          	sb	a5,88(s1)
  log_write(bp);
    800032aa:	7d1000ef          	jal	ra,8000427a <log_write>
  brelse(bp);
    800032ae:	854a                	mv	a0,s2
    800032b0:	ebfff0ef          	jal	ra,8000316e <brelse>
}
    800032b4:	60e2                	ld	ra,24(sp)
    800032b6:	6442                	ld	s0,16(sp)
    800032b8:	64a2                	ld	s1,8(sp)
    800032ba:	6902                	ld	s2,0(sp)
    800032bc:	6105                	addi	sp,sp,32
    800032be:	8082                	ret
    panic("freeing free block");
    800032c0:	00004517          	auipc	a0,0x4
    800032c4:	38050513          	addi	a0,a0,896 # 80007640 <syscalls+0x110>
    800032c8:	cc6fd0ef          	jal	ra,8000078e <panic>

00000000800032cc <balloc>:
{
    800032cc:	711d                	addi	sp,sp,-96
    800032ce:	ec86                	sd	ra,88(sp)
    800032d0:	e8a2                	sd	s0,80(sp)
    800032d2:	e4a6                	sd	s1,72(sp)
    800032d4:	e0ca                	sd	s2,64(sp)
    800032d6:	fc4e                	sd	s3,56(sp)
    800032d8:	f852                	sd	s4,48(sp)
    800032da:	f456                	sd	s5,40(sp)
    800032dc:	f05a                	sd	s6,32(sp)
    800032de:	ec5e                	sd	s7,24(sp)
    800032e0:	e862                	sd	s8,16(sp)
    800032e2:	e466                	sd	s9,8(sp)
    800032e4:	1080                	addi	s0,sp,96
  for(b = 0; b < sb.size; b += BPB){
    800032e6:	0001b797          	auipc	a5,0x1b
    800032ea:	6ee7a783          	lw	a5,1774(a5) # 8001e9d4 <sb+0x4>
    800032ee:	0e078163          	beqz	a5,800033d0 <balloc+0x104>
    800032f2:	8baa                	mv	s7,a0
    800032f4:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    800032f6:	0001bb17          	auipc	s6,0x1b
    800032fa:	6dab0b13          	addi	s6,s6,1754 # 8001e9d0 <sb>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800032fe:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    80003300:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003302:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80003304:	6c89                	lui	s9,0x2
    80003306:	a0b5                	j	80003372 <balloc+0xa6>
        bp->data[bi/8] |= m;  // Mark block in use.
    80003308:	974a                	add	a4,a4,s2
    8000330a:	8fd5                	or	a5,a5,a3
    8000330c:	04f70c23          	sb	a5,88(a4)
        log_write(bp);
    80003310:	854a                	mv	a0,s2
    80003312:	769000ef          	jal	ra,8000427a <log_write>
        brelse(bp);
    80003316:	854a                	mv	a0,s2
    80003318:	e57ff0ef          	jal	ra,8000316e <brelse>
  bp = bread(dev, bno);
    8000331c:	85a6                	mv	a1,s1
    8000331e:	855e                	mv	a0,s7
    80003320:	d47ff0ef          	jal	ra,80003066 <bread>
    80003324:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80003326:	40000613          	li	a2,1024
    8000332a:	4581                	li	a1,0
    8000332c:	05850513          	addi	a0,a0,88
    80003330:	95ffd0ef          	jal	ra,80000c8e <memset>
  log_write(bp);
    80003334:	854a                	mv	a0,s2
    80003336:	745000ef          	jal	ra,8000427a <log_write>
  brelse(bp);
    8000333a:	854a                	mv	a0,s2
    8000333c:	e33ff0ef          	jal	ra,8000316e <brelse>
}
    80003340:	8526                	mv	a0,s1
    80003342:	60e6                	ld	ra,88(sp)
    80003344:	6446                	ld	s0,80(sp)
    80003346:	64a6                	ld	s1,72(sp)
    80003348:	6906                	ld	s2,64(sp)
    8000334a:	79e2                	ld	s3,56(sp)
    8000334c:	7a42                	ld	s4,48(sp)
    8000334e:	7aa2                	ld	s5,40(sp)
    80003350:	7b02                	ld	s6,32(sp)
    80003352:	6be2                	ld	s7,24(sp)
    80003354:	6c42                	ld	s8,16(sp)
    80003356:	6ca2                	ld	s9,8(sp)
    80003358:	6125                	addi	sp,sp,96
    8000335a:	8082                	ret
    brelse(bp);
    8000335c:	854a                	mv	a0,s2
    8000335e:	e11ff0ef          	jal	ra,8000316e <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80003362:	015c87bb          	addw	a5,s9,s5
    80003366:	00078a9b          	sext.w	s5,a5
    8000336a:	004b2703          	lw	a4,4(s6)
    8000336e:	06eaf163          	bgeu	s5,a4,800033d0 <balloc+0x104>
    bp = bread(dev, BBLOCK(b, sb));
    80003372:	41fad79b          	sraiw	a5,s5,0x1f
    80003376:	0137d79b          	srliw	a5,a5,0x13
    8000337a:	015787bb          	addw	a5,a5,s5
    8000337e:	40d7d79b          	sraiw	a5,a5,0xd
    80003382:	01cb2583          	lw	a1,28(s6)
    80003386:	9dbd                	addw	a1,a1,a5
    80003388:	855e                	mv	a0,s7
    8000338a:	cddff0ef          	jal	ra,80003066 <bread>
    8000338e:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003390:	004b2503          	lw	a0,4(s6)
    80003394:	000a849b          	sext.w	s1,s5
    80003398:	8662                	mv	a2,s8
    8000339a:	fca4f1e3          	bgeu	s1,a0,8000335c <balloc+0x90>
      m = 1 << (bi % 8);
    8000339e:	41f6579b          	sraiw	a5,a2,0x1f
    800033a2:	01d7d69b          	srliw	a3,a5,0x1d
    800033a6:	00c6873b          	addw	a4,a3,a2
    800033aa:	00777793          	andi	a5,a4,7
    800033ae:	9f95                	subw	a5,a5,a3
    800033b0:	00f997bb          	sllw	a5,s3,a5
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    800033b4:	4037571b          	sraiw	a4,a4,0x3
    800033b8:	00e906b3          	add	a3,s2,a4
    800033bc:	0586c683          	lbu	a3,88(a3) # 1058 <_entry-0x7fffefa8>
    800033c0:	00d7f5b3          	and	a1,a5,a3
    800033c4:	d1b1                	beqz	a1,80003308 <balloc+0x3c>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800033c6:	2605                	addiw	a2,a2,1
    800033c8:	2485                	addiw	s1,s1,1
    800033ca:	fd4618e3          	bne	a2,s4,8000339a <balloc+0xce>
    800033ce:	b779                	j	8000335c <balloc+0x90>
  printf("balloc: out of blocks\n");
    800033d0:	00004517          	auipc	a0,0x4
    800033d4:	28850513          	addi	a0,a0,648 # 80007658 <syscalls+0x128>
    800033d8:	8f0fd0ef          	jal	ra,800004c8 <printf>
  return 0;
    800033dc:	4481                	li	s1,0
    800033de:	b78d                	j	80003340 <balloc+0x74>

00000000800033e0 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    800033e0:	7179                	addi	sp,sp,-48
    800033e2:	f406                	sd	ra,40(sp)
    800033e4:	f022                	sd	s0,32(sp)
    800033e6:	ec26                	sd	s1,24(sp)
    800033e8:	e84a                	sd	s2,16(sp)
    800033ea:	e44e                	sd	s3,8(sp)
    800033ec:	e052                	sd	s4,0(sp)
    800033ee:	1800                	addi	s0,sp,48
    800033f0:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    800033f2:	47ad                	li	a5,11
    800033f4:	02b7e563          	bltu	a5,a1,8000341e <bmap+0x3e>
    if((addr = ip->addrs[bn]) == 0){
    800033f8:	02059493          	slli	s1,a1,0x20
    800033fc:	9081                	srli	s1,s1,0x20
    800033fe:	048a                	slli	s1,s1,0x2
    80003400:	94aa                	add	s1,s1,a0
    80003402:	0504a903          	lw	s2,80(s1)
    80003406:	06091663          	bnez	s2,80003472 <bmap+0x92>
      addr = balloc(ip->dev);
    8000340a:	4108                	lw	a0,0(a0)
    8000340c:	ec1ff0ef          	jal	ra,800032cc <balloc>
    80003410:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80003414:	04090f63          	beqz	s2,80003472 <bmap+0x92>
        return 0;
      ip->addrs[bn] = addr;
    80003418:	0524a823          	sw	s2,80(s1)
    8000341c:	a899                	j	80003472 <bmap+0x92>
    }
    return addr;
  }
  bn -= NDIRECT;
    8000341e:	ff45849b          	addiw	s1,a1,-12
    80003422:	0004871b          	sext.w	a4,s1

  if(bn < NINDIRECT){
    80003426:	0ff00793          	li	a5,255
    8000342a:	06e7eb63          	bltu	a5,a4,800034a0 <bmap+0xc0>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    8000342e:	08052903          	lw	s2,128(a0)
    80003432:	00091b63          	bnez	s2,80003448 <bmap+0x68>
      addr = balloc(ip->dev);
    80003436:	4108                	lw	a0,0(a0)
    80003438:	e95ff0ef          	jal	ra,800032cc <balloc>
    8000343c:	0005091b          	sext.w	s2,a0
      if(addr == 0)
    80003440:	02090963          	beqz	s2,80003472 <bmap+0x92>
        return 0;
      ip->addrs[NDIRECT] = addr;
    80003444:	0929a023          	sw	s2,128(s3)
    }
    bp = bread(ip->dev, addr);
    80003448:	85ca                	mv	a1,s2
    8000344a:	0009a503          	lw	a0,0(s3)
    8000344e:	c19ff0ef          	jal	ra,80003066 <bread>
    80003452:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80003454:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80003458:	02049593          	slli	a1,s1,0x20
    8000345c:	9181                	srli	a1,a1,0x20
    8000345e:	058a                	slli	a1,a1,0x2
    80003460:	00b784b3          	add	s1,a5,a1
    80003464:	0004a903          	lw	s2,0(s1)
    80003468:	00090e63          	beqz	s2,80003484 <bmap+0xa4>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    8000346c:	8552                	mv	a0,s4
    8000346e:	d01ff0ef          	jal	ra,8000316e <brelse>
    return addr;
  }

  panic("bmap: out of range");
}
    80003472:	854a                	mv	a0,s2
    80003474:	70a2                	ld	ra,40(sp)
    80003476:	7402                	ld	s0,32(sp)
    80003478:	64e2                	ld	s1,24(sp)
    8000347a:	6942                	ld	s2,16(sp)
    8000347c:	69a2                	ld	s3,8(sp)
    8000347e:	6a02                	ld	s4,0(sp)
    80003480:	6145                	addi	sp,sp,48
    80003482:	8082                	ret
      addr = balloc(ip->dev);
    80003484:	0009a503          	lw	a0,0(s3)
    80003488:	e45ff0ef          	jal	ra,800032cc <balloc>
    8000348c:	0005091b          	sext.w	s2,a0
      if(addr){
    80003490:	fc090ee3          	beqz	s2,8000346c <bmap+0x8c>
        a[bn] = addr;
    80003494:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    80003498:	8552                	mv	a0,s4
    8000349a:	5e1000ef          	jal	ra,8000427a <log_write>
    8000349e:	b7f9                	j	8000346c <bmap+0x8c>
  panic("bmap: out of range");
    800034a0:	00004517          	auipc	a0,0x4
    800034a4:	1d050513          	addi	a0,a0,464 # 80007670 <syscalls+0x140>
    800034a8:	ae6fd0ef          	jal	ra,8000078e <panic>

00000000800034ac <iget>:
{
    800034ac:	7179                	addi	sp,sp,-48
    800034ae:	f406                	sd	ra,40(sp)
    800034b0:	f022                	sd	s0,32(sp)
    800034b2:	ec26                	sd	s1,24(sp)
    800034b4:	e84a                	sd	s2,16(sp)
    800034b6:	e44e                	sd	s3,8(sp)
    800034b8:	e052                	sd	s4,0(sp)
    800034ba:	1800                	addi	s0,sp,48
    800034bc:	89aa                	mv	s3,a0
    800034be:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    800034c0:	0001b517          	auipc	a0,0x1b
    800034c4:	53050513          	addi	a0,a0,1328 # 8001e9f0 <itable>
    800034c8:	ef2fd0ef          	jal	ra,80000bba <acquire>
  empty = 0;
    800034cc:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800034ce:	0001b497          	auipc	s1,0x1b
    800034d2:	53a48493          	addi	s1,s1,1338 # 8001ea08 <itable+0x18>
    800034d6:	0001d697          	auipc	a3,0x1d
    800034da:	fc268693          	addi	a3,a3,-62 # 80020498 <log>
    800034de:	a039                	j	800034ec <iget+0x40>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    800034e0:	02090963          	beqz	s2,80003512 <iget+0x66>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800034e4:	08848493          	addi	s1,s1,136
    800034e8:	02d48863          	beq	s1,a3,80003518 <iget+0x6c>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800034ec:	449c                	lw	a5,8(s1)
    800034ee:	fef059e3          	blez	a5,800034e0 <iget+0x34>
    800034f2:	4098                	lw	a4,0(s1)
    800034f4:	ff3716e3          	bne	a4,s3,800034e0 <iget+0x34>
    800034f8:	40d8                	lw	a4,4(s1)
    800034fa:	ff4713e3          	bne	a4,s4,800034e0 <iget+0x34>
      ip->ref++;
    800034fe:	2785                	addiw	a5,a5,1
    80003500:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80003502:	0001b517          	auipc	a0,0x1b
    80003506:	4ee50513          	addi	a0,a0,1262 # 8001e9f0 <itable>
    8000350a:	f48fd0ef          	jal	ra,80000c52 <release>
      return ip;
    8000350e:	8926                	mv	s2,s1
    80003510:	a02d                	j	8000353a <iget+0x8e>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80003512:	fbe9                	bnez	a5,800034e4 <iget+0x38>
    80003514:	8926                	mv	s2,s1
    80003516:	b7f9                	j	800034e4 <iget+0x38>
  if(empty == 0)
    80003518:	02090a63          	beqz	s2,8000354c <iget+0xa0>
  ip->dev = dev;
    8000351c:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    80003520:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80003524:	4785                	li	a5,1
    80003526:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    8000352a:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    8000352e:	0001b517          	auipc	a0,0x1b
    80003532:	4c250513          	addi	a0,a0,1218 # 8001e9f0 <itable>
    80003536:	f1cfd0ef          	jal	ra,80000c52 <release>
}
    8000353a:	854a                	mv	a0,s2
    8000353c:	70a2                	ld	ra,40(sp)
    8000353e:	7402                	ld	s0,32(sp)
    80003540:	64e2                	ld	s1,24(sp)
    80003542:	6942                	ld	s2,16(sp)
    80003544:	69a2                	ld	s3,8(sp)
    80003546:	6a02                	ld	s4,0(sp)
    80003548:	6145                	addi	sp,sp,48
    8000354a:	8082                	ret
    panic("iget: no inodes");
    8000354c:	00004517          	auipc	a0,0x4
    80003550:	13c50513          	addi	a0,a0,316 # 80007688 <syscalls+0x158>
    80003554:	a3afd0ef          	jal	ra,8000078e <panic>

0000000080003558 <iinit>:
{
    80003558:	7179                	addi	sp,sp,-48
    8000355a:	f406                	sd	ra,40(sp)
    8000355c:	f022                	sd	s0,32(sp)
    8000355e:	ec26                	sd	s1,24(sp)
    80003560:	e84a                	sd	s2,16(sp)
    80003562:	e44e                	sd	s3,8(sp)
    80003564:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003566:	00004597          	auipc	a1,0x4
    8000356a:	13258593          	addi	a1,a1,306 # 80007698 <syscalls+0x168>
    8000356e:	0001b517          	auipc	a0,0x1b
    80003572:	48250513          	addi	a0,a0,1154 # 8001e9f0 <itable>
    80003576:	dc4fd0ef          	jal	ra,80000b3a <initlock>
  for(i = 0; i < NINODE; i++) {
    8000357a:	0001b497          	auipc	s1,0x1b
    8000357e:	49e48493          	addi	s1,s1,1182 # 8001ea18 <itable+0x28>
    80003582:	0001d997          	auipc	s3,0x1d
    80003586:	f2698993          	addi	s3,s3,-218 # 800204a8 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    8000358a:	00004917          	auipc	s2,0x4
    8000358e:	11690913          	addi	s2,s2,278 # 800076a0 <syscalls+0x170>
    80003592:	85ca                	mv	a1,s2
    80003594:	8526                	mv	a0,s1
    80003596:	5a9000ef          	jal	ra,8000433e <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    8000359a:	08848493          	addi	s1,s1,136
    8000359e:	ff349ae3          	bne	s1,s3,80003592 <iinit+0x3a>
}
    800035a2:	70a2                	ld	ra,40(sp)
    800035a4:	7402                	ld	s0,32(sp)
    800035a6:	64e2                	ld	s1,24(sp)
    800035a8:	6942                	ld	s2,16(sp)
    800035aa:	69a2                	ld	s3,8(sp)
    800035ac:	6145                	addi	sp,sp,48
    800035ae:	8082                	ret

00000000800035b0 <ialloc>:
{
    800035b0:	715d                	addi	sp,sp,-80
    800035b2:	e486                	sd	ra,72(sp)
    800035b4:	e0a2                	sd	s0,64(sp)
    800035b6:	fc26                	sd	s1,56(sp)
    800035b8:	f84a                	sd	s2,48(sp)
    800035ba:	f44e                	sd	s3,40(sp)
    800035bc:	f052                	sd	s4,32(sp)
    800035be:	ec56                	sd	s5,24(sp)
    800035c0:	e85a                	sd	s6,16(sp)
    800035c2:	e45e                	sd	s7,8(sp)
    800035c4:	0880                	addi	s0,sp,80
  for(inum = 1; inum < sb.ninodes; inum++){
    800035c6:	0001b717          	auipc	a4,0x1b
    800035ca:	41672703          	lw	a4,1046(a4) # 8001e9dc <sb+0xc>
    800035ce:	4785                	li	a5,1
    800035d0:	04e7f663          	bgeu	a5,a4,8000361c <ialloc+0x6c>
    800035d4:	8aaa                	mv	s5,a0
    800035d6:	8bae                	mv	s7,a1
    800035d8:	4485                	li	s1,1
    bp = bread(dev, IBLOCK(inum, sb));
    800035da:	0001ba17          	auipc	s4,0x1b
    800035de:	3f6a0a13          	addi	s4,s4,1014 # 8001e9d0 <sb>
    800035e2:	00048b1b          	sext.w	s6,s1
    800035e6:	0044d593          	srli	a1,s1,0x4
    800035ea:	018a2783          	lw	a5,24(s4)
    800035ee:	9dbd                	addw	a1,a1,a5
    800035f0:	8556                	mv	a0,s5
    800035f2:	a75ff0ef          	jal	ra,80003066 <bread>
    800035f6:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    800035f8:	05850993          	addi	s3,a0,88
    800035fc:	00f4f793          	andi	a5,s1,15
    80003600:	079a                	slli	a5,a5,0x6
    80003602:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    80003604:	00099783          	lh	a5,0(s3)
    80003608:	cf85                	beqz	a5,80003640 <ialloc+0x90>
    brelse(bp);
    8000360a:	b65ff0ef          	jal	ra,8000316e <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    8000360e:	0485                	addi	s1,s1,1
    80003610:	00ca2703          	lw	a4,12(s4)
    80003614:	0004879b          	sext.w	a5,s1
    80003618:	fce7e5e3          	bltu	a5,a4,800035e2 <ialloc+0x32>
  printf("ialloc: no inodes\n");
    8000361c:	00004517          	auipc	a0,0x4
    80003620:	08c50513          	addi	a0,a0,140 # 800076a8 <syscalls+0x178>
    80003624:	ea5fc0ef          	jal	ra,800004c8 <printf>
  return 0;
    80003628:	4501                	li	a0,0
}
    8000362a:	60a6                	ld	ra,72(sp)
    8000362c:	6406                	ld	s0,64(sp)
    8000362e:	74e2                	ld	s1,56(sp)
    80003630:	7942                	ld	s2,48(sp)
    80003632:	79a2                	ld	s3,40(sp)
    80003634:	7a02                	ld	s4,32(sp)
    80003636:	6ae2                	ld	s5,24(sp)
    80003638:	6b42                	ld	s6,16(sp)
    8000363a:	6ba2                	ld	s7,8(sp)
    8000363c:	6161                	addi	sp,sp,80
    8000363e:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003640:	04000613          	li	a2,64
    80003644:	4581                	li	a1,0
    80003646:	854e                	mv	a0,s3
    80003648:	e46fd0ef          	jal	ra,80000c8e <memset>
      dip->type = type;
    8000364c:	01799023          	sh	s7,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80003650:	854a                	mv	a0,s2
    80003652:	429000ef          	jal	ra,8000427a <log_write>
      brelse(bp);
    80003656:	854a                	mv	a0,s2
    80003658:	b17ff0ef          	jal	ra,8000316e <brelse>
      return iget(dev, inum);
    8000365c:	85da                	mv	a1,s6
    8000365e:	8556                	mv	a0,s5
    80003660:	e4dff0ef          	jal	ra,800034ac <iget>
    80003664:	b7d9                	j	8000362a <ialloc+0x7a>

0000000080003666 <iupdate>:
{
    80003666:	1101                	addi	sp,sp,-32
    80003668:	ec06                	sd	ra,24(sp)
    8000366a:	e822                	sd	s0,16(sp)
    8000366c:	e426                	sd	s1,8(sp)
    8000366e:	e04a                	sd	s2,0(sp)
    80003670:	1000                	addi	s0,sp,32
    80003672:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003674:	415c                	lw	a5,4(a0)
    80003676:	0047d79b          	srliw	a5,a5,0x4
    8000367a:	0001b597          	auipc	a1,0x1b
    8000367e:	36e5a583          	lw	a1,878(a1) # 8001e9e8 <sb+0x18>
    80003682:	9dbd                	addw	a1,a1,a5
    80003684:	4108                	lw	a0,0(a0)
    80003686:	9e1ff0ef          	jal	ra,80003066 <bread>
    8000368a:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000368c:	05850793          	addi	a5,a0,88
    80003690:	40c8                	lw	a0,4(s1)
    80003692:	893d                	andi	a0,a0,15
    80003694:	051a                	slli	a0,a0,0x6
    80003696:	953e                	add	a0,a0,a5
  dip->type = ip->type;
    80003698:	04449703          	lh	a4,68(s1)
    8000369c:	00e51023          	sh	a4,0(a0)
  dip->major = ip->major;
    800036a0:	04649703          	lh	a4,70(s1)
    800036a4:	00e51123          	sh	a4,2(a0)
  dip->minor = ip->minor;
    800036a8:	04849703          	lh	a4,72(s1)
    800036ac:	00e51223          	sh	a4,4(a0)
  dip->nlink = ip->nlink;
    800036b0:	04a49703          	lh	a4,74(s1)
    800036b4:	00e51323          	sh	a4,6(a0)
  dip->size = ip->size;
    800036b8:	44f8                	lw	a4,76(s1)
    800036ba:	c518                	sw	a4,8(a0)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    800036bc:	03400613          	li	a2,52
    800036c0:	05048593          	addi	a1,s1,80
    800036c4:	0531                	addi	a0,a0,12
    800036c6:	e28fd0ef          	jal	ra,80000cee <memmove>
  log_write(bp);
    800036ca:	854a                	mv	a0,s2
    800036cc:	3af000ef          	jal	ra,8000427a <log_write>
  brelse(bp);
    800036d0:	854a                	mv	a0,s2
    800036d2:	a9dff0ef          	jal	ra,8000316e <brelse>
}
    800036d6:	60e2                	ld	ra,24(sp)
    800036d8:	6442                	ld	s0,16(sp)
    800036da:	64a2                	ld	s1,8(sp)
    800036dc:	6902                	ld	s2,0(sp)
    800036de:	6105                	addi	sp,sp,32
    800036e0:	8082                	ret

00000000800036e2 <idup>:
{
    800036e2:	1101                	addi	sp,sp,-32
    800036e4:	ec06                	sd	ra,24(sp)
    800036e6:	e822                	sd	s0,16(sp)
    800036e8:	e426                	sd	s1,8(sp)
    800036ea:	1000                	addi	s0,sp,32
    800036ec:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800036ee:	0001b517          	auipc	a0,0x1b
    800036f2:	30250513          	addi	a0,a0,770 # 8001e9f0 <itable>
    800036f6:	cc4fd0ef          	jal	ra,80000bba <acquire>
  ip->ref++;
    800036fa:	449c                	lw	a5,8(s1)
    800036fc:	2785                	addiw	a5,a5,1
    800036fe:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003700:	0001b517          	auipc	a0,0x1b
    80003704:	2f050513          	addi	a0,a0,752 # 8001e9f0 <itable>
    80003708:	d4afd0ef          	jal	ra,80000c52 <release>
}
    8000370c:	8526                	mv	a0,s1
    8000370e:	60e2                	ld	ra,24(sp)
    80003710:	6442                	ld	s0,16(sp)
    80003712:	64a2                	ld	s1,8(sp)
    80003714:	6105                	addi	sp,sp,32
    80003716:	8082                	ret

0000000080003718 <ilock>:
{
    80003718:	1101                	addi	sp,sp,-32
    8000371a:	ec06                	sd	ra,24(sp)
    8000371c:	e822                	sd	s0,16(sp)
    8000371e:	e426                	sd	s1,8(sp)
    80003720:	e04a                	sd	s2,0(sp)
    80003722:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    80003724:	c105                	beqz	a0,80003744 <ilock+0x2c>
    80003726:	84aa                	mv	s1,a0
    80003728:	451c                	lw	a5,8(a0)
    8000372a:	00f05d63          	blez	a5,80003744 <ilock+0x2c>
  acquiresleep(&ip->lock);
    8000372e:	0541                	addi	a0,a0,16
    80003730:	445000ef          	jal	ra,80004374 <acquiresleep>
  if(ip->valid == 0){
    80003734:	40bc                	lw	a5,64(s1)
    80003736:	cf89                	beqz	a5,80003750 <ilock+0x38>
}
    80003738:	60e2                	ld	ra,24(sp)
    8000373a:	6442                	ld	s0,16(sp)
    8000373c:	64a2                	ld	s1,8(sp)
    8000373e:	6902                	ld	s2,0(sp)
    80003740:	6105                	addi	sp,sp,32
    80003742:	8082                	ret
    panic("ilock");
    80003744:	00004517          	auipc	a0,0x4
    80003748:	f7c50513          	addi	a0,a0,-132 # 800076c0 <syscalls+0x190>
    8000374c:	842fd0ef          	jal	ra,8000078e <panic>
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003750:	40dc                	lw	a5,4(s1)
    80003752:	0047d79b          	srliw	a5,a5,0x4
    80003756:	0001b597          	auipc	a1,0x1b
    8000375a:	2925a583          	lw	a1,658(a1) # 8001e9e8 <sb+0x18>
    8000375e:	9dbd                	addw	a1,a1,a5
    80003760:	4088                	lw	a0,0(s1)
    80003762:	905ff0ef          	jal	ra,80003066 <bread>
    80003766:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    80003768:	05850593          	addi	a1,a0,88
    8000376c:	40dc                	lw	a5,4(s1)
    8000376e:	8bbd                	andi	a5,a5,15
    80003770:	079a                	slli	a5,a5,0x6
    80003772:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003774:	00059783          	lh	a5,0(a1)
    80003778:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    8000377c:	00259783          	lh	a5,2(a1)
    80003780:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80003784:	00459783          	lh	a5,4(a1)
    80003788:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    8000378c:	00659783          	lh	a5,6(a1)
    80003790:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80003794:	459c                	lw	a5,8(a1)
    80003796:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80003798:	03400613          	li	a2,52
    8000379c:	05b1                	addi	a1,a1,12
    8000379e:	05048513          	addi	a0,s1,80
    800037a2:	d4cfd0ef          	jal	ra,80000cee <memmove>
    brelse(bp);
    800037a6:	854a                	mv	a0,s2
    800037a8:	9c7ff0ef          	jal	ra,8000316e <brelse>
    ip->valid = 1;
    800037ac:	4785                	li	a5,1
    800037ae:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    800037b0:	04449783          	lh	a5,68(s1)
    800037b4:	f3d1                	bnez	a5,80003738 <ilock+0x20>
      panic("ilock: no type");
    800037b6:	00004517          	auipc	a0,0x4
    800037ba:	f1250513          	addi	a0,a0,-238 # 800076c8 <syscalls+0x198>
    800037be:	fd1fc0ef          	jal	ra,8000078e <panic>

00000000800037c2 <iunlock>:
{
    800037c2:	1101                	addi	sp,sp,-32
    800037c4:	ec06                	sd	ra,24(sp)
    800037c6:	e822                	sd	s0,16(sp)
    800037c8:	e426                	sd	s1,8(sp)
    800037ca:	e04a                	sd	s2,0(sp)
    800037cc:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    800037ce:	c505                	beqz	a0,800037f6 <iunlock+0x34>
    800037d0:	84aa                	mv	s1,a0
    800037d2:	01050913          	addi	s2,a0,16
    800037d6:	854a                	mv	a0,s2
    800037d8:	41b000ef          	jal	ra,800043f2 <holdingsleep>
    800037dc:	cd09                	beqz	a0,800037f6 <iunlock+0x34>
    800037de:	449c                	lw	a5,8(s1)
    800037e0:	00f05b63          	blez	a5,800037f6 <iunlock+0x34>
  releasesleep(&ip->lock);
    800037e4:	854a                	mv	a0,s2
    800037e6:	3d5000ef          	jal	ra,800043ba <releasesleep>
}
    800037ea:	60e2                	ld	ra,24(sp)
    800037ec:	6442                	ld	s0,16(sp)
    800037ee:	64a2                	ld	s1,8(sp)
    800037f0:	6902                	ld	s2,0(sp)
    800037f2:	6105                	addi	sp,sp,32
    800037f4:	8082                	ret
    panic("iunlock");
    800037f6:	00004517          	auipc	a0,0x4
    800037fa:	ee250513          	addi	a0,a0,-286 # 800076d8 <syscalls+0x1a8>
    800037fe:	f91fc0ef          	jal	ra,8000078e <panic>

0000000080003802 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80003802:	7179                	addi	sp,sp,-48
    80003804:	f406                	sd	ra,40(sp)
    80003806:	f022                	sd	s0,32(sp)
    80003808:	ec26                	sd	s1,24(sp)
    8000380a:	e84a                	sd	s2,16(sp)
    8000380c:	e44e                	sd	s3,8(sp)
    8000380e:	e052                	sd	s4,0(sp)
    80003810:	1800                	addi	s0,sp,48
    80003812:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    80003814:	05050493          	addi	s1,a0,80
    80003818:	08050913          	addi	s2,a0,128
    8000381c:	a021                	j	80003824 <itrunc+0x22>
    8000381e:	0491                	addi	s1,s1,4
    80003820:	01248b63          	beq	s1,s2,80003836 <itrunc+0x34>
    if(ip->addrs[i]){
    80003824:	408c                	lw	a1,0(s1)
    80003826:	dde5                	beqz	a1,8000381e <itrunc+0x1c>
      bfree(ip->dev, ip->addrs[i]);
    80003828:	0009a503          	lw	a0,0(s3)
    8000382c:	a35ff0ef          	jal	ra,80003260 <bfree>
      ip->addrs[i] = 0;
    80003830:	0004a023          	sw	zero,0(s1)
    80003834:	b7ed                	j	8000381e <itrunc+0x1c>
    }
  }

  if(ip->addrs[NDIRECT]){
    80003836:	0809a583          	lw	a1,128(s3)
    8000383a:	ed91                	bnez	a1,80003856 <itrunc+0x54>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    8000383c:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003840:	854e                	mv	a0,s3
    80003842:	e25ff0ef          	jal	ra,80003666 <iupdate>
}
    80003846:	70a2                	ld	ra,40(sp)
    80003848:	7402                	ld	s0,32(sp)
    8000384a:	64e2                	ld	s1,24(sp)
    8000384c:	6942                	ld	s2,16(sp)
    8000384e:	69a2                	ld	s3,8(sp)
    80003850:	6a02                	ld	s4,0(sp)
    80003852:	6145                	addi	sp,sp,48
    80003854:	8082                	ret
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80003856:	0009a503          	lw	a0,0(s3)
    8000385a:	80dff0ef          	jal	ra,80003066 <bread>
    8000385e:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80003860:	05850493          	addi	s1,a0,88
    80003864:	45850913          	addi	s2,a0,1112
    80003868:	a801                	j	80003878 <itrunc+0x76>
        bfree(ip->dev, a[j]);
    8000386a:	0009a503          	lw	a0,0(s3)
    8000386e:	9f3ff0ef          	jal	ra,80003260 <bfree>
    for(j = 0; j < NINDIRECT; j++){
    80003872:	0491                	addi	s1,s1,4
    80003874:	01248563          	beq	s1,s2,8000387e <itrunc+0x7c>
      if(a[j])
    80003878:	408c                	lw	a1,0(s1)
    8000387a:	dde5                	beqz	a1,80003872 <itrunc+0x70>
    8000387c:	b7fd                	j	8000386a <itrunc+0x68>
    brelse(bp);
    8000387e:	8552                	mv	a0,s4
    80003880:	8efff0ef          	jal	ra,8000316e <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80003884:	0809a583          	lw	a1,128(s3)
    80003888:	0009a503          	lw	a0,0(s3)
    8000388c:	9d5ff0ef          	jal	ra,80003260 <bfree>
    ip->addrs[NDIRECT] = 0;
    80003890:	0809a023          	sw	zero,128(s3)
    80003894:	b765                	j	8000383c <itrunc+0x3a>

0000000080003896 <iput>:
{
    80003896:	1101                	addi	sp,sp,-32
    80003898:	ec06                	sd	ra,24(sp)
    8000389a:	e822                	sd	s0,16(sp)
    8000389c:	e426                	sd	s1,8(sp)
    8000389e:	e04a                	sd	s2,0(sp)
    800038a0:	1000                	addi	s0,sp,32
    800038a2:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800038a4:	0001b517          	auipc	a0,0x1b
    800038a8:	14c50513          	addi	a0,a0,332 # 8001e9f0 <itable>
    800038ac:	b0efd0ef          	jal	ra,80000bba <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800038b0:	4498                	lw	a4,8(s1)
    800038b2:	4785                	li	a5,1
    800038b4:	02f70163          	beq	a4,a5,800038d6 <iput+0x40>
  ip->ref--;
    800038b8:	449c                	lw	a5,8(s1)
    800038ba:	37fd                	addiw	a5,a5,-1
    800038bc:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800038be:	0001b517          	auipc	a0,0x1b
    800038c2:	13250513          	addi	a0,a0,306 # 8001e9f0 <itable>
    800038c6:	b8cfd0ef          	jal	ra,80000c52 <release>
}
    800038ca:	60e2                	ld	ra,24(sp)
    800038cc:	6442                	ld	s0,16(sp)
    800038ce:	64a2                	ld	s1,8(sp)
    800038d0:	6902                	ld	s2,0(sp)
    800038d2:	6105                	addi	sp,sp,32
    800038d4:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800038d6:	40bc                	lw	a5,64(s1)
    800038d8:	d3e5                	beqz	a5,800038b8 <iput+0x22>
    800038da:	04a49783          	lh	a5,74(s1)
    800038de:	ffe9                	bnez	a5,800038b8 <iput+0x22>
    acquiresleep(&ip->lock);
    800038e0:	01048913          	addi	s2,s1,16
    800038e4:	854a                	mv	a0,s2
    800038e6:	28f000ef          	jal	ra,80004374 <acquiresleep>
    release(&itable.lock);
    800038ea:	0001b517          	auipc	a0,0x1b
    800038ee:	10650513          	addi	a0,a0,262 # 8001e9f0 <itable>
    800038f2:	b60fd0ef          	jal	ra,80000c52 <release>
    itrunc(ip);
    800038f6:	8526                	mv	a0,s1
    800038f8:	f0bff0ef          	jal	ra,80003802 <itrunc>
    ip->type = 0;
    800038fc:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80003900:	8526                	mv	a0,s1
    80003902:	d65ff0ef          	jal	ra,80003666 <iupdate>
    ip->valid = 0;
    80003906:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    8000390a:	854a                	mv	a0,s2
    8000390c:	2af000ef          	jal	ra,800043ba <releasesleep>
    acquire(&itable.lock);
    80003910:	0001b517          	auipc	a0,0x1b
    80003914:	0e050513          	addi	a0,a0,224 # 8001e9f0 <itable>
    80003918:	aa2fd0ef          	jal	ra,80000bba <acquire>
    8000391c:	bf71                	j	800038b8 <iput+0x22>

000000008000391e <iunlockput>:
{
    8000391e:	1101                	addi	sp,sp,-32
    80003920:	ec06                	sd	ra,24(sp)
    80003922:	e822                	sd	s0,16(sp)
    80003924:	e426                	sd	s1,8(sp)
    80003926:	1000                	addi	s0,sp,32
    80003928:	84aa                	mv	s1,a0
  iunlock(ip);
    8000392a:	e99ff0ef          	jal	ra,800037c2 <iunlock>
  iput(ip);
    8000392e:	8526                	mv	a0,s1
    80003930:	f67ff0ef          	jal	ra,80003896 <iput>
}
    80003934:	60e2                	ld	ra,24(sp)
    80003936:	6442                	ld	s0,16(sp)
    80003938:	64a2                	ld	s1,8(sp)
    8000393a:	6105                	addi	sp,sp,32
    8000393c:	8082                	ret

000000008000393e <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    8000393e:	0001b717          	auipc	a4,0x1b
    80003942:	09e72703          	lw	a4,158(a4) # 8001e9dc <sb+0xc>
    80003946:	4785                	li	a5,1
    80003948:	0ae7ff63          	bgeu	a5,a4,80003a06 <ireclaim+0xc8>
{
    8000394c:	7139                	addi	sp,sp,-64
    8000394e:	fc06                	sd	ra,56(sp)
    80003950:	f822                	sd	s0,48(sp)
    80003952:	f426                	sd	s1,40(sp)
    80003954:	f04a                	sd	s2,32(sp)
    80003956:	ec4e                	sd	s3,24(sp)
    80003958:	e852                	sd	s4,16(sp)
    8000395a:	e456                	sd	s5,8(sp)
    8000395c:	e05a                	sd	s6,0(sp)
    8000395e:	0080                	addi	s0,sp,64
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003960:	4485                	li	s1,1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003962:	00050a1b          	sext.w	s4,a0
    80003966:	0001ba97          	auipc	s5,0x1b
    8000396a:	06aa8a93          	addi	s5,s5,106 # 8001e9d0 <sb>
      printf("ireclaim: orphaned inode %d\n", inum);
    8000396e:	00004b17          	auipc	s6,0x4
    80003972:	d72b0b13          	addi	s6,s6,-654 # 800076e0 <syscalls+0x1b0>
    80003976:	a099                	j	800039bc <ireclaim+0x7e>
    80003978:	85ce                	mv	a1,s3
    8000397a:	855a                	mv	a0,s6
    8000397c:	b4dfc0ef          	jal	ra,800004c8 <printf>
      ip = iget(dev, inum);
    80003980:	85ce                	mv	a1,s3
    80003982:	8552                	mv	a0,s4
    80003984:	b29ff0ef          	jal	ra,800034ac <iget>
    80003988:	89aa                	mv	s3,a0
    brelse(bp);
    8000398a:	854a                	mv	a0,s2
    8000398c:	fe2ff0ef          	jal	ra,8000316e <brelse>
    if (ip) {
    80003990:	00098f63          	beqz	s3,800039ae <ireclaim+0x70>
      begin_op();
    80003994:	762000ef          	jal	ra,800040f6 <begin_op>
      ilock(ip);
    80003998:	854e                	mv	a0,s3
    8000399a:	d7fff0ef          	jal	ra,80003718 <ilock>
      iunlock(ip);
    8000399e:	854e                	mv	a0,s3
    800039a0:	e23ff0ef          	jal	ra,800037c2 <iunlock>
      iput(ip);
    800039a4:	854e                	mv	a0,s3
    800039a6:	ef1ff0ef          	jal	ra,80003896 <iput>
      end_op();
    800039aa:	7bc000ef          	jal	ra,80004166 <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800039ae:	0485                	addi	s1,s1,1
    800039b0:	00caa703          	lw	a4,12(s5)
    800039b4:	0004879b          	sext.w	a5,s1
    800039b8:	02e7fd63          	bgeu	a5,a4,800039f2 <ireclaim+0xb4>
    800039bc:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800039c0:	0044d593          	srli	a1,s1,0x4
    800039c4:	018aa783          	lw	a5,24(s5)
    800039c8:	9dbd                	addw	a1,a1,a5
    800039ca:	8552                	mv	a0,s4
    800039cc:	e9aff0ef          	jal	ra,80003066 <bread>
    800039d0:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    800039d2:	05850793          	addi	a5,a0,88
    800039d6:	00f9f713          	andi	a4,s3,15
    800039da:	071a                	slli	a4,a4,0x6
    800039dc:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) {  // is an orphaned inode
    800039de:	00079703          	lh	a4,0(a5)
    800039e2:	c701                	beqz	a4,800039ea <ireclaim+0xac>
    800039e4:	00679783          	lh	a5,6(a5)
    800039e8:	dbc1                	beqz	a5,80003978 <ireclaim+0x3a>
    brelse(bp);
    800039ea:	854a                	mv	a0,s2
    800039ec:	f82ff0ef          	jal	ra,8000316e <brelse>
    if (ip) {
    800039f0:	bf7d                	j	800039ae <ireclaim+0x70>
}
    800039f2:	70e2                	ld	ra,56(sp)
    800039f4:	7442                	ld	s0,48(sp)
    800039f6:	74a2                	ld	s1,40(sp)
    800039f8:	7902                	ld	s2,32(sp)
    800039fa:	69e2                	ld	s3,24(sp)
    800039fc:	6a42                	ld	s4,16(sp)
    800039fe:	6aa2                	ld	s5,8(sp)
    80003a00:	6b02                	ld	s6,0(sp)
    80003a02:	6121                	addi	sp,sp,64
    80003a04:	8082                	ret
    80003a06:	8082                	ret

0000000080003a08 <fsinit>:
fsinit(int dev) {
    80003a08:	7179                	addi	sp,sp,-48
    80003a0a:	f406                	sd	ra,40(sp)
    80003a0c:	f022                	sd	s0,32(sp)
    80003a0e:	ec26                	sd	s1,24(sp)
    80003a10:	e84a                	sd	s2,16(sp)
    80003a12:	e44e                	sd	s3,8(sp)
    80003a14:	1800                	addi	s0,sp,48
    80003a16:	84aa                	mv	s1,a0
  bp = bread(dev, 1);
    80003a18:	4585                	li	a1,1
    80003a1a:	e4cff0ef          	jal	ra,80003066 <bread>
    80003a1e:	892a                	mv	s2,a0
  memmove(sb, bp->data, sizeof(*sb));
    80003a20:	0001b997          	auipc	s3,0x1b
    80003a24:	fb098993          	addi	s3,s3,-80 # 8001e9d0 <sb>
    80003a28:	02000613          	li	a2,32
    80003a2c:	05850593          	addi	a1,a0,88
    80003a30:	854e                	mv	a0,s3
    80003a32:	abcfd0ef          	jal	ra,80000cee <memmove>
  brelse(bp);
    80003a36:	854a                	mv	a0,s2
    80003a38:	f36ff0ef          	jal	ra,8000316e <brelse>
  if(sb.magic != FSMAGIC)
    80003a3c:	0009a703          	lw	a4,0(s3)
    80003a40:	102037b7          	lui	a5,0x10203
    80003a44:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80003a48:	02f71363          	bne	a4,a5,80003a6e <fsinit+0x66>
  initlog(dev, &sb);
    80003a4c:	0001b597          	auipc	a1,0x1b
    80003a50:	f8458593          	addi	a1,a1,-124 # 8001e9d0 <sb>
    80003a54:	8526                	mv	a0,s1
    80003a56:	616000ef          	jal	ra,8000406c <initlog>
  ireclaim(dev);
    80003a5a:	8526                	mv	a0,s1
    80003a5c:	ee3ff0ef          	jal	ra,8000393e <ireclaim>
}
    80003a60:	70a2                	ld	ra,40(sp)
    80003a62:	7402                	ld	s0,32(sp)
    80003a64:	64e2                	ld	s1,24(sp)
    80003a66:	6942                	ld	s2,16(sp)
    80003a68:	69a2                	ld	s3,8(sp)
    80003a6a:	6145                	addi	sp,sp,48
    80003a6c:	8082                	ret
    panic("invalid file system");
    80003a6e:	00004517          	auipc	a0,0x4
    80003a72:	c9250513          	addi	a0,a0,-878 # 80007700 <syscalls+0x1d0>
    80003a76:	d19fc0ef          	jal	ra,8000078e <panic>

0000000080003a7a <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003a7a:	1141                	addi	sp,sp,-16
    80003a7c:	e422                	sd	s0,8(sp)
    80003a7e:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003a80:	411c                	lw	a5,0(a0)
    80003a82:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80003a84:	415c                	lw	a5,4(a0)
    80003a86:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80003a88:	04451783          	lh	a5,68(a0)
    80003a8c:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003a90:	04a51783          	lh	a5,74(a0)
    80003a94:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003a98:	04c56783          	lwu	a5,76(a0)
    80003a9c:	e99c                	sd	a5,16(a1)
}
    80003a9e:	6422                	ld	s0,8(sp)
    80003aa0:	0141                	addi	sp,sp,16
    80003aa2:	8082                	ret

0000000080003aa4 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003aa4:	457c                	lw	a5,76(a0)
    80003aa6:	0cd7ef63          	bltu	a5,a3,80003b84 <readi+0xe0>
{
    80003aaa:	7159                	addi	sp,sp,-112
    80003aac:	f486                	sd	ra,104(sp)
    80003aae:	f0a2                	sd	s0,96(sp)
    80003ab0:	eca6                	sd	s1,88(sp)
    80003ab2:	e8ca                	sd	s2,80(sp)
    80003ab4:	e4ce                	sd	s3,72(sp)
    80003ab6:	e0d2                	sd	s4,64(sp)
    80003ab8:	fc56                	sd	s5,56(sp)
    80003aba:	f85a                	sd	s6,48(sp)
    80003abc:	f45e                	sd	s7,40(sp)
    80003abe:	f062                	sd	s8,32(sp)
    80003ac0:	ec66                	sd	s9,24(sp)
    80003ac2:	e86a                	sd	s10,16(sp)
    80003ac4:	e46e                	sd	s11,8(sp)
    80003ac6:	1880                	addi	s0,sp,112
    80003ac8:	8b2a                	mv	s6,a0
    80003aca:	8bae                	mv	s7,a1
    80003acc:	8a32                	mv	s4,a2
    80003ace:	84b6                	mv	s1,a3
    80003ad0:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80003ad2:	9f35                	addw	a4,a4,a3
    return 0;
    80003ad4:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80003ad6:	08d76663          	bltu	a4,a3,80003b62 <readi+0xbe>
  if(off + n > ip->size)
    80003ada:	00e7f463          	bgeu	a5,a4,80003ae2 <readi+0x3e>
    n = ip->size - off;
    80003ade:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003ae2:	080a8f63          	beqz	s5,80003b80 <readi+0xdc>
    80003ae6:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003ae8:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80003aec:	5c7d                	li	s8,-1
    80003aee:	a80d                	j	80003b20 <readi+0x7c>
    80003af0:	020d1d93          	slli	s11,s10,0x20
    80003af4:	020ddd93          	srli	s11,s11,0x20
    80003af8:	05890613          	addi	a2,s2,88
    80003afc:	86ee                	mv	a3,s11
    80003afe:	963a                	add	a2,a2,a4
    80003b00:	85d2                	mv	a1,s4
    80003b02:	855e                	mv	a0,s7
    80003b04:	88ffe0ef          	jal	ra,80002392 <either_copyout>
    80003b08:	05850763          	beq	a0,s8,80003b56 <readi+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003b0c:	854a                	mv	a0,s2
    80003b0e:	e60ff0ef          	jal	ra,8000316e <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003b12:	013d09bb          	addw	s3,s10,s3
    80003b16:	009d04bb          	addw	s1,s10,s1
    80003b1a:	9a6e                	add	s4,s4,s11
    80003b1c:	0559f163          	bgeu	s3,s5,80003b5e <readi+0xba>
    uint addr = bmap(ip, off/BSIZE);
    80003b20:	00a4d59b          	srliw	a1,s1,0xa
    80003b24:	855a                	mv	a0,s6
    80003b26:	8bbff0ef          	jal	ra,800033e0 <bmap>
    80003b2a:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003b2e:	c985                	beqz	a1,80003b5e <readi+0xba>
    bp = bread(ip->dev, addr);
    80003b30:	000b2503          	lw	a0,0(s6)
    80003b34:	d32ff0ef          	jal	ra,80003066 <bread>
    80003b38:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003b3a:	3ff4f713          	andi	a4,s1,1023
    80003b3e:	40ec87bb          	subw	a5,s9,a4
    80003b42:	413a86bb          	subw	a3,s5,s3
    80003b46:	8d3e                	mv	s10,a5
    80003b48:	2781                	sext.w	a5,a5
    80003b4a:	0006861b          	sext.w	a2,a3
    80003b4e:	faf671e3          	bgeu	a2,a5,80003af0 <readi+0x4c>
    80003b52:	8d36                	mv	s10,a3
    80003b54:	bf71                	j	80003af0 <readi+0x4c>
      brelse(bp);
    80003b56:	854a                	mv	a0,s2
    80003b58:	e16ff0ef          	jal	ra,8000316e <brelse>
      tot = -1;
    80003b5c:	59fd                	li	s3,-1
  }
  return tot;
    80003b5e:	0009851b          	sext.w	a0,s3
}
    80003b62:	70a6                	ld	ra,104(sp)
    80003b64:	7406                	ld	s0,96(sp)
    80003b66:	64e6                	ld	s1,88(sp)
    80003b68:	6946                	ld	s2,80(sp)
    80003b6a:	69a6                	ld	s3,72(sp)
    80003b6c:	6a06                	ld	s4,64(sp)
    80003b6e:	7ae2                	ld	s5,56(sp)
    80003b70:	7b42                	ld	s6,48(sp)
    80003b72:	7ba2                	ld	s7,40(sp)
    80003b74:	7c02                	ld	s8,32(sp)
    80003b76:	6ce2                	ld	s9,24(sp)
    80003b78:	6d42                	ld	s10,16(sp)
    80003b7a:	6da2                	ld	s11,8(sp)
    80003b7c:	6165                	addi	sp,sp,112
    80003b7e:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003b80:	89d6                	mv	s3,s5
    80003b82:	bff1                	j	80003b5e <readi+0xba>
    return 0;
    80003b84:	4501                	li	a0,0
}
    80003b86:	8082                	ret

0000000080003b88 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003b88:	457c                	lw	a5,76(a0)
    80003b8a:	0ed7ea63          	bltu	a5,a3,80003c7e <writei+0xf6>
{
    80003b8e:	7159                	addi	sp,sp,-112
    80003b90:	f486                	sd	ra,104(sp)
    80003b92:	f0a2                	sd	s0,96(sp)
    80003b94:	eca6                	sd	s1,88(sp)
    80003b96:	e8ca                	sd	s2,80(sp)
    80003b98:	e4ce                	sd	s3,72(sp)
    80003b9a:	e0d2                	sd	s4,64(sp)
    80003b9c:	fc56                	sd	s5,56(sp)
    80003b9e:	f85a                	sd	s6,48(sp)
    80003ba0:	f45e                	sd	s7,40(sp)
    80003ba2:	f062                	sd	s8,32(sp)
    80003ba4:	ec66                	sd	s9,24(sp)
    80003ba6:	e86a                	sd	s10,16(sp)
    80003ba8:	e46e                	sd	s11,8(sp)
    80003baa:	1880                	addi	s0,sp,112
    80003bac:	8aaa                	mv	s5,a0
    80003bae:	8bae                	mv	s7,a1
    80003bb0:	8a32                	mv	s4,a2
    80003bb2:	8936                	mv	s2,a3
    80003bb4:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80003bb6:	00e687bb          	addw	a5,a3,a4
    80003bba:	0cd7e463          	bltu	a5,a3,80003c82 <writei+0xfa>
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80003bbe:	00043737          	lui	a4,0x43
    80003bc2:	0cf76263          	bltu	a4,a5,80003c86 <writei+0xfe>
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003bc6:	0a0b0a63          	beqz	s6,80003c7a <writei+0xf2>
    80003bca:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003bcc:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003bd0:	5c7d                	li	s8,-1
    80003bd2:	a825                	j	80003c0a <writei+0x82>
    80003bd4:	020d1d93          	slli	s11,s10,0x20
    80003bd8:	020ddd93          	srli	s11,s11,0x20
    80003bdc:	05848513          	addi	a0,s1,88
    80003be0:	86ee                	mv	a3,s11
    80003be2:	8652                	mv	a2,s4
    80003be4:	85de                	mv	a1,s7
    80003be6:	953a                	add	a0,a0,a4
    80003be8:	ff4fe0ef          	jal	ra,800023dc <either_copyin>
    80003bec:	05850a63          	beq	a0,s8,80003c40 <writei+0xb8>
      brelse(bp);
      break;
    }
    log_write(bp);
    80003bf0:	8526                	mv	a0,s1
    80003bf2:	688000ef          	jal	ra,8000427a <log_write>
    brelse(bp);
    80003bf6:	8526                	mv	a0,s1
    80003bf8:	d76ff0ef          	jal	ra,8000316e <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003bfc:	013d09bb          	addw	s3,s10,s3
    80003c00:	012d093b          	addw	s2,s10,s2
    80003c04:	9a6e                	add	s4,s4,s11
    80003c06:	0569f063          	bgeu	s3,s6,80003c46 <writei+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80003c0a:	00a9559b          	srliw	a1,s2,0xa
    80003c0e:	8556                	mv	a0,s5
    80003c10:	fd0ff0ef          	jal	ra,800033e0 <bmap>
    80003c14:	0005059b          	sext.w	a1,a0
    if(addr == 0)
    80003c18:	c59d                	beqz	a1,80003c46 <writei+0xbe>
    bp = bread(ip->dev, addr);
    80003c1a:	000aa503          	lw	a0,0(s5)
    80003c1e:	c48ff0ef          	jal	ra,80003066 <bread>
    80003c22:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003c24:	3ff97713          	andi	a4,s2,1023
    80003c28:	40ec87bb          	subw	a5,s9,a4
    80003c2c:	413b06bb          	subw	a3,s6,s3
    80003c30:	8d3e                	mv	s10,a5
    80003c32:	2781                	sext.w	a5,a5
    80003c34:	0006861b          	sext.w	a2,a3
    80003c38:	f8f67ee3          	bgeu	a2,a5,80003bd4 <writei+0x4c>
    80003c3c:	8d36                	mv	s10,a3
    80003c3e:	bf59                	j	80003bd4 <writei+0x4c>
      brelse(bp);
    80003c40:	8526                	mv	a0,s1
    80003c42:	d2cff0ef          	jal	ra,8000316e <brelse>
  }

  if(off > ip->size)
    80003c46:	04caa783          	lw	a5,76(s5)
    80003c4a:	0127f463          	bgeu	a5,s2,80003c52 <writei+0xca>
    ip->size = off;
    80003c4e:	052aa623          	sw	s2,76(s5)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003c52:	8556                	mv	a0,s5
    80003c54:	a13ff0ef          	jal	ra,80003666 <iupdate>

  return tot;
    80003c58:	0009851b          	sext.w	a0,s3
}
    80003c5c:	70a6                	ld	ra,104(sp)
    80003c5e:	7406                	ld	s0,96(sp)
    80003c60:	64e6                	ld	s1,88(sp)
    80003c62:	6946                	ld	s2,80(sp)
    80003c64:	69a6                	ld	s3,72(sp)
    80003c66:	6a06                	ld	s4,64(sp)
    80003c68:	7ae2                	ld	s5,56(sp)
    80003c6a:	7b42                	ld	s6,48(sp)
    80003c6c:	7ba2                	ld	s7,40(sp)
    80003c6e:	7c02                	ld	s8,32(sp)
    80003c70:	6ce2                	ld	s9,24(sp)
    80003c72:	6d42                	ld	s10,16(sp)
    80003c74:	6da2                	ld	s11,8(sp)
    80003c76:	6165                	addi	sp,sp,112
    80003c78:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003c7a:	89da                	mv	s3,s6
    80003c7c:	bfd9                	j	80003c52 <writei+0xca>
    return -1;
    80003c7e:	557d                	li	a0,-1
}
    80003c80:	8082                	ret
    return -1;
    80003c82:	557d                	li	a0,-1
    80003c84:	bfe1                	j	80003c5c <writei+0xd4>
    return -1;
    80003c86:	557d                	li	a0,-1
    80003c88:	bfd1                	j	80003c5c <writei+0xd4>

0000000080003c8a <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003c8a:	1141                	addi	sp,sp,-16
    80003c8c:	e406                	sd	ra,8(sp)
    80003c8e:	e022                	sd	s0,0(sp)
    80003c90:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003c92:	4639                	li	a2,14
    80003c94:	8cefd0ef          	jal	ra,80000d62 <strncmp>
}
    80003c98:	60a2                	ld	ra,8(sp)
    80003c9a:	6402                	ld	s0,0(sp)
    80003c9c:	0141                	addi	sp,sp,16
    80003c9e:	8082                	ret

0000000080003ca0 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003ca0:	7139                	addi	sp,sp,-64
    80003ca2:	fc06                	sd	ra,56(sp)
    80003ca4:	f822                	sd	s0,48(sp)
    80003ca6:	f426                	sd	s1,40(sp)
    80003ca8:	f04a                	sd	s2,32(sp)
    80003caa:	ec4e                	sd	s3,24(sp)
    80003cac:	e852                	sd	s4,16(sp)
    80003cae:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003cb0:	04451703          	lh	a4,68(a0)
    80003cb4:	4785                	li	a5,1
    80003cb6:	00f71a63          	bne	a4,a5,80003cca <dirlookup+0x2a>
    80003cba:	892a                	mv	s2,a0
    80003cbc:	89ae                	mv	s3,a1
    80003cbe:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003cc0:	457c                	lw	a5,76(a0)
    80003cc2:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003cc4:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003cc6:	e39d                	bnez	a5,80003cec <dirlookup+0x4c>
    80003cc8:	a095                	j	80003d2c <dirlookup+0x8c>
    panic("dirlookup not DIR");
    80003cca:	00004517          	auipc	a0,0x4
    80003cce:	a4e50513          	addi	a0,a0,-1458 # 80007718 <syscalls+0x1e8>
    80003cd2:	abdfc0ef          	jal	ra,8000078e <panic>
      panic("dirlookup read");
    80003cd6:	00004517          	auipc	a0,0x4
    80003cda:	a5a50513          	addi	a0,a0,-1446 # 80007730 <syscalls+0x200>
    80003cde:	ab1fc0ef          	jal	ra,8000078e <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003ce2:	24c1                	addiw	s1,s1,16
    80003ce4:	04c92783          	lw	a5,76(s2)
    80003ce8:	04f4f163          	bgeu	s1,a5,80003d2a <dirlookup+0x8a>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003cec:	4741                	li	a4,16
    80003cee:	86a6                	mv	a3,s1
    80003cf0:	fc040613          	addi	a2,s0,-64
    80003cf4:	4581                	li	a1,0
    80003cf6:	854a                	mv	a0,s2
    80003cf8:	dadff0ef          	jal	ra,80003aa4 <readi>
    80003cfc:	47c1                	li	a5,16
    80003cfe:	fcf51ce3          	bne	a0,a5,80003cd6 <dirlookup+0x36>
    if(de.inum == 0)
    80003d02:	fc045783          	lhu	a5,-64(s0)
    80003d06:	dff1                	beqz	a5,80003ce2 <dirlookup+0x42>
    if(namecmp(name, de.name) == 0){
    80003d08:	fc240593          	addi	a1,s0,-62
    80003d0c:	854e                	mv	a0,s3
    80003d0e:	f7dff0ef          	jal	ra,80003c8a <namecmp>
    80003d12:	f961                	bnez	a0,80003ce2 <dirlookup+0x42>
      if(poff)
    80003d14:	000a0463          	beqz	s4,80003d1c <dirlookup+0x7c>
        *poff = off;
    80003d18:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80003d1c:	fc045583          	lhu	a1,-64(s0)
    80003d20:	00092503          	lw	a0,0(s2)
    80003d24:	f88ff0ef          	jal	ra,800034ac <iget>
    80003d28:	a011                	j	80003d2c <dirlookup+0x8c>
  return 0;
    80003d2a:	4501                	li	a0,0
}
    80003d2c:	70e2                	ld	ra,56(sp)
    80003d2e:	7442                	ld	s0,48(sp)
    80003d30:	74a2                	ld	s1,40(sp)
    80003d32:	7902                	ld	s2,32(sp)
    80003d34:	69e2                	ld	s3,24(sp)
    80003d36:	6a42                	ld	s4,16(sp)
    80003d38:	6121                	addi	sp,sp,64
    80003d3a:	8082                	ret

0000000080003d3c <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003d3c:	711d                	addi	sp,sp,-96
    80003d3e:	ec86                	sd	ra,88(sp)
    80003d40:	e8a2                	sd	s0,80(sp)
    80003d42:	e4a6                	sd	s1,72(sp)
    80003d44:	e0ca                	sd	s2,64(sp)
    80003d46:	fc4e                	sd	s3,56(sp)
    80003d48:	f852                	sd	s4,48(sp)
    80003d4a:	f456                	sd	s5,40(sp)
    80003d4c:	f05a                	sd	s6,32(sp)
    80003d4e:	ec5e                	sd	s7,24(sp)
    80003d50:	e862                	sd	s8,16(sp)
    80003d52:	e466                	sd	s9,8(sp)
    80003d54:	1080                	addi	s0,sp,96
    80003d56:	84aa                	mv	s1,a0
    80003d58:	8b2e                	mv	s6,a1
    80003d5a:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003d5c:	00054703          	lbu	a4,0(a0)
    80003d60:	02f00793          	li	a5,47
    80003d64:	00f70f63          	beq	a4,a5,80003d82 <namex+0x46>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003d68:	af3fd0ef          	jal	ra,8000185a <myproc>
    80003d6c:	15053503          	ld	a0,336(a0)
    80003d70:	973ff0ef          	jal	ra,800036e2 <idup>
    80003d74:	89aa                	mv	s3,a0
  while(*path == '/')
    80003d76:	02f00913          	li	s2,47
  len = path - s;
    80003d7a:	4b81                	li	s7,0
  if(len >= DIRSIZ)
    80003d7c:	4cb5                	li	s9,13

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003d7e:	4c05                	li	s8,1
    80003d80:	a861                	j	80003e18 <namex+0xdc>
    ip = iget(ROOTDEV, ROOTINO);
    80003d82:	4585                	li	a1,1
    80003d84:	4505                	li	a0,1
    80003d86:	f26ff0ef          	jal	ra,800034ac <iget>
    80003d8a:	89aa                	mv	s3,a0
    80003d8c:	b7ed                	j	80003d76 <namex+0x3a>
      iunlockput(ip);
    80003d8e:	854e                	mv	a0,s3
    80003d90:	b8fff0ef          	jal	ra,8000391e <iunlockput>
      return 0;
    80003d94:	4981                	li	s3,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003d96:	854e                	mv	a0,s3
    80003d98:	60e6                	ld	ra,88(sp)
    80003d9a:	6446                	ld	s0,80(sp)
    80003d9c:	64a6                	ld	s1,72(sp)
    80003d9e:	6906                	ld	s2,64(sp)
    80003da0:	79e2                	ld	s3,56(sp)
    80003da2:	7a42                	ld	s4,48(sp)
    80003da4:	7aa2                	ld	s5,40(sp)
    80003da6:	7b02                	ld	s6,32(sp)
    80003da8:	6be2                	ld	s7,24(sp)
    80003daa:	6c42                	ld	s8,16(sp)
    80003dac:	6ca2                	ld	s9,8(sp)
    80003dae:	6125                	addi	sp,sp,96
    80003db0:	8082                	ret
      iunlock(ip);
    80003db2:	854e                	mv	a0,s3
    80003db4:	a0fff0ef          	jal	ra,800037c2 <iunlock>
      return ip;
    80003db8:	bff9                	j	80003d96 <namex+0x5a>
      iunlockput(ip);
    80003dba:	854e                	mv	a0,s3
    80003dbc:	b63ff0ef          	jal	ra,8000391e <iunlockput>
      return 0;
    80003dc0:	89d2                	mv	s3,s4
    80003dc2:	bfd1                	j	80003d96 <namex+0x5a>
  len = path - s;
    80003dc4:	40b48633          	sub	a2,s1,a1
    80003dc8:	00060a1b          	sext.w	s4,a2
  if(len >= DIRSIZ)
    80003dcc:	074cdc63          	bge	s9,s4,80003e44 <namex+0x108>
    memmove(name, s, DIRSIZ);
    80003dd0:	4639                	li	a2,14
    80003dd2:	8556                	mv	a0,s5
    80003dd4:	f1bfc0ef          	jal	ra,80000cee <memmove>
  while(*path == '/')
    80003dd8:	0004c783          	lbu	a5,0(s1)
    80003ddc:	01279763          	bne	a5,s2,80003dea <namex+0xae>
    path++;
    80003de0:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003de2:	0004c783          	lbu	a5,0(s1)
    80003de6:	ff278de3          	beq	a5,s2,80003de0 <namex+0xa4>
    ilock(ip);
    80003dea:	854e                	mv	a0,s3
    80003dec:	92dff0ef          	jal	ra,80003718 <ilock>
    if(ip->type != T_DIR){
    80003df0:	04499783          	lh	a5,68(s3)
    80003df4:	f9879de3          	bne	a5,s8,80003d8e <namex+0x52>
    if(nameiparent && *path == '\0'){
    80003df8:	000b0563          	beqz	s6,80003e02 <namex+0xc6>
    80003dfc:	0004c783          	lbu	a5,0(s1)
    80003e00:	dbcd                	beqz	a5,80003db2 <namex+0x76>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003e02:	865e                	mv	a2,s7
    80003e04:	85d6                	mv	a1,s5
    80003e06:	854e                	mv	a0,s3
    80003e08:	e99ff0ef          	jal	ra,80003ca0 <dirlookup>
    80003e0c:	8a2a                	mv	s4,a0
    80003e0e:	d555                	beqz	a0,80003dba <namex+0x7e>
    iunlockput(ip);
    80003e10:	854e                	mv	a0,s3
    80003e12:	b0dff0ef          	jal	ra,8000391e <iunlockput>
    ip = next;
    80003e16:	89d2                	mv	s3,s4
  while(*path == '/')
    80003e18:	0004c783          	lbu	a5,0(s1)
    80003e1c:	05279363          	bne	a5,s2,80003e62 <namex+0x126>
    path++;
    80003e20:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003e22:	0004c783          	lbu	a5,0(s1)
    80003e26:	ff278de3          	beq	a5,s2,80003e20 <namex+0xe4>
  if(*path == 0)
    80003e2a:	c78d                	beqz	a5,80003e54 <namex+0x118>
    path++;
    80003e2c:	85a6                	mv	a1,s1
  len = path - s;
    80003e2e:	8a5e                	mv	s4,s7
    80003e30:	865e                	mv	a2,s7
  while(*path != '/' && *path != 0)
    80003e32:	01278963          	beq	a5,s2,80003e44 <namex+0x108>
    80003e36:	d7d9                	beqz	a5,80003dc4 <namex+0x88>
    path++;
    80003e38:	0485                	addi	s1,s1,1
  while(*path != '/' && *path != 0)
    80003e3a:	0004c783          	lbu	a5,0(s1)
    80003e3e:	ff279ce3          	bne	a5,s2,80003e36 <namex+0xfa>
    80003e42:	b749                	j	80003dc4 <namex+0x88>
    memmove(name, s, len);
    80003e44:	2601                	sext.w	a2,a2
    80003e46:	8556                	mv	a0,s5
    80003e48:	ea7fc0ef          	jal	ra,80000cee <memmove>
    name[len] = 0;
    80003e4c:	9a56                	add	s4,s4,s5
    80003e4e:	000a0023          	sb	zero,0(s4)
    80003e52:	b759                	j	80003dd8 <namex+0x9c>
  if(nameiparent){
    80003e54:	f40b01e3          	beqz	s6,80003d96 <namex+0x5a>
    iput(ip);
    80003e58:	854e                	mv	a0,s3
    80003e5a:	a3dff0ef          	jal	ra,80003896 <iput>
    return 0;
    80003e5e:	4981                	li	s3,0
    80003e60:	bf1d                	j	80003d96 <namex+0x5a>
  if(*path == 0)
    80003e62:	dbed                	beqz	a5,80003e54 <namex+0x118>
  while(*path != '/' && *path != 0)
    80003e64:	0004c783          	lbu	a5,0(s1)
    80003e68:	85a6                	mv	a1,s1
    80003e6a:	b7f1                	j	80003e36 <namex+0xfa>

0000000080003e6c <dirlink>:
{
    80003e6c:	7139                	addi	sp,sp,-64
    80003e6e:	fc06                	sd	ra,56(sp)
    80003e70:	f822                	sd	s0,48(sp)
    80003e72:	f426                	sd	s1,40(sp)
    80003e74:	f04a                	sd	s2,32(sp)
    80003e76:	ec4e                	sd	s3,24(sp)
    80003e78:	e852                	sd	s4,16(sp)
    80003e7a:	0080                	addi	s0,sp,64
    80003e7c:	892a                	mv	s2,a0
    80003e7e:	8a2e                	mv	s4,a1
    80003e80:	89b2                	mv	s3,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003e82:	4601                	li	a2,0
    80003e84:	e1dff0ef          	jal	ra,80003ca0 <dirlookup>
    80003e88:	e52d                	bnez	a0,80003ef2 <dirlink+0x86>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003e8a:	04c92483          	lw	s1,76(s2)
    80003e8e:	c48d                	beqz	s1,80003eb8 <dirlink+0x4c>
    80003e90:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003e92:	4741                	li	a4,16
    80003e94:	86a6                	mv	a3,s1
    80003e96:	fc040613          	addi	a2,s0,-64
    80003e9a:	4581                	li	a1,0
    80003e9c:	854a                	mv	a0,s2
    80003e9e:	c07ff0ef          	jal	ra,80003aa4 <readi>
    80003ea2:	47c1                	li	a5,16
    80003ea4:	04f51b63          	bne	a0,a5,80003efa <dirlink+0x8e>
    if(de.inum == 0)
    80003ea8:	fc045783          	lhu	a5,-64(s0)
    80003eac:	c791                	beqz	a5,80003eb8 <dirlink+0x4c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003eae:	24c1                	addiw	s1,s1,16
    80003eb0:	04c92783          	lw	a5,76(s2)
    80003eb4:	fcf4efe3          	bltu	s1,a5,80003e92 <dirlink+0x26>
  strncpy(de.name, name, DIRSIZ);
    80003eb8:	4639                	li	a2,14
    80003eba:	85d2                	mv	a1,s4
    80003ebc:	fc240513          	addi	a0,s0,-62
    80003ec0:	edffc0ef          	jal	ra,80000d9e <strncpy>
  de.inum = inum;
    80003ec4:	fd341023          	sh	s3,-64(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003ec8:	4741                	li	a4,16
    80003eca:	86a6                	mv	a3,s1
    80003ecc:	fc040613          	addi	a2,s0,-64
    80003ed0:	4581                	li	a1,0
    80003ed2:	854a                	mv	a0,s2
    80003ed4:	cb5ff0ef          	jal	ra,80003b88 <writei>
    80003ed8:	1541                	addi	a0,a0,-16
    80003eda:	00a03533          	snez	a0,a0
    80003ede:	40a00533          	neg	a0,a0
}
    80003ee2:	70e2                	ld	ra,56(sp)
    80003ee4:	7442                	ld	s0,48(sp)
    80003ee6:	74a2                	ld	s1,40(sp)
    80003ee8:	7902                	ld	s2,32(sp)
    80003eea:	69e2                	ld	s3,24(sp)
    80003eec:	6a42                	ld	s4,16(sp)
    80003eee:	6121                	addi	sp,sp,64
    80003ef0:	8082                	ret
    iput(ip);
    80003ef2:	9a5ff0ef          	jal	ra,80003896 <iput>
    return -1;
    80003ef6:	557d                	li	a0,-1
    80003ef8:	b7ed                	j	80003ee2 <dirlink+0x76>
      panic("dirlink read");
    80003efa:	00004517          	auipc	a0,0x4
    80003efe:	84650513          	addi	a0,a0,-1978 # 80007740 <syscalls+0x210>
    80003f02:	88dfc0ef          	jal	ra,8000078e <panic>

0000000080003f06 <namei>:

struct inode*
namei(char *path)
{
    80003f06:	1101                	addi	sp,sp,-32
    80003f08:	ec06                	sd	ra,24(sp)
    80003f0a:	e822                	sd	s0,16(sp)
    80003f0c:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003f0e:	fe040613          	addi	a2,s0,-32
    80003f12:	4581                	li	a1,0
    80003f14:	e29ff0ef          	jal	ra,80003d3c <namex>
}
    80003f18:	60e2                	ld	ra,24(sp)
    80003f1a:	6442                	ld	s0,16(sp)
    80003f1c:	6105                	addi	sp,sp,32
    80003f1e:	8082                	ret

0000000080003f20 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003f20:	1141                	addi	sp,sp,-16
    80003f22:	e406                	sd	ra,8(sp)
    80003f24:	e022                	sd	s0,0(sp)
    80003f26:	0800                	addi	s0,sp,16
    80003f28:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003f2a:	4585                	li	a1,1
    80003f2c:	e11ff0ef          	jal	ra,80003d3c <namex>
}
    80003f30:	60a2                	ld	ra,8(sp)
    80003f32:	6402                	ld	s0,0(sp)
    80003f34:	0141                	addi	sp,sp,16
    80003f36:	8082                	ret

0000000080003f38 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003f38:	1101                	addi	sp,sp,-32
    80003f3a:	ec06                	sd	ra,24(sp)
    80003f3c:	e822                	sd	s0,16(sp)
    80003f3e:	e426                	sd	s1,8(sp)
    80003f40:	e04a                	sd	s2,0(sp)
    80003f42:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003f44:	0001c917          	auipc	s2,0x1c
    80003f48:	55490913          	addi	s2,s2,1364 # 80020498 <log>
    80003f4c:	01892583          	lw	a1,24(s2)
    80003f50:	02492503          	lw	a0,36(s2)
    80003f54:	912ff0ef          	jal	ra,80003066 <bread>
    80003f58:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003f5a:	02892683          	lw	a3,40(s2)
    80003f5e:	cd34                	sw	a3,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003f60:	02d05763          	blez	a3,80003f8e <write_head+0x56>
    80003f64:	0001c797          	auipc	a5,0x1c
    80003f68:	56078793          	addi	a5,a5,1376 # 800204c4 <log+0x2c>
    80003f6c:	05c50713          	addi	a4,a0,92
    80003f70:	36fd                	addiw	a3,a3,-1
    80003f72:	1682                	slli	a3,a3,0x20
    80003f74:	9281                	srli	a3,a3,0x20
    80003f76:	068a                	slli	a3,a3,0x2
    80003f78:	0001c617          	auipc	a2,0x1c
    80003f7c:	55060613          	addi	a2,a2,1360 # 800204c8 <log+0x30>
    80003f80:	96b2                	add	a3,a3,a2
    hb->block[i] = log.lh.block[i];
    80003f82:	4390                	lw	a2,0(a5)
    80003f84:	c310                	sw	a2,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003f86:	0791                	addi	a5,a5,4
    80003f88:	0711                	addi	a4,a4,4
    80003f8a:	fed79ce3          	bne	a5,a3,80003f82 <write_head+0x4a>
  }
  bwrite(buf);
    80003f8e:	8526                	mv	a0,s1
    80003f90:	9acff0ef          	jal	ra,8000313c <bwrite>
  brelse(buf);
    80003f94:	8526                	mv	a0,s1
    80003f96:	9d8ff0ef          	jal	ra,8000316e <brelse>
}
    80003f9a:	60e2                	ld	ra,24(sp)
    80003f9c:	6442                	ld	s0,16(sp)
    80003f9e:	64a2                	ld	s1,8(sp)
    80003fa0:	6902                	ld	s2,0(sp)
    80003fa2:	6105                	addi	sp,sp,32
    80003fa4:	8082                	ret

0000000080003fa6 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003fa6:	0001c797          	auipc	a5,0x1c
    80003faa:	51a7a783          	lw	a5,1306(a5) # 800204c0 <log+0x28>
    80003fae:	0af05e63          	blez	a5,8000406a <install_trans+0xc4>
{
    80003fb2:	715d                	addi	sp,sp,-80
    80003fb4:	e486                	sd	ra,72(sp)
    80003fb6:	e0a2                	sd	s0,64(sp)
    80003fb8:	fc26                	sd	s1,56(sp)
    80003fba:	f84a                	sd	s2,48(sp)
    80003fbc:	f44e                	sd	s3,40(sp)
    80003fbe:	f052                	sd	s4,32(sp)
    80003fc0:	ec56                	sd	s5,24(sp)
    80003fc2:	e85a                	sd	s6,16(sp)
    80003fc4:	e45e                	sd	s7,8(sp)
    80003fc6:	0880                	addi	s0,sp,80
    80003fc8:	8b2a                	mv	s6,a0
    80003fca:	0001ca97          	auipc	s5,0x1c
    80003fce:	4faa8a93          	addi	s5,s5,1274 # 800204c4 <log+0x2c>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003fd2:	4981                	li	s3,0
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003fd4:	00003b97          	auipc	s7,0x3
    80003fd8:	77cb8b93          	addi	s7,s7,1916 # 80007750 <syscalls+0x220>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003fdc:	0001ca17          	auipc	s4,0x1c
    80003fe0:	4bca0a13          	addi	s4,s4,1212 # 80020498 <log>
    80003fe4:	a03d                	j	80004012 <install_trans+0x6c>
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003fe6:	000aa603          	lw	a2,0(s5)
    80003fea:	85ce                	mv	a1,s3
    80003fec:	855e                	mv	a0,s7
    80003fee:	cdafc0ef          	jal	ra,800004c8 <printf>
    80003ff2:	a015                	j	80004016 <install_trans+0x70>
      bunpin(dbuf);
    80003ff4:	8526                	mv	a0,s1
    80003ff6:	a36ff0ef          	jal	ra,8000322c <bunpin>
    brelse(lbuf);
    80003ffa:	854a                	mv	a0,s2
    80003ffc:	972ff0ef          	jal	ra,8000316e <brelse>
    brelse(dbuf);
    80004000:	8526                	mv	a0,s1
    80004002:	96cff0ef          	jal	ra,8000316e <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80004006:	2985                	addiw	s3,s3,1
    80004008:	0a91                	addi	s5,s5,4
    8000400a:	028a2783          	lw	a5,40(s4)
    8000400e:	04f9d363          	bge	s3,a5,80004054 <install_trans+0xae>
    if(recovering) {
    80004012:	fc0b1ae3          	bnez	s6,80003fe6 <install_trans+0x40>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80004016:	018a2583          	lw	a1,24(s4)
    8000401a:	013585bb          	addw	a1,a1,s3
    8000401e:	2585                	addiw	a1,a1,1
    80004020:	024a2503          	lw	a0,36(s4)
    80004024:	842ff0ef          	jal	ra,80003066 <bread>
    80004028:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    8000402a:	000aa583          	lw	a1,0(s5)
    8000402e:	024a2503          	lw	a0,36(s4)
    80004032:	834ff0ef          	jal	ra,80003066 <bread>
    80004036:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80004038:	40000613          	li	a2,1024
    8000403c:	05890593          	addi	a1,s2,88
    80004040:	05850513          	addi	a0,a0,88
    80004044:	cabfc0ef          	jal	ra,80000cee <memmove>
    bwrite(dbuf);  // write dst to disk
    80004048:	8526                	mv	a0,s1
    8000404a:	8f2ff0ef          	jal	ra,8000313c <bwrite>
    if(recovering == 0)
    8000404e:	fa0b16e3          	bnez	s6,80003ffa <install_trans+0x54>
    80004052:	b74d                	j	80003ff4 <install_trans+0x4e>
}
    80004054:	60a6                	ld	ra,72(sp)
    80004056:	6406                	ld	s0,64(sp)
    80004058:	74e2                	ld	s1,56(sp)
    8000405a:	7942                	ld	s2,48(sp)
    8000405c:	79a2                	ld	s3,40(sp)
    8000405e:	7a02                	ld	s4,32(sp)
    80004060:	6ae2                	ld	s5,24(sp)
    80004062:	6b42                	ld	s6,16(sp)
    80004064:	6ba2                	ld	s7,8(sp)
    80004066:	6161                	addi	sp,sp,80
    80004068:	8082                	ret
    8000406a:	8082                	ret

000000008000406c <initlog>:
{
    8000406c:	7179                	addi	sp,sp,-48
    8000406e:	f406                	sd	ra,40(sp)
    80004070:	f022                	sd	s0,32(sp)
    80004072:	ec26                	sd	s1,24(sp)
    80004074:	e84a                	sd	s2,16(sp)
    80004076:	e44e                	sd	s3,8(sp)
    80004078:	1800                	addi	s0,sp,48
    8000407a:	892a                	mv	s2,a0
    8000407c:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    8000407e:	0001c497          	auipc	s1,0x1c
    80004082:	41a48493          	addi	s1,s1,1050 # 80020498 <log>
    80004086:	00003597          	auipc	a1,0x3
    8000408a:	6ea58593          	addi	a1,a1,1770 # 80007770 <syscalls+0x240>
    8000408e:	8526                	mv	a0,s1
    80004090:	aabfc0ef          	jal	ra,80000b3a <initlock>
  log.start = sb->logstart;
    80004094:	0149a583          	lw	a1,20(s3)
    80004098:	cc8c                	sw	a1,24(s1)
  log.dev = dev;
    8000409a:	0324a223          	sw	s2,36(s1)
  struct buf *buf = bread(log.dev, log.start);
    8000409e:	854a                	mv	a0,s2
    800040a0:	fc7fe0ef          	jal	ra,80003066 <bread>
  log.lh.n = lh->n;
    800040a4:	4d3c                	lw	a5,88(a0)
    800040a6:	d49c                	sw	a5,40(s1)
  for (i = 0; i < log.lh.n; i++) {
    800040a8:	02f05563          	blez	a5,800040d2 <initlog+0x66>
    800040ac:	05c50713          	addi	a4,a0,92
    800040b0:	0001c697          	auipc	a3,0x1c
    800040b4:	41468693          	addi	a3,a3,1044 # 800204c4 <log+0x2c>
    800040b8:	37fd                	addiw	a5,a5,-1
    800040ba:	1782                	slli	a5,a5,0x20
    800040bc:	9381                	srli	a5,a5,0x20
    800040be:	078a                	slli	a5,a5,0x2
    800040c0:	06050613          	addi	a2,a0,96
    800040c4:	97b2                	add	a5,a5,a2
    log.lh.block[i] = lh->block[i];
    800040c6:	4310                	lw	a2,0(a4)
    800040c8:	c290                	sw	a2,0(a3)
  for (i = 0; i < log.lh.n; i++) {
    800040ca:	0711                	addi	a4,a4,4
    800040cc:	0691                	addi	a3,a3,4
    800040ce:	fef71ce3          	bne	a4,a5,800040c6 <initlog+0x5a>
  brelse(buf);
    800040d2:	89cff0ef          	jal	ra,8000316e <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    800040d6:	4505                	li	a0,1
    800040d8:	ecfff0ef          	jal	ra,80003fa6 <install_trans>
  log.lh.n = 0;
    800040dc:	0001c797          	auipc	a5,0x1c
    800040e0:	3e07a223          	sw	zero,996(a5) # 800204c0 <log+0x28>
  write_head(); // clear the log
    800040e4:	e55ff0ef          	jal	ra,80003f38 <write_head>
}
    800040e8:	70a2                	ld	ra,40(sp)
    800040ea:	7402                	ld	s0,32(sp)
    800040ec:	64e2                	ld	s1,24(sp)
    800040ee:	6942                	ld	s2,16(sp)
    800040f0:	69a2                	ld	s3,8(sp)
    800040f2:	6145                	addi	sp,sp,48
    800040f4:	8082                	ret

00000000800040f6 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    800040f6:	1101                	addi	sp,sp,-32
    800040f8:	ec06                	sd	ra,24(sp)
    800040fa:	e822                	sd	s0,16(sp)
    800040fc:	e426                	sd	s1,8(sp)
    800040fe:	e04a                	sd	s2,0(sp)
    80004100:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80004102:	0001c517          	auipc	a0,0x1c
    80004106:	39650513          	addi	a0,a0,918 # 80020498 <log>
    8000410a:	ab1fc0ef          	jal	ra,80000bba <acquire>
  while(1){
    if(log.committing){
    8000410e:	0001c497          	auipc	s1,0x1c
    80004112:	38a48493          	addi	s1,s1,906 # 80020498 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80004116:	4979                	li	s2,30
    80004118:	a029                	j	80004122 <begin_op+0x2c>
      sleep(&log, &log.lock);
    8000411a:	85a6                	mv	a1,s1
    8000411c:	8526                	mv	a0,s1
    8000411e:	ed9fd0ef          	jal	ra,80001ff6 <sleep>
    if(log.committing){
    80004122:	509c                	lw	a5,32(s1)
    80004124:	fbfd                	bnez	a5,8000411a <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80004126:	4cdc                	lw	a5,28(s1)
    80004128:	0017871b          	addiw	a4,a5,1
    8000412c:	0007069b          	sext.w	a3,a4
    80004130:	0027179b          	slliw	a5,a4,0x2
    80004134:	9fb9                	addw	a5,a5,a4
    80004136:	0017979b          	slliw	a5,a5,0x1
    8000413a:	5498                	lw	a4,40(s1)
    8000413c:	9fb9                	addw	a5,a5,a4
    8000413e:	00f95763          	bge	s2,a5,8000414c <begin_op+0x56>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80004142:	85a6                	mv	a1,s1
    80004144:	8526                	mv	a0,s1
    80004146:	eb1fd0ef          	jal	ra,80001ff6 <sleep>
    8000414a:	bfe1                	j	80004122 <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    8000414c:	0001c517          	auipc	a0,0x1c
    80004150:	34c50513          	addi	a0,a0,844 # 80020498 <log>
    80004154:	cd54                	sw	a3,28(a0)
      release(&log.lock);
    80004156:	afdfc0ef          	jal	ra,80000c52 <release>
      break;
    }
  }
}
    8000415a:	60e2                	ld	ra,24(sp)
    8000415c:	6442                	ld	s0,16(sp)
    8000415e:	64a2                	ld	s1,8(sp)
    80004160:	6902                	ld	s2,0(sp)
    80004162:	6105                	addi	sp,sp,32
    80004164:	8082                	ret

0000000080004166 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80004166:	7139                	addi	sp,sp,-64
    80004168:	fc06                	sd	ra,56(sp)
    8000416a:	f822                	sd	s0,48(sp)
    8000416c:	f426                	sd	s1,40(sp)
    8000416e:	f04a                	sd	s2,32(sp)
    80004170:	ec4e                	sd	s3,24(sp)
    80004172:	e852                	sd	s4,16(sp)
    80004174:	e456                	sd	s5,8(sp)
    80004176:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80004178:	0001c497          	auipc	s1,0x1c
    8000417c:	32048493          	addi	s1,s1,800 # 80020498 <log>
    80004180:	8526                	mv	a0,s1
    80004182:	a39fc0ef          	jal	ra,80000bba <acquire>
  log.outstanding -= 1;
    80004186:	4cdc                	lw	a5,28(s1)
    80004188:	37fd                	addiw	a5,a5,-1
    8000418a:	0007891b          	sext.w	s2,a5
    8000418e:	ccdc                	sw	a5,28(s1)
  if(log.committing)
    80004190:	509c                	lw	a5,32(s1)
    80004192:	e7b9                	bnez	a5,800041e0 <end_op+0x7a>
    panic("log.committing");
  if(log.outstanding == 0){
    80004194:	04091c63          	bnez	s2,800041ec <end_op+0x86>
    do_commit = 1;
    log.committing = 1;
    80004198:	0001c497          	auipc	s1,0x1c
    8000419c:	30048493          	addi	s1,s1,768 # 80020498 <log>
    800041a0:	4785                	li	a5,1
    800041a2:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    800041a4:	8526                	mv	a0,s1
    800041a6:	aadfc0ef          	jal	ra,80000c52 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    800041aa:	549c                	lw	a5,40(s1)
    800041ac:	04f04b63          	bgtz	a5,80004202 <end_op+0x9c>
    acquire(&log.lock);
    800041b0:	0001c497          	auipc	s1,0x1c
    800041b4:	2e848493          	addi	s1,s1,744 # 80020498 <log>
    800041b8:	8526                	mv	a0,s1
    800041ba:	a01fc0ef          	jal	ra,80000bba <acquire>
    log.committing = 0;
    800041be:	0204a023          	sw	zero,32(s1)
    wakeup(&log);
    800041c2:	8526                	mv	a0,s1
    800041c4:	e7ffd0ef          	jal	ra,80002042 <wakeup>
    release(&log.lock);
    800041c8:	8526                	mv	a0,s1
    800041ca:	a89fc0ef          	jal	ra,80000c52 <release>
}
    800041ce:	70e2                	ld	ra,56(sp)
    800041d0:	7442                	ld	s0,48(sp)
    800041d2:	74a2                	ld	s1,40(sp)
    800041d4:	7902                	ld	s2,32(sp)
    800041d6:	69e2                	ld	s3,24(sp)
    800041d8:	6a42                	ld	s4,16(sp)
    800041da:	6aa2                	ld	s5,8(sp)
    800041dc:	6121                	addi	sp,sp,64
    800041de:	8082                	ret
    panic("log.committing");
    800041e0:	00003517          	auipc	a0,0x3
    800041e4:	59850513          	addi	a0,a0,1432 # 80007778 <syscalls+0x248>
    800041e8:	da6fc0ef          	jal	ra,8000078e <panic>
    wakeup(&log);
    800041ec:	0001c497          	auipc	s1,0x1c
    800041f0:	2ac48493          	addi	s1,s1,684 # 80020498 <log>
    800041f4:	8526                	mv	a0,s1
    800041f6:	e4dfd0ef          	jal	ra,80002042 <wakeup>
  release(&log.lock);
    800041fa:	8526                	mv	a0,s1
    800041fc:	a57fc0ef          	jal	ra,80000c52 <release>
  if(do_commit){
    80004200:	b7f9                	j	800041ce <end_op+0x68>
  for (tail = 0; tail < log.lh.n; tail++) {
    80004202:	0001ca97          	auipc	s5,0x1c
    80004206:	2c2a8a93          	addi	s5,s5,706 # 800204c4 <log+0x2c>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    8000420a:	0001ca17          	auipc	s4,0x1c
    8000420e:	28ea0a13          	addi	s4,s4,654 # 80020498 <log>
    80004212:	018a2583          	lw	a1,24(s4)
    80004216:	012585bb          	addw	a1,a1,s2
    8000421a:	2585                	addiw	a1,a1,1
    8000421c:	024a2503          	lw	a0,36(s4)
    80004220:	e47fe0ef          	jal	ra,80003066 <bread>
    80004224:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80004226:	000aa583          	lw	a1,0(s5)
    8000422a:	024a2503          	lw	a0,36(s4)
    8000422e:	e39fe0ef          	jal	ra,80003066 <bread>
    80004232:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80004234:	40000613          	li	a2,1024
    80004238:	05850593          	addi	a1,a0,88
    8000423c:	05848513          	addi	a0,s1,88
    80004240:	aaffc0ef          	jal	ra,80000cee <memmove>
    bwrite(to);  // write the log
    80004244:	8526                	mv	a0,s1
    80004246:	ef7fe0ef          	jal	ra,8000313c <bwrite>
    brelse(from);
    8000424a:	854e                	mv	a0,s3
    8000424c:	f23fe0ef          	jal	ra,8000316e <brelse>
    brelse(to);
    80004250:	8526                	mv	a0,s1
    80004252:	f1dfe0ef          	jal	ra,8000316e <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80004256:	2905                	addiw	s2,s2,1
    80004258:	0a91                	addi	s5,s5,4
    8000425a:	028a2783          	lw	a5,40(s4)
    8000425e:	faf94ae3          	blt	s2,a5,80004212 <end_op+0xac>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80004262:	cd7ff0ef          	jal	ra,80003f38 <write_head>
    install_trans(0); // Now install writes to home locations
    80004266:	4501                	li	a0,0
    80004268:	d3fff0ef          	jal	ra,80003fa6 <install_trans>
    log.lh.n = 0;
    8000426c:	0001c797          	auipc	a5,0x1c
    80004270:	2407aa23          	sw	zero,596(a5) # 800204c0 <log+0x28>
    write_head();    // Erase the transaction from the log
    80004274:	cc5ff0ef          	jal	ra,80003f38 <write_head>
    80004278:	bf25                	j	800041b0 <end_op+0x4a>

000000008000427a <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    8000427a:	1101                	addi	sp,sp,-32
    8000427c:	ec06                	sd	ra,24(sp)
    8000427e:	e822                	sd	s0,16(sp)
    80004280:	e426                	sd	s1,8(sp)
    80004282:	e04a                	sd	s2,0(sp)
    80004284:	1000                	addi	s0,sp,32
    80004286:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80004288:	0001c917          	auipc	s2,0x1c
    8000428c:	21090913          	addi	s2,s2,528 # 80020498 <log>
    80004290:	854a                	mv	a0,s2
    80004292:	929fc0ef          	jal	ra,80000bba <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80004296:	02892603          	lw	a2,40(s2)
    8000429a:	47f5                	li	a5,29
    8000429c:	04c7cc63          	blt	a5,a2,800042f4 <log_write+0x7a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    800042a0:	0001c797          	auipc	a5,0x1c
    800042a4:	2147a783          	lw	a5,532(a5) # 800204b4 <log+0x1c>
    800042a8:	04f05c63          	blez	a5,80004300 <log_write+0x86>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    800042ac:	4781                	li	a5,0
    800042ae:	04c05f63          	blez	a2,8000430c <log_write+0x92>
    if (log.lh.block[i] == b->blockno)   // log absorption
    800042b2:	44cc                	lw	a1,12(s1)
    800042b4:	0001c717          	auipc	a4,0x1c
    800042b8:	21070713          	addi	a4,a4,528 # 800204c4 <log+0x2c>
  for (i = 0; i < log.lh.n; i++) {
    800042bc:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    800042be:	4314                	lw	a3,0(a4)
    800042c0:	04b68663          	beq	a3,a1,8000430c <log_write+0x92>
  for (i = 0; i < log.lh.n; i++) {
    800042c4:	2785                	addiw	a5,a5,1
    800042c6:	0711                	addi	a4,a4,4
    800042c8:	fef61be3          	bne	a2,a5,800042be <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    800042cc:	0621                	addi	a2,a2,8
    800042ce:	060a                	slli	a2,a2,0x2
    800042d0:	0001c797          	auipc	a5,0x1c
    800042d4:	1c878793          	addi	a5,a5,456 # 80020498 <log>
    800042d8:	963e                	add	a2,a2,a5
    800042da:	44dc                	lw	a5,12(s1)
    800042dc:	c65c                	sw	a5,12(a2)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    800042de:	8526                	mv	a0,s1
    800042e0:	f19fe0ef          	jal	ra,800031f8 <bpin>
    log.lh.n++;
    800042e4:	0001c717          	auipc	a4,0x1c
    800042e8:	1b470713          	addi	a4,a4,436 # 80020498 <log>
    800042ec:	571c                	lw	a5,40(a4)
    800042ee:	2785                	addiw	a5,a5,1
    800042f0:	d71c                	sw	a5,40(a4)
    800042f2:	a815                	j	80004326 <log_write+0xac>
    panic("too big a transaction");
    800042f4:	00003517          	auipc	a0,0x3
    800042f8:	49450513          	addi	a0,a0,1172 # 80007788 <syscalls+0x258>
    800042fc:	c92fc0ef          	jal	ra,8000078e <panic>
    panic("log_write outside of trans");
    80004300:	00003517          	auipc	a0,0x3
    80004304:	4a050513          	addi	a0,a0,1184 # 800077a0 <syscalls+0x270>
    80004308:	c86fc0ef          	jal	ra,8000078e <panic>
  log.lh.block[i] = b->blockno;
    8000430c:	00878713          	addi	a4,a5,8
    80004310:	00271693          	slli	a3,a4,0x2
    80004314:	0001c717          	auipc	a4,0x1c
    80004318:	18470713          	addi	a4,a4,388 # 80020498 <log>
    8000431c:	9736                	add	a4,a4,a3
    8000431e:	44d4                	lw	a3,12(s1)
    80004320:	c754                	sw	a3,12(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80004322:	faf60ee3          	beq	a2,a5,800042de <log_write+0x64>
  }
  release(&log.lock);
    80004326:	0001c517          	auipc	a0,0x1c
    8000432a:	17250513          	addi	a0,a0,370 # 80020498 <log>
    8000432e:	925fc0ef          	jal	ra,80000c52 <release>
}
    80004332:	60e2                	ld	ra,24(sp)
    80004334:	6442                	ld	s0,16(sp)
    80004336:	64a2                	ld	s1,8(sp)
    80004338:	6902                	ld	s2,0(sp)
    8000433a:	6105                	addi	sp,sp,32
    8000433c:	8082                	ret

000000008000433e <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    8000433e:	1101                	addi	sp,sp,-32
    80004340:	ec06                	sd	ra,24(sp)
    80004342:	e822                	sd	s0,16(sp)
    80004344:	e426                	sd	s1,8(sp)
    80004346:	e04a                	sd	s2,0(sp)
    80004348:	1000                	addi	s0,sp,32
    8000434a:	84aa                	mv	s1,a0
    8000434c:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    8000434e:	00003597          	auipc	a1,0x3
    80004352:	47258593          	addi	a1,a1,1138 # 800077c0 <syscalls+0x290>
    80004356:	0521                	addi	a0,a0,8
    80004358:	fe2fc0ef          	jal	ra,80000b3a <initlock>
  lk->name = name;
    8000435c:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80004360:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004364:	0204a423          	sw	zero,40(s1)
}
    80004368:	60e2                	ld	ra,24(sp)
    8000436a:	6442                	ld	s0,16(sp)
    8000436c:	64a2                	ld	s1,8(sp)
    8000436e:	6902                	ld	s2,0(sp)
    80004370:	6105                	addi	sp,sp,32
    80004372:	8082                	ret

0000000080004374 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80004374:	1101                	addi	sp,sp,-32
    80004376:	ec06                	sd	ra,24(sp)
    80004378:	e822                	sd	s0,16(sp)
    8000437a:	e426                	sd	s1,8(sp)
    8000437c:	e04a                	sd	s2,0(sp)
    8000437e:	1000                	addi	s0,sp,32
    80004380:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004382:	00850913          	addi	s2,a0,8
    80004386:	854a                	mv	a0,s2
    80004388:	833fc0ef          	jal	ra,80000bba <acquire>
  while (lk->locked) {
    8000438c:	409c                	lw	a5,0(s1)
    8000438e:	c799                	beqz	a5,8000439c <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    80004390:	85ca                	mv	a1,s2
    80004392:	8526                	mv	a0,s1
    80004394:	c63fd0ef          	jal	ra,80001ff6 <sleep>
  while (lk->locked) {
    80004398:	409c                	lw	a5,0(s1)
    8000439a:	fbfd                	bnez	a5,80004390 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    8000439c:	4785                	li	a5,1
    8000439e:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    800043a0:	cbafd0ef          	jal	ra,8000185a <myproc>
    800043a4:	591c                	lw	a5,48(a0)
    800043a6:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    800043a8:	854a                	mv	a0,s2
    800043aa:	8a9fc0ef          	jal	ra,80000c52 <release>
}
    800043ae:	60e2                	ld	ra,24(sp)
    800043b0:	6442                	ld	s0,16(sp)
    800043b2:	64a2                	ld	s1,8(sp)
    800043b4:	6902                	ld	s2,0(sp)
    800043b6:	6105                	addi	sp,sp,32
    800043b8:	8082                	ret

00000000800043ba <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    800043ba:	1101                	addi	sp,sp,-32
    800043bc:	ec06                	sd	ra,24(sp)
    800043be:	e822                	sd	s0,16(sp)
    800043c0:	e426                	sd	s1,8(sp)
    800043c2:	e04a                	sd	s2,0(sp)
    800043c4:	1000                	addi	s0,sp,32
    800043c6:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    800043c8:	00850913          	addi	s2,a0,8
    800043cc:	854a                	mv	a0,s2
    800043ce:	fecfc0ef          	jal	ra,80000bba <acquire>
  lk->locked = 0;
    800043d2:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800043d6:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    800043da:	8526                	mv	a0,s1
    800043dc:	c67fd0ef          	jal	ra,80002042 <wakeup>
  release(&lk->lk);
    800043e0:	854a                	mv	a0,s2
    800043e2:	871fc0ef          	jal	ra,80000c52 <release>
}
    800043e6:	60e2                	ld	ra,24(sp)
    800043e8:	6442                	ld	s0,16(sp)
    800043ea:	64a2                	ld	s1,8(sp)
    800043ec:	6902                	ld	s2,0(sp)
    800043ee:	6105                	addi	sp,sp,32
    800043f0:	8082                	ret

00000000800043f2 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    800043f2:	7179                	addi	sp,sp,-48
    800043f4:	f406                	sd	ra,40(sp)
    800043f6:	f022                	sd	s0,32(sp)
    800043f8:	ec26                	sd	s1,24(sp)
    800043fa:	e84a                	sd	s2,16(sp)
    800043fc:	e44e                	sd	s3,8(sp)
    800043fe:	1800                	addi	s0,sp,48
    80004400:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80004402:	00850913          	addi	s2,a0,8
    80004406:	854a                	mv	a0,s2
    80004408:	fb2fc0ef          	jal	ra,80000bba <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    8000440c:	409c                	lw	a5,0(s1)
    8000440e:	ef89                	bnez	a5,80004428 <holdingsleep+0x36>
    80004410:	4481                	li	s1,0
  release(&lk->lk);
    80004412:	854a                	mv	a0,s2
    80004414:	83ffc0ef          	jal	ra,80000c52 <release>
  return r;
}
    80004418:	8526                	mv	a0,s1
    8000441a:	70a2                	ld	ra,40(sp)
    8000441c:	7402                	ld	s0,32(sp)
    8000441e:	64e2                	ld	s1,24(sp)
    80004420:	6942                	ld	s2,16(sp)
    80004422:	69a2                	ld	s3,8(sp)
    80004424:	6145                	addi	sp,sp,48
    80004426:	8082                	ret
  r = lk->locked && (lk->pid == myproc()->pid);
    80004428:	0284a983          	lw	s3,40(s1)
    8000442c:	c2efd0ef          	jal	ra,8000185a <myproc>
    80004430:	5904                	lw	s1,48(a0)
    80004432:	413484b3          	sub	s1,s1,s3
    80004436:	0014b493          	seqz	s1,s1
    8000443a:	bfe1                	j	80004412 <holdingsleep+0x20>

000000008000443c <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    8000443c:	1141                	addi	sp,sp,-16
    8000443e:	e406                	sd	ra,8(sp)
    80004440:	e022                	sd	s0,0(sp)
    80004442:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80004444:	00003597          	auipc	a1,0x3
    80004448:	38c58593          	addi	a1,a1,908 # 800077d0 <syscalls+0x2a0>
    8000444c:	0001c517          	auipc	a0,0x1c
    80004450:	19450513          	addi	a0,a0,404 # 800205e0 <ftable>
    80004454:	ee6fc0ef          	jal	ra,80000b3a <initlock>
}
    80004458:	60a2                	ld	ra,8(sp)
    8000445a:	6402                	ld	s0,0(sp)
    8000445c:	0141                	addi	sp,sp,16
    8000445e:	8082                	ret

0000000080004460 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80004460:	1101                	addi	sp,sp,-32
    80004462:	ec06                	sd	ra,24(sp)
    80004464:	e822                	sd	s0,16(sp)
    80004466:	e426                	sd	s1,8(sp)
    80004468:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    8000446a:	0001c517          	auipc	a0,0x1c
    8000446e:	17650513          	addi	a0,a0,374 # 800205e0 <ftable>
    80004472:	f48fc0ef          	jal	ra,80000bba <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004476:	0001c497          	auipc	s1,0x1c
    8000447a:	18248493          	addi	s1,s1,386 # 800205f8 <ftable+0x18>
    8000447e:	0001d717          	auipc	a4,0x1d
    80004482:	11a70713          	addi	a4,a4,282 # 80021598 <disk>
    if(f->ref == 0){
    80004486:	40dc                	lw	a5,4(s1)
    80004488:	cf89                	beqz	a5,800044a2 <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    8000448a:	02848493          	addi	s1,s1,40
    8000448e:	fee49ce3          	bne	s1,a4,80004486 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80004492:	0001c517          	auipc	a0,0x1c
    80004496:	14e50513          	addi	a0,a0,334 # 800205e0 <ftable>
    8000449a:	fb8fc0ef          	jal	ra,80000c52 <release>
  return 0;
    8000449e:	4481                	li	s1,0
    800044a0:	a809                	j	800044b2 <filealloc+0x52>
      f->ref = 1;
    800044a2:	4785                	li	a5,1
    800044a4:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    800044a6:	0001c517          	auipc	a0,0x1c
    800044aa:	13a50513          	addi	a0,a0,314 # 800205e0 <ftable>
    800044ae:	fa4fc0ef          	jal	ra,80000c52 <release>
}
    800044b2:	8526                	mv	a0,s1
    800044b4:	60e2                	ld	ra,24(sp)
    800044b6:	6442                	ld	s0,16(sp)
    800044b8:	64a2                	ld	s1,8(sp)
    800044ba:	6105                	addi	sp,sp,32
    800044bc:	8082                	ret

00000000800044be <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    800044be:	1101                	addi	sp,sp,-32
    800044c0:	ec06                	sd	ra,24(sp)
    800044c2:	e822                	sd	s0,16(sp)
    800044c4:	e426                	sd	s1,8(sp)
    800044c6:	1000                	addi	s0,sp,32
    800044c8:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    800044ca:	0001c517          	auipc	a0,0x1c
    800044ce:	11650513          	addi	a0,a0,278 # 800205e0 <ftable>
    800044d2:	ee8fc0ef          	jal	ra,80000bba <acquire>
  if(f->ref < 1)
    800044d6:	40dc                	lw	a5,4(s1)
    800044d8:	02f05063          	blez	a5,800044f8 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    800044dc:	2785                	addiw	a5,a5,1
    800044de:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    800044e0:	0001c517          	auipc	a0,0x1c
    800044e4:	10050513          	addi	a0,a0,256 # 800205e0 <ftable>
    800044e8:	f6afc0ef          	jal	ra,80000c52 <release>
  return f;
}
    800044ec:	8526                	mv	a0,s1
    800044ee:	60e2                	ld	ra,24(sp)
    800044f0:	6442                	ld	s0,16(sp)
    800044f2:	64a2                	ld	s1,8(sp)
    800044f4:	6105                	addi	sp,sp,32
    800044f6:	8082                	ret
    panic("filedup");
    800044f8:	00003517          	auipc	a0,0x3
    800044fc:	2e050513          	addi	a0,a0,736 # 800077d8 <syscalls+0x2a8>
    80004500:	a8efc0ef          	jal	ra,8000078e <panic>

0000000080004504 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80004504:	7139                	addi	sp,sp,-64
    80004506:	fc06                	sd	ra,56(sp)
    80004508:	f822                	sd	s0,48(sp)
    8000450a:	f426                	sd	s1,40(sp)
    8000450c:	f04a                	sd	s2,32(sp)
    8000450e:	ec4e                	sd	s3,24(sp)
    80004510:	e852                	sd	s4,16(sp)
    80004512:	e456                	sd	s5,8(sp)
    80004514:	0080                	addi	s0,sp,64
    80004516:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80004518:	0001c517          	auipc	a0,0x1c
    8000451c:	0c850513          	addi	a0,a0,200 # 800205e0 <ftable>
    80004520:	e9afc0ef          	jal	ra,80000bba <acquire>
  if(f->ref < 1)
    80004524:	40dc                	lw	a5,4(s1)
    80004526:	04f05963          	blez	a5,80004578 <fileclose+0x74>
    panic("fileclose");
  if(--f->ref > 0){
    8000452a:	37fd                	addiw	a5,a5,-1
    8000452c:	0007871b          	sext.w	a4,a5
    80004530:	c0dc                	sw	a5,4(s1)
    80004532:	04e04963          	bgtz	a4,80004584 <fileclose+0x80>
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80004536:	0004a903          	lw	s2,0(s1)
    8000453a:	0094ca83          	lbu	s5,9(s1)
    8000453e:	0104ba03          	ld	s4,16(s1)
    80004542:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    80004546:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    8000454a:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    8000454e:	0001c517          	auipc	a0,0x1c
    80004552:	09250513          	addi	a0,a0,146 # 800205e0 <ftable>
    80004556:	efcfc0ef          	jal	ra,80000c52 <release>

  if(ff.type == FD_PIPE){
    8000455a:	4785                	li	a5,1
    8000455c:	04f90363          	beq	s2,a5,800045a2 <fileclose+0x9e>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    80004560:	3979                	addiw	s2,s2,-2
    80004562:	4785                	li	a5,1
    80004564:	0327e663          	bltu	a5,s2,80004590 <fileclose+0x8c>
    begin_op();
    80004568:	b8fff0ef          	jal	ra,800040f6 <begin_op>
    iput(ff.ip);
    8000456c:	854e                	mv	a0,s3
    8000456e:	b28ff0ef          	jal	ra,80003896 <iput>
    end_op();
    80004572:	bf5ff0ef          	jal	ra,80004166 <end_op>
    80004576:	a829                	j	80004590 <fileclose+0x8c>
    panic("fileclose");
    80004578:	00003517          	auipc	a0,0x3
    8000457c:	26850513          	addi	a0,a0,616 # 800077e0 <syscalls+0x2b0>
    80004580:	a0efc0ef          	jal	ra,8000078e <panic>
    release(&ftable.lock);
    80004584:	0001c517          	auipc	a0,0x1c
    80004588:	05c50513          	addi	a0,a0,92 # 800205e0 <ftable>
    8000458c:	ec6fc0ef          	jal	ra,80000c52 <release>
  }
}
    80004590:	70e2                	ld	ra,56(sp)
    80004592:	7442                	ld	s0,48(sp)
    80004594:	74a2                	ld	s1,40(sp)
    80004596:	7902                	ld	s2,32(sp)
    80004598:	69e2                	ld	s3,24(sp)
    8000459a:	6a42                	ld	s4,16(sp)
    8000459c:	6aa2                	ld	s5,8(sp)
    8000459e:	6121                	addi	sp,sp,64
    800045a0:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    800045a2:	85d6                	mv	a1,s5
    800045a4:	8552                	mv	a0,s4
    800045a6:	2ec000ef          	jal	ra,80004892 <pipeclose>
    800045aa:	b7dd                	j	80004590 <fileclose+0x8c>

00000000800045ac <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800045ac:	715d                	addi	sp,sp,-80
    800045ae:	e486                	sd	ra,72(sp)
    800045b0:	e0a2                	sd	s0,64(sp)
    800045b2:	fc26                	sd	s1,56(sp)
    800045b4:	f84a                	sd	s2,48(sp)
    800045b6:	f44e                	sd	s3,40(sp)
    800045b8:	0880                	addi	s0,sp,80
    800045ba:	84aa                	mv	s1,a0
    800045bc:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    800045be:	a9cfd0ef          	jal	ra,8000185a <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    800045c2:	409c                	lw	a5,0(s1)
    800045c4:	37f9                	addiw	a5,a5,-2
    800045c6:	4705                	li	a4,1
    800045c8:	02f76f63          	bltu	a4,a5,80004606 <filestat+0x5a>
    800045cc:	892a                	mv	s2,a0
    ilock(f->ip);
    800045ce:	6c88                	ld	a0,24(s1)
    800045d0:	948ff0ef          	jal	ra,80003718 <ilock>
    stati(f->ip, &st);
    800045d4:	fb840593          	addi	a1,s0,-72
    800045d8:	6c88                	ld	a0,24(s1)
    800045da:	ca0ff0ef          	jal	ra,80003a7a <stati>
    iunlock(f->ip);
    800045de:	6c88                	ld	a0,24(s1)
    800045e0:	9e2ff0ef          	jal	ra,800037c2 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    800045e4:	46e1                	li	a3,24
    800045e6:	fb840613          	addi	a2,s0,-72
    800045ea:	85ce                	mv	a1,s3
    800045ec:	05093503          	ld	a0,80(s2)
    800045f0:	fb9fc0ef          	jal	ra,800015a8 <copyout>
    800045f4:	41f5551b          	sraiw	a0,a0,0x1f
      return -1;
    return 0;
  }
  return -1;
}
    800045f8:	60a6                	ld	ra,72(sp)
    800045fa:	6406                	ld	s0,64(sp)
    800045fc:	74e2                	ld	s1,56(sp)
    800045fe:	7942                	ld	s2,48(sp)
    80004600:	79a2                	ld	s3,40(sp)
    80004602:	6161                	addi	sp,sp,80
    80004604:	8082                	ret
  return -1;
    80004606:	557d                	li	a0,-1
    80004608:	bfc5                	j	800045f8 <filestat+0x4c>

000000008000460a <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    8000460a:	7179                	addi	sp,sp,-48
    8000460c:	f406                	sd	ra,40(sp)
    8000460e:	f022                	sd	s0,32(sp)
    80004610:	ec26                	sd	s1,24(sp)
    80004612:	e84a                	sd	s2,16(sp)
    80004614:	e44e                	sd	s3,8(sp)
    80004616:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80004618:	00854783          	lbu	a5,8(a0)
    8000461c:	cbc1                	beqz	a5,800046ac <fileread+0xa2>
    8000461e:	84aa                	mv	s1,a0
    80004620:	89ae                	mv	s3,a1
    80004622:	8932                	mv	s2,a2
    return -1;

  if(f->type == FD_PIPE){
    80004624:	411c                	lw	a5,0(a0)
    80004626:	4705                	li	a4,1
    80004628:	04e78363          	beq	a5,a4,8000466e <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    8000462c:	470d                	li	a4,3
    8000462e:	04e78563          	beq	a5,a4,80004678 <fileread+0x6e>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80004632:	4709                	li	a4,2
    80004634:	06e79663          	bne	a5,a4,800046a0 <fileread+0x96>
    ilock(f->ip);
    80004638:	6d08                	ld	a0,24(a0)
    8000463a:	8deff0ef          	jal	ra,80003718 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    8000463e:	874a                	mv	a4,s2
    80004640:	5094                	lw	a3,32(s1)
    80004642:	864e                	mv	a2,s3
    80004644:	4585                	li	a1,1
    80004646:	6c88                	ld	a0,24(s1)
    80004648:	c5cff0ef          	jal	ra,80003aa4 <readi>
    8000464c:	892a                	mv	s2,a0
    8000464e:	00a05563          	blez	a0,80004658 <fileread+0x4e>
      f->off += r;
    80004652:	509c                	lw	a5,32(s1)
    80004654:	9fa9                	addw	a5,a5,a0
    80004656:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80004658:	6c88                	ld	a0,24(s1)
    8000465a:	968ff0ef          	jal	ra,800037c2 <iunlock>
  } else {
    panic("fileread");
  }

  return r;
}
    8000465e:	854a                	mv	a0,s2
    80004660:	70a2                	ld	ra,40(sp)
    80004662:	7402                	ld	s0,32(sp)
    80004664:	64e2                	ld	s1,24(sp)
    80004666:	6942                	ld	s2,16(sp)
    80004668:	69a2                	ld	s3,8(sp)
    8000466a:	6145                	addi	sp,sp,48
    8000466c:	8082                	ret
    r = piperead(f->pipe, addr, n);
    8000466e:	6908                	ld	a0,16(a0)
    80004670:	356000ef          	jal	ra,800049c6 <piperead>
    80004674:	892a                	mv	s2,a0
    80004676:	b7e5                	j	8000465e <fileread+0x54>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80004678:	02451783          	lh	a5,36(a0)
    8000467c:	03079693          	slli	a3,a5,0x30
    80004680:	92c1                	srli	a3,a3,0x30
    80004682:	4725                	li	a4,9
    80004684:	02d76663          	bltu	a4,a3,800046b0 <fileread+0xa6>
    80004688:	0792                	slli	a5,a5,0x4
    8000468a:	0001c717          	auipc	a4,0x1c
    8000468e:	eb670713          	addi	a4,a4,-330 # 80020540 <devsw>
    80004692:	97ba                	add	a5,a5,a4
    80004694:	639c                	ld	a5,0(a5)
    80004696:	cf99                	beqz	a5,800046b4 <fileread+0xaa>
    r = devsw[f->major].read(1, addr, n);
    80004698:	4505                	li	a0,1
    8000469a:	9782                	jalr	a5
    8000469c:	892a                	mv	s2,a0
    8000469e:	b7c1                	j	8000465e <fileread+0x54>
    panic("fileread");
    800046a0:	00003517          	auipc	a0,0x3
    800046a4:	15050513          	addi	a0,a0,336 # 800077f0 <syscalls+0x2c0>
    800046a8:	8e6fc0ef          	jal	ra,8000078e <panic>
    return -1;
    800046ac:	597d                	li	s2,-1
    800046ae:	bf45                	j	8000465e <fileread+0x54>
      return -1;
    800046b0:	597d                	li	s2,-1
    800046b2:	b775                	j	8000465e <fileread+0x54>
    800046b4:	597d                	li	s2,-1
    800046b6:	b765                	j	8000465e <fileread+0x54>

00000000800046b8 <filewrite>:

// Write to file f.
// addr is a user virtual address.
int
filewrite(struct file *f, uint64 addr, int n)
{
    800046b8:	715d                	addi	sp,sp,-80
    800046ba:	e486                	sd	ra,72(sp)
    800046bc:	e0a2                	sd	s0,64(sp)
    800046be:	fc26                	sd	s1,56(sp)
    800046c0:	f84a                	sd	s2,48(sp)
    800046c2:	f44e                	sd	s3,40(sp)
    800046c4:	f052                	sd	s4,32(sp)
    800046c6:	ec56                	sd	s5,24(sp)
    800046c8:	e85a                	sd	s6,16(sp)
    800046ca:	e45e                	sd	s7,8(sp)
    800046cc:	e062                	sd	s8,0(sp)
    800046ce:	0880                	addi	s0,sp,80
  int r, ret = 0;

  if(f->writable == 0)
    800046d0:	00954783          	lbu	a5,9(a0)
    800046d4:	0e078863          	beqz	a5,800047c4 <filewrite+0x10c>
    800046d8:	892a                	mv	s2,a0
    800046da:	8aae                	mv	s5,a1
    800046dc:	8a32                	mv	s4,a2
    return -1;

  if(f->type == FD_PIPE){
    800046de:	411c                	lw	a5,0(a0)
    800046e0:	4705                	li	a4,1
    800046e2:	02e78263          	beq	a5,a4,80004706 <filewrite+0x4e>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800046e6:	470d                	li	a4,3
    800046e8:	02e78463          	beq	a5,a4,80004710 <filewrite+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800046ec:	4709                	li	a4,2
    800046ee:	0ce79563          	bne	a5,a4,800047b8 <filewrite+0x100>
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800046f2:	0ac05163          	blez	a2,80004794 <filewrite+0xdc>
    int i = 0;
    800046f6:	4981                	li	s3,0
    800046f8:	6b05                	lui	s6,0x1
    800046fa:	c00b0b13          	addi	s6,s6,-1024 # c00 <_entry-0x7ffff400>
    800046fe:	6b85                	lui	s7,0x1
    80004700:	c00b8b9b          	addiw	s7,s7,-1024
    80004704:	a041                	j	80004784 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    80004706:	6908                	ld	a0,16(a0)
    80004708:	1e2000ef          	jal	ra,800048ea <pipewrite>
    8000470c:	8a2a                	mv	s4,a0
    8000470e:	a071                	j	8000479a <filewrite+0xe2>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004710:	02451783          	lh	a5,36(a0)
    80004714:	03079693          	slli	a3,a5,0x30
    80004718:	92c1                	srli	a3,a3,0x30
    8000471a:	4725                	li	a4,9
    8000471c:	0ad76663          	bltu	a4,a3,800047c8 <filewrite+0x110>
    80004720:	0792                	slli	a5,a5,0x4
    80004722:	0001c717          	auipc	a4,0x1c
    80004726:	e1e70713          	addi	a4,a4,-482 # 80020540 <devsw>
    8000472a:	97ba                	add	a5,a5,a4
    8000472c:	679c                	ld	a5,8(a5)
    8000472e:	cfd9                	beqz	a5,800047cc <filewrite+0x114>
    ret = devsw[f->major].write(1, addr, n);
    80004730:	4505                	li	a0,1
    80004732:	9782                	jalr	a5
    80004734:	8a2a                	mv	s4,a0
    80004736:	a095                	j	8000479a <filewrite+0xe2>
    80004738:	00048c1b          	sext.w	s8,s1
      int n1 = n - i;
      if(n1 > max)
        n1 = max;

      begin_op();
    8000473c:	9bbff0ef          	jal	ra,800040f6 <begin_op>
      ilock(f->ip);
    80004740:	01893503          	ld	a0,24(s2)
    80004744:	fd5fe0ef          	jal	ra,80003718 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004748:	8762                	mv	a4,s8
    8000474a:	02092683          	lw	a3,32(s2)
    8000474e:	01598633          	add	a2,s3,s5
    80004752:	4585                	li	a1,1
    80004754:	01893503          	ld	a0,24(s2)
    80004758:	c30ff0ef          	jal	ra,80003b88 <writei>
    8000475c:	84aa                	mv	s1,a0
    8000475e:	00a05763          	blez	a0,8000476c <filewrite+0xb4>
        f->off += r;
    80004762:	02092783          	lw	a5,32(s2)
    80004766:	9fa9                	addw	a5,a5,a0
    80004768:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    8000476c:	01893503          	ld	a0,24(s2)
    80004770:	852ff0ef          	jal	ra,800037c2 <iunlock>
      end_op();
    80004774:	9f3ff0ef          	jal	ra,80004166 <end_op>

      if(r != n1){
    80004778:	009c1f63          	bne	s8,s1,80004796 <filewrite+0xde>
        // error from writei
        break;
      }
      i += r;
    8000477c:	013489bb          	addw	s3,s1,s3
    while(i < n){
    80004780:	0149db63          	bge	s3,s4,80004796 <filewrite+0xde>
      int n1 = n - i;
    80004784:	413a07bb          	subw	a5,s4,s3
      if(n1 > max)
    80004788:	84be                	mv	s1,a5
    8000478a:	2781                	sext.w	a5,a5
    8000478c:	fafb56e3          	bge	s6,a5,80004738 <filewrite+0x80>
    80004790:	84de                	mv	s1,s7
    80004792:	b75d                	j	80004738 <filewrite+0x80>
    int i = 0;
    80004794:	4981                	li	s3,0
    }
    ret = (i == n ? n : -1);
    80004796:	013a1f63          	bne	s4,s3,800047b4 <filewrite+0xfc>
  } else {
    panic("filewrite");
  }

  return ret;
}
    8000479a:	8552                	mv	a0,s4
    8000479c:	60a6                	ld	ra,72(sp)
    8000479e:	6406                	ld	s0,64(sp)
    800047a0:	74e2                	ld	s1,56(sp)
    800047a2:	7942                	ld	s2,48(sp)
    800047a4:	79a2                	ld	s3,40(sp)
    800047a6:	7a02                	ld	s4,32(sp)
    800047a8:	6ae2                	ld	s5,24(sp)
    800047aa:	6b42                	ld	s6,16(sp)
    800047ac:	6ba2                	ld	s7,8(sp)
    800047ae:	6c02                	ld	s8,0(sp)
    800047b0:	6161                	addi	sp,sp,80
    800047b2:	8082                	ret
    ret = (i == n ? n : -1);
    800047b4:	5a7d                	li	s4,-1
    800047b6:	b7d5                	j	8000479a <filewrite+0xe2>
    panic("filewrite");
    800047b8:	00003517          	auipc	a0,0x3
    800047bc:	04850513          	addi	a0,a0,72 # 80007800 <syscalls+0x2d0>
    800047c0:	fcffb0ef          	jal	ra,8000078e <panic>
    return -1;
    800047c4:	5a7d                	li	s4,-1
    800047c6:	bfd1                	j	8000479a <filewrite+0xe2>
      return -1;
    800047c8:	5a7d                	li	s4,-1
    800047ca:	bfc1                	j	8000479a <filewrite+0xe2>
    800047cc:	5a7d                	li	s4,-1
    800047ce:	b7f1                	j	8000479a <filewrite+0xe2>

00000000800047d0 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800047d0:	7179                	addi	sp,sp,-48
    800047d2:	f406                	sd	ra,40(sp)
    800047d4:	f022                	sd	s0,32(sp)
    800047d6:	ec26                	sd	s1,24(sp)
    800047d8:	e84a                	sd	s2,16(sp)
    800047da:	e44e                	sd	s3,8(sp)
    800047dc:	e052                	sd	s4,0(sp)
    800047de:	1800                	addi	s0,sp,48
    800047e0:	84aa                	mv	s1,a0
    800047e2:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800047e4:	0005b023          	sd	zero,0(a1)
    800047e8:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800047ec:	c75ff0ef          	jal	ra,80004460 <filealloc>
    800047f0:	e088                	sd	a0,0(s1)
    800047f2:	cd35                	beqz	a0,8000486e <pipealloc+0x9e>
    800047f4:	c6dff0ef          	jal	ra,80004460 <filealloc>
    800047f8:	00aa3023          	sd	a0,0(s4)
    800047fc:	c52d                	beqz	a0,80004866 <pipealloc+0x96>
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    800047fe:	aaafc0ef          	jal	ra,80000aa8 <kalloc>
    80004802:	892a                	mv	s2,a0
    80004804:	cd31                	beqz	a0,80004860 <pipealloc+0x90>
    goto bad;
  pi->readopen = 1;
    80004806:	4985                	li	s3,1
    80004808:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    8000480c:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004810:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004814:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004818:	00003597          	auipc	a1,0x3
    8000481c:	ff858593          	addi	a1,a1,-8 # 80007810 <syscalls+0x2e0>
    80004820:	b1afc0ef          	jal	ra,80000b3a <initlock>
  (*f0)->type = FD_PIPE;
    80004824:	609c                	ld	a5,0(s1)
    80004826:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    8000482a:	609c                	ld	a5,0(s1)
    8000482c:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004830:	609c                	ld	a5,0(s1)
    80004832:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80004836:	609c                	ld	a5,0(s1)
    80004838:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    8000483c:	000a3783          	ld	a5,0(s4)
    80004840:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80004844:	000a3783          	ld	a5,0(s4)
    80004848:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    8000484c:	000a3783          	ld	a5,0(s4)
    80004850:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80004854:	000a3783          	ld	a5,0(s4)
    80004858:	0127b823          	sd	s2,16(a5)
  return 0;
    8000485c:	4501                	li	a0,0
    8000485e:	a005                	j	8000487e <pipealloc+0xae>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80004860:	6088                	ld	a0,0(s1)
    80004862:	e501                	bnez	a0,8000486a <pipealloc+0x9a>
    80004864:	a029                	j	8000486e <pipealloc+0x9e>
    80004866:	6088                	ld	a0,0(s1)
    80004868:	c11d                	beqz	a0,8000488e <pipealloc+0xbe>
    fileclose(*f0);
    8000486a:	c9bff0ef          	jal	ra,80004504 <fileclose>
  if(*f1)
    8000486e:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80004872:	557d                	li	a0,-1
  if(*f1)
    80004874:	c789                	beqz	a5,8000487e <pipealloc+0xae>
    fileclose(*f1);
    80004876:	853e                	mv	a0,a5
    80004878:	c8dff0ef          	jal	ra,80004504 <fileclose>
  return -1;
    8000487c:	557d                	li	a0,-1
}
    8000487e:	70a2                	ld	ra,40(sp)
    80004880:	7402                	ld	s0,32(sp)
    80004882:	64e2                	ld	s1,24(sp)
    80004884:	6942                	ld	s2,16(sp)
    80004886:	69a2                	ld	s3,8(sp)
    80004888:	6a02                	ld	s4,0(sp)
    8000488a:	6145                	addi	sp,sp,48
    8000488c:	8082                	ret
  return -1;
    8000488e:	557d                	li	a0,-1
    80004890:	b7fd                	j	8000487e <pipealloc+0xae>

0000000080004892 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004892:	1101                	addi	sp,sp,-32
    80004894:	ec06                	sd	ra,24(sp)
    80004896:	e822                	sd	s0,16(sp)
    80004898:	e426                	sd	s1,8(sp)
    8000489a:	e04a                	sd	s2,0(sp)
    8000489c:	1000                	addi	s0,sp,32
    8000489e:	84aa                	mv	s1,a0
    800048a0:	892e                	mv	s2,a1
  acquire(&pi->lock);
    800048a2:	b18fc0ef          	jal	ra,80000bba <acquire>
  if(writable){
    800048a6:	02090763          	beqz	s2,800048d4 <pipeclose+0x42>
    pi->writeopen = 0;
    800048aa:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    800048ae:	21848513          	addi	a0,s1,536
    800048b2:	f90fd0ef          	jal	ra,80002042 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    800048b6:	2204b783          	ld	a5,544(s1)
    800048ba:	e785                	bnez	a5,800048e2 <pipeclose+0x50>
    release(&pi->lock);
    800048bc:	8526                	mv	a0,s1
    800048be:	b94fc0ef          	jal	ra,80000c52 <release>
    kfree((char*)pi);
    800048c2:	8526                	mv	a0,s1
    800048c4:	904fc0ef          	jal	ra,800009c8 <kfree>
  } else
    release(&pi->lock);
}
    800048c8:	60e2                	ld	ra,24(sp)
    800048ca:	6442                	ld	s0,16(sp)
    800048cc:	64a2                	ld	s1,8(sp)
    800048ce:	6902                	ld	s2,0(sp)
    800048d0:	6105                	addi	sp,sp,32
    800048d2:	8082                	ret
    pi->readopen = 0;
    800048d4:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    800048d8:	21c48513          	addi	a0,s1,540
    800048dc:	f66fd0ef          	jal	ra,80002042 <wakeup>
    800048e0:	bfd9                	j	800048b6 <pipeclose+0x24>
    release(&pi->lock);
    800048e2:	8526                	mv	a0,s1
    800048e4:	b6efc0ef          	jal	ra,80000c52 <release>
}
    800048e8:	b7c5                	j	800048c8 <pipeclose+0x36>

00000000800048ea <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800048ea:	7159                	addi	sp,sp,-112
    800048ec:	f486                	sd	ra,104(sp)
    800048ee:	f0a2                	sd	s0,96(sp)
    800048f0:	eca6                	sd	s1,88(sp)
    800048f2:	e8ca                	sd	s2,80(sp)
    800048f4:	e4ce                	sd	s3,72(sp)
    800048f6:	e0d2                	sd	s4,64(sp)
    800048f8:	fc56                	sd	s5,56(sp)
    800048fa:	f85a                	sd	s6,48(sp)
    800048fc:	f45e                	sd	s7,40(sp)
    800048fe:	f062                	sd	s8,32(sp)
    80004900:	ec66                	sd	s9,24(sp)
    80004902:	1880                	addi	s0,sp,112
    80004904:	84aa                	mv	s1,a0
    80004906:	8aae                	mv	s5,a1
    80004908:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    8000490a:	f51fc0ef          	jal	ra,8000185a <myproc>
    8000490e:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004910:	8526                	mv	a0,s1
    80004912:	aa8fc0ef          	jal	ra,80000bba <acquire>
  while(i < n){
    80004916:	0b405663          	blez	s4,800049c2 <pipewrite+0xd8>
    8000491a:	8ba6                	mv	s7,s1
  int i = 0;
    8000491c:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    8000491e:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80004920:	21848c93          	addi	s9,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004924:	21c48c13          	addi	s8,s1,540
    80004928:	a899                	j	8000497e <pipewrite+0x94>
      release(&pi->lock);
    8000492a:	8526                	mv	a0,s1
    8000492c:	b26fc0ef          	jal	ra,80000c52 <release>
      return -1;
    80004930:	597d                	li	s2,-1
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004932:	854a                	mv	a0,s2
    80004934:	70a6                	ld	ra,104(sp)
    80004936:	7406                	ld	s0,96(sp)
    80004938:	64e6                	ld	s1,88(sp)
    8000493a:	6946                	ld	s2,80(sp)
    8000493c:	69a6                	ld	s3,72(sp)
    8000493e:	6a06                	ld	s4,64(sp)
    80004940:	7ae2                	ld	s5,56(sp)
    80004942:	7b42                	ld	s6,48(sp)
    80004944:	7ba2                	ld	s7,40(sp)
    80004946:	7c02                	ld	s8,32(sp)
    80004948:	6ce2                	ld	s9,24(sp)
    8000494a:	6165                	addi	sp,sp,112
    8000494c:	8082                	ret
      wakeup(&pi->nread);
    8000494e:	8566                	mv	a0,s9
    80004950:	ef2fd0ef          	jal	ra,80002042 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80004954:	85de                	mv	a1,s7
    80004956:	8562                	mv	a0,s8
    80004958:	e9efd0ef          	jal	ra,80001ff6 <sleep>
    8000495c:	a839                	j	8000497a <pipewrite+0x90>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    8000495e:	21c4a783          	lw	a5,540(s1)
    80004962:	0017871b          	addiw	a4,a5,1
    80004966:	20e4ae23          	sw	a4,540(s1)
    8000496a:	1ff7f793          	andi	a5,a5,511
    8000496e:	97a6                	add	a5,a5,s1
    80004970:	f9f44703          	lbu	a4,-97(s0)
    80004974:	00e78c23          	sb	a4,24(a5)
      i++;
    80004978:	2905                	addiw	s2,s2,1
  while(i < n){
    8000497a:	03495c63          	bge	s2,s4,800049b2 <pipewrite+0xc8>
    if(pi->readopen == 0 || killed(pr)){
    8000497e:	2204a783          	lw	a5,544(s1)
    80004982:	d7c5                	beqz	a5,8000492a <pipewrite+0x40>
    80004984:	854e                	mv	a0,s3
    80004986:	8e9fd0ef          	jal	ra,8000226e <killed>
    8000498a:	f145                	bnez	a0,8000492a <pipewrite+0x40>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    8000498c:	2184a783          	lw	a5,536(s1)
    80004990:	21c4a703          	lw	a4,540(s1)
    80004994:	2007879b          	addiw	a5,a5,512
    80004998:	faf70be3          	beq	a4,a5,8000494e <pipewrite+0x64>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    8000499c:	4685                	li	a3,1
    8000499e:	01590633          	add	a2,s2,s5
    800049a2:	f9f40593          	addi	a1,s0,-97
    800049a6:	0509b503          	ld	a0,80(s3)
    800049aa:	cc5fc0ef          	jal	ra,8000166e <copyin>
    800049ae:	fb6518e3          	bne	a0,s6,8000495e <pipewrite+0x74>
  wakeup(&pi->nread);
    800049b2:	21848513          	addi	a0,s1,536
    800049b6:	e8cfd0ef          	jal	ra,80002042 <wakeup>
  release(&pi->lock);
    800049ba:	8526                	mv	a0,s1
    800049bc:	a96fc0ef          	jal	ra,80000c52 <release>
  return i;
    800049c0:	bf8d                	j	80004932 <pipewrite+0x48>
  int i = 0;
    800049c2:	4901                	li	s2,0
    800049c4:	b7fd                	j	800049b2 <pipewrite+0xc8>

00000000800049c6 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800049c6:	715d                	addi	sp,sp,-80
    800049c8:	e486                	sd	ra,72(sp)
    800049ca:	e0a2                	sd	s0,64(sp)
    800049cc:	fc26                	sd	s1,56(sp)
    800049ce:	f84a                	sd	s2,48(sp)
    800049d0:	f44e                	sd	s3,40(sp)
    800049d2:	f052                	sd	s4,32(sp)
    800049d4:	ec56                	sd	s5,24(sp)
    800049d6:	e85a                	sd	s6,16(sp)
    800049d8:	0880                	addi	s0,sp,80
    800049da:	84aa                	mv	s1,a0
    800049dc:	892e                	mv	s2,a1
    800049de:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    800049e0:	e7bfc0ef          	jal	ra,8000185a <myproc>
    800049e4:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    800049e6:	8b26                	mv	s6,s1
    800049e8:	8526                	mv	a0,s1
    800049ea:	9d0fc0ef          	jal	ra,80000bba <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800049ee:	2184a703          	lw	a4,536(s1)
    800049f2:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800049f6:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800049fa:	02f71363          	bne	a4,a5,80004a20 <piperead+0x5a>
    800049fe:	2244a783          	lw	a5,548(s1)
    80004a02:	cf99                	beqz	a5,80004a20 <piperead+0x5a>
    if(killed(pr)){
    80004a04:	8552                	mv	a0,s4
    80004a06:	869fd0ef          	jal	ra,8000226e <killed>
    80004a0a:	e149                	bnez	a0,80004a8c <piperead+0xc6>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004a0c:	85da                	mv	a1,s6
    80004a0e:	854e                	mv	a0,s3
    80004a10:	de6fd0ef          	jal	ra,80001ff6 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004a14:	2184a703          	lw	a4,536(s1)
    80004a18:	21c4a783          	lw	a5,540(s1)
    80004a1c:	fef701e3          	beq	a4,a5,800049fe <piperead+0x38>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004a20:	07505f63          	blez	s5,80004a9e <piperead+0xd8>
    80004a24:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1) {
    80004a26:	5b7d                	li	s6,-1
    if(pi->nread == pi->nwrite)
    80004a28:	2184a783          	lw	a5,536(s1)
    80004a2c:	21c4a703          	lw	a4,540(s1)
    80004a30:	02f70c63          	beq	a4,a5,80004a68 <piperead+0xa2>
    ch = pi->data[pi->nread % PIPESIZE];
    80004a34:	1ff7f793          	andi	a5,a5,511
    80004a38:	97a6                	add	a5,a5,s1
    80004a3a:	0187c783          	lbu	a5,24(a5)
    80004a3e:	faf40fa3          	sb	a5,-65(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1) {
    80004a42:	4685                	li	a3,1
    80004a44:	fbf40613          	addi	a2,s0,-65
    80004a48:	85ca                	mv	a1,s2
    80004a4a:	050a3503          	ld	a0,80(s4)
    80004a4e:	b5bfc0ef          	jal	ra,800015a8 <copyout>
    80004a52:	05650263          	beq	a0,s6,80004a96 <piperead+0xd0>
      if(i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    80004a56:	2184a783          	lw	a5,536(s1)
    80004a5a:	2785                	addiw	a5,a5,1
    80004a5c:	20f4ac23          	sw	a5,536(s1)
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004a60:	2985                	addiw	s3,s3,1
    80004a62:	0905                	addi	s2,s2,1
    80004a64:	fd3a92e3          	bne	s5,s3,80004a28 <piperead+0x62>
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80004a68:	21c48513          	addi	a0,s1,540
    80004a6c:	dd6fd0ef          	jal	ra,80002042 <wakeup>
  release(&pi->lock);
    80004a70:	8526                	mv	a0,s1
    80004a72:	9e0fc0ef          	jal	ra,80000c52 <release>
  return i;
}
    80004a76:	854e                	mv	a0,s3
    80004a78:	60a6                	ld	ra,72(sp)
    80004a7a:	6406                	ld	s0,64(sp)
    80004a7c:	74e2                	ld	s1,56(sp)
    80004a7e:	7942                	ld	s2,48(sp)
    80004a80:	79a2                	ld	s3,40(sp)
    80004a82:	7a02                	ld	s4,32(sp)
    80004a84:	6ae2                	ld	s5,24(sp)
    80004a86:	6b42                	ld	s6,16(sp)
    80004a88:	6161                	addi	sp,sp,80
    80004a8a:	8082                	ret
      release(&pi->lock);
    80004a8c:	8526                	mv	a0,s1
    80004a8e:	9c4fc0ef          	jal	ra,80000c52 <release>
      return -1;
    80004a92:	59fd                	li	s3,-1
    80004a94:	b7cd                	j	80004a76 <piperead+0xb0>
      if(i == 0)
    80004a96:	fc0999e3          	bnez	s3,80004a68 <piperead+0xa2>
        i = -1;
    80004a9a:	89aa                	mv	s3,a0
    80004a9c:	b7f1                	j	80004a68 <piperead+0xa2>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004a9e:	4981                	li	s3,0
    80004aa0:	b7e1                	j	80004a68 <piperead+0xa2>

0000000080004aa2 <flags2perm>:

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int flags2perm(int flags)
{
    80004aa2:	1141                	addi	sp,sp,-16
    80004aa4:	e422                	sd	s0,8(sp)
    80004aa6:	0800                	addi	s0,sp,16
    80004aa8:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80004aaa:	8905                	andi	a0,a0,1
    80004aac:	c111                	beqz	a0,80004ab0 <flags2perm+0xe>
      perm = PTE_X;
    80004aae:	4521                	li	a0,8
    if(flags & 0x2)
    80004ab0:	8b89                	andi	a5,a5,2
    80004ab2:	c399                	beqz	a5,80004ab8 <flags2perm+0x16>
      perm |= PTE_W;
    80004ab4:	00456513          	ori	a0,a0,4
    return perm;
}
    80004ab8:	6422                	ld	s0,8(sp)
    80004aba:	0141                	addi	sp,sp,16
    80004abc:	8082                	ret

0000000080004abe <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    80004abe:	df010113          	addi	sp,sp,-528
    80004ac2:	20113423          	sd	ra,520(sp)
    80004ac6:	20813023          	sd	s0,512(sp)
    80004aca:	ffa6                	sd	s1,504(sp)
    80004acc:	fbca                	sd	s2,496(sp)
    80004ace:	f7ce                	sd	s3,488(sp)
    80004ad0:	f3d2                	sd	s4,480(sp)
    80004ad2:	efd6                	sd	s5,472(sp)
    80004ad4:	ebda                	sd	s6,464(sp)
    80004ad6:	e7de                	sd	s7,456(sp)
    80004ad8:	e3e2                	sd	s8,448(sp)
    80004ada:	ff66                	sd	s9,440(sp)
    80004adc:	fb6a                	sd	s10,432(sp)
    80004ade:	f76e                	sd	s11,424(sp)
    80004ae0:	0c00                	addi	s0,sp,528
    80004ae2:	84aa                	mv	s1,a0
    80004ae4:	dea43c23          	sd	a0,-520(s0)
    80004ae8:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004aec:	d6ffc0ef          	jal	ra,8000185a <myproc>
    80004af0:	892a                	mv	s2,a0

  begin_op();
    80004af2:	e04ff0ef          	jal	ra,800040f6 <begin_op>

  // Open the executable file.
  if((ip = namei(path)) == 0){
    80004af6:	8526                	mv	a0,s1
    80004af8:	c0eff0ef          	jal	ra,80003f06 <namei>
    80004afc:	c12d                	beqz	a0,80004b5e <kexec+0xa0>
    80004afe:	84aa                	mv	s1,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004b00:	c19fe0ef          	jal	ra,80003718 <ilock>

  // Read the ELF header.
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004b04:	04000713          	li	a4,64
    80004b08:	4681                	li	a3,0
    80004b0a:	e5040613          	addi	a2,s0,-432
    80004b0e:	4581                	li	a1,0
    80004b10:	8526                	mv	a0,s1
    80004b12:	f93fe0ef          	jal	ra,80003aa4 <readi>
    80004b16:	04000793          	li	a5,64
    80004b1a:	00f51a63          	bne	a0,a5,80004b2e <kexec+0x70>
    goto bad;

  // Is this really an ELF file?
  if(elf.magic != ELF_MAGIC)
    80004b1e:	e5042703          	lw	a4,-432(s0)
    80004b22:	464c47b7          	lui	a5,0x464c4
    80004b26:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004b2a:	02f70e63          	beq	a4,a5,80004b66 <kexec+0xa8>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80004b2e:	8526                	mv	a0,s1
    80004b30:	deffe0ef          	jal	ra,8000391e <iunlockput>
    end_op();
    80004b34:	e32ff0ef          	jal	ra,80004166 <end_op>
  }
  return -1;
    80004b38:	557d                	li	a0,-1
}
    80004b3a:	20813083          	ld	ra,520(sp)
    80004b3e:	20013403          	ld	s0,512(sp)
    80004b42:	74fe                	ld	s1,504(sp)
    80004b44:	795e                	ld	s2,496(sp)
    80004b46:	79be                	ld	s3,488(sp)
    80004b48:	7a1e                	ld	s4,480(sp)
    80004b4a:	6afe                	ld	s5,472(sp)
    80004b4c:	6b5e                	ld	s6,464(sp)
    80004b4e:	6bbe                	ld	s7,456(sp)
    80004b50:	6c1e                	ld	s8,448(sp)
    80004b52:	7cfa                	ld	s9,440(sp)
    80004b54:	7d5a                	ld	s10,432(sp)
    80004b56:	7dba                	ld	s11,424(sp)
    80004b58:	21010113          	addi	sp,sp,528
    80004b5c:	8082                	ret
    end_op();
    80004b5e:	e08ff0ef          	jal	ra,80004166 <end_op>
    return -1;
    80004b62:	557d                	li	a0,-1
    80004b64:	bfd9                	j	80004b3a <kexec+0x7c>
  if((pagetable = proc_pagetable(p)) == 0)
    80004b66:	854a                	mv	a0,s2
    80004b68:	df9fc0ef          	jal	ra,80001960 <proc_pagetable>
    80004b6c:	8baa                	mv	s7,a0
    80004b6e:	d161                	beqz	a0,80004b2e <kexec+0x70>
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004b70:	e7042983          	lw	s3,-400(s0)
    80004b74:	e8845783          	lhu	a5,-376(s0)
    80004b78:	cfb9                	beqz	a5,80004bd6 <kexec+0x118>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004b7a:	4a01                	li	s4,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004b7c:	4b01                	li	s6,0
    if(ph.vaddr % PGSIZE != 0)
    80004b7e:	6c85                	lui	s9,0x1
    80004b80:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80004b84:	def43823          	sd	a5,-528(s0)
    80004b88:	aadd                	j	80004d7e <kexec+0x2c0>
  uint64 pa;

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    80004b8a:	00003517          	auipc	a0,0x3
    80004b8e:	c8e50513          	addi	a0,a0,-882 # 80007818 <syscalls+0x2e8>
    80004b92:	bfdfb0ef          	jal	ra,8000078e <panic>
    if(sz - i < PGSIZE)
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80004b96:	8756                	mv	a4,s5
    80004b98:	012d86bb          	addw	a3,s11,s2
    80004b9c:	4581                	li	a1,0
    80004b9e:	8526                	mv	a0,s1
    80004ba0:	f05fe0ef          	jal	ra,80003aa4 <readi>
    80004ba4:	2501                	sext.w	a0,a0
    80004ba6:	18aa9263          	bne	s5,a0,80004d2a <kexec+0x26c>
  for(i = 0; i < sz; i += PGSIZE){
    80004baa:	6785                	lui	a5,0x1
    80004bac:	0127893b          	addw	s2,a5,s2
    80004bb0:	77fd                	lui	a5,0xfffff
    80004bb2:	01478a3b          	addw	s4,a5,s4
    80004bb6:	1b897b63          	bgeu	s2,s8,80004d6c <kexec+0x2ae>
    pa = walkaddr(pagetable, va + i);
    80004bba:	02091593          	slli	a1,s2,0x20
    80004bbe:	9181                	srli	a1,a1,0x20
    80004bc0:	95ea                	add	a1,a1,s10
    80004bc2:	855e                	mv	a0,s7
    80004bc4:	be8fc0ef          	jal	ra,80000fac <walkaddr>
    80004bc8:	862a                	mv	a2,a0
    if(pa == 0)
    80004bca:	d161                	beqz	a0,80004b8a <kexec+0xcc>
      n = PGSIZE;
    80004bcc:	8ae6                	mv	s5,s9
    if(sz - i < PGSIZE)
    80004bce:	fd9a74e3          	bgeu	s4,s9,80004b96 <kexec+0xd8>
      n = sz - i;
    80004bd2:	8ad2                	mv	s5,s4
    80004bd4:	b7c9                	j	80004b96 <kexec+0xd8>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004bd6:	4a01                	li	s4,0
  iunlockput(ip);
    80004bd8:	8526                	mv	a0,s1
    80004bda:	d45fe0ef          	jal	ra,8000391e <iunlockput>
  end_op();
    80004bde:	d88ff0ef          	jal	ra,80004166 <end_op>
  p = myproc();
    80004be2:	c79fc0ef          	jal	ra,8000185a <myproc>
    80004be6:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80004be8:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80004bec:	6785                	lui	a5,0x1
    80004bee:	17fd                	addi	a5,a5,-1
    80004bf0:	9a3e                	add	s4,s4,a5
    80004bf2:	757d                	lui	a0,0xfffff
    80004bf4:	00aa77b3          	and	a5,s4,a0
    80004bf8:	e0f43423          	sd	a5,-504(s0)
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80004bfc:	4691                	li	a3,4
    80004bfe:	6609                	lui	a2,0x2
    80004c00:	963e                	add	a2,a2,a5
    80004c02:	85be                	mv	a1,a5
    80004c04:	855e                	mv	a0,s7
    80004c06:	e70fc0ef          	jal	ra,80001276 <uvmalloc>
    80004c0a:	8b2a                	mv	s6,a0
  ip = 0;
    80004c0c:	4481                	li	s1,0
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80004c0e:	10050e63          	beqz	a0,80004d2a <kexec+0x26c>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80004c12:	75f9                	lui	a1,0xffffe
    80004c14:	95aa                	add	a1,a1,a0
    80004c16:	855e                	mv	a0,s7
    80004c18:	825fc0ef          	jal	ra,8000143c <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80004c1c:	7c7d                	lui	s8,0xfffff
    80004c1e:	9c5a                	add	s8,s8,s6
  for(argc = 0; argv[argc]; argc++) {
    80004c20:	e0043783          	ld	a5,-512(s0)
    80004c24:	6388                	ld	a0,0(a5)
    80004c26:	c125                	beqz	a0,80004c86 <kexec+0x1c8>
    80004c28:	e9040993          	addi	s3,s0,-368
    80004c2c:	f9040c93          	addi	s9,s0,-112
  sp = sz;
    80004c30:	895a                	mv	s2,s6
    sp -= strlen(argv[argc]) + 1;
    80004c32:	9dcfc0ef          	jal	ra,80000e0e <strlen>
    80004c36:	2505                	addiw	a0,a0,1
    80004c38:	40a90933          	sub	s2,s2,a0
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004c3c:	ff097913          	andi	s2,s2,-16
    if(sp < stackbase)
    80004c40:	11896a63          	bltu	s2,s8,80004d54 <kexec+0x296>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004c44:	e0043d83          	ld	s11,-512(s0)
    80004c48:	000dba03          	ld	s4,0(s11)
    80004c4c:	8552                	mv	a0,s4
    80004c4e:	9c0fc0ef          	jal	ra,80000e0e <strlen>
    80004c52:	0015069b          	addiw	a3,a0,1
    80004c56:	8652                	mv	a2,s4
    80004c58:	85ca                	mv	a1,s2
    80004c5a:	855e                	mv	a0,s7
    80004c5c:	94dfc0ef          	jal	ra,800015a8 <copyout>
    80004c60:	0e054e63          	bltz	a0,80004d5c <kexec+0x29e>
    ustack[argc] = sp;
    80004c64:	0129b023          	sd	s2,0(s3)
  for(argc = 0; argv[argc]; argc++) {
    80004c68:	0485                	addi	s1,s1,1
    80004c6a:	008d8793          	addi	a5,s11,8
    80004c6e:	e0f43023          	sd	a5,-512(s0)
    80004c72:	008db503          	ld	a0,8(s11)
    80004c76:	c911                	beqz	a0,80004c8a <kexec+0x1cc>
    if(argc >= MAXARG)
    80004c78:	09a1                	addi	s3,s3,8
    80004c7a:	fb3c9ce3          	bne	s9,s3,80004c32 <kexec+0x174>
  sz = sz1;
    80004c7e:	e1643423          	sd	s6,-504(s0)
  ip = 0;
    80004c82:	4481                	li	s1,0
    80004c84:	a05d                	j	80004d2a <kexec+0x26c>
  sp = sz;
    80004c86:	895a                	mv	s2,s6
  for(argc = 0; argv[argc]; argc++) {
    80004c88:	4481                	li	s1,0
  ustack[argc] = 0;
    80004c8a:	00349793          	slli	a5,s1,0x3
    80004c8e:	f9040713          	addi	a4,s0,-112
    80004c92:	97ba                	add	a5,a5,a4
    80004c94:	f007b023          	sd	zero,-256(a5) # f00 <_entry-0x7ffff100>
  sp -= (argc+1) * sizeof(uint64);
    80004c98:	00148693          	addi	a3,s1,1
    80004c9c:	068e                	slli	a3,a3,0x3
    80004c9e:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004ca2:	ff097913          	andi	s2,s2,-16
  if(sp < stackbase)
    80004ca6:	01897663          	bgeu	s2,s8,80004cb2 <kexec+0x1f4>
  sz = sz1;
    80004caa:	e1643423          	sd	s6,-504(s0)
  ip = 0;
    80004cae:	4481                	li	s1,0
    80004cb0:	a8ad                	j	80004d2a <kexec+0x26c>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004cb2:	e9040613          	addi	a2,s0,-368
    80004cb6:	85ca                	mv	a1,s2
    80004cb8:	855e                	mv	a0,s7
    80004cba:	8effc0ef          	jal	ra,800015a8 <copyout>
    80004cbe:	0a054363          	bltz	a0,80004d64 <kexec+0x2a6>
  p->trapframe->a1 = sp;
    80004cc2:	058ab783          	ld	a5,88(s5)
    80004cc6:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80004cca:	df843783          	ld	a5,-520(s0)
    80004cce:	0007c703          	lbu	a4,0(a5)
    80004cd2:	cf11                	beqz	a4,80004cee <kexec+0x230>
    80004cd4:	0785                	addi	a5,a5,1
    if(*s == '/')
    80004cd6:	02f00693          	li	a3,47
    80004cda:	a039                	j	80004ce8 <kexec+0x22a>
      last = s+1;
    80004cdc:	def43c23          	sd	a5,-520(s0)
  for(last=s=path; *s; s++)
    80004ce0:	0785                	addi	a5,a5,1
    80004ce2:	fff7c703          	lbu	a4,-1(a5)
    80004ce6:	c701                	beqz	a4,80004cee <kexec+0x230>
    if(*s == '/')
    80004ce8:	fed71ce3          	bne	a4,a3,80004ce0 <kexec+0x222>
    80004cec:	bfc5                	j	80004cdc <kexec+0x21e>
  safestrcpy(p->name, last, sizeof(p->name));
    80004cee:	4641                	li	a2,16
    80004cf0:	df843583          	ld	a1,-520(s0)
    80004cf4:	158a8513          	addi	a0,s5,344
    80004cf8:	8e4fc0ef          	jal	ra,80000ddc <safestrcpy>
  oldpagetable = p->pagetable;
    80004cfc:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    80004d00:	057ab823          	sd	s7,80(s5)
  p->sz = sz;
    80004d04:	056ab423          	sd	s6,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = ulib.c:start()
    80004d08:	058ab783          	ld	a5,88(s5)
    80004d0c:	e6843703          	ld	a4,-408(s0)
    80004d10:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80004d12:	058ab783          	ld	a5,88(s5)
    80004d16:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004d1a:	85ea                	mv	a1,s10
    80004d1c:	cc9fc0ef          	jal	ra,800019e4 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004d20:	0004851b          	sext.w	a0,s1
    80004d24:	bd19                	j	80004b3a <kexec+0x7c>
    80004d26:	e1443423          	sd	s4,-504(s0)
    proc_freepagetable(pagetable, sz);
    80004d2a:	e0843583          	ld	a1,-504(s0)
    80004d2e:	855e                	mv	a0,s7
    80004d30:	cb5fc0ef          	jal	ra,800019e4 <proc_freepagetable>
  if(ip){
    80004d34:	de049de3          	bnez	s1,80004b2e <kexec+0x70>
  return -1;
    80004d38:	557d                	li	a0,-1
    80004d3a:	b501                	j	80004b3a <kexec+0x7c>
    80004d3c:	e1443423          	sd	s4,-504(s0)
    80004d40:	b7ed                	j	80004d2a <kexec+0x26c>
    80004d42:	e1443423          	sd	s4,-504(s0)
    80004d46:	b7d5                	j	80004d2a <kexec+0x26c>
    80004d48:	e1443423          	sd	s4,-504(s0)
    80004d4c:	bff9                	j	80004d2a <kexec+0x26c>
    80004d4e:	e1443423          	sd	s4,-504(s0)
    80004d52:	bfe1                	j	80004d2a <kexec+0x26c>
  sz = sz1;
    80004d54:	e1643423          	sd	s6,-504(s0)
  ip = 0;
    80004d58:	4481                	li	s1,0
    80004d5a:	bfc1                	j	80004d2a <kexec+0x26c>
  sz = sz1;
    80004d5c:	e1643423          	sd	s6,-504(s0)
  ip = 0;
    80004d60:	4481                	li	s1,0
    80004d62:	b7e1                	j	80004d2a <kexec+0x26c>
  sz = sz1;
    80004d64:	e1643423          	sd	s6,-504(s0)
  ip = 0;
    80004d68:	4481                	li	s1,0
    80004d6a:	b7c1                	j	80004d2a <kexec+0x26c>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004d6c:	e0843a03          	ld	s4,-504(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004d70:	2b05                	addiw	s6,s6,1
    80004d72:	0389899b          	addiw	s3,s3,56
    80004d76:	e8845783          	lhu	a5,-376(s0)
    80004d7a:	e4fb5fe3          	bge	s6,a5,80004bd8 <kexec+0x11a>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004d7e:	2981                	sext.w	s3,s3
    80004d80:	03800713          	li	a4,56
    80004d84:	86ce                	mv	a3,s3
    80004d86:	e1840613          	addi	a2,s0,-488
    80004d8a:	4581                	li	a1,0
    80004d8c:	8526                	mv	a0,s1
    80004d8e:	d17fe0ef          	jal	ra,80003aa4 <readi>
    80004d92:	03800793          	li	a5,56
    80004d96:	f8f518e3          	bne	a0,a5,80004d26 <kexec+0x268>
    if(ph.type != ELF_PROG_LOAD)
    80004d9a:	e1842783          	lw	a5,-488(s0)
    80004d9e:	4705                	li	a4,1
    80004da0:	fce798e3          	bne	a5,a4,80004d70 <kexec+0x2b2>
    if(ph.memsz < ph.filesz)
    80004da4:	e4043903          	ld	s2,-448(s0)
    80004da8:	e3843783          	ld	a5,-456(s0)
    80004dac:	f8f968e3          	bltu	s2,a5,80004d3c <kexec+0x27e>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80004db0:	e2843783          	ld	a5,-472(s0)
    80004db4:	993e                	add	s2,s2,a5
    80004db6:	f8f966e3          	bltu	s2,a5,80004d42 <kexec+0x284>
    if(ph.vaddr % PGSIZE != 0)
    80004dba:	df043703          	ld	a4,-528(s0)
    80004dbe:	8ff9                	and	a5,a5,a4
    80004dc0:	f7c1                	bnez	a5,80004d48 <kexec+0x28a>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004dc2:	e1c42503          	lw	a0,-484(s0)
    80004dc6:	cddff0ef          	jal	ra,80004aa2 <flags2perm>
    80004dca:	86aa                	mv	a3,a0
    80004dcc:	864a                	mv	a2,s2
    80004dce:	85d2                	mv	a1,s4
    80004dd0:	855e                	mv	a0,s7
    80004dd2:	ca4fc0ef          	jal	ra,80001276 <uvmalloc>
    80004dd6:	e0a43423          	sd	a0,-504(s0)
    80004dda:	d935                	beqz	a0,80004d4e <kexec+0x290>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004ddc:	e2843d03          	ld	s10,-472(s0)
    80004de0:	e2042d83          	lw	s11,-480(s0)
    80004de4:	e3842c03          	lw	s8,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004de8:	f80c02e3          	beqz	s8,80004d6c <kexec+0x2ae>
    80004dec:	8a62                	mv	s4,s8
    80004dee:	4901                	li	s2,0
    80004df0:	b3e9                	j	80004bba <kexec+0xfc>

0000000080004df2 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004df2:	7179                	addi	sp,sp,-48
    80004df4:	f406                	sd	ra,40(sp)
    80004df6:	f022                	sd	s0,32(sp)
    80004df8:	ec26                	sd	s1,24(sp)
    80004dfa:	e84a                	sd	s2,16(sp)
    80004dfc:	1800                	addi	s0,sp,48
    80004dfe:	892e                	mv	s2,a1
    80004e00:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004e02:	fdc40593          	addi	a1,s0,-36
    80004e06:	e7ffd0ef          	jal	ra,80002c84 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004e0a:	fdc42703          	lw	a4,-36(s0)
    80004e0e:	47bd                	li	a5,15
    80004e10:	02e7e963          	bltu	a5,a4,80004e42 <argfd+0x50>
    80004e14:	a47fc0ef          	jal	ra,8000185a <myproc>
    80004e18:	fdc42703          	lw	a4,-36(s0)
    80004e1c:	01a70793          	addi	a5,a4,26
    80004e20:	078e                	slli	a5,a5,0x3
    80004e22:	953e                	add	a0,a0,a5
    80004e24:	611c                	ld	a5,0(a0)
    80004e26:	c385                	beqz	a5,80004e46 <argfd+0x54>
    return -1;
  if(pfd)
    80004e28:	00090463          	beqz	s2,80004e30 <argfd+0x3e>
    *pfd = fd;
    80004e2c:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80004e30:	4501                	li	a0,0
  if(pf)
    80004e32:	c091                	beqz	s1,80004e36 <argfd+0x44>
    *pf = f;
    80004e34:	e09c                	sd	a5,0(s1)
}
    80004e36:	70a2                	ld	ra,40(sp)
    80004e38:	7402                	ld	s0,32(sp)
    80004e3a:	64e2                	ld	s1,24(sp)
    80004e3c:	6942                	ld	s2,16(sp)
    80004e3e:	6145                	addi	sp,sp,48
    80004e40:	8082                	ret
    return -1;
    80004e42:	557d                	li	a0,-1
    80004e44:	bfcd                	j	80004e36 <argfd+0x44>
    80004e46:	557d                	li	a0,-1
    80004e48:	b7fd                	j	80004e36 <argfd+0x44>

0000000080004e4a <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004e4a:	1101                	addi	sp,sp,-32
    80004e4c:	ec06                	sd	ra,24(sp)
    80004e4e:	e822                	sd	s0,16(sp)
    80004e50:	e426                	sd	s1,8(sp)
    80004e52:	1000                	addi	s0,sp,32
    80004e54:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004e56:	a05fc0ef          	jal	ra,8000185a <myproc>
    80004e5a:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80004e5c:	0d050793          	addi	a5,a0,208 # fffffffffffff0d0 <end+0xffffffff7ffdd9f8>
    80004e60:	4501                	li	a0,0
    80004e62:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80004e64:	6398                	ld	a4,0(a5)
    80004e66:	cb19                	beqz	a4,80004e7c <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80004e68:	2505                	addiw	a0,a0,1
    80004e6a:	07a1                	addi	a5,a5,8
    80004e6c:	fed51ce3          	bne	a0,a3,80004e64 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004e70:	557d                	li	a0,-1
}
    80004e72:	60e2                	ld	ra,24(sp)
    80004e74:	6442                	ld	s0,16(sp)
    80004e76:	64a2                	ld	s1,8(sp)
    80004e78:	6105                	addi	sp,sp,32
    80004e7a:	8082                	ret
      p->ofile[fd] = f;
    80004e7c:	01a50793          	addi	a5,a0,26
    80004e80:	078e                	slli	a5,a5,0x3
    80004e82:	963e                	add	a2,a2,a5
    80004e84:	e204                	sd	s1,0(a2)
      return fd;
    80004e86:	b7f5                	j	80004e72 <fdalloc+0x28>

0000000080004e88 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80004e88:	715d                	addi	sp,sp,-80
    80004e8a:	e486                	sd	ra,72(sp)
    80004e8c:	e0a2                	sd	s0,64(sp)
    80004e8e:	fc26                	sd	s1,56(sp)
    80004e90:	f84a                	sd	s2,48(sp)
    80004e92:	f44e                	sd	s3,40(sp)
    80004e94:	f052                	sd	s4,32(sp)
    80004e96:	ec56                	sd	s5,24(sp)
    80004e98:	e85a                	sd	s6,16(sp)
    80004e9a:	0880                	addi	s0,sp,80
    80004e9c:	8b2e                	mv	s6,a1
    80004e9e:	89b2                	mv	s3,a2
    80004ea0:	8936                	mv	s2,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80004ea2:	fb040593          	addi	a1,s0,-80
    80004ea6:	87aff0ef          	jal	ra,80003f20 <nameiparent>
    80004eaa:	84aa                	mv	s1,a0
    80004eac:	10050c63          	beqz	a0,80004fc4 <create+0x13c>
    return 0;

  ilock(dp);
    80004eb0:	869fe0ef          	jal	ra,80003718 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80004eb4:	4601                	li	a2,0
    80004eb6:	fb040593          	addi	a1,s0,-80
    80004eba:	8526                	mv	a0,s1
    80004ebc:	de5fe0ef          	jal	ra,80003ca0 <dirlookup>
    80004ec0:	8aaa                	mv	s5,a0
    80004ec2:	c521                	beqz	a0,80004f0a <create+0x82>
    iunlockput(dp);
    80004ec4:	8526                	mv	a0,s1
    80004ec6:	a59fe0ef          	jal	ra,8000391e <iunlockput>
    ilock(ip);
    80004eca:	8556                	mv	a0,s5
    80004ecc:	84dfe0ef          	jal	ra,80003718 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004ed0:	000b059b          	sext.w	a1,s6
    80004ed4:	4789                	li	a5,2
    80004ed6:	02f59563          	bne	a1,a5,80004f00 <create+0x78>
    80004eda:	044ad783          	lhu	a5,68(s5)
    80004ede:	37f9                	addiw	a5,a5,-2
    80004ee0:	17c2                	slli	a5,a5,0x30
    80004ee2:	93c1                	srli	a5,a5,0x30
    80004ee4:	4705                	li	a4,1
    80004ee6:	00f76d63          	bltu	a4,a5,80004f00 <create+0x78>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004eea:	8556                	mv	a0,s5
    80004eec:	60a6                	ld	ra,72(sp)
    80004eee:	6406                	ld	s0,64(sp)
    80004ef0:	74e2                	ld	s1,56(sp)
    80004ef2:	7942                	ld	s2,48(sp)
    80004ef4:	79a2                	ld	s3,40(sp)
    80004ef6:	7a02                	ld	s4,32(sp)
    80004ef8:	6ae2                	ld	s5,24(sp)
    80004efa:	6b42                	ld	s6,16(sp)
    80004efc:	6161                	addi	sp,sp,80
    80004efe:	8082                	ret
    iunlockput(ip);
    80004f00:	8556                	mv	a0,s5
    80004f02:	a1dfe0ef          	jal	ra,8000391e <iunlockput>
    return 0;
    80004f06:	4a81                	li	s5,0
    80004f08:	b7cd                	j	80004eea <create+0x62>
  if((ip = ialloc(dp->dev, type)) == 0){
    80004f0a:	85da                	mv	a1,s6
    80004f0c:	4088                	lw	a0,0(s1)
    80004f0e:	ea2fe0ef          	jal	ra,800035b0 <ialloc>
    80004f12:	8a2a                	mv	s4,a0
    80004f14:	c121                	beqz	a0,80004f54 <create+0xcc>
  ilock(ip);
    80004f16:	803fe0ef          	jal	ra,80003718 <ilock>
  ip->major = major;
    80004f1a:	053a1323          	sh	s3,70(s4)
  ip->minor = minor;
    80004f1e:	052a1423          	sh	s2,72(s4)
  ip->nlink = 1;
    80004f22:	4785                	li	a5,1
    80004f24:	04fa1523          	sh	a5,74(s4)
  iupdate(ip);
    80004f28:	8552                	mv	a0,s4
    80004f2a:	f3cfe0ef          	jal	ra,80003666 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80004f2e:	000b059b          	sext.w	a1,s6
    80004f32:	4785                	li	a5,1
    80004f34:	02f58563          	beq	a1,a5,80004f5e <create+0xd6>
  if(dirlink(dp, name, ip->inum) < 0)
    80004f38:	004a2603          	lw	a2,4(s4)
    80004f3c:	fb040593          	addi	a1,s0,-80
    80004f40:	8526                	mv	a0,s1
    80004f42:	f2bfe0ef          	jal	ra,80003e6c <dirlink>
    80004f46:	06054363          	bltz	a0,80004fac <create+0x124>
  iunlockput(dp);
    80004f4a:	8526                	mv	a0,s1
    80004f4c:	9d3fe0ef          	jal	ra,8000391e <iunlockput>
  return ip;
    80004f50:	8ad2                	mv	s5,s4
    80004f52:	bf61                	j	80004eea <create+0x62>
    iunlockput(dp);
    80004f54:	8526                	mv	a0,s1
    80004f56:	9c9fe0ef          	jal	ra,8000391e <iunlockput>
    return 0;
    80004f5a:	8ad2                	mv	s5,s4
    80004f5c:	b779                	j	80004eea <create+0x62>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004f5e:	004a2603          	lw	a2,4(s4)
    80004f62:	00003597          	auipc	a1,0x3
    80004f66:	8d658593          	addi	a1,a1,-1834 # 80007838 <syscalls+0x308>
    80004f6a:	8552                	mv	a0,s4
    80004f6c:	f01fe0ef          	jal	ra,80003e6c <dirlink>
    80004f70:	02054e63          	bltz	a0,80004fac <create+0x124>
    80004f74:	40d0                	lw	a2,4(s1)
    80004f76:	00003597          	auipc	a1,0x3
    80004f7a:	8ca58593          	addi	a1,a1,-1846 # 80007840 <syscalls+0x310>
    80004f7e:	8552                	mv	a0,s4
    80004f80:	eedfe0ef          	jal	ra,80003e6c <dirlink>
    80004f84:	02054463          	bltz	a0,80004fac <create+0x124>
  if(dirlink(dp, name, ip->inum) < 0)
    80004f88:	004a2603          	lw	a2,4(s4)
    80004f8c:	fb040593          	addi	a1,s0,-80
    80004f90:	8526                	mv	a0,s1
    80004f92:	edbfe0ef          	jal	ra,80003e6c <dirlink>
    80004f96:	00054b63          	bltz	a0,80004fac <create+0x124>
    dp->nlink++;  // for ".."
    80004f9a:	04a4d783          	lhu	a5,74(s1)
    80004f9e:	2785                	addiw	a5,a5,1
    80004fa0:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004fa4:	8526                	mv	a0,s1
    80004fa6:	ec0fe0ef          	jal	ra,80003666 <iupdate>
    80004faa:	b745                	j	80004f4a <create+0xc2>
  ip->nlink = 0;
    80004fac:	040a1523          	sh	zero,74(s4)
  iupdate(ip);
    80004fb0:	8552                	mv	a0,s4
    80004fb2:	eb4fe0ef          	jal	ra,80003666 <iupdate>
  iunlockput(ip);
    80004fb6:	8552                	mv	a0,s4
    80004fb8:	967fe0ef          	jal	ra,8000391e <iunlockput>
  iunlockput(dp);
    80004fbc:	8526                	mv	a0,s1
    80004fbe:	961fe0ef          	jal	ra,8000391e <iunlockput>
  return 0;
    80004fc2:	b725                	j	80004eea <create+0x62>
    return 0;
    80004fc4:	8aaa                	mv	s5,a0
    80004fc6:	b715                	j	80004eea <create+0x62>

0000000080004fc8 <sys_dup>:
{
    80004fc8:	7179                	addi	sp,sp,-48
    80004fca:	f406                	sd	ra,40(sp)
    80004fcc:	f022                	sd	s0,32(sp)
    80004fce:	ec26                	sd	s1,24(sp)
    80004fd0:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80004fd2:	fd840613          	addi	a2,s0,-40
    80004fd6:	4581                	li	a1,0
    80004fd8:	4501                	li	a0,0
    80004fda:	e19ff0ef          	jal	ra,80004df2 <argfd>
    return -1;
    80004fde:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004fe0:	00054f63          	bltz	a0,80004ffe <sys_dup+0x36>
  if((fd=fdalloc(f)) < 0)
    80004fe4:	fd843503          	ld	a0,-40(s0)
    80004fe8:	e63ff0ef          	jal	ra,80004e4a <fdalloc>
    80004fec:	84aa                	mv	s1,a0
    return -1;
    80004fee:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004ff0:	00054763          	bltz	a0,80004ffe <sys_dup+0x36>
  filedup(f);
    80004ff4:	fd843503          	ld	a0,-40(s0)
    80004ff8:	cc6ff0ef          	jal	ra,800044be <filedup>
  return fd;
    80004ffc:	87a6                	mv	a5,s1
}
    80004ffe:	853e                	mv	a0,a5
    80005000:	70a2                	ld	ra,40(sp)
    80005002:	7402                	ld	s0,32(sp)
    80005004:	64e2                	ld	s1,24(sp)
    80005006:	6145                	addi	sp,sp,48
    80005008:	8082                	ret

000000008000500a <sys_read>:
{
    8000500a:	7179                	addi	sp,sp,-48
    8000500c:	f406                	sd	ra,40(sp)
    8000500e:	f022                	sd	s0,32(sp)
    80005010:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80005012:	fd840593          	addi	a1,s0,-40
    80005016:	4505                	li	a0,1
    80005018:	c89fd0ef          	jal	ra,80002ca0 <argaddr>
  argint(2, &n);
    8000501c:	fe440593          	addi	a1,s0,-28
    80005020:	4509                	li	a0,2
    80005022:	c63fd0ef          	jal	ra,80002c84 <argint>
  if(argfd(0, 0, &f) < 0)
    80005026:	fe840613          	addi	a2,s0,-24
    8000502a:	4581                	li	a1,0
    8000502c:	4501                	li	a0,0
    8000502e:	dc5ff0ef          	jal	ra,80004df2 <argfd>
    80005032:	87aa                	mv	a5,a0
    return -1;
    80005034:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80005036:	0007ca63          	bltz	a5,8000504a <sys_read+0x40>
  return fileread(f, p, n);
    8000503a:	fe442603          	lw	a2,-28(s0)
    8000503e:	fd843583          	ld	a1,-40(s0)
    80005042:	fe843503          	ld	a0,-24(s0)
    80005046:	dc4ff0ef          	jal	ra,8000460a <fileread>
}
    8000504a:	70a2                	ld	ra,40(sp)
    8000504c:	7402                	ld	s0,32(sp)
    8000504e:	6145                	addi	sp,sp,48
    80005050:	8082                	ret

0000000080005052 <sys_write>:
{
    80005052:	7179                	addi	sp,sp,-48
    80005054:	f406                	sd	ra,40(sp)
    80005056:	f022                	sd	s0,32(sp)
    80005058:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    8000505a:	fd840593          	addi	a1,s0,-40
    8000505e:	4505                	li	a0,1
    80005060:	c41fd0ef          	jal	ra,80002ca0 <argaddr>
  argint(2, &n);
    80005064:	fe440593          	addi	a1,s0,-28
    80005068:	4509                	li	a0,2
    8000506a:	c1bfd0ef          	jal	ra,80002c84 <argint>
  if(argfd(0, 0, &f) < 0)
    8000506e:	fe840613          	addi	a2,s0,-24
    80005072:	4581                	li	a1,0
    80005074:	4501                	li	a0,0
    80005076:	d7dff0ef          	jal	ra,80004df2 <argfd>
    8000507a:	87aa                	mv	a5,a0
    return -1;
    8000507c:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000507e:	0007ca63          	bltz	a5,80005092 <sys_write+0x40>
  return filewrite(f, p, n);
    80005082:	fe442603          	lw	a2,-28(s0)
    80005086:	fd843583          	ld	a1,-40(s0)
    8000508a:	fe843503          	ld	a0,-24(s0)
    8000508e:	e2aff0ef          	jal	ra,800046b8 <filewrite>
}
    80005092:	70a2                	ld	ra,40(sp)
    80005094:	7402                	ld	s0,32(sp)
    80005096:	6145                	addi	sp,sp,48
    80005098:	8082                	ret

000000008000509a <sys_close>:
{
    8000509a:	1101                	addi	sp,sp,-32
    8000509c:	ec06                	sd	ra,24(sp)
    8000509e:	e822                	sd	s0,16(sp)
    800050a0:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    800050a2:	fe040613          	addi	a2,s0,-32
    800050a6:	fec40593          	addi	a1,s0,-20
    800050aa:	4501                	li	a0,0
    800050ac:	d47ff0ef          	jal	ra,80004df2 <argfd>
    return -1;
    800050b0:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    800050b2:	02054063          	bltz	a0,800050d2 <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    800050b6:	fa4fc0ef          	jal	ra,8000185a <myproc>
    800050ba:	fec42783          	lw	a5,-20(s0)
    800050be:	07e9                	addi	a5,a5,26
    800050c0:	078e                	slli	a5,a5,0x3
    800050c2:	97aa                	add	a5,a5,a0
    800050c4:	0007b023          	sd	zero,0(a5)
  fileclose(f);
    800050c8:	fe043503          	ld	a0,-32(s0)
    800050cc:	c38ff0ef          	jal	ra,80004504 <fileclose>
  return 0;
    800050d0:	4781                	li	a5,0
}
    800050d2:	853e                	mv	a0,a5
    800050d4:	60e2                	ld	ra,24(sp)
    800050d6:	6442                	ld	s0,16(sp)
    800050d8:	6105                	addi	sp,sp,32
    800050da:	8082                	ret

00000000800050dc <sys_fstat>:
{
    800050dc:	1101                	addi	sp,sp,-32
    800050de:	ec06                	sd	ra,24(sp)
    800050e0:	e822                	sd	s0,16(sp)
    800050e2:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    800050e4:	fe040593          	addi	a1,s0,-32
    800050e8:	4505                	li	a0,1
    800050ea:	bb7fd0ef          	jal	ra,80002ca0 <argaddr>
  if(argfd(0, 0, &f) < 0)
    800050ee:	fe840613          	addi	a2,s0,-24
    800050f2:	4581                	li	a1,0
    800050f4:	4501                	li	a0,0
    800050f6:	cfdff0ef          	jal	ra,80004df2 <argfd>
    800050fa:	87aa                	mv	a5,a0
    return -1;
    800050fc:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800050fe:	0007c863          	bltz	a5,8000510e <sys_fstat+0x32>
  return filestat(f, st);
    80005102:	fe043583          	ld	a1,-32(s0)
    80005106:	fe843503          	ld	a0,-24(s0)
    8000510a:	ca2ff0ef          	jal	ra,800045ac <filestat>
}
    8000510e:	60e2                	ld	ra,24(sp)
    80005110:	6442                	ld	s0,16(sp)
    80005112:	6105                	addi	sp,sp,32
    80005114:	8082                	ret

0000000080005116 <sys_link>:
{
    80005116:	7169                	addi	sp,sp,-304
    80005118:	f606                	sd	ra,296(sp)
    8000511a:	f222                	sd	s0,288(sp)
    8000511c:	ee26                	sd	s1,280(sp)
    8000511e:	ea4a                	sd	s2,272(sp)
    80005120:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80005122:	08000613          	li	a2,128
    80005126:	ed040593          	addi	a1,s0,-304
    8000512a:	4501                	li	a0,0
    8000512c:	b91fd0ef          	jal	ra,80002cbc <argstr>
    return -1;
    80005130:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80005132:	0c054663          	bltz	a0,800051fe <sys_link+0xe8>
    80005136:	08000613          	li	a2,128
    8000513a:	f5040593          	addi	a1,s0,-176
    8000513e:	4505                	li	a0,1
    80005140:	b7dfd0ef          	jal	ra,80002cbc <argstr>
    return -1;
    80005144:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80005146:	0a054c63          	bltz	a0,800051fe <sys_link+0xe8>
  begin_op();
    8000514a:	fadfe0ef          	jal	ra,800040f6 <begin_op>
  if((ip = namei(old)) == 0){
    8000514e:	ed040513          	addi	a0,s0,-304
    80005152:	db5fe0ef          	jal	ra,80003f06 <namei>
    80005156:	84aa                	mv	s1,a0
    80005158:	c525                	beqz	a0,800051c0 <sys_link+0xaa>
  ilock(ip);
    8000515a:	dbefe0ef          	jal	ra,80003718 <ilock>
  if(ip->type == T_DIR){
    8000515e:	04449703          	lh	a4,68(s1)
    80005162:	4785                	li	a5,1
    80005164:	06f70263          	beq	a4,a5,800051c8 <sys_link+0xb2>
  ip->nlink++;
    80005168:	04a4d783          	lhu	a5,74(s1)
    8000516c:	2785                	addiw	a5,a5,1
    8000516e:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005172:	8526                	mv	a0,s1
    80005174:	cf2fe0ef          	jal	ra,80003666 <iupdate>
  iunlock(ip);
    80005178:	8526                	mv	a0,s1
    8000517a:	e48fe0ef          	jal	ra,800037c2 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    8000517e:	fd040593          	addi	a1,s0,-48
    80005182:	f5040513          	addi	a0,s0,-176
    80005186:	d9bfe0ef          	jal	ra,80003f20 <nameiparent>
    8000518a:	892a                	mv	s2,a0
    8000518c:	c921                	beqz	a0,800051dc <sys_link+0xc6>
  ilock(dp);
    8000518e:	d8afe0ef          	jal	ra,80003718 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80005192:	00092703          	lw	a4,0(s2)
    80005196:	409c                	lw	a5,0(s1)
    80005198:	02f71f63          	bne	a4,a5,800051d6 <sys_link+0xc0>
    8000519c:	40d0                	lw	a2,4(s1)
    8000519e:	fd040593          	addi	a1,s0,-48
    800051a2:	854a                	mv	a0,s2
    800051a4:	cc9fe0ef          	jal	ra,80003e6c <dirlink>
    800051a8:	02054763          	bltz	a0,800051d6 <sys_link+0xc0>
  iunlockput(dp);
    800051ac:	854a                	mv	a0,s2
    800051ae:	f70fe0ef          	jal	ra,8000391e <iunlockput>
  iput(ip);
    800051b2:	8526                	mv	a0,s1
    800051b4:	ee2fe0ef          	jal	ra,80003896 <iput>
  end_op();
    800051b8:	faffe0ef          	jal	ra,80004166 <end_op>
  return 0;
    800051bc:	4781                	li	a5,0
    800051be:	a081                	j	800051fe <sys_link+0xe8>
    end_op();
    800051c0:	fa7fe0ef          	jal	ra,80004166 <end_op>
    return -1;
    800051c4:	57fd                	li	a5,-1
    800051c6:	a825                	j	800051fe <sys_link+0xe8>
    iunlockput(ip);
    800051c8:	8526                	mv	a0,s1
    800051ca:	f54fe0ef          	jal	ra,8000391e <iunlockput>
    end_op();
    800051ce:	f99fe0ef          	jal	ra,80004166 <end_op>
    return -1;
    800051d2:	57fd                	li	a5,-1
    800051d4:	a02d                	j	800051fe <sys_link+0xe8>
    iunlockput(dp);
    800051d6:	854a                	mv	a0,s2
    800051d8:	f46fe0ef          	jal	ra,8000391e <iunlockput>
  ilock(ip);
    800051dc:	8526                	mv	a0,s1
    800051de:	d3afe0ef          	jal	ra,80003718 <ilock>
  ip->nlink--;
    800051e2:	04a4d783          	lhu	a5,74(s1)
    800051e6:	37fd                	addiw	a5,a5,-1
    800051e8:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800051ec:	8526                	mv	a0,s1
    800051ee:	c78fe0ef          	jal	ra,80003666 <iupdate>
  iunlockput(ip);
    800051f2:	8526                	mv	a0,s1
    800051f4:	f2afe0ef          	jal	ra,8000391e <iunlockput>
  end_op();
    800051f8:	f6ffe0ef          	jal	ra,80004166 <end_op>
  return -1;
    800051fc:	57fd                	li	a5,-1
}
    800051fe:	853e                	mv	a0,a5
    80005200:	70b2                	ld	ra,296(sp)
    80005202:	7412                	ld	s0,288(sp)
    80005204:	64f2                	ld	s1,280(sp)
    80005206:	6952                	ld	s2,272(sp)
    80005208:	6155                	addi	sp,sp,304
    8000520a:	8082                	ret

000000008000520c <sys_unlink>:
{
    8000520c:	7151                	addi	sp,sp,-240
    8000520e:	f586                	sd	ra,232(sp)
    80005210:	f1a2                	sd	s0,224(sp)
    80005212:	eda6                	sd	s1,216(sp)
    80005214:	e9ca                	sd	s2,208(sp)
    80005216:	e5ce                	sd	s3,200(sp)
    80005218:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    8000521a:	08000613          	li	a2,128
    8000521e:	f3040593          	addi	a1,s0,-208
    80005222:	4501                	li	a0,0
    80005224:	a99fd0ef          	jal	ra,80002cbc <argstr>
    80005228:	12054b63          	bltz	a0,8000535e <sys_unlink+0x152>
  begin_op();
    8000522c:	ecbfe0ef          	jal	ra,800040f6 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80005230:	fb040593          	addi	a1,s0,-80
    80005234:	f3040513          	addi	a0,s0,-208
    80005238:	ce9fe0ef          	jal	ra,80003f20 <nameiparent>
    8000523c:	84aa                	mv	s1,a0
    8000523e:	c54d                	beqz	a0,800052e8 <sys_unlink+0xdc>
  ilock(dp);
    80005240:	cd8fe0ef          	jal	ra,80003718 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80005244:	00002597          	auipc	a1,0x2
    80005248:	5f458593          	addi	a1,a1,1524 # 80007838 <syscalls+0x308>
    8000524c:	fb040513          	addi	a0,s0,-80
    80005250:	a3bfe0ef          	jal	ra,80003c8a <namecmp>
    80005254:	10050a63          	beqz	a0,80005368 <sys_unlink+0x15c>
    80005258:	00002597          	auipc	a1,0x2
    8000525c:	5e858593          	addi	a1,a1,1512 # 80007840 <syscalls+0x310>
    80005260:	fb040513          	addi	a0,s0,-80
    80005264:	a27fe0ef          	jal	ra,80003c8a <namecmp>
    80005268:	10050063          	beqz	a0,80005368 <sys_unlink+0x15c>
  if((ip = dirlookup(dp, name, &off)) == 0)
    8000526c:	f2c40613          	addi	a2,s0,-212
    80005270:	fb040593          	addi	a1,s0,-80
    80005274:	8526                	mv	a0,s1
    80005276:	a2bfe0ef          	jal	ra,80003ca0 <dirlookup>
    8000527a:	892a                	mv	s2,a0
    8000527c:	0e050663          	beqz	a0,80005368 <sys_unlink+0x15c>
  ilock(ip);
    80005280:	c98fe0ef          	jal	ra,80003718 <ilock>
  if(ip->nlink < 1)
    80005284:	04a91783          	lh	a5,74(s2)
    80005288:	06f05463          	blez	a5,800052f0 <sys_unlink+0xe4>
  if(ip->type == T_DIR && !isdirempty(ip)){
    8000528c:	04491703          	lh	a4,68(s2)
    80005290:	4785                	li	a5,1
    80005292:	06f70563          	beq	a4,a5,800052fc <sys_unlink+0xf0>
  memset(&de, 0, sizeof(de));
    80005296:	4641                	li	a2,16
    80005298:	4581                	li	a1,0
    8000529a:	fc040513          	addi	a0,s0,-64
    8000529e:	9f1fb0ef          	jal	ra,80000c8e <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800052a2:	4741                	li	a4,16
    800052a4:	f2c42683          	lw	a3,-212(s0)
    800052a8:	fc040613          	addi	a2,s0,-64
    800052ac:	4581                	li	a1,0
    800052ae:	8526                	mv	a0,s1
    800052b0:	8d9fe0ef          	jal	ra,80003b88 <writei>
    800052b4:	47c1                	li	a5,16
    800052b6:	08f51563          	bne	a0,a5,80005340 <sys_unlink+0x134>
  if(ip->type == T_DIR){
    800052ba:	04491703          	lh	a4,68(s2)
    800052be:	4785                	li	a5,1
    800052c0:	08f70663          	beq	a4,a5,8000534c <sys_unlink+0x140>
  iunlockput(dp);
    800052c4:	8526                	mv	a0,s1
    800052c6:	e58fe0ef          	jal	ra,8000391e <iunlockput>
  ip->nlink--;
    800052ca:	04a95783          	lhu	a5,74(s2)
    800052ce:	37fd                	addiw	a5,a5,-1
    800052d0:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    800052d4:	854a                	mv	a0,s2
    800052d6:	b90fe0ef          	jal	ra,80003666 <iupdate>
  iunlockput(ip);
    800052da:	854a                	mv	a0,s2
    800052dc:	e42fe0ef          	jal	ra,8000391e <iunlockput>
  end_op();
    800052e0:	e87fe0ef          	jal	ra,80004166 <end_op>
  return 0;
    800052e4:	4501                	li	a0,0
    800052e6:	a079                	j	80005374 <sys_unlink+0x168>
    end_op();
    800052e8:	e7ffe0ef          	jal	ra,80004166 <end_op>
    return -1;
    800052ec:	557d                	li	a0,-1
    800052ee:	a059                	j	80005374 <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    800052f0:	00002517          	auipc	a0,0x2
    800052f4:	55850513          	addi	a0,a0,1368 # 80007848 <syscalls+0x318>
    800052f8:	c96fb0ef          	jal	ra,8000078e <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    800052fc:	04c92703          	lw	a4,76(s2)
    80005300:	02000793          	li	a5,32
    80005304:	f8e7f9e3          	bgeu	a5,a4,80005296 <sys_unlink+0x8a>
    80005308:	02000993          	li	s3,32
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000530c:	4741                	li	a4,16
    8000530e:	86ce                	mv	a3,s3
    80005310:	f1840613          	addi	a2,s0,-232
    80005314:	4581                	li	a1,0
    80005316:	854a                	mv	a0,s2
    80005318:	f8cfe0ef          	jal	ra,80003aa4 <readi>
    8000531c:	47c1                	li	a5,16
    8000531e:	00f51b63          	bne	a0,a5,80005334 <sys_unlink+0x128>
    if(de.inum != 0)
    80005322:	f1845783          	lhu	a5,-232(s0)
    80005326:	ef95                	bnez	a5,80005362 <sys_unlink+0x156>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80005328:	29c1                	addiw	s3,s3,16
    8000532a:	04c92783          	lw	a5,76(s2)
    8000532e:	fcf9efe3          	bltu	s3,a5,8000530c <sys_unlink+0x100>
    80005332:	b795                	j	80005296 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80005334:	00002517          	auipc	a0,0x2
    80005338:	52c50513          	addi	a0,a0,1324 # 80007860 <syscalls+0x330>
    8000533c:	c52fb0ef          	jal	ra,8000078e <panic>
    panic("unlink: writei");
    80005340:	00002517          	auipc	a0,0x2
    80005344:	53850513          	addi	a0,a0,1336 # 80007878 <syscalls+0x348>
    80005348:	c46fb0ef          	jal	ra,8000078e <panic>
    dp->nlink--;
    8000534c:	04a4d783          	lhu	a5,74(s1)
    80005350:	37fd                	addiw	a5,a5,-1
    80005352:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80005356:	8526                	mv	a0,s1
    80005358:	b0efe0ef          	jal	ra,80003666 <iupdate>
    8000535c:	b7a5                	j	800052c4 <sys_unlink+0xb8>
    return -1;
    8000535e:	557d                	li	a0,-1
    80005360:	a811                	j	80005374 <sys_unlink+0x168>
    iunlockput(ip);
    80005362:	854a                	mv	a0,s2
    80005364:	dbafe0ef          	jal	ra,8000391e <iunlockput>
  iunlockput(dp);
    80005368:	8526                	mv	a0,s1
    8000536a:	db4fe0ef          	jal	ra,8000391e <iunlockput>
  end_op();
    8000536e:	df9fe0ef          	jal	ra,80004166 <end_op>
  return -1;
    80005372:	557d                	li	a0,-1
}
    80005374:	70ae                	ld	ra,232(sp)
    80005376:	740e                	ld	s0,224(sp)
    80005378:	64ee                	ld	s1,216(sp)
    8000537a:	694e                	ld	s2,208(sp)
    8000537c:	69ae                	ld	s3,200(sp)
    8000537e:	616d                	addi	sp,sp,240
    80005380:	8082                	ret

0000000080005382 <sys_open>:

uint64
sys_open(void)
{
    80005382:	7131                	addi	sp,sp,-192
    80005384:	fd06                	sd	ra,184(sp)
    80005386:	f922                	sd	s0,176(sp)
    80005388:	f526                	sd	s1,168(sp)
    8000538a:	f14a                	sd	s2,160(sp)
    8000538c:	ed4e                	sd	s3,152(sp)
    8000538e:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80005390:	f4c40593          	addi	a1,s0,-180
    80005394:	4505                	li	a0,1
    80005396:	8effd0ef          	jal	ra,80002c84 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    8000539a:	08000613          	li	a2,128
    8000539e:	f5040593          	addi	a1,s0,-176
    800053a2:	4501                	li	a0,0
    800053a4:	919fd0ef          	jal	ra,80002cbc <argstr>
    800053a8:	87aa                	mv	a5,a0
    return -1;
    800053aa:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    800053ac:	0807cd63          	bltz	a5,80005446 <sys_open+0xc4>

  begin_op();
    800053b0:	d47fe0ef          	jal	ra,800040f6 <begin_op>

  if(omode & O_CREATE){
    800053b4:	f4c42783          	lw	a5,-180(s0)
    800053b8:	2007f793          	andi	a5,a5,512
    800053bc:	c3c5                	beqz	a5,8000545c <sys_open+0xda>
    ip = create(path, T_FILE, 0, 0);
    800053be:	4681                	li	a3,0
    800053c0:	4601                	li	a2,0
    800053c2:	4589                	li	a1,2
    800053c4:	f5040513          	addi	a0,s0,-176
    800053c8:	ac1ff0ef          	jal	ra,80004e88 <create>
    800053cc:	84aa                	mv	s1,a0
    if(ip == 0){
    800053ce:	c159                	beqz	a0,80005454 <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    800053d0:	04449703          	lh	a4,68(s1)
    800053d4:	478d                	li	a5,3
    800053d6:	00f71763          	bne	a4,a5,800053e4 <sys_open+0x62>
    800053da:	0464d703          	lhu	a4,70(s1)
    800053de:	47a5                	li	a5,9
    800053e0:	0ae7e963          	bltu	a5,a4,80005492 <sys_open+0x110>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    800053e4:	87cff0ef          	jal	ra,80004460 <filealloc>
    800053e8:	89aa                	mv	s3,a0
    800053ea:	0c050963          	beqz	a0,800054bc <sys_open+0x13a>
    800053ee:	a5dff0ef          	jal	ra,80004e4a <fdalloc>
    800053f2:	892a                	mv	s2,a0
    800053f4:	0c054163          	bltz	a0,800054b6 <sys_open+0x134>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    800053f8:	04449703          	lh	a4,68(s1)
    800053fc:	478d                	li	a5,3
    800053fe:	0af70163          	beq	a4,a5,800054a0 <sys_open+0x11e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80005402:	4789                	li	a5,2
    80005404:	00f9a023          	sw	a5,0(s3)
    f->off = 0;
    80005408:	0209a023          	sw	zero,32(s3)
  }
  f->ip = ip;
    8000540c:	0099bc23          	sd	s1,24(s3)
  f->readable = !(omode & O_WRONLY);
    80005410:	f4c42783          	lw	a5,-180(s0)
    80005414:	0017c713          	xori	a4,a5,1
    80005418:	8b05                	andi	a4,a4,1
    8000541a:	00e98423          	sb	a4,8(s3)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    8000541e:	0037f713          	andi	a4,a5,3
    80005422:	00e03733          	snez	a4,a4
    80005426:	00e984a3          	sb	a4,9(s3)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    8000542a:	4007f793          	andi	a5,a5,1024
    8000542e:	c791                	beqz	a5,8000543a <sys_open+0xb8>
    80005430:	04449703          	lh	a4,68(s1)
    80005434:	4789                	li	a5,2
    80005436:	06f70c63          	beq	a4,a5,800054ae <sys_open+0x12c>
    itrunc(ip);
  }

  iunlock(ip);
    8000543a:	8526                	mv	a0,s1
    8000543c:	b86fe0ef          	jal	ra,800037c2 <iunlock>
  end_op();
    80005440:	d27fe0ef          	jal	ra,80004166 <end_op>

  return fd;
    80005444:	854a                	mv	a0,s2
}
    80005446:	70ea                	ld	ra,184(sp)
    80005448:	744a                	ld	s0,176(sp)
    8000544a:	74aa                	ld	s1,168(sp)
    8000544c:	790a                	ld	s2,160(sp)
    8000544e:	69ea                	ld	s3,152(sp)
    80005450:	6129                	addi	sp,sp,192
    80005452:	8082                	ret
      end_op();
    80005454:	d13fe0ef          	jal	ra,80004166 <end_op>
      return -1;
    80005458:	557d                	li	a0,-1
    8000545a:	b7f5                	j	80005446 <sys_open+0xc4>
    if((ip = namei(path)) == 0){
    8000545c:	f5040513          	addi	a0,s0,-176
    80005460:	aa7fe0ef          	jal	ra,80003f06 <namei>
    80005464:	84aa                	mv	s1,a0
    80005466:	c115                	beqz	a0,8000548a <sys_open+0x108>
    ilock(ip);
    80005468:	ab0fe0ef          	jal	ra,80003718 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    8000546c:	04449703          	lh	a4,68(s1)
    80005470:	4785                	li	a5,1
    80005472:	f4f71fe3          	bne	a4,a5,800053d0 <sys_open+0x4e>
    80005476:	f4c42783          	lw	a5,-180(s0)
    8000547a:	d7ad                	beqz	a5,800053e4 <sys_open+0x62>
      iunlockput(ip);
    8000547c:	8526                	mv	a0,s1
    8000547e:	ca0fe0ef          	jal	ra,8000391e <iunlockput>
      end_op();
    80005482:	ce5fe0ef          	jal	ra,80004166 <end_op>
      return -1;
    80005486:	557d                	li	a0,-1
    80005488:	bf7d                	j	80005446 <sys_open+0xc4>
      end_op();
    8000548a:	cddfe0ef          	jal	ra,80004166 <end_op>
      return -1;
    8000548e:	557d                	li	a0,-1
    80005490:	bf5d                	j	80005446 <sys_open+0xc4>
    iunlockput(ip);
    80005492:	8526                	mv	a0,s1
    80005494:	c8afe0ef          	jal	ra,8000391e <iunlockput>
    end_op();
    80005498:	ccffe0ef          	jal	ra,80004166 <end_op>
    return -1;
    8000549c:	557d                	li	a0,-1
    8000549e:	b765                	j	80005446 <sys_open+0xc4>
    f->type = FD_DEVICE;
    800054a0:	00f9a023          	sw	a5,0(s3)
    f->major = ip->major;
    800054a4:	04649783          	lh	a5,70(s1)
    800054a8:	02f99223          	sh	a5,36(s3)
    800054ac:	b785                	j	8000540c <sys_open+0x8a>
    itrunc(ip);
    800054ae:	8526                	mv	a0,s1
    800054b0:	b52fe0ef          	jal	ra,80003802 <itrunc>
    800054b4:	b759                	j	8000543a <sys_open+0xb8>
      fileclose(f);
    800054b6:	854e                	mv	a0,s3
    800054b8:	84cff0ef          	jal	ra,80004504 <fileclose>
    iunlockput(ip);
    800054bc:	8526                	mv	a0,s1
    800054be:	c60fe0ef          	jal	ra,8000391e <iunlockput>
    end_op();
    800054c2:	ca5fe0ef          	jal	ra,80004166 <end_op>
    return -1;
    800054c6:	557d                	li	a0,-1
    800054c8:	bfbd                	j	80005446 <sys_open+0xc4>

00000000800054ca <sys_mkdir>:

uint64
sys_mkdir(void)
{
    800054ca:	7175                	addi	sp,sp,-144
    800054cc:	e506                	sd	ra,136(sp)
    800054ce:	e122                	sd	s0,128(sp)
    800054d0:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    800054d2:	c25fe0ef          	jal	ra,800040f6 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    800054d6:	08000613          	li	a2,128
    800054da:	f7040593          	addi	a1,s0,-144
    800054de:	4501                	li	a0,0
    800054e0:	fdcfd0ef          	jal	ra,80002cbc <argstr>
    800054e4:	02054363          	bltz	a0,8000550a <sys_mkdir+0x40>
    800054e8:	4681                	li	a3,0
    800054ea:	4601                	li	a2,0
    800054ec:	4585                	li	a1,1
    800054ee:	f7040513          	addi	a0,s0,-144
    800054f2:	997ff0ef          	jal	ra,80004e88 <create>
    800054f6:	c911                	beqz	a0,8000550a <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800054f8:	c26fe0ef          	jal	ra,8000391e <iunlockput>
  end_op();
    800054fc:	c6bfe0ef          	jal	ra,80004166 <end_op>
  return 0;
    80005500:	4501                	li	a0,0
}
    80005502:	60aa                	ld	ra,136(sp)
    80005504:	640a                	ld	s0,128(sp)
    80005506:	6149                	addi	sp,sp,144
    80005508:	8082                	ret
    end_op();
    8000550a:	c5dfe0ef          	jal	ra,80004166 <end_op>
    return -1;
    8000550e:	557d                	li	a0,-1
    80005510:	bfcd                	j	80005502 <sys_mkdir+0x38>

0000000080005512 <sys_mknod>:

uint64
sys_mknod(void)
{
    80005512:	7135                	addi	sp,sp,-160
    80005514:	ed06                	sd	ra,152(sp)
    80005516:	e922                	sd	s0,144(sp)
    80005518:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    8000551a:	bddfe0ef          	jal	ra,800040f6 <begin_op>
  argint(1, &major);
    8000551e:	f6c40593          	addi	a1,s0,-148
    80005522:	4505                	li	a0,1
    80005524:	f60fd0ef          	jal	ra,80002c84 <argint>
  argint(2, &minor);
    80005528:	f6840593          	addi	a1,s0,-152
    8000552c:	4509                	li	a0,2
    8000552e:	f56fd0ef          	jal	ra,80002c84 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005532:	08000613          	li	a2,128
    80005536:	f7040593          	addi	a1,s0,-144
    8000553a:	4501                	li	a0,0
    8000553c:	f80fd0ef          	jal	ra,80002cbc <argstr>
    80005540:	02054563          	bltz	a0,8000556a <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80005544:	f6841683          	lh	a3,-152(s0)
    80005548:	f6c41603          	lh	a2,-148(s0)
    8000554c:	458d                	li	a1,3
    8000554e:	f7040513          	addi	a0,s0,-144
    80005552:	937ff0ef          	jal	ra,80004e88 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005556:	c911                	beqz	a0,8000556a <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005558:	bc6fe0ef          	jal	ra,8000391e <iunlockput>
  end_op();
    8000555c:	c0bfe0ef          	jal	ra,80004166 <end_op>
  return 0;
    80005560:	4501                	li	a0,0
}
    80005562:	60ea                	ld	ra,152(sp)
    80005564:	644a                	ld	s0,144(sp)
    80005566:	610d                	addi	sp,sp,160
    80005568:	8082                	ret
    end_op();
    8000556a:	bfdfe0ef          	jal	ra,80004166 <end_op>
    return -1;
    8000556e:	557d                	li	a0,-1
    80005570:	bfcd                	j	80005562 <sys_mknod+0x50>

0000000080005572 <sys_chdir>:

uint64
sys_chdir(void)
{
    80005572:	7135                	addi	sp,sp,-160
    80005574:	ed06                	sd	ra,152(sp)
    80005576:	e922                	sd	s0,144(sp)
    80005578:	e526                	sd	s1,136(sp)
    8000557a:	e14a                	sd	s2,128(sp)
    8000557c:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    8000557e:	adcfc0ef          	jal	ra,8000185a <myproc>
    80005582:	892a                	mv	s2,a0
  
  begin_op();
    80005584:	b73fe0ef          	jal	ra,800040f6 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    80005588:	08000613          	li	a2,128
    8000558c:	f6040593          	addi	a1,s0,-160
    80005590:	4501                	li	a0,0
    80005592:	f2afd0ef          	jal	ra,80002cbc <argstr>
    80005596:	04054163          	bltz	a0,800055d8 <sys_chdir+0x66>
    8000559a:	f6040513          	addi	a0,s0,-160
    8000559e:	969fe0ef          	jal	ra,80003f06 <namei>
    800055a2:	84aa                	mv	s1,a0
    800055a4:	c915                	beqz	a0,800055d8 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    800055a6:	972fe0ef          	jal	ra,80003718 <ilock>
  if(ip->type != T_DIR){
    800055aa:	04449703          	lh	a4,68(s1)
    800055ae:	4785                	li	a5,1
    800055b0:	02f71863          	bne	a4,a5,800055e0 <sys_chdir+0x6e>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800055b4:	8526                	mv	a0,s1
    800055b6:	a0cfe0ef          	jal	ra,800037c2 <iunlock>
  iput(p->cwd);
    800055ba:	15093503          	ld	a0,336(s2)
    800055be:	ad8fe0ef          	jal	ra,80003896 <iput>
  end_op();
    800055c2:	ba5fe0ef          	jal	ra,80004166 <end_op>
  p->cwd = ip;
    800055c6:	14993823          	sd	s1,336(s2)
  return 0;
    800055ca:	4501                	li	a0,0
}
    800055cc:	60ea                	ld	ra,152(sp)
    800055ce:	644a                	ld	s0,144(sp)
    800055d0:	64aa                	ld	s1,136(sp)
    800055d2:	690a                	ld	s2,128(sp)
    800055d4:	610d                	addi	sp,sp,160
    800055d6:	8082                	ret
    end_op();
    800055d8:	b8ffe0ef          	jal	ra,80004166 <end_op>
    return -1;
    800055dc:	557d                	li	a0,-1
    800055de:	b7fd                	j	800055cc <sys_chdir+0x5a>
    iunlockput(ip);
    800055e0:	8526                	mv	a0,s1
    800055e2:	b3cfe0ef          	jal	ra,8000391e <iunlockput>
    end_op();
    800055e6:	b81fe0ef          	jal	ra,80004166 <end_op>
    return -1;
    800055ea:	557d                	li	a0,-1
    800055ec:	b7c5                	j	800055cc <sys_chdir+0x5a>

00000000800055ee <sys_exec>:

uint64
sys_exec(void)
{
    800055ee:	7145                	addi	sp,sp,-464
    800055f0:	e786                	sd	ra,456(sp)
    800055f2:	e3a2                	sd	s0,448(sp)
    800055f4:	ff26                	sd	s1,440(sp)
    800055f6:	fb4a                	sd	s2,432(sp)
    800055f8:	f74e                	sd	s3,424(sp)
    800055fa:	f352                	sd	s4,416(sp)
    800055fc:	ef56                	sd	s5,408(sp)
    800055fe:	0b80                	addi	s0,sp,464
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80005600:	e3840593          	addi	a1,s0,-456
    80005604:	4505                	li	a0,1
    80005606:	e9afd0ef          	jal	ra,80002ca0 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    8000560a:	08000613          	li	a2,128
    8000560e:	f4040593          	addi	a1,s0,-192
    80005612:	4501                	li	a0,0
    80005614:	ea8fd0ef          	jal	ra,80002cbc <argstr>
    80005618:	87aa                	mv	a5,a0
    return -1;
    8000561a:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    8000561c:	0a07c463          	bltz	a5,800056c4 <sys_exec+0xd6>
  }
  memset(argv, 0, sizeof(argv));
    80005620:	10000613          	li	a2,256
    80005624:	4581                	li	a1,0
    80005626:	e4040513          	addi	a0,s0,-448
    8000562a:	e64fb0ef          	jal	ra,80000c8e <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    8000562e:	e4040493          	addi	s1,s0,-448
  memset(argv, 0, sizeof(argv));
    80005632:	89a6                	mv	s3,s1
    80005634:	4901                	li	s2,0
    if(i >= NELEM(argv)){
    80005636:	02000a13          	li	s4,32
    8000563a:	00090a9b          	sext.w	s5,s2
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    8000563e:	00391513          	slli	a0,s2,0x3
    80005642:	e3040593          	addi	a1,s0,-464
    80005646:	e3843783          	ld	a5,-456(s0)
    8000564a:	953e                	add	a0,a0,a5
    8000564c:	daefd0ef          	jal	ra,80002bfa <fetchaddr>
    80005650:	02054663          	bltz	a0,8000567c <sys_exec+0x8e>
      goto bad;
    }
    if(uarg == 0){
    80005654:	e3043783          	ld	a5,-464(s0)
    80005658:	cf8d                	beqz	a5,80005692 <sys_exec+0xa4>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    8000565a:	c4efb0ef          	jal	ra,80000aa8 <kalloc>
    8000565e:	85aa                	mv	a1,a0
    80005660:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    80005664:	cd01                	beqz	a0,8000567c <sys_exec+0x8e>
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005666:	6605                	lui	a2,0x1
    80005668:	e3043503          	ld	a0,-464(s0)
    8000566c:	dd8fd0ef          	jal	ra,80002c44 <fetchstr>
    80005670:	00054663          	bltz	a0,8000567c <sys_exec+0x8e>
    if(i >= NELEM(argv)){
    80005674:	0905                	addi	s2,s2,1
    80005676:	09a1                	addi	s3,s3,8
    80005678:	fd4911e3          	bne	s2,s4,8000563a <sys_exec+0x4c>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000567c:	10048913          	addi	s2,s1,256
    80005680:	6088                	ld	a0,0(s1)
    80005682:	c121                	beqz	a0,800056c2 <sys_exec+0xd4>
    kfree(argv[i]);
    80005684:	b44fb0ef          	jal	ra,800009c8 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005688:	04a1                	addi	s1,s1,8
    8000568a:	ff249be3          	bne	s1,s2,80005680 <sys_exec+0x92>
  return -1;
    8000568e:	557d                	li	a0,-1
    80005690:	a815                	j	800056c4 <sys_exec+0xd6>
      argv[i] = 0;
    80005692:	0a8e                	slli	s5,s5,0x3
    80005694:	fc040793          	addi	a5,s0,-64
    80005698:	9abe                	add	s5,s5,a5
    8000569a:	e80ab023          	sd	zero,-384(s5)
  int ret = kexec(path, argv);
    8000569e:	e4040593          	addi	a1,s0,-448
    800056a2:	f4040513          	addi	a0,s0,-192
    800056a6:	c18ff0ef          	jal	ra,80004abe <kexec>
    800056aa:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800056ac:	10048993          	addi	s3,s1,256
    800056b0:	6088                	ld	a0,0(s1)
    800056b2:	c511                	beqz	a0,800056be <sys_exec+0xd0>
    kfree(argv[i]);
    800056b4:	b14fb0ef          	jal	ra,800009c8 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800056b8:	04a1                	addi	s1,s1,8
    800056ba:	ff349be3          	bne	s1,s3,800056b0 <sys_exec+0xc2>
  return ret;
    800056be:	854a                	mv	a0,s2
    800056c0:	a011                	j	800056c4 <sys_exec+0xd6>
  return -1;
    800056c2:	557d                	li	a0,-1
}
    800056c4:	60be                	ld	ra,456(sp)
    800056c6:	641e                	ld	s0,448(sp)
    800056c8:	74fa                	ld	s1,440(sp)
    800056ca:	795a                	ld	s2,432(sp)
    800056cc:	79ba                	ld	s3,424(sp)
    800056ce:	7a1a                	ld	s4,416(sp)
    800056d0:	6afa                	ld	s5,408(sp)
    800056d2:	6179                	addi	sp,sp,464
    800056d4:	8082                	ret

00000000800056d6 <sys_pipe>:

uint64
sys_pipe(void)
{
    800056d6:	7139                	addi	sp,sp,-64
    800056d8:	fc06                	sd	ra,56(sp)
    800056da:	f822                	sd	s0,48(sp)
    800056dc:	f426                	sd	s1,40(sp)
    800056de:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    800056e0:	97afc0ef          	jal	ra,8000185a <myproc>
    800056e4:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    800056e6:	fd840593          	addi	a1,s0,-40
    800056ea:	4501                	li	a0,0
    800056ec:	db4fd0ef          	jal	ra,80002ca0 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    800056f0:	fc840593          	addi	a1,s0,-56
    800056f4:	fd040513          	addi	a0,s0,-48
    800056f8:	8d8ff0ef          	jal	ra,800047d0 <pipealloc>
    return -1;
    800056fc:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    800056fe:	0a054463          	bltz	a0,800057a6 <sys_pipe+0xd0>
  fd0 = -1;
    80005702:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80005706:	fd043503          	ld	a0,-48(s0)
    8000570a:	f40ff0ef          	jal	ra,80004e4a <fdalloc>
    8000570e:	fca42223          	sw	a0,-60(s0)
    80005712:	08054163          	bltz	a0,80005794 <sys_pipe+0xbe>
    80005716:	fc843503          	ld	a0,-56(s0)
    8000571a:	f30ff0ef          	jal	ra,80004e4a <fdalloc>
    8000571e:	fca42023          	sw	a0,-64(s0)
    80005722:	06054063          	bltz	a0,80005782 <sys_pipe+0xac>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005726:	4691                	li	a3,4
    80005728:	fc440613          	addi	a2,s0,-60
    8000572c:	fd843583          	ld	a1,-40(s0)
    80005730:	68a8                	ld	a0,80(s1)
    80005732:	e77fb0ef          	jal	ra,800015a8 <copyout>
    80005736:	00054e63          	bltz	a0,80005752 <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    8000573a:	4691                	li	a3,4
    8000573c:	fc040613          	addi	a2,s0,-64
    80005740:	fd843583          	ld	a1,-40(s0)
    80005744:	0591                	addi	a1,a1,4
    80005746:	68a8                	ld	a0,80(s1)
    80005748:	e61fb0ef          	jal	ra,800015a8 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    8000574c:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    8000574e:	04055c63          	bgez	a0,800057a6 <sys_pipe+0xd0>
    p->ofile[fd0] = 0;
    80005752:	fc442783          	lw	a5,-60(s0)
    80005756:	07e9                	addi	a5,a5,26
    80005758:	078e                	slli	a5,a5,0x3
    8000575a:	97a6                	add	a5,a5,s1
    8000575c:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80005760:	fc042503          	lw	a0,-64(s0)
    80005764:	0569                	addi	a0,a0,26
    80005766:	050e                	slli	a0,a0,0x3
    80005768:	94aa                	add	s1,s1,a0
    8000576a:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    8000576e:	fd043503          	ld	a0,-48(s0)
    80005772:	d93fe0ef          	jal	ra,80004504 <fileclose>
    fileclose(wf);
    80005776:	fc843503          	ld	a0,-56(s0)
    8000577a:	d8bfe0ef          	jal	ra,80004504 <fileclose>
    return -1;
    8000577e:	57fd                	li	a5,-1
    80005780:	a01d                	j	800057a6 <sys_pipe+0xd0>
    if(fd0 >= 0)
    80005782:	fc442783          	lw	a5,-60(s0)
    80005786:	0007c763          	bltz	a5,80005794 <sys_pipe+0xbe>
      p->ofile[fd0] = 0;
    8000578a:	07e9                	addi	a5,a5,26
    8000578c:	078e                	slli	a5,a5,0x3
    8000578e:	94be                	add	s1,s1,a5
    80005790:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    80005794:	fd043503          	ld	a0,-48(s0)
    80005798:	d6dfe0ef          	jal	ra,80004504 <fileclose>
    fileclose(wf);
    8000579c:	fc843503          	ld	a0,-56(s0)
    800057a0:	d65fe0ef          	jal	ra,80004504 <fileclose>
    return -1;
    800057a4:	57fd                	li	a5,-1
}
    800057a6:	853e                	mv	a0,a5
    800057a8:	70e2                	ld	ra,56(sp)
    800057aa:	7442                	ld	s0,48(sp)
    800057ac:	74a2                	ld	s1,40(sp)
    800057ae:	6121                	addi	sp,sp,64
    800057b0:	8082                	ret
	...

00000000800057c0 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    800057c0:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    800057c2:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    800057c4:	e80e                	sd	gp,16(sp)
        sd tp, 24(sp)
    800057c6:	ec12                	sd	tp,24(sp)
        sd t0, 32(sp)
    800057c8:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    800057ca:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    800057cc:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    800057ce:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    800057d0:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    800057d2:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    800057d4:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    800057d6:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    800057d8:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    800057da:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    800057dc:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    800057de:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    800057e0:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    800057e2:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    800057e4:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    800057e6:	b24fd0ef          	jal	ra,80002b0a <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    800057ea:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    800057ec:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    800057ee:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    800057f0:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    800057f2:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    800057f4:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    800057f6:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    800057f8:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    800057fa:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    800057fc:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    800057fe:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    80005800:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    80005802:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    80005804:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    80005806:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    80005808:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    8000580a:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    8000580c:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    8000580e:	10200073          	sret
	...

000000008000581e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000581e:	1141                	addi	sp,sp,-16
    80005820:	e422                	sd	s0,8(sp)
    80005822:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80005824:	0c0007b7          	lui	a5,0xc000
    80005828:	4705                	li	a4,1
    8000582a:	d798                	sw	a4,40(a5)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000582c:	c3d8                	sw	a4,4(a5)
}
    8000582e:	6422                	ld	s0,8(sp)
    80005830:	0141                	addi	sp,sp,16
    80005832:	8082                	ret

0000000080005834 <plicinithart>:

void
plicinithart(void)
{
    80005834:	1141                	addi	sp,sp,-16
    80005836:	e406                	sd	ra,8(sp)
    80005838:	e022                	sd	s0,0(sp)
    8000583a:	0800                	addi	s0,sp,16
  int hart = cpuid();
    8000583c:	ff3fb0ef          	jal	ra,8000182e <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005840:	0085171b          	slliw	a4,a0,0x8
    80005844:	0c0027b7          	lui	a5,0xc002
    80005848:	97ba                	add	a5,a5,a4
    8000584a:	40200713          	li	a4,1026
    8000584e:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80005852:	00d5151b          	slliw	a0,a0,0xd
    80005856:	0c2017b7          	lui	a5,0xc201
    8000585a:	953e                	add	a0,a0,a5
    8000585c:	00052023          	sw	zero,0(a0)
}
    80005860:	60a2                	ld	ra,8(sp)
    80005862:	6402                	ld	s0,0(sp)
    80005864:	0141                	addi	sp,sp,16
    80005866:	8082                	ret

0000000080005868 <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    80005868:	1141                	addi	sp,sp,-16
    8000586a:	e406                	sd	ra,8(sp)
    8000586c:	e022                	sd	s0,0(sp)
    8000586e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005870:	fbffb0ef          	jal	ra,8000182e <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80005874:	00d5179b          	slliw	a5,a0,0xd
    80005878:	0c201537          	lui	a0,0xc201
    8000587c:	953e                	add	a0,a0,a5
  return irq;
}
    8000587e:	4148                	lw	a0,4(a0)
    80005880:	60a2                	ld	ra,8(sp)
    80005882:	6402                	ld	s0,0(sp)
    80005884:	0141                	addi	sp,sp,16
    80005886:	8082                	ret

0000000080005888 <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005888:	1101                	addi	sp,sp,-32
    8000588a:	ec06                	sd	ra,24(sp)
    8000588c:	e822                	sd	s0,16(sp)
    8000588e:	e426                	sd	s1,8(sp)
    80005890:	1000                	addi	s0,sp,32
    80005892:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005894:	f9bfb0ef          	jal	ra,8000182e <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    80005898:	00d5151b          	slliw	a0,a0,0xd
    8000589c:	0c2017b7          	lui	a5,0xc201
    800058a0:	97aa                	add	a5,a5,a0
    800058a2:	c3c4                	sw	s1,4(a5)
}
    800058a4:	60e2                	ld	ra,24(sp)
    800058a6:	6442                	ld	s0,16(sp)
    800058a8:	64a2                	ld	s1,8(sp)
    800058aa:	6105                	addi	sp,sp,32
    800058ac:	8082                	ret

00000000800058ae <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    800058ae:	1141                	addi	sp,sp,-16
    800058b0:	e406                	sd	ra,8(sp)
    800058b2:	e022                	sd	s0,0(sp)
    800058b4:	0800                	addi	s0,sp,16
  if(i >= NUM)
    800058b6:	479d                	li	a5,7
    800058b8:	04a7ca63          	blt	a5,a0,8000590c <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    800058bc:	0001c797          	auipc	a5,0x1c
    800058c0:	cdc78793          	addi	a5,a5,-804 # 80021598 <disk>
    800058c4:	97aa                	add	a5,a5,a0
    800058c6:	0187c783          	lbu	a5,24(a5)
    800058ca:	e7b9                	bnez	a5,80005918 <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    800058cc:	00451613          	slli	a2,a0,0x4
    800058d0:	0001c797          	auipc	a5,0x1c
    800058d4:	cc878793          	addi	a5,a5,-824 # 80021598 <disk>
    800058d8:	6394                	ld	a3,0(a5)
    800058da:	96b2                	add	a3,a3,a2
    800058dc:	0006b023          	sd	zero,0(a3)
  disk.desc[i].len = 0;
    800058e0:	6398                	ld	a4,0(a5)
    800058e2:	9732                	add	a4,a4,a2
    800058e4:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    800058e8:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    800058ec:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    800058f0:	953e                	add	a0,a0,a5
    800058f2:	4785                	li	a5,1
    800058f4:	00f50c23          	sb	a5,24(a0) # c201018 <_entry-0x73dfefe8>
  wakeup(&disk.free[0]);
    800058f8:	0001c517          	auipc	a0,0x1c
    800058fc:	cb850513          	addi	a0,a0,-840 # 800215b0 <disk+0x18>
    80005900:	f42fc0ef          	jal	ra,80002042 <wakeup>
}
    80005904:	60a2                	ld	ra,8(sp)
    80005906:	6402                	ld	s0,0(sp)
    80005908:	0141                	addi	sp,sp,16
    8000590a:	8082                	ret
    panic("free_desc 1");
    8000590c:	00002517          	auipc	a0,0x2
    80005910:	f7c50513          	addi	a0,a0,-132 # 80007888 <syscalls+0x358>
    80005914:	e7bfa0ef          	jal	ra,8000078e <panic>
    panic("free_desc 2");
    80005918:	00002517          	auipc	a0,0x2
    8000591c:	f8050513          	addi	a0,a0,-128 # 80007898 <syscalls+0x368>
    80005920:	e6ffa0ef          	jal	ra,8000078e <panic>

0000000080005924 <virtio_disk_init>:
{
    80005924:	1101                	addi	sp,sp,-32
    80005926:	ec06                	sd	ra,24(sp)
    80005928:	e822                	sd	s0,16(sp)
    8000592a:	e426                	sd	s1,8(sp)
    8000592c:	e04a                	sd	s2,0(sp)
    8000592e:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005930:	00002597          	auipc	a1,0x2
    80005934:	f7858593          	addi	a1,a1,-136 # 800078a8 <syscalls+0x378>
    80005938:	0001c517          	auipc	a0,0x1c
    8000593c:	d8850513          	addi	a0,a0,-632 # 800216c0 <disk+0x128>
    80005940:	9fafb0ef          	jal	ra,80000b3a <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005944:	100017b7          	lui	a5,0x10001
    80005948:	4398                	lw	a4,0(a5)
    8000594a:	2701                	sext.w	a4,a4
    8000594c:	747277b7          	lui	a5,0x74727
    80005950:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005954:	14f71263          	bne	a4,a5,80005a98 <virtio_disk_init+0x174>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005958:	100017b7          	lui	a5,0x10001
    8000595c:	43dc                	lw	a5,4(a5)
    8000595e:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005960:	4709                	li	a4,2
    80005962:	12e79b63          	bne	a5,a4,80005a98 <virtio_disk_init+0x174>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005966:	100017b7          	lui	a5,0x10001
    8000596a:	479c                	lw	a5,8(a5)
    8000596c:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    8000596e:	12e79563          	bne	a5,a4,80005a98 <virtio_disk_init+0x174>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80005972:	100017b7          	lui	a5,0x10001
    80005976:	47d8                	lw	a4,12(a5)
    80005978:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    8000597a:	554d47b7          	lui	a5,0x554d4
    8000597e:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005982:	10f71b63          	bne	a4,a5,80005a98 <virtio_disk_init+0x174>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005986:	100017b7          	lui	a5,0x10001
    8000598a:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000598e:	4705                	li	a4,1
    80005990:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005992:	470d                	li	a4,3
    80005994:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80005996:	4b94                	lw	a3,16(a5)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005998:	c7ffe737          	lui	a4,0xc7ffe
    8000599c:	75f70713          	addi	a4,a4,1887 # ffffffffc7ffe75f <end+0xffffffff47fdd087>
    800059a0:	8f75                	and	a4,a4,a3
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    800059a2:	2701                	sext.w	a4,a4
    800059a4:	d398                	sw	a4,32(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800059a6:	472d                	li	a4,11
    800059a8:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    800059aa:	0707a903          	lw	s2,112(a5)
    800059ae:	2901                	sext.w	s2,s2
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    800059b0:	00897793          	andi	a5,s2,8
    800059b4:	0e078863          	beqz	a5,80005aa4 <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    800059b8:	100017b7          	lui	a5,0x10001
    800059bc:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    800059c0:	43fc                	lw	a5,68(a5)
    800059c2:	2781                	sext.w	a5,a5
    800059c4:	0e079663          	bnez	a5,80005ab0 <virtio_disk_init+0x18c>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    800059c8:	100017b7          	lui	a5,0x10001
    800059cc:	5bdc                	lw	a5,52(a5)
    800059ce:	2781                	sext.w	a5,a5
  if(max == 0)
    800059d0:	0e078663          	beqz	a5,80005abc <virtio_disk_init+0x198>
  if(max < NUM)
    800059d4:	471d                	li	a4,7
    800059d6:	0ef77963          	bgeu	a4,a5,80005ac8 <virtio_disk_init+0x1a4>
  disk.desc = kalloc();
    800059da:	8cefb0ef          	jal	ra,80000aa8 <kalloc>
    800059de:	0001c497          	auipc	s1,0x1c
    800059e2:	bba48493          	addi	s1,s1,-1094 # 80021598 <disk>
    800059e6:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    800059e8:	8c0fb0ef          	jal	ra,80000aa8 <kalloc>
    800059ec:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    800059ee:	8bafb0ef          	jal	ra,80000aa8 <kalloc>
    800059f2:	87aa                	mv	a5,a0
    800059f4:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    800059f6:	6088                	ld	a0,0(s1)
    800059f8:	cd71                	beqz	a0,80005ad4 <virtio_disk_init+0x1b0>
    800059fa:	0001c717          	auipc	a4,0x1c
    800059fe:	ba673703          	ld	a4,-1114(a4) # 800215a0 <disk+0x8>
    80005a02:	cb69                	beqz	a4,80005ad4 <virtio_disk_init+0x1b0>
    80005a04:	cbe1                	beqz	a5,80005ad4 <virtio_disk_init+0x1b0>
  memset(disk.desc, 0, PGSIZE);
    80005a06:	6605                	lui	a2,0x1
    80005a08:	4581                	li	a1,0
    80005a0a:	a84fb0ef          	jal	ra,80000c8e <memset>
  memset(disk.avail, 0, PGSIZE);
    80005a0e:	0001c497          	auipc	s1,0x1c
    80005a12:	b8a48493          	addi	s1,s1,-1142 # 80021598 <disk>
    80005a16:	6605                	lui	a2,0x1
    80005a18:	4581                	li	a1,0
    80005a1a:	6488                	ld	a0,8(s1)
    80005a1c:	a72fb0ef          	jal	ra,80000c8e <memset>
  memset(disk.used, 0, PGSIZE);
    80005a20:	6605                	lui	a2,0x1
    80005a22:	4581                	li	a1,0
    80005a24:	6888                	ld	a0,16(s1)
    80005a26:	a68fb0ef          	jal	ra,80000c8e <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80005a2a:	100017b7          	lui	a5,0x10001
    80005a2e:	4721                	li	a4,8
    80005a30:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80005a32:	4098                	lw	a4,0(s1)
    80005a34:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005a38:	40d8                	lw	a4,4(s1)
    80005a3a:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005a3e:	6498                	ld	a4,8(s1)
    80005a40:	0007069b          	sext.w	a3,a4
    80005a44:	08d7a823          	sw	a3,144(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005a48:	9701                	srai	a4,a4,0x20
    80005a4a:	08e7aa23          	sw	a4,148(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005a4e:	6898                	ld	a4,16(s1)
    80005a50:	0007069b          	sext.w	a3,a4
    80005a54:	0ad7a023          	sw	a3,160(a5)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80005a58:	9701                	srai	a4,a4,0x20
    80005a5a:	0ae7a223          	sw	a4,164(a5)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005a5e:	4685                	li	a3,1
    80005a60:	c3f4                	sw	a3,68(a5)
    disk.free[i] = 1;
    80005a62:	4705                	li	a4,1
    80005a64:	00d48c23          	sb	a3,24(s1)
    80005a68:	00e48ca3          	sb	a4,25(s1)
    80005a6c:	00e48d23          	sb	a4,26(s1)
    80005a70:	00e48da3          	sb	a4,27(s1)
    80005a74:	00e48e23          	sb	a4,28(s1)
    80005a78:	00e48ea3          	sb	a4,29(s1)
    80005a7c:	00e48f23          	sb	a4,30(s1)
    80005a80:	00e48fa3          	sb	a4,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005a84:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005a88:	0727a823          	sw	s2,112(a5)
}
    80005a8c:	60e2                	ld	ra,24(sp)
    80005a8e:	6442                	ld	s0,16(sp)
    80005a90:	64a2                	ld	s1,8(sp)
    80005a92:	6902                	ld	s2,0(sp)
    80005a94:	6105                	addi	sp,sp,32
    80005a96:	8082                	ret
    panic("could not find virtio disk");
    80005a98:	00002517          	auipc	a0,0x2
    80005a9c:	e2050513          	addi	a0,a0,-480 # 800078b8 <syscalls+0x388>
    80005aa0:	ceffa0ef          	jal	ra,8000078e <panic>
    panic("virtio disk FEATURES_OK unset");
    80005aa4:	00002517          	auipc	a0,0x2
    80005aa8:	e3450513          	addi	a0,a0,-460 # 800078d8 <syscalls+0x3a8>
    80005aac:	ce3fa0ef          	jal	ra,8000078e <panic>
    panic("virtio disk should not be ready");
    80005ab0:	00002517          	auipc	a0,0x2
    80005ab4:	e4850513          	addi	a0,a0,-440 # 800078f8 <syscalls+0x3c8>
    80005ab8:	cd7fa0ef          	jal	ra,8000078e <panic>
    panic("virtio disk has no queue 0");
    80005abc:	00002517          	auipc	a0,0x2
    80005ac0:	e5c50513          	addi	a0,a0,-420 # 80007918 <syscalls+0x3e8>
    80005ac4:	ccbfa0ef          	jal	ra,8000078e <panic>
    panic("virtio disk max queue too short");
    80005ac8:	00002517          	auipc	a0,0x2
    80005acc:	e7050513          	addi	a0,a0,-400 # 80007938 <syscalls+0x408>
    80005ad0:	cbffa0ef          	jal	ra,8000078e <panic>
    panic("virtio disk kalloc");
    80005ad4:	00002517          	auipc	a0,0x2
    80005ad8:	e8450513          	addi	a0,a0,-380 # 80007958 <syscalls+0x428>
    80005adc:	cb3fa0ef          	jal	ra,8000078e <panic>

0000000080005ae0 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80005ae0:	7159                	addi	sp,sp,-112
    80005ae2:	f486                	sd	ra,104(sp)
    80005ae4:	f0a2                	sd	s0,96(sp)
    80005ae6:	eca6                	sd	s1,88(sp)
    80005ae8:	e8ca                	sd	s2,80(sp)
    80005aea:	e4ce                	sd	s3,72(sp)
    80005aec:	e0d2                	sd	s4,64(sp)
    80005aee:	fc56                	sd	s5,56(sp)
    80005af0:	f85a                	sd	s6,48(sp)
    80005af2:	f45e                	sd	s7,40(sp)
    80005af4:	f062                	sd	s8,32(sp)
    80005af6:	ec66                	sd	s9,24(sp)
    80005af8:	e86a                	sd	s10,16(sp)
    80005afa:	1880                	addi	s0,sp,112
    80005afc:	892a                	mv	s2,a0
    80005afe:	8d2e                	mv	s10,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80005b00:	00c52c83          	lw	s9,12(a0)
    80005b04:	001c9c9b          	slliw	s9,s9,0x1
    80005b08:	1c82                	slli	s9,s9,0x20
    80005b0a:	020cdc93          	srli	s9,s9,0x20

  acquire(&disk.vdisk_lock);
    80005b0e:	0001c517          	auipc	a0,0x1c
    80005b12:	bb250513          	addi	a0,a0,-1102 # 800216c0 <disk+0x128>
    80005b16:	8a4fb0ef          	jal	ra,80000bba <acquire>
  for(int i = 0; i < 3; i++){
    80005b1a:	4981                	li	s3,0
  for(int i = 0; i < NUM; i++){
    80005b1c:	4ba1                	li	s7,8
      disk.free[i] = 0;
    80005b1e:	0001cb17          	auipc	s6,0x1c
    80005b22:	a7ab0b13          	addi	s6,s6,-1414 # 80021598 <disk>
  for(int i = 0; i < 3; i++){
    80005b26:	4a8d                	li	s5,3
  for(int i = 0; i < NUM; i++){
    80005b28:	8a4e                	mv	s4,s3
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005b2a:	0001cc17          	auipc	s8,0x1c
    80005b2e:	b96c0c13          	addi	s8,s8,-1130 # 800216c0 <disk+0x128>
    80005b32:	a0b5                	j	80005b9e <virtio_disk_rw+0xbe>
      disk.free[i] = 0;
    80005b34:	00fb06b3          	add	a3,s6,a5
    80005b38:	00068c23          	sb	zero,24(a3)
    idx[i] = alloc_desc();
    80005b3c:	c21c                	sw	a5,0(a2)
    if(idx[i] < 0){
    80005b3e:	0207c563          	bltz	a5,80005b68 <virtio_disk_rw+0x88>
  for(int i = 0; i < 3; i++){
    80005b42:	2485                	addiw	s1,s1,1
    80005b44:	0711                	addi	a4,a4,4
    80005b46:	1d548c63          	beq	s1,s5,80005d1e <virtio_disk_rw+0x23e>
    idx[i] = alloc_desc();
    80005b4a:	863a                	mv	a2,a4
  for(int i = 0; i < NUM; i++){
    80005b4c:	0001c697          	auipc	a3,0x1c
    80005b50:	a4c68693          	addi	a3,a3,-1460 # 80021598 <disk>
    80005b54:	87d2                	mv	a5,s4
    if(disk.free[i]){
    80005b56:	0186c583          	lbu	a1,24(a3)
    80005b5a:	fde9                	bnez	a1,80005b34 <virtio_disk_rw+0x54>
  for(int i = 0; i < NUM; i++){
    80005b5c:	2785                	addiw	a5,a5,1
    80005b5e:	0685                	addi	a3,a3,1
    80005b60:	ff779be3          	bne	a5,s7,80005b56 <virtio_disk_rw+0x76>
    idx[i] = alloc_desc();
    80005b64:	57fd                	li	a5,-1
    80005b66:	c21c                	sw	a5,0(a2)
      for(int j = 0; j < i; j++)
    80005b68:	02905463          	blez	s1,80005b90 <virtio_disk_rw+0xb0>
        free_desc(idx[j]);
    80005b6c:	f9042503          	lw	a0,-112(s0)
    80005b70:	d3fff0ef          	jal	ra,800058ae <free_desc>
      for(int j = 0; j < i; j++)
    80005b74:	4785                	li	a5,1
    80005b76:	0097dd63          	bge	a5,s1,80005b90 <virtio_disk_rw+0xb0>
        free_desc(idx[j]);
    80005b7a:	f9442503          	lw	a0,-108(s0)
    80005b7e:	d31ff0ef          	jal	ra,800058ae <free_desc>
      for(int j = 0; j < i; j++)
    80005b82:	4789                	li	a5,2
    80005b84:	0097d663          	bge	a5,s1,80005b90 <virtio_disk_rw+0xb0>
        free_desc(idx[j]);
    80005b88:	f9842503          	lw	a0,-104(s0)
    80005b8c:	d23ff0ef          	jal	ra,800058ae <free_desc>
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005b90:	85e2                	mv	a1,s8
    80005b92:	0001c517          	auipc	a0,0x1c
    80005b96:	a1e50513          	addi	a0,a0,-1506 # 800215b0 <disk+0x18>
    80005b9a:	c5cfc0ef          	jal	ra,80001ff6 <sleep>
  for(int i = 0; i < 3; i++){
    80005b9e:	f9040713          	addi	a4,s0,-112
    80005ba2:	84ce                	mv	s1,s3
    80005ba4:	b75d                	j	80005b4a <virtio_disk_rw+0x6a>
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];

  if(write)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
    80005ba6:	00a60793          	addi	a5,a2,10 # 100a <_entry-0x7fffeff6>
    80005baa:	00479693          	slli	a3,a5,0x4
    80005bae:	0001c797          	auipc	a5,0x1c
    80005bb2:	9ea78793          	addi	a5,a5,-1558 # 80021598 <disk>
    80005bb6:	97b6                	add	a5,a5,a3
    80005bb8:	4685                	li	a3,1
    80005bba:	c794                	sw	a3,8(a5)
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005bbc:	0001c597          	auipc	a1,0x1c
    80005bc0:	9dc58593          	addi	a1,a1,-1572 # 80021598 <disk>
    80005bc4:	00a60793          	addi	a5,a2,10
    80005bc8:	0792                	slli	a5,a5,0x4
    80005bca:	97ae                	add	a5,a5,a1
    80005bcc:	0007a623          	sw	zero,12(a5)
  buf0->sector = sector;
    80005bd0:	0197b823          	sd	s9,16(a5)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80005bd4:	f6070693          	addi	a3,a4,-160
    80005bd8:	619c                	ld	a5,0(a1)
    80005bda:	97b6                	add	a5,a5,a3
    80005bdc:	e388                	sd	a0,0(a5)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005bde:	6188                	ld	a0,0(a1)
    80005be0:	96aa                	add	a3,a3,a0
    80005be2:	47c1                	li	a5,16
    80005be4:	c69c                	sw	a5,8(a3)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005be6:	4785                	li	a5,1
    80005be8:	00f69623          	sh	a5,12(a3)
  disk.desc[idx[0]].next = idx[1];
    80005bec:	f9442783          	lw	a5,-108(s0)
    80005bf0:	00f69723          	sh	a5,14(a3)

  disk.desc[idx[1]].addr = (uint64) b->data;
    80005bf4:	0792                	slli	a5,a5,0x4
    80005bf6:	953e                	add	a0,a0,a5
    80005bf8:	05890693          	addi	a3,s2,88
    80005bfc:	e114                	sd	a3,0(a0)
  disk.desc[idx[1]].len = BSIZE;
    80005bfe:	6188                	ld	a0,0(a1)
    80005c00:	97aa                	add	a5,a5,a0
    80005c02:	40000693          	li	a3,1024
    80005c06:	c794                	sw	a3,8(a5)
  if(write)
    80005c08:	100d0763          	beqz	s10,80005d16 <virtio_disk_rw+0x236>
    disk.desc[idx[1]].flags = 0; // device reads b->data
    80005c0c:	00079623          	sh	zero,12(a5)
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80005c10:	00c7d683          	lhu	a3,12(a5)
    80005c14:	0016e693          	ori	a3,a3,1
    80005c18:	00d79623          	sh	a3,12(a5)
  disk.desc[idx[1]].next = idx[2];
    80005c1c:	f9842583          	lw	a1,-104(s0)
    80005c20:	00b79723          	sh	a1,14(a5)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80005c24:	0001c697          	auipc	a3,0x1c
    80005c28:	97468693          	addi	a3,a3,-1676 # 80021598 <disk>
    80005c2c:	00260793          	addi	a5,a2,2
    80005c30:	0792                	slli	a5,a5,0x4
    80005c32:	97b6                	add	a5,a5,a3
    80005c34:	587d                	li	a6,-1
    80005c36:	01078823          	sb	a6,16(a5)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    80005c3a:	0592                	slli	a1,a1,0x4
    80005c3c:	952e                	add	a0,a0,a1
    80005c3e:	f9070713          	addi	a4,a4,-112
    80005c42:	9736                	add	a4,a4,a3
    80005c44:	e118                	sd	a4,0(a0)
  disk.desc[idx[2]].len = 1;
    80005c46:	6298                	ld	a4,0(a3)
    80005c48:	972e                	add	a4,a4,a1
    80005c4a:	4585                	li	a1,1
    80005c4c:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005c4e:	4509                	li	a0,2
    80005c50:	00a71623          	sh	a0,12(a4)
  disk.desc[idx[2]].next = 0;
    80005c54:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005c58:	00b92223          	sw	a1,4(s2)
  disk.info[idx[0]].b = b;
    80005c5c:	0127b423          	sd	s2,8(a5)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005c60:	6698                	ld	a4,8(a3)
    80005c62:	00275783          	lhu	a5,2(a4)
    80005c66:	8b9d                	andi	a5,a5,7
    80005c68:	0786                	slli	a5,a5,0x1
    80005c6a:	97ba                	add	a5,a5,a4
    80005c6c:	00c79223          	sh	a2,4(a5)

  __sync_synchronize();
    80005c70:	0ff0000f          	fence

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005c74:	6698                	ld	a4,8(a3)
    80005c76:	00275783          	lhu	a5,2(a4)
    80005c7a:	2785                	addiw	a5,a5,1
    80005c7c:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80005c80:	0ff0000f          	fence

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005c84:	100017b7          	lui	a5,0x10001
    80005c88:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    80005c8c:	00492703          	lw	a4,4(s2)
    80005c90:	4785                	li	a5,1
    80005c92:	00f71f63          	bne	a4,a5,80005cb0 <virtio_disk_rw+0x1d0>
    sleep(b, &disk.vdisk_lock);
    80005c96:	0001c997          	auipc	s3,0x1c
    80005c9a:	a2a98993          	addi	s3,s3,-1494 # 800216c0 <disk+0x128>
  while(b->disk == 1) {
    80005c9e:	4485                	li	s1,1
    sleep(b, &disk.vdisk_lock);
    80005ca0:	85ce                	mv	a1,s3
    80005ca2:	854a                	mv	a0,s2
    80005ca4:	b52fc0ef          	jal	ra,80001ff6 <sleep>
  while(b->disk == 1) {
    80005ca8:	00492783          	lw	a5,4(s2)
    80005cac:	fe978ae3          	beq	a5,s1,80005ca0 <virtio_disk_rw+0x1c0>
  }

  disk.info[idx[0]].b = 0;
    80005cb0:	f9042903          	lw	s2,-112(s0)
    80005cb4:	00290793          	addi	a5,s2,2
    80005cb8:	00479713          	slli	a4,a5,0x4
    80005cbc:	0001c797          	auipc	a5,0x1c
    80005cc0:	8dc78793          	addi	a5,a5,-1828 # 80021598 <disk>
    80005cc4:	97ba                	add	a5,a5,a4
    80005cc6:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    80005cca:	0001c997          	auipc	s3,0x1c
    80005cce:	8ce98993          	addi	s3,s3,-1842 # 80021598 <disk>
    80005cd2:	00491713          	slli	a4,s2,0x4
    80005cd6:	0009b783          	ld	a5,0(s3)
    80005cda:	97ba                	add	a5,a5,a4
    80005cdc:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005ce0:	854a                	mv	a0,s2
    80005ce2:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005ce6:	bc9ff0ef          	jal	ra,800058ae <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80005cea:	8885                	andi	s1,s1,1
    80005cec:	f0fd                	bnez	s1,80005cd2 <virtio_disk_rw+0x1f2>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80005cee:	0001c517          	auipc	a0,0x1c
    80005cf2:	9d250513          	addi	a0,a0,-1582 # 800216c0 <disk+0x128>
    80005cf6:	f5dfa0ef          	jal	ra,80000c52 <release>
}
    80005cfa:	70a6                	ld	ra,104(sp)
    80005cfc:	7406                	ld	s0,96(sp)
    80005cfe:	64e6                	ld	s1,88(sp)
    80005d00:	6946                	ld	s2,80(sp)
    80005d02:	69a6                	ld	s3,72(sp)
    80005d04:	6a06                	ld	s4,64(sp)
    80005d06:	7ae2                	ld	s5,56(sp)
    80005d08:	7b42                	ld	s6,48(sp)
    80005d0a:	7ba2                	ld	s7,40(sp)
    80005d0c:	7c02                	ld	s8,32(sp)
    80005d0e:	6ce2                	ld	s9,24(sp)
    80005d10:	6d42                	ld	s10,16(sp)
    80005d12:	6165                	addi	sp,sp,112
    80005d14:	8082                	ret
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
    80005d16:	4689                	li	a3,2
    80005d18:	00d79623          	sh	a3,12(a5)
    80005d1c:	bdd5                	j	80005c10 <virtio_disk_rw+0x130>
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005d1e:	f9042603          	lw	a2,-112(s0)
    80005d22:	00a60713          	addi	a4,a2,10
    80005d26:	0712                	slli	a4,a4,0x4
    80005d28:	0001c517          	auipc	a0,0x1c
    80005d2c:	87850513          	addi	a0,a0,-1928 # 800215a0 <disk+0x8>
    80005d30:	953a                	add	a0,a0,a4
  if(write)
    80005d32:	e60d1ae3          	bnez	s10,80005ba6 <virtio_disk_rw+0xc6>
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
    80005d36:	00a60793          	addi	a5,a2,10
    80005d3a:	00479693          	slli	a3,a5,0x4
    80005d3e:	0001c797          	auipc	a5,0x1c
    80005d42:	85a78793          	addi	a5,a5,-1958 # 80021598 <disk>
    80005d46:	97b6                	add	a5,a5,a3
    80005d48:	0007a423          	sw	zero,8(a5)
    80005d4c:	bd85                	j	80005bbc <virtio_disk_rw+0xdc>

0000000080005d4e <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005d4e:	1101                	addi	sp,sp,-32
    80005d50:	ec06                	sd	ra,24(sp)
    80005d52:	e822                	sd	s0,16(sp)
    80005d54:	e426                	sd	s1,8(sp)
    80005d56:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    80005d58:	0001c497          	auipc	s1,0x1c
    80005d5c:	84048493          	addi	s1,s1,-1984 # 80021598 <disk>
    80005d60:	0001c517          	auipc	a0,0x1c
    80005d64:	96050513          	addi	a0,a0,-1696 # 800216c0 <disk+0x128>
    80005d68:	e53fa0ef          	jal	ra,80000bba <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80005d6c:	10001737          	lui	a4,0x10001
    80005d70:	533c                	lw	a5,96(a4)
    80005d72:	8b8d                	andi	a5,a5,3
    80005d74:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    80005d76:	0ff0000f          	fence

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80005d7a:	689c                	ld	a5,16(s1)
    80005d7c:	0204d703          	lhu	a4,32(s1)
    80005d80:	0027d783          	lhu	a5,2(a5)
    80005d84:	04f70663          	beq	a4,a5,80005dd0 <virtio_disk_intr+0x82>
    __sync_synchronize();
    80005d88:	0ff0000f          	fence
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005d8c:	6898                	ld	a4,16(s1)
    80005d8e:	0204d783          	lhu	a5,32(s1)
    80005d92:	8b9d                	andi	a5,a5,7
    80005d94:	078e                	slli	a5,a5,0x3
    80005d96:	97ba                	add	a5,a5,a4
    80005d98:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80005d9a:	00278713          	addi	a4,a5,2
    80005d9e:	0712                	slli	a4,a4,0x4
    80005da0:	9726                	add	a4,a4,s1
    80005da2:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    80005da6:	e321                	bnez	a4,80005de6 <virtio_disk_intr+0x98>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80005da8:	0789                	addi	a5,a5,2
    80005daa:	0792                	slli	a5,a5,0x4
    80005dac:	97a6                	add	a5,a5,s1
    80005dae:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80005db0:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80005db4:	a8efc0ef          	jal	ra,80002042 <wakeup>

    disk.used_idx += 1;
    80005db8:	0204d783          	lhu	a5,32(s1)
    80005dbc:	2785                	addiw	a5,a5,1
    80005dbe:	17c2                	slli	a5,a5,0x30
    80005dc0:	93c1                	srli	a5,a5,0x30
    80005dc2:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80005dc6:	6898                	ld	a4,16(s1)
    80005dc8:	00275703          	lhu	a4,2(a4)
    80005dcc:	faf71ee3          	bne	a4,a5,80005d88 <virtio_disk_intr+0x3a>
  }

  release(&disk.vdisk_lock);
    80005dd0:	0001c517          	auipc	a0,0x1c
    80005dd4:	8f050513          	addi	a0,a0,-1808 # 800216c0 <disk+0x128>
    80005dd8:	e7bfa0ef          	jal	ra,80000c52 <release>
}
    80005ddc:	60e2                	ld	ra,24(sp)
    80005dde:	6442                	ld	s0,16(sp)
    80005de0:	64a2                	ld	s1,8(sp)
    80005de2:	6105                	addi	sp,sp,32
    80005de4:	8082                	ret
      panic("virtio_disk_intr status");
    80005de6:	00002517          	auipc	a0,0x2
    80005dea:	b8a50513          	addi	a0,a0,-1142 # 80007970 <syscalls+0x440>
    80005dee:	9a1fa0ef          	jal	ra,8000078e <panic>
	...

0000000080006000 <_trampoline>:
        # user page table.
        #

        # save user a0 in sscratch so
        # a0 can be used to get at TRAPFRAME.
        csrw sscratch, a0
    80006000:	14051073          	csrw	sscratch,a0

        # each process has a separate p->trapframe memory area,
        # but it's mapped to the same virtual address
        # (TRAPFRAME) in every process's user page table.
        li a0, TRAPFRAME
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1
    8000600a:	0536                	slli	a0,a0,0xd
        
        # save the user registers in TRAPFRAME
        sd ra, 40(a0)
    8000600c:	02153423          	sd	ra,40(a0) # 2000028 <_entry-0x7dffffd8>
        sd sp, 48(a0)
    80006010:	02253823          	sd	sp,48(a0)
        sd gp, 56(a0)
    80006014:	02353c23          	sd	gp,56(a0)
        sd tp, 64(a0)
    80006018:	04453023          	sd	tp,64(a0)
        sd t0, 72(a0)
    8000601c:	04553423          	sd	t0,72(a0)
        sd t1, 80(a0)
    80006020:	04653823          	sd	t1,80(a0)
        sd t2, 88(a0)
    80006024:	04753c23          	sd	t2,88(a0)
        sd s0, 96(a0)
    80006028:	f120                	sd	s0,96(a0)
        sd s1, 104(a0)
    8000602a:	f524                	sd	s1,104(a0)
        sd a1, 120(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
        sd a2, 128(a0)
    8000602e:	e150                	sd	a2,128(a0)
        sd a3, 136(a0)
    80006030:	e554                	sd	a3,136(a0)
        sd a4, 144(a0)
    80006032:	e958                	sd	a4,144(a0)
        sd a5, 152(a0)
    80006034:	ed5c                	sd	a5,152(a0)
        sd a6, 160(a0)
    80006036:	0b053023          	sd	a6,160(a0)
        sd a7, 168(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
        sd s2, 176(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
        sd s3, 184(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
        sd s4, 192(a0)
    80006046:	0d453023          	sd	s4,192(a0)
        sd s5, 200(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
        sd s6, 208(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
        sd s7, 216(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
        sd s8, 224(a0)
    80006056:	0f853023          	sd	s8,224(a0)
        sd s9, 232(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
        sd s10, 240(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
        sd s11, 248(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
        sd t3, 256(a0)
    80006066:	11c53023          	sd	t3,256(a0)
        sd t4, 264(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
        sd t5, 272(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
        sd t6, 280(a0)
    80006072:	11f53c23          	sd	t6,280(a0)

	# save the user a0 in p->trapframe->a0
        csrr t0, sscratch
    80006076:	140022f3          	csrr	t0,sscratch
        sd t0, 112(a0)
    8000607a:	06553823          	sd	t0,112(a0)

        # initialize kernel stack pointer, from p->trapframe->kernel_sp
        ld sp, 8(a0)
    8000607e:	00853103          	ld	sp,8(a0)

        # make tp hold the current hartid, from p->trapframe->kernel_hartid
        ld tp, 32(a0)
    80006082:	02053203          	ld	tp,32(a0)

        # load the address of usertrap(), from p->trapframe->kernel_trap
        ld t0, 16(a0)
    80006086:	01053283          	ld	t0,16(a0)

        # fetch the kernel page table address, from p->trapframe->kernel_satp.
        ld t1, 0(a0)
    8000608a:	00053303          	ld	t1,0(a0)

        # wait for any previous memory operations to complete, so that
        # they use the user page table.
        sfence.vma zero, zero
    8000608e:	12000073          	sfence.vma

        # install the kernel page table.
        csrw satp, t1
    80006092:	18031073          	csrw	satp,t1

        # flush now-stale user entries from the TLB.
        sfence.vma zero, zero
    80006096:	12000073          	sfence.vma

        # call usertrap()
        jalr t0
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
userret:
        # usertrap() returns here, with user satp in a0.
        # return from kernel to user.

        # switch to the user page table.
        sfence.vma zero, zero
    8000609c:	12000073          	sfence.vma
        csrw satp, a0
    800060a0:	18051073          	csrw	satp,a0
        sfence.vma zero, zero
    800060a4:	12000073          	sfence.vma

        li a0, TRAPFRAME
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1
    800060ae:	0536                	slli	a0,a0,0xd

        # restore all but a0 from TRAPFRAME
        ld ra, 40(a0)
    800060b0:	02853083          	ld	ra,40(a0) # 2000028 <_entry-0x7dffffd8>
        ld sp, 48(a0)
    800060b4:	03053103          	ld	sp,48(a0)
        ld gp, 56(a0)
    800060b8:	03853183          	ld	gp,56(a0)
        ld tp, 64(a0)
    800060bc:	04053203          	ld	tp,64(a0)
        ld t0, 72(a0)
    800060c0:	04853283          	ld	t0,72(a0)
        ld t1, 80(a0)
    800060c4:	05053303          	ld	t1,80(a0)
        ld t2, 88(a0)
    800060c8:	05853383          	ld	t2,88(a0)
        ld s0, 96(a0)
    800060cc:	7120                	ld	s0,96(a0)
        ld s1, 104(a0)
    800060ce:	7524                	ld	s1,104(a0)
        ld a1, 120(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
        ld a2, 128(a0)
    800060d2:	6150                	ld	a2,128(a0)
        ld a3, 136(a0)
    800060d4:	6554                	ld	a3,136(a0)
        ld a4, 144(a0)
    800060d6:	6958                	ld	a4,144(a0)
        ld a5, 152(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
        ld a6, 160(a0)
    800060da:	0a053803          	ld	a6,160(a0)
        ld a7, 168(a0)
    800060de:	0a853883          	ld	a7,168(a0)
        ld s2, 176(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
        ld s3, 184(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
        ld s4, 192(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
        ld s5, 200(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
        ld s6, 208(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
        ld s7, 216(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
        ld s8, 224(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
        ld s9, 232(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
        ld s10, 240(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
        ld s11, 248(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
        ld t3, 256(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
        ld t4, 264(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
        ld t5, 272(a0)
    80006112:	11053f03          	ld	t5,272(a0)
        ld t6, 280(a0)
    80006116:	11853f83          	ld	t6,280(a0)

	# restore user a0
        ld a0, 112(a0)
    8000611a:	7928                	ld	a0,112(a0)
        
        # return to user mode and user pc.
        # usertrapret() set up sstatus and sepc.
        sret
    8000611c:	10200073          	sret
	...
