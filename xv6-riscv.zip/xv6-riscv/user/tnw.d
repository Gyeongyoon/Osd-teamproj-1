user/tnw.o: user/tnw.c kernel/types.h kernel/stat.h user/user.h
