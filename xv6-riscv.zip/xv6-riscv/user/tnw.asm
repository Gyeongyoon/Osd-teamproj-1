
user/_tnw:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <busy_work>:
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void busy_work() {
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	ec26                	sd	s1,24(sp)
   8:	e84a                	sd	s2,16(sp)
   a:	e44e                	sd	s3,8(sp)
   c:	e052                	sd	s4,0(sp)
   e:	1800                	addi	s0,sp,48
    int start = uptime();
  10:	48a000ef          	jal	ra,49a <uptime>
  14:	8a2a                	mv	s4,a0
    int x = 0, z = 20, i, j;
    while ((uptime() - start) < 4) {
  16:	490d                	li	s2,3
  18:	67e1                	lui	a5,0x18
  1a:	6a078993          	addi	s3,a5,1696 # 186a0 <base+0x17690>
void busy_work() {
  1e:	6489                	lui	s1,0x2
  20:	71048493          	addi	s1,s1,1808 # 2710 <base+0x1700>
    while ((uptime() - start) < 4) {
  24:	476000ef          	jal	ra,49a <uptime>
  28:	414507bb          	subw	a5,a0,s4
  2c:	00f94a63          	blt	s2,a5,40 <busy_work+0x40>
  30:	874e                	mv	a4,s3
  32:	a019                	j	38 <busy_work+0x38>
        for (i = 0; i < 100000; i++)
  34:	377d                	addiw	a4,a4,-1
  36:	d77d                	beqz	a4,24 <busy_work+0x24>
void busy_work() {
  38:	87a6                	mv	a5,s1
            for (j = 0; j < 10000; j++)
  3a:	37fd                	addiw	a5,a5,-1
  3c:	fffd                	bnez	a5,3a <busy_work+0x3a>
  3e:	bfdd                	j	34 <busy_work+0x34>
                x += z * 89;
    }
}
  40:	70a2                	ld	ra,40(sp)
  42:	7402                	ld	s0,32(sp)
  44:	64e2                	ld	s1,24(sp)
  46:	6942                	ld	s2,16(sp)
  48:	69a2                	ld	s3,8(sp)
  4a:	6a02                	ld	s4,0(sp)
  4c:	6145                	addi	sp,sp,48
  4e:	8082                	ret

0000000000000050 <count_iterations>:

int count_iterations(int duration) {
  50:	7179                	addi	sp,sp,-48
  52:	f406                	sd	ra,40(sp)
  54:	f022                	sd	s0,32(sp)
  56:	ec26                	sd	s1,24(sp)
  58:	e84a                	sd	s2,16(sp)
  5a:	e44e                	sd	s3,8(sp)
  5c:	e052                	sd	s4,0(sp)
  5e:	1800                	addi	s0,sp,48
  60:	89aa                	mv	s3,a0
    int start = uptime();
  62:	438000ef          	jal	ra,49a <uptime>
  66:	892a                	mv	s2,a0
    int x = 0, iterations = 0;
  68:	4481                	li	s1,0
  6a:	3e800a13          	li	s4,1000
    while ((uptime() - start) < duration) {
  6e:	a011                	j	72 <count_iterations+0x22>
        for (int i = 0; i < 1000; i++)
            x += i * 7;
        iterations++;
  70:	2485                	addiw	s1,s1,1
    while ((uptime() - start) < duration) {
  72:	428000ef          	jal	ra,49a <uptime>
  76:	412507bb          	subw	a5,a0,s2
  7a:	0137d663          	bge	a5,s3,86 <count_iterations+0x36>
  7e:	87d2                	mv	a5,s4
        for (int i = 0; i < 1000; i++)
  80:	37fd                	addiw	a5,a5,-1
  82:	fffd                	bnez	a5,80 <count_iterations+0x30>
  84:	b7f5                	j	70 <count_iterations+0x20>
    }
    return iterations;
}
  86:	8526                	mv	a0,s1
  88:	70a2                	ld	ra,40(sp)
  8a:	7402                	ld	s0,32(sp)
  8c:	64e2                	ld	s1,24(sp)
  8e:	6942                	ld	s2,16(sp)
  90:	69a2                	ld	s3,8(sp)
  92:	6a02                	ld	s4,0(sp)
  94:	6145                	addi	sp,sp,48
  96:	8082                	ret

0000000000000098 <main>:

int main(int argc, char **argv) {
  98:	7179                	addi	sp,sp,-48
  9a:	f406                	sd	ra,40(sp)
  9c:	f022                	sd	s0,32(sp)
  9e:	ec26                	sd	s1,24(sp)
  a0:	1800                	addi	s0,sp,48
    printf("=== TEST: Weight-based Scheduling (nice 5 vs nice 20) ===\n");
  a2:	00001517          	auipc	a0,0x1
  a6:	93e50513          	addi	a0,a0,-1730 # 9e0 <malloc+0xe0>
  aa:	79c000ef          	jal	ra,846 <printf>

    // Child 1: high priority
    int child1 = fork();
  ae:	34c000ef          	jal	ra,3fa <fork>
    if (child1 == 0) {
  b2:	ed01                	bnez	a0,ca <main+0x32>
        setnice(getpid(), 5);  // weight 29154
  b4:	3ce000ef          	jal	ra,482 <getpid>
  b8:	4595                	li	a1,5
  ba:	3f0000ef          	jal	ra,4aa <setnice>
        int iters = count_iterations(200);
  be:	0c800513          	li	a0,200
  c2:	f8fff0ef          	jal	ra,50 <count_iterations>
        exit(iters);
  c6:	33c000ef          	jal	ra,402 <exit>
    }

    // Child 2: default priority
    int child2 = fork();
  ca:	330000ef          	jal	ra,3fa <fork>
    if (child2 == 0) {
  ce:	4491                	li	s1,4
  d0:	c925                	beqz	a0,140 <main+0xa8>
        exit(iters);
    }

    // Parent: observe with periodic ps() snapshots
    for (int i = 0; i < 4; i++) {
        busy_work();
  d2:	f2fff0ef          	jal	ra,0 <busy_work>
        ps(0);
  d6:	4501                	li	a0,0
  d8:	3da000ef          	jal	ra,4b2 <ps>
    for (int i = 0; i < 4; i++) {
  dc:	34fd                	addiw	s1,s1,-1
  de:	f8f5                	bnez	s1,d2 <main+0x3a>
    }

    int iters_high, iters_low;
    wait(&iters_high);
  e0:	fdc40513          	addi	a0,s0,-36
  e4:	326000ef          	jal	ra,40a <wait>
    wait(&iters_low);
  e8:	fd840513          	addi	a0,s0,-40
  ec:	31e000ef          	jal	ra,40a <wait>

    // Ensure iters_high is the nice=5 child
    // (wait returns in exit order, so sort)
    if (iters_high < iters_low) {
  f0:	fdc42783          	lw	a5,-36(s0)
  f4:	fd842703          	lw	a4,-40(s0)
  f8:	00e7d663          	bge	a5,a4,104 <main+0x6c>
        int tmp = iters_high;
        iters_high = iters_low;
  fc:	fce42e23          	sw	a4,-36(s0)
        iters_low = tmp;
 100:	fcf42c23          	sw	a5,-40(s0)
    }

    printf("\nIterations — Child nice 5: %d, Child nice 20: %d\n",
 104:	fd842603          	lw	a2,-40(s0)
 108:	fdc42583          	lw	a1,-36(s0)
 10c:	00001517          	auipc	a0,0x1
 110:	91450513          	addi	a0,a0,-1772 # a20 <malloc+0x120>
 114:	732000ef          	jal	ra,846 <printf>
        iters_high, iters_low);

    if (iters_high > iters_low)
 118:	fdc42703          	lw	a4,-36(s0)
 11c:	fd842783          	lw	a5,-40(s0)
 120:	02e7db63          	bge	a5,a4,156 <main+0xbe>
        printf("[PASS] Higher weight process completed more work (ratio: %dx)\n",
 124:	55fd                	li	a1,-1
 126:	00f05463          	blez	a5,12e <main+0x96>
 12a:	02f745bb          	divw	a1,a4,a5
 12e:	00001517          	auipc	a0,0x1
 132:	92a50513          	addi	a0,a0,-1750 # a58 <malloc+0x158>
 136:	710000ef          	jal	ra,846 <printf>
            iters_low > 0 ? iters_high / iters_low : -1);
    else
        printf("[FAIL] Weight-based distribution not working\n");

    exit(0);
 13a:	4501                	li	a0,0
 13c:	2c6000ef          	jal	ra,402 <exit>
        setnice(getpid(), 20);  // weight 1024
 140:	342000ef          	jal	ra,482 <getpid>
 144:	45d1                	li	a1,20
 146:	364000ef          	jal	ra,4aa <setnice>
        int iters = count_iterations(200);
 14a:	0c800513          	li	a0,200
 14e:	f03ff0ef          	jal	ra,50 <count_iterations>
        exit(iters);
 152:	2b0000ef          	jal	ra,402 <exit>
        printf("[FAIL] Weight-based distribution not working\n");
 156:	00001517          	auipc	a0,0x1
 15a:	94250513          	addi	a0,a0,-1726 # a98 <malloc+0x198>
 15e:	6e8000ef          	jal	ra,846 <printf>
 162:	bfe1                	j	13a <main+0xa2>

0000000000000164 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 164:	1141                	addi	sp,sp,-16
 166:	e406                	sd	ra,8(sp)
 168:	e022                	sd	s0,0(sp)
 16a:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 16c:	f2dff0ef          	jal	ra,98 <main>
  exit(r);
 170:	292000ef          	jal	ra,402 <exit>

0000000000000174 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 174:	1141                	addi	sp,sp,-16
 176:	e422                	sd	s0,8(sp)
 178:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 17a:	87aa                	mv	a5,a0
 17c:	0585                	addi	a1,a1,1
 17e:	0785                	addi	a5,a5,1
 180:	fff5c703          	lbu	a4,-1(a1)
 184:	fee78fa3          	sb	a4,-1(a5)
 188:	fb75                	bnez	a4,17c <strcpy+0x8>
    ;
  return os;
}
 18a:	6422                	ld	s0,8(sp)
 18c:	0141                	addi	sp,sp,16
 18e:	8082                	ret

0000000000000190 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 190:	1141                	addi	sp,sp,-16
 192:	e422                	sd	s0,8(sp)
 194:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 196:	00054783          	lbu	a5,0(a0)
 19a:	cb91                	beqz	a5,1ae <strcmp+0x1e>
 19c:	0005c703          	lbu	a4,0(a1)
 1a0:	00f71763          	bne	a4,a5,1ae <strcmp+0x1e>
    p++, q++;
 1a4:	0505                	addi	a0,a0,1
 1a6:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 1a8:	00054783          	lbu	a5,0(a0)
 1ac:	fbe5                	bnez	a5,19c <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 1ae:	0005c503          	lbu	a0,0(a1)
}
 1b2:	40a7853b          	subw	a0,a5,a0
 1b6:	6422                	ld	s0,8(sp)
 1b8:	0141                	addi	sp,sp,16
 1ba:	8082                	ret

00000000000001bc <strlen>:

uint
strlen(const char *s)
{
 1bc:	1141                	addi	sp,sp,-16
 1be:	e422                	sd	s0,8(sp)
 1c0:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 1c2:	00054783          	lbu	a5,0(a0)
 1c6:	cf91                	beqz	a5,1e2 <strlen+0x26>
 1c8:	0505                	addi	a0,a0,1
 1ca:	87aa                	mv	a5,a0
 1cc:	4685                	li	a3,1
 1ce:	9e89                	subw	a3,a3,a0
 1d0:	00f6853b          	addw	a0,a3,a5
 1d4:	0785                	addi	a5,a5,1
 1d6:	fff7c703          	lbu	a4,-1(a5)
 1da:	fb7d                	bnez	a4,1d0 <strlen+0x14>
    ;
  return n;
}
 1dc:	6422                	ld	s0,8(sp)
 1de:	0141                	addi	sp,sp,16
 1e0:	8082                	ret
  for(n = 0; s[n]; n++)
 1e2:	4501                	li	a0,0
 1e4:	bfe5                	j	1dc <strlen+0x20>

00000000000001e6 <memset>:

void*
memset(void *dst, int c, uint n)
{
 1e6:	1141                	addi	sp,sp,-16
 1e8:	e422                	sd	s0,8(sp)
 1ea:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 1ec:	ce09                	beqz	a2,206 <memset+0x20>
 1ee:	87aa                	mv	a5,a0
 1f0:	fff6071b          	addiw	a4,a2,-1
 1f4:	1702                	slli	a4,a4,0x20
 1f6:	9301                	srli	a4,a4,0x20
 1f8:	0705                	addi	a4,a4,1
 1fa:	972a                	add	a4,a4,a0
    cdst[i] = c;
 1fc:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 200:	0785                	addi	a5,a5,1
 202:	fee79de3          	bne	a5,a4,1fc <memset+0x16>
  }
  return dst;
}
 206:	6422                	ld	s0,8(sp)
 208:	0141                	addi	sp,sp,16
 20a:	8082                	ret

000000000000020c <strchr>:

char*
strchr(const char *s, char c)
{
 20c:	1141                	addi	sp,sp,-16
 20e:	e422                	sd	s0,8(sp)
 210:	0800                	addi	s0,sp,16
  for(; *s; s++)
 212:	00054783          	lbu	a5,0(a0)
 216:	cb99                	beqz	a5,22c <strchr+0x20>
    if(*s == c)
 218:	00f58763          	beq	a1,a5,226 <strchr+0x1a>
  for(; *s; s++)
 21c:	0505                	addi	a0,a0,1
 21e:	00054783          	lbu	a5,0(a0)
 222:	fbfd                	bnez	a5,218 <strchr+0xc>
      return (char*)s;
  return 0;
 224:	4501                	li	a0,0
}
 226:	6422                	ld	s0,8(sp)
 228:	0141                	addi	sp,sp,16
 22a:	8082                	ret
  return 0;
 22c:	4501                	li	a0,0
 22e:	bfe5                	j	226 <strchr+0x1a>

0000000000000230 <gets>:

char*
gets(char *buf, int max)
{
 230:	711d                	addi	sp,sp,-96
 232:	ec86                	sd	ra,88(sp)
 234:	e8a2                	sd	s0,80(sp)
 236:	e4a6                	sd	s1,72(sp)
 238:	e0ca                	sd	s2,64(sp)
 23a:	fc4e                	sd	s3,56(sp)
 23c:	f852                	sd	s4,48(sp)
 23e:	f456                	sd	s5,40(sp)
 240:	f05a                	sd	s6,32(sp)
 242:	ec5e                	sd	s7,24(sp)
 244:	1080                	addi	s0,sp,96
 246:	8baa                	mv	s7,a0
 248:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 24a:	892a                	mv	s2,a0
 24c:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 24e:	4aa9                	li	s5,10
 250:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 252:	89a6                	mv	s3,s1
 254:	2485                	addiw	s1,s1,1
 256:	0344d663          	bge	s1,s4,282 <gets+0x52>
    cc = read(0, &c, 1);
 25a:	4605                	li	a2,1
 25c:	faf40593          	addi	a1,s0,-81
 260:	4501                	li	a0,0
 262:	1b8000ef          	jal	ra,41a <read>
    if(cc < 1)
 266:	00a05e63          	blez	a0,282 <gets+0x52>
    buf[i++] = c;
 26a:	faf44783          	lbu	a5,-81(s0)
 26e:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 272:	01578763          	beq	a5,s5,280 <gets+0x50>
 276:	0905                	addi	s2,s2,1
 278:	fd679de3          	bne	a5,s6,252 <gets+0x22>
  for(i=0; i+1 < max; ){
 27c:	89a6                	mv	s3,s1
 27e:	a011                	j	282 <gets+0x52>
 280:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 282:	99de                	add	s3,s3,s7
 284:	00098023          	sb	zero,0(s3)
  return buf;
}
 288:	855e                	mv	a0,s7
 28a:	60e6                	ld	ra,88(sp)
 28c:	6446                	ld	s0,80(sp)
 28e:	64a6                	ld	s1,72(sp)
 290:	6906                	ld	s2,64(sp)
 292:	79e2                	ld	s3,56(sp)
 294:	7a42                	ld	s4,48(sp)
 296:	7aa2                	ld	s5,40(sp)
 298:	7b02                	ld	s6,32(sp)
 29a:	6be2                	ld	s7,24(sp)
 29c:	6125                	addi	sp,sp,96
 29e:	8082                	ret

00000000000002a0 <stat>:

int
stat(const char *n, struct stat *st)
{
 2a0:	1101                	addi	sp,sp,-32
 2a2:	ec06                	sd	ra,24(sp)
 2a4:	e822                	sd	s0,16(sp)
 2a6:	e426                	sd	s1,8(sp)
 2a8:	e04a                	sd	s2,0(sp)
 2aa:	1000                	addi	s0,sp,32
 2ac:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 2ae:	4581                	li	a1,0
 2b0:	192000ef          	jal	ra,442 <open>
  if(fd < 0)
 2b4:	02054163          	bltz	a0,2d6 <stat+0x36>
 2b8:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 2ba:	85ca                	mv	a1,s2
 2bc:	19e000ef          	jal	ra,45a <fstat>
 2c0:	892a                	mv	s2,a0
  close(fd);
 2c2:	8526                	mv	a0,s1
 2c4:	166000ef          	jal	ra,42a <close>
  return r;
}
 2c8:	854a                	mv	a0,s2
 2ca:	60e2                	ld	ra,24(sp)
 2cc:	6442                	ld	s0,16(sp)
 2ce:	64a2                	ld	s1,8(sp)
 2d0:	6902                	ld	s2,0(sp)
 2d2:	6105                	addi	sp,sp,32
 2d4:	8082                	ret
    return -1;
 2d6:	597d                	li	s2,-1
 2d8:	bfc5                	j	2c8 <stat+0x28>

00000000000002da <atoi>:

int
atoi(const char *s)
{
 2da:	1141                	addi	sp,sp,-16
 2dc:	e422                	sd	s0,8(sp)
 2de:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 2e0:	00054603          	lbu	a2,0(a0)
 2e4:	fd06079b          	addiw	a5,a2,-48
 2e8:	0ff7f793          	andi	a5,a5,255
 2ec:	4725                	li	a4,9
 2ee:	02f76963          	bltu	a4,a5,320 <atoi+0x46>
 2f2:	86aa                	mv	a3,a0
  n = 0;
 2f4:	4501                	li	a0,0
  while('0' <= *s && *s <= '9')
 2f6:	45a5                	li	a1,9
    n = n*10 + *s++ - '0';
 2f8:	0685                	addi	a3,a3,1
 2fa:	0025179b          	slliw	a5,a0,0x2
 2fe:	9fa9                	addw	a5,a5,a0
 300:	0017979b          	slliw	a5,a5,0x1
 304:	9fb1                	addw	a5,a5,a2
 306:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 30a:	0006c603          	lbu	a2,0(a3)
 30e:	fd06071b          	addiw	a4,a2,-48
 312:	0ff77713          	andi	a4,a4,255
 316:	fee5f1e3          	bgeu	a1,a4,2f8 <atoi+0x1e>
  return n;
}
 31a:	6422                	ld	s0,8(sp)
 31c:	0141                	addi	sp,sp,16
 31e:	8082                	ret
  n = 0;
 320:	4501                	li	a0,0
 322:	bfe5                	j	31a <atoi+0x40>

0000000000000324 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 324:	1141                	addi	sp,sp,-16
 326:	e422                	sd	s0,8(sp)
 328:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 32a:	02b57663          	bgeu	a0,a1,356 <memmove+0x32>
    while(n-- > 0)
 32e:	02c05163          	blez	a2,350 <memmove+0x2c>
 332:	fff6079b          	addiw	a5,a2,-1
 336:	1782                	slli	a5,a5,0x20
 338:	9381                	srli	a5,a5,0x20
 33a:	0785                	addi	a5,a5,1
 33c:	97aa                	add	a5,a5,a0
  dst = vdst;
 33e:	872a                	mv	a4,a0
      *dst++ = *src++;
 340:	0585                	addi	a1,a1,1
 342:	0705                	addi	a4,a4,1
 344:	fff5c683          	lbu	a3,-1(a1)
 348:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 34c:	fee79ae3          	bne	a5,a4,340 <memmove+0x1c>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 350:	6422                	ld	s0,8(sp)
 352:	0141                	addi	sp,sp,16
 354:	8082                	ret
    dst += n;
 356:	00c50733          	add	a4,a0,a2
    src += n;
 35a:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 35c:	fec05ae3          	blez	a2,350 <memmove+0x2c>
 360:	fff6079b          	addiw	a5,a2,-1
 364:	1782                	slli	a5,a5,0x20
 366:	9381                	srli	a5,a5,0x20
 368:	fff7c793          	not	a5,a5
 36c:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 36e:	15fd                	addi	a1,a1,-1
 370:	177d                	addi	a4,a4,-1
 372:	0005c683          	lbu	a3,0(a1)
 376:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 37a:	fee79ae3          	bne	a5,a4,36e <memmove+0x4a>
 37e:	bfc9                	j	350 <memmove+0x2c>

0000000000000380 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 380:	1141                	addi	sp,sp,-16
 382:	e422                	sd	s0,8(sp)
 384:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 386:	ca05                	beqz	a2,3b6 <memcmp+0x36>
 388:	fff6069b          	addiw	a3,a2,-1
 38c:	1682                	slli	a3,a3,0x20
 38e:	9281                	srli	a3,a3,0x20
 390:	0685                	addi	a3,a3,1
 392:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 394:	00054783          	lbu	a5,0(a0)
 398:	0005c703          	lbu	a4,0(a1)
 39c:	00e79863          	bne	a5,a4,3ac <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 3a0:	0505                	addi	a0,a0,1
    p2++;
 3a2:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 3a4:	fed518e3          	bne	a0,a3,394 <memcmp+0x14>
  }
  return 0;
 3a8:	4501                	li	a0,0
 3aa:	a019                	j	3b0 <memcmp+0x30>
      return *p1 - *p2;
 3ac:	40e7853b          	subw	a0,a5,a4
}
 3b0:	6422                	ld	s0,8(sp)
 3b2:	0141                	addi	sp,sp,16
 3b4:	8082                	ret
  return 0;
 3b6:	4501                	li	a0,0
 3b8:	bfe5                	j	3b0 <memcmp+0x30>

00000000000003ba <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 3ba:	1141                	addi	sp,sp,-16
 3bc:	e406                	sd	ra,8(sp)
 3be:	e022                	sd	s0,0(sp)
 3c0:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 3c2:	f63ff0ef          	jal	ra,324 <memmove>
}
 3c6:	60a2                	ld	ra,8(sp)
 3c8:	6402                	ld	s0,0(sp)
 3ca:	0141                	addi	sp,sp,16
 3cc:	8082                	ret

00000000000003ce <sbrk>:

char *
sbrk(int n) {
 3ce:	1141                	addi	sp,sp,-16
 3d0:	e406                	sd	ra,8(sp)
 3d2:	e022                	sd	s0,0(sp)
 3d4:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 3d6:	4585                	li	a1,1
 3d8:	0b2000ef          	jal	ra,48a <sys_sbrk>
}
 3dc:	60a2                	ld	ra,8(sp)
 3de:	6402                	ld	s0,0(sp)
 3e0:	0141                	addi	sp,sp,16
 3e2:	8082                	ret

00000000000003e4 <sbrklazy>:

char *
sbrklazy(int n) {
 3e4:	1141                	addi	sp,sp,-16
 3e6:	e406                	sd	ra,8(sp)
 3e8:	e022                	sd	s0,0(sp)
 3ea:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 3ec:	4589                	li	a1,2
 3ee:	09c000ef          	jal	ra,48a <sys_sbrk>
}
 3f2:	60a2                	ld	ra,8(sp)
 3f4:	6402                	ld	s0,0(sp)
 3f6:	0141                	addi	sp,sp,16
 3f8:	8082                	ret

00000000000003fa <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 3fa:	4885                	li	a7,1
 ecall
 3fc:	00000073          	ecall
 ret
 400:	8082                	ret

0000000000000402 <exit>:
.global exit
exit:
 li a7, SYS_exit
 402:	4889                	li	a7,2
 ecall
 404:	00000073          	ecall
 ret
 408:	8082                	ret

000000000000040a <wait>:
.global wait
wait:
 li a7, SYS_wait
 40a:	488d                	li	a7,3
 ecall
 40c:	00000073          	ecall
 ret
 410:	8082                	ret

0000000000000412 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 412:	4891                	li	a7,4
 ecall
 414:	00000073          	ecall
 ret
 418:	8082                	ret

000000000000041a <read>:
.global read
read:
 li a7, SYS_read
 41a:	4895                	li	a7,5
 ecall
 41c:	00000073          	ecall
 ret
 420:	8082                	ret

0000000000000422 <write>:
.global write
write:
 li a7, SYS_write
 422:	48c1                	li	a7,16
 ecall
 424:	00000073          	ecall
 ret
 428:	8082                	ret

000000000000042a <close>:
.global close
close:
 li a7, SYS_close
 42a:	48d5                	li	a7,21
 ecall
 42c:	00000073          	ecall
 ret
 430:	8082                	ret

0000000000000432 <kill>:
.global kill
kill:
 li a7, SYS_kill
 432:	4899                	li	a7,6
 ecall
 434:	00000073          	ecall
 ret
 438:	8082                	ret

000000000000043a <exec>:
.global exec
exec:
 li a7, SYS_exec
 43a:	489d                	li	a7,7
 ecall
 43c:	00000073          	ecall
 ret
 440:	8082                	ret

0000000000000442 <open>:
.global open
open:
 li a7, SYS_open
 442:	48bd                	li	a7,15
 ecall
 444:	00000073          	ecall
 ret
 448:	8082                	ret

000000000000044a <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 44a:	48c5                	li	a7,17
 ecall
 44c:	00000073          	ecall
 ret
 450:	8082                	ret

0000000000000452 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 452:	48c9                	li	a7,18
 ecall
 454:	00000073          	ecall
 ret
 458:	8082                	ret

000000000000045a <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 45a:	48a1                	li	a7,8
 ecall
 45c:	00000073          	ecall
 ret
 460:	8082                	ret

0000000000000462 <link>:
.global link
link:
 li a7, SYS_link
 462:	48cd                	li	a7,19
 ecall
 464:	00000073          	ecall
 ret
 468:	8082                	ret

000000000000046a <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 46a:	48d1                	li	a7,20
 ecall
 46c:	00000073          	ecall
 ret
 470:	8082                	ret

0000000000000472 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 472:	48a5                	li	a7,9
 ecall
 474:	00000073          	ecall
 ret
 478:	8082                	ret

000000000000047a <dup>:
.global dup
dup:
 li a7, SYS_dup
 47a:	48a9                	li	a7,10
 ecall
 47c:	00000073          	ecall
 ret
 480:	8082                	ret

0000000000000482 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 482:	48ad                	li	a7,11
 ecall
 484:	00000073          	ecall
 ret
 488:	8082                	ret

000000000000048a <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 48a:	48b1                	li	a7,12
 ecall
 48c:	00000073          	ecall
 ret
 490:	8082                	ret

0000000000000492 <pause>:
.global pause
pause:
 li a7, SYS_pause
 492:	48b5                	li	a7,13
 ecall
 494:	00000073          	ecall
 ret
 498:	8082                	ret

000000000000049a <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 49a:	48b9                	li	a7,14
 ecall
 49c:	00000073          	ecall
 ret
 4a0:	8082                	ret

00000000000004a2 <getnice>:
.global getnice
getnice:
 li a7, SYS_getnice
 4a2:	48d9                	li	a7,22
 ecall
 4a4:	00000073          	ecall
 ret
 4a8:	8082                	ret

00000000000004aa <setnice>:
.global setnice
setnice:
 li a7, SYS_setnice
 4aa:	48dd                	li	a7,23
 ecall
 4ac:	00000073          	ecall
 ret
 4b0:	8082                	ret

00000000000004b2 <ps>:
.global ps
ps:
 li a7, SYS_ps
 4b2:	48e1                	li	a7,24
 ecall
 4b4:	00000073          	ecall
 ret
 4b8:	8082                	ret

00000000000004ba <meminfo>:
.global meminfo
meminfo:
 li a7, SYS_meminfo
 4ba:	48e5                	li	a7,25
 ecall
 4bc:	00000073          	ecall
 ret
 4c0:	8082                	ret

00000000000004c2 <waitpid>:
.global waitpid
waitpid:
 li a7, SYS_waitpid
 4c2:	48e9                	li	a7,26
 ecall
 4c4:	00000073          	ecall
 ret
 4c8:	8082                	ret

00000000000004ca <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 4ca:	1101                	addi	sp,sp,-32
 4cc:	ec06                	sd	ra,24(sp)
 4ce:	e822                	sd	s0,16(sp)
 4d0:	1000                	addi	s0,sp,32
 4d2:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 4d6:	4605                	li	a2,1
 4d8:	fef40593          	addi	a1,s0,-17
 4dc:	f47ff0ef          	jal	ra,422 <write>
}
 4e0:	60e2                	ld	ra,24(sp)
 4e2:	6442                	ld	s0,16(sp)
 4e4:	6105                	addi	sp,sp,32
 4e6:	8082                	ret

00000000000004e8 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 4e8:	715d                	addi	sp,sp,-80
 4ea:	e486                	sd	ra,72(sp)
 4ec:	e0a2                	sd	s0,64(sp)
 4ee:	fc26                	sd	s1,56(sp)
 4f0:	f84a                	sd	s2,48(sp)
 4f2:	f44e                	sd	s3,40(sp)
 4f4:	0880                	addi	s0,sp,80
 4f6:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 4f8:	c299                	beqz	a3,4fe <printint+0x16>
 4fa:	0805c163          	bltz	a1,57c <printint+0x94>
  neg = 0;
 4fe:	4881                	li	a7,0
 500:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 504:	4781                	li	a5,0
  do{
    buf[i++] = digits[x % base];
 506:	00000517          	auipc	a0,0x0
 50a:	5ca50513          	addi	a0,a0,1482 # ad0 <digits>
 50e:	883e                	mv	a6,a5
 510:	2785                	addiw	a5,a5,1
 512:	02c5f733          	remu	a4,a1,a2
 516:	972a                	add	a4,a4,a0
 518:	00074703          	lbu	a4,0(a4)
 51c:	00e68023          	sb	a4,0(a3)
  }while((x /= base) != 0);
 520:	872e                	mv	a4,a1
 522:	02c5d5b3          	divu	a1,a1,a2
 526:	0685                	addi	a3,a3,1
 528:	fec773e3          	bgeu	a4,a2,50e <printint+0x26>
  if(neg)
 52c:	00088b63          	beqz	a7,542 <printint+0x5a>
    buf[i++] = '-';
 530:	fd040713          	addi	a4,s0,-48
 534:	97ba                	add	a5,a5,a4
 536:	02d00713          	li	a4,45
 53a:	fee78423          	sb	a4,-24(a5)
 53e:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
 542:	02f05663          	blez	a5,56e <printint+0x86>
 546:	fb840713          	addi	a4,s0,-72
 54a:	00f704b3          	add	s1,a4,a5
 54e:	fff70993          	addi	s3,a4,-1
 552:	99be                	add	s3,s3,a5
 554:	37fd                	addiw	a5,a5,-1
 556:	1782                	slli	a5,a5,0x20
 558:	9381                	srli	a5,a5,0x20
 55a:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 55e:	fff4c583          	lbu	a1,-1(s1)
 562:	854a                	mv	a0,s2
 564:	f67ff0ef          	jal	ra,4ca <putc>
  while(--i >= 0)
 568:	14fd                	addi	s1,s1,-1
 56a:	ff349ae3          	bne	s1,s3,55e <printint+0x76>
}
 56e:	60a6                	ld	ra,72(sp)
 570:	6406                	ld	s0,64(sp)
 572:	74e2                	ld	s1,56(sp)
 574:	7942                	ld	s2,48(sp)
 576:	79a2                	ld	s3,40(sp)
 578:	6161                	addi	sp,sp,80
 57a:	8082                	ret
    x = -xx;
 57c:	40b005b3          	neg	a1,a1
    neg = 1;
 580:	4885                	li	a7,1
    x = -xx;
 582:	bfbd                	j	500 <printint+0x18>

0000000000000584 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 584:	7119                	addi	sp,sp,-128
 586:	fc86                	sd	ra,120(sp)
 588:	f8a2                	sd	s0,112(sp)
 58a:	f4a6                	sd	s1,104(sp)
 58c:	f0ca                	sd	s2,96(sp)
 58e:	ecce                	sd	s3,88(sp)
 590:	e8d2                	sd	s4,80(sp)
 592:	e4d6                	sd	s5,72(sp)
 594:	e0da                	sd	s6,64(sp)
 596:	fc5e                	sd	s7,56(sp)
 598:	f862                	sd	s8,48(sp)
 59a:	f466                	sd	s9,40(sp)
 59c:	f06a                	sd	s10,32(sp)
 59e:	ec6e                	sd	s11,24(sp)
 5a0:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 5a2:	0005c903          	lbu	s2,0(a1)
 5a6:	24090c63          	beqz	s2,7fe <vprintf+0x27a>
 5aa:	8b2a                	mv	s6,a0
 5ac:	8a2e                	mv	s4,a1
 5ae:	8bb2                	mv	s7,a2
  state = 0;
 5b0:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 5b2:	4481                	li	s1,0
 5b4:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 5b6:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 5ba:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 5be:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 5c2:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 5c6:	00000c97          	auipc	s9,0x0
 5ca:	50ac8c93          	addi	s9,s9,1290 # ad0 <digits>
 5ce:	a005                	j	5ee <vprintf+0x6a>
        putc(fd, c0);
 5d0:	85ca                	mv	a1,s2
 5d2:	855a                	mv	a0,s6
 5d4:	ef7ff0ef          	jal	ra,4ca <putc>
 5d8:	a019                	j	5de <vprintf+0x5a>
    } else if(state == '%'){
 5da:	03598263          	beq	s3,s5,5fe <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 5de:	2485                	addiw	s1,s1,1
 5e0:	8726                	mv	a4,s1
 5e2:	009a07b3          	add	a5,s4,s1
 5e6:	0007c903          	lbu	s2,0(a5)
 5ea:	20090a63          	beqz	s2,7fe <vprintf+0x27a>
    c0 = fmt[i] & 0xff;
 5ee:	0009079b          	sext.w	a5,s2
    if(state == 0){
 5f2:	fe0994e3          	bnez	s3,5da <vprintf+0x56>
      if(c0 == '%'){
 5f6:	fd579de3          	bne	a5,s5,5d0 <vprintf+0x4c>
        state = '%';
 5fa:	89be                	mv	s3,a5
 5fc:	b7cd                	j	5de <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
 5fe:	c3c1                	beqz	a5,67e <vprintf+0xfa>
 600:	00ea06b3          	add	a3,s4,a4
 604:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 608:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 60a:	c681                	beqz	a3,612 <vprintf+0x8e>
 60c:	9752                	add	a4,a4,s4
 60e:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 612:	03878e63          	beq	a5,s8,64e <vprintf+0xca>
      } else if(c0 == 'l' && c1 == 'd'){
 616:	05a78863          	beq	a5,s10,666 <vprintf+0xe2>
      } else if(c0 == 'u'){
 61a:	0db78b63          	beq	a5,s11,6f0 <vprintf+0x16c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 61e:	07800713          	li	a4,120
 622:	10e78d63          	beq	a5,a4,73c <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 626:	07000713          	li	a4,112
 62a:	14e78263          	beq	a5,a4,76e <vprintf+0x1ea>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 62e:	06300713          	li	a4,99
 632:	16e78f63          	beq	a5,a4,7b0 <vprintf+0x22c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 636:	07300713          	li	a4,115
 63a:	18e78563          	beq	a5,a4,7c4 <vprintf+0x240>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 63e:	05579063          	bne	a5,s5,67e <vprintf+0xfa>
        putc(fd, '%');
 642:	85d6                	mv	a1,s5
 644:	855a                	mv	a0,s6
 646:	e85ff0ef          	jal	ra,4ca <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 64a:	4981                	li	s3,0
 64c:	bf49                	j	5de <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
 64e:	008b8913          	addi	s2,s7,8
 652:	4685                	li	a3,1
 654:	4629                	li	a2,10
 656:	000ba583          	lw	a1,0(s7)
 65a:	855a                	mv	a0,s6
 65c:	e8dff0ef          	jal	ra,4e8 <printint>
 660:	8bca                	mv	s7,s2
      state = 0;
 662:	4981                	li	s3,0
 664:	bfad                	j	5de <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
 666:	03868663          	beq	a3,s8,692 <vprintf+0x10e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 66a:	05a68163          	beq	a3,s10,6ac <vprintf+0x128>
      } else if(c0 == 'l' && c1 == 'u'){
 66e:	09b68d63          	beq	a3,s11,708 <vprintf+0x184>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 672:	03a68f63          	beq	a3,s10,6b0 <vprintf+0x12c>
      } else if(c0 == 'l' && c1 == 'x'){
 676:	07800793          	li	a5,120
 67a:	0cf68d63          	beq	a3,a5,754 <vprintf+0x1d0>
        putc(fd, '%');
 67e:	85d6                	mv	a1,s5
 680:	855a                	mv	a0,s6
 682:	e49ff0ef          	jal	ra,4ca <putc>
        putc(fd, c0);
 686:	85ca                	mv	a1,s2
 688:	855a                	mv	a0,s6
 68a:	e41ff0ef          	jal	ra,4ca <putc>
      state = 0;
 68e:	4981                	li	s3,0
 690:	b7b9                	j	5de <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 692:	008b8913          	addi	s2,s7,8
 696:	4685                	li	a3,1
 698:	4629                	li	a2,10
 69a:	000bb583          	ld	a1,0(s7)
 69e:	855a                	mv	a0,s6
 6a0:	e49ff0ef          	jal	ra,4e8 <printint>
        i += 1;
 6a4:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 6a6:	8bca                	mv	s7,s2
      state = 0;
 6a8:	4981                	li	s3,0
        i += 1;
 6aa:	bf15                	j	5de <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6ac:	03860563          	beq	a2,s8,6d6 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 6b0:	07b60963          	beq	a2,s11,722 <vprintf+0x19e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 6b4:	07800793          	li	a5,120
 6b8:	fcf613e3          	bne	a2,a5,67e <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6bc:	008b8913          	addi	s2,s7,8
 6c0:	4681                	li	a3,0
 6c2:	4641                	li	a2,16
 6c4:	000bb583          	ld	a1,0(s7)
 6c8:	855a                	mv	a0,s6
 6ca:	e1fff0ef          	jal	ra,4e8 <printint>
        i += 2;
 6ce:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 6d0:	8bca                	mv	s7,s2
      state = 0;
 6d2:	4981                	li	s3,0
        i += 2;
 6d4:	b729                	j	5de <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 6d6:	008b8913          	addi	s2,s7,8
 6da:	4685                	li	a3,1
 6dc:	4629                	li	a2,10
 6de:	000bb583          	ld	a1,0(s7)
 6e2:	855a                	mv	a0,s6
 6e4:	e05ff0ef          	jal	ra,4e8 <printint>
        i += 2;
 6e8:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 6ea:	8bca                	mv	s7,s2
      state = 0;
 6ec:	4981                	li	s3,0
        i += 2;
 6ee:	bdc5                	j	5de <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 6f0:	008b8913          	addi	s2,s7,8
 6f4:	4681                	li	a3,0
 6f6:	4629                	li	a2,10
 6f8:	000be583          	lwu	a1,0(s7)
 6fc:	855a                	mv	a0,s6
 6fe:	debff0ef          	jal	ra,4e8 <printint>
 702:	8bca                	mv	s7,s2
      state = 0;
 704:	4981                	li	s3,0
 706:	bde1                	j	5de <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 708:	008b8913          	addi	s2,s7,8
 70c:	4681                	li	a3,0
 70e:	4629                	li	a2,10
 710:	000bb583          	ld	a1,0(s7)
 714:	855a                	mv	a0,s6
 716:	dd3ff0ef          	jal	ra,4e8 <printint>
        i += 1;
 71a:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 71c:	8bca                	mv	s7,s2
      state = 0;
 71e:	4981                	li	s3,0
        i += 1;
 720:	bd7d                	j	5de <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 722:	008b8913          	addi	s2,s7,8
 726:	4681                	li	a3,0
 728:	4629                	li	a2,10
 72a:	000bb583          	ld	a1,0(s7)
 72e:	855a                	mv	a0,s6
 730:	db9ff0ef          	jal	ra,4e8 <printint>
        i += 2;
 734:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 736:	8bca                	mv	s7,s2
      state = 0;
 738:	4981                	li	s3,0
        i += 2;
 73a:	b555                	j	5de <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 73c:	008b8913          	addi	s2,s7,8
 740:	4681                	li	a3,0
 742:	4641                	li	a2,16
 744:	000be583          	lwu	a1,0(s7)
 748:	855a                	mv	a0,s6
 74a:	d9fff0ef          	jal	ra,4e8 <printint>
 74e:	8bca                	mv	s7,s2
      state = 0;
 750:	4981                	li	s3,0
 752:	b571                	j	5de <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 754:	008b8913          	addi	s2,s7,8
 758:	4681                	li	a3,0
 75a:	4641                	li	a2,16
 75c:	000bb583          	ld	a1,0(s7)
 760:	855a                	mv	a0,s6
 762:	d87ff0ef          	jal	ra,4e8 <printint>
        i += 1;
 766:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 768:	8bca                	mv	s7,s2
      state = 0;
 76a:	4981                	li	s3,0
        i += 1;
 76c:	bd8d                	j	5de <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
 76e:	008b8793          	addi	a5,s7,8
 772:	f8f43423          	sd	a5,-120(s0)
 776:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 77a:	03000593          	li	a1,48
 77e:	855a                	mv	a0,s6
 780:	d4bff0ef          	jal	ra,4ca <putc>
  putc(fd, 'x');
 784:	07800593          	li	a1,120
 788:	855a                	mv	a0,s6
 78a:	d41ff0ef          	jal	ra,4ca <putc>
 78e:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 790:	03c9d793          	srli	a5,s3,0x3c
 794:	97e6                	add	a5,a5,s9
 796:	0007c583          	lbu	a1,0(a5)
 79a:	855a                	mv	a0,s6
 79c:	d2fff0ef          	jal	ra,4ca <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 7a0:	0992                	slli	s3,s3,0x4
 7a2:	397d                	addiw	s2,s2,-1
 7a4:	fe0916e3          	bnez	s2,790 <vprintf+0x20c>
        printptr(fd, va_arg(ap, uint64));
 7a8:	f8843b83          	ld	s7,-120(s0)
      state = 0;
 7ac:	4981                	li	s3,0
 7ae:	bd05                	j	5de <vprintf+0x5a>
        putc(fd, va_arg(ap, uint32));
 7b0:	008b8913          	addi	s2,s7,8
 7b4:	000bc583          	lbu	a1,0(s7)
 7b8:	855a                	mv	a0,s6
 7ba:	d11ff0ef          	jal	ra,4ca <putc>
 7be:	8bca                	mv	s7,s2
      state = 0;
 7c0:	4981                	li	s3,0
 7c2:	bd31                	j	5de <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
 7c4:	008b8993          	addi	s3,s7,8
 7c8:	000bb903          	ld	s2,0(s7)
 7cc:	00090f63          	beqz	s2,7ea <vprintf+0x266>
        for(; *s; s++)
 7d0:	00094583          	lbu	a1,0(s2)
 7d4:	c195                	beqz	a1,7f8 <vprintf+0x274>
          putc(fd, *s);
 7d6:	855a                	mv	a0,s6
 7d8:	cf3ff0ef          	jal	ra,4ca <putc>
        for(; *s; s++)
 7dc:	0905                	addi	s2,s2,1
 7de:	00094583          	lbu	a1,0(s2)
 7e2:	f9f5                	bnez	a1,7d6 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 7e4:	8bce                	mv	s7,s3
      state = 0;
 7e6:	4981                	li	s3,0
 7e8:	bbdd                	j	5de <vprintf+0x5a>
          s = "(null)";
 7ea:	00000917          	auipc	s2,0x0
 7ee:	2de90913          	addi	s2,s2,734 # ac8 <malloc+0x1c8>
        for(; *s; s++)
 7f2:	02800593          	li	a1,40
 7f6:	b7c5                	j	7d6 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 7f8:	8bce                	mv	s7,s3
      state = 0;
 7fa:	4981                	li	s3,0
 7fc:	b3cd                	j	5de <vprintf+0x5a>
    }
  }
}
 7fe:	70e6                	ld	ra,120(sp)
 800:	7446                	ld	s0,112(sp)
 802:	74a6                	ld	s1,104(sp)
 804:	7906                	ld	s2,96(sp)
 806:	69e6                	ld	s3,88(sp)
 808:	6a46                	ld	s4,80(sp)
 80a:	6aa6                	ld	s5,72(sp)
 80c:	6b06                	ld	s6,64(sp)
 80e:	7be2                	ld	s7,56(sp)
 810:	7c42                	ld	s8,48(sp)
 812:	7ca2                	ld	s9,40(sp)
 814:	7d02                	ld	s10,32(sp)
 816:	6de2                	ld	s11,24(sp)
 818:	6109                	addi	sp,sp,128
 81a:	8082                	ret

000000000000081c <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 81c:	715d                	addi	sp,sp,-80
 81e:	ec06                	sd	ra,24(sp)
 820:	e822                	sd	s0,16(sp)
 822:	1000                	addi	s0,sp,32
 824:	e010                	sd	a2,0(s0)
 826:	e414                	sd	a3,8(s0)
 828:	e818                	sd	a4,16(s0)
 82a:	ec1c                	sd	a5,24(s0)
 82c:	03043023          	sd	a6,32(s0)
 830:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 834:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 838:	8622                	mv	a2,s0
 83a:	d4bff0ef          	jal	ra,584 <vprintf>
}
 83e:	60e2                	ld	ra,24(sp)
 840:	6442                	ld	s0,16(sp)
 842:	6161                	addi	sp,sp,80
 844:	8082                	ret

0000000000000846 <printf>:

void
printf(const char *fmt, ...)
{
 846:	711d                	addi	sp,sp,-96
 848:	ec06                	sd	ra,24(sp)
 84a:	e822                	sd	s0,16(sp)
 84c:	1000                	addi	s0,sp,32
 84e:	e40c                	sd	a1,8(s0)
 850:	e810                	sd	a2,16(s0)
 852:	ec14                	sd	a3,24(s0)
 854:	f018                	sd	a4,32(s0)
 856:	f41c                	sd	a5,40(s0)
 858:	03043823          	sd	a6,48(s0)
 85c:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 860:	00840613          	addi	a2,s0,8
 864:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 868:	85aa                	mv	a1,a0
 86a:	4505                	li	a0,1
 86c:	d19ff0ef          	jal	ra,584 <vprintf>
}
 870:	60e2                	ld	ra,24(sp)
 872:	6442                	ld	s0,16(sp)
 874:	6125                	addi	sp,sp,96
 876:	8082                	ret

0000000000000878 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 878:	1141                	addi	sp,sp,-16
 87a:	e422                	sd	s0,8(sp)
 87c:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 87e:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 882:	00000797          	auipc	a5,0x0
 886:	77e7b783          	ld	a5,1918(a5) # 1000 <freep>
 88a:	a805                	j	8ba <free+0x42>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 88c:	4618                	lw	a4,8(a2)
 88e:	9db9                	addw	a1,a1,a4
 890:	feb52c23          	sw	a1,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 894:	6398                	ld	a4,0(a5)
 896:	6318                	ld	a4,0(a4)
 898:	fee53823          	sd	a4,-16(a0)
 89c:	a091                	j	8e0 <free+0x68>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 89e:	ff852703          	lw	a4,-8(a0)
 8a2:	9e39                	addw	a2,a2,a4
 8a4:	c790                	sw	a2,8(a5)
    p->s.ptr = bp->s.ptr;
 8a6:	ff053703          	ld	a4,-16(a0)
 8aa:	e398                	sd	a4,0(a5)
 8ac:	a099                	j	8f2 <free+0x7a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8ae:	6398                	ld	a4,0(a5)
 8b0:	00e7e463          	bltu	a5,a4,8b8 <free+0x40>
 8b4:	00e6ea63          	bltu	a3,a4,8c8 <free+0x50>
{
 8b8:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8ba:	fed7fae3          	bgeu	a5,a3,8ae <free+0x36>
 8be:	6398                	ld	a4,0(a5)
 8c0:	00e6e463          	bltu	a3,a4,8c8 <free+0x50>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8c4:	fee7eae3          	bltu	a5,a4,8b8 <free+0x40>
  if(bp + bp->s.size == p->s.ptr){
 8c8:	ff852583          	lw	a1,-8(a0)
 8cc:	6390                	ld	a2,0(a5)
 8ce:	02059713          	slli	a4,a1,0x20
 8d2:	9301                	srli	a4,a4,0x20
 8d4:	0712                	slli	a4,a4,0x4
 8d6:	9736                	add	a4,a4,a3
 8d8:	fae60ae3          	beq	a2,a4,88c <free+0x14>
    bp->s.ptr = p->s.ptr;
 8dc:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 8e0:	4790                	lw	a2,8(a5)
 8e2:	02061713          	slli	a4,a2,0x20
 8e6:	9301                	srli	a4,a4,0x20
 8e8:	0712                	slli	a4,a4,0x4
 8ea:	973e                	add	a4,a4,a5
 8ec:	fae689e3          	beq	a3,a4,89e <free+0x26>
  } else
    p->s.ptr = bp;
 8f0:	e394                	sd	a3,0(a5)
  freep = p;
 8f2:	00000717          	auipc	a4,0x0
 8f6:	70f73723          	sd	a5,1806(a4) # 1000 <freep>
}
 8fa:	6422                	ld	s0,8(sp)
 8fc:	0141                	addi	sp,sp,16
 8fe:	8082                	ret

0000000000000900 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 900:	7139                	addi	sp,sp,-64
 902:	fc06                	sd	ra,56(sp)
 904:	f822                	sd	s0,48(sp)
 906:	f426                	sd	s1,40(sp)
 908:	f04a                	sd	s2,32(sp)
 90a:	ec4e                	sd	s3,24(sp)
 90c:	e852                	sd	s4,16(sp)
 90e:	e456                	sd	s5,8(sp)
 910:	e05a                	sd	s6,0(sp)
 912:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 914:	02051493          	slli	s1,a0,0x20
 918:	9081                	srli	s1,s1,0x20
 91a:	04bd                	addi	s1,s1,15
 91c:	8091                	srli	s1,s1,0x4
 91e:	0014899b          	addiw	s3,s1,1
 922:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 924:	00000517          	auipc	a0,0x0
 928:	6dc53503          	ld	a0,1756(a0) # 1000 <freep>
 92c:	c515                	beqz	a0,958 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 92e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 930:	4798                	lw	a4,8(a5)
 932:	02977f63          	bgeu	a4,s1,970 <malloc+0x70>
 936:	8a4e                	mv	s4,s3
 938:	0009871b          	sext.w	a4,s3
 93c:	6685                	lui	a3,0x1
 93e:	00d77363          	bgeu	a4,a3,944 <malloc+0x44>
 942:	6a05                	lui	s4,0x1
 944:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 948:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 94c:	00000917          	auipc	s2,0x0
 950:	6b490913          	addi	s2,s2,1716 # 1000 <freep>
  if(p == SBRK_ERROR)
 954:	5afd                	li	s5,-1
 956:	a0bd                	j	9c4 <malloc+0xc4>
    base.s.ptr = freep = prevp = &base;
 958:	00000797          	auipc	a5,0x0
 95c:	6b878793          	addi	a5,a5,1720 # 1010 <base>
 960:	00000717          	auipc	a4,0x0
 964:	6af73023          	sd	a5,1696(a4) # 1000 <freep>
 968:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 96a:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 96e:	b7e1                	j	936 <malloc+0x36>
      if(p->s.size == nunits)
 970:	02e48b63          	beq	s1,a4,9a6 <malloc+0xa6>
        p->s.size -= nunits;
 974:	4137073b          	subw	a4,a4,s3
 978:	c798                	sw	a4,8(a5)
        p += p->s.size;
 97a:	1702                	slli	a4,a4,0x20
 97c:	9301                	srli	a4,a4,0x20
 97e:	0712                	slli	a4,a4,0x4
 980:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 982:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 986:	00000717          	auipc	a4,0x0
 98a:	66a73d23          	sd	a0,1658(a4) # 1000 <freep>
      return (void*)(p + 1);
 98e:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 992:	70e2                	ld	ra,56(sp)
 994:	7442                	ld	s0,48(sp)
 996:	74a2                	ld	s1,40(sp)
 998:	7902                	ld	s2,32(sp)
 99a:	69e2                	ld	s3,24(sp)
 99c:	6a42                	ld	s4,16(sp)
 99e:	6aa2                	ld	s5,8(sp)
 9a0:	6b02                	ld	s6,0(sp)
 9a2:	6121                	addi	sp,sp,64
 9a4:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 9a6:	6398                	ld	a4,0(a5)
 9a8:	e118                	sd	a4,0(a0)
 9aa:	bff1                	j	986 <malloc+0x86>
  hp->s.size = nu;
 9ac:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 9b0:	0541                	addi	a0,a0,16
 9b2:	ec7ff0ef          	jal	ra,878 <free>
  return freep;
 9b6:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 9ba:	dd61                	beqz	a0,992 <malloc+0x92>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 9bc:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 9be:	4798                	lw	a4,8(a5)
 9c0:	fa9778e3          	bgeu	a4,s1,970 <malloc+0x70>
    if(p == freep)
 9c4:	00093703          	ld	a4,0(s2)
 9c8:	853e                	mv	a0,a5
 9ca:	fef719e3          	bne	a4,a5,9bc <malloc+0xbc>
  p = sbrk(nu * sizeof(Header));
 9ce:	8552                	mv	a0,s4
 9d0:	9ffff0ef          	jal	ra,3ce <sbrk>
  if(p == SBRK_ERROR)
 9d4:	fd551ce3          	bne	a0,s5,9ac <malloc+0xac>
        return 0;
 9d8:	4501                	li	a0,0
 9da:	bf65                	j	992 <malloc+0x92>
