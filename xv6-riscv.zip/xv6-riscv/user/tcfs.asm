
user/_tcfs:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <busy_work>:
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

void busy_work() {
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	ec26                	sd	s1,24(sp)
   8:	e84a                	sd	s2,16(sp)
   a:	e44e                	sd	s3,8(sp)
   c:	e052                	sd	s4,0(sp)
   e:	1800                	addi	s0,sp,48
    int start = uptime();
  10:	482000ef          	jal	ra,492 <uptime>
  14:	8a2a                	mv	s4,a0
    int x = 0, z = 20, i, j;
    while ((uptime() - start) < 4) {
  16:	490d                	li	s2,3
  18:	67e1                	lui	a5,0x18
  1a:	6a078993          	addi	s3,a5,1696 # 186a0 <base+0x17690>
void busy_work() {
  1e:	6489                	lui	s1,0x2
  20:	71048493          	addi	s1,s1,1808 # 2710 <base+0x1700>
    while ((uptime() - start) < 4) {
  24:	46e000ef          	jal	ra,492 <uptime>
  28:	414507bb          	subw	a5,a0,s4
  2c:	00f94a63          	blt	s2,a5,40 <busy_work+0x40>
  30:	874e                	mv	a4,s3
  32:	a019                	j	38 <busy_work+0x38>
        for (i = 0; i < 100000; i++)
  34:	377d                	addiw	a4,a4,-1
  36:	d77d                	beqz	a4,24 <busy_work+0x24>
void busy_work() {
  38:	87a6                	mv	a5,s1
            for (j = 0; j < 10000; j++)
  3a:	37fd                	addiw	a5,a5,-1
  3c:	fffd                	bnez	a5,3a <busy_work+0x3a>
  3e:	bfdd                	j	34 <busy_work+0x34>
                x += z * 89;
    }
}
  40:	70a2                	ld	ra,40(sp)
  42:	7402                	ld	s0,32(sp)
  44:	64e2                	ld	s1,24(sp)
  46:	6942                	ld	s2,16(sp)
  48:	69a2                	ld	s3,8(sp)
  4a:	6a02                	ld	s4,0(sp)
  4c:	6145                	addi	sp,sp,48
  4e:	8082                	ret

0000000000000050 <count_iterations>:

int count_iterations(int duration) {
  50:	7179                	addi	sp,sp,-48
  52:	f406                	sd	ra,40(sp)
  54:	f022                	sd	s0,32(sp)
  56:	ec26                	sd	s1,24(sp)
  58:	e84a                	sd	s2,16(sp)
  5a:	e44e                	sd	s3,8(sp)
  5c:	e052                	sd	s4,0(sp)
  5e:	1800                	addi	s0,sp,48
  60:	89aa                	mv	s3,a0
    int start = uptime();
  62:	430000ef          	jal	ra,492 <uptime>
  66:	892a                	mv	s2,a0
    int x = 0, iterations = 0;
  68:	4481                	li	s1,0
  6a:	3e800a13          	li	s4,1000
    while ((uptime() - start) < duration) {
  6e:	a011                	j	72 <count_iterations+0x22>
        for (int i = 0; i < 1000; i++)
            x += i * 7;
        iterations++;
  70:	2485                	addiw	s1,s1,1
    while ((uptime() - start) < duration) {
  72:	420000ef          	jal	ra,492 <uptime>
  76:	412507bb          	subw	a5,a0,s2
  7a:	0137d663          	bge	a5,s3,86 <count_iterations+0x36>
  7e:	87d2                	mv	a5,s4
        for (int i = 0; i < 1000; i++)
  80:	37fd                	addiw	a5,a5,-1
  82:	fffd                	bnez	a5,80 <count_iterations+0x30>
  84:	b7f5                	j	70 <count_iterations+0x20>
    }
    return iterations;
}
  86:	8526                	mv	a0,s1
  88:	70a2                	ld	ra,40(sp)
  8a:	7402                	ld	s0,32(sp)
  8c:	64e2                	ld	s1,24(sp)
  8e:	6942                	ld	s2,16(sp)
  90:	69a2                	ld	s3,8(sp)
  92:	6a02                	ld	s4,0(sp)
  94:	6145                	addi	sp,sp,48
  96:	8082                	ret

0000000000000098 <main>:

int main(int argc, char **argv) {
  98:	7179                	addi	sp,sp,-48
  9a:	f406                	sd	ra,40(sp)
  9c:	f022                	sd	s0,32(sp)
  9e:	ec26                	sd	s1,24(sp)
  a0:	1800                	addi	s0,sp,48
    printf("=== TEST: Fair Scheduling (same nice) ===\n");
  a2:	00001517          	auipc	a0,0x1
  a6:	93e50513          	addi	a0,a0,-1730 # 9e0 <malloc+0xe8>
  aa:	794000ef          	jal	ra,83e <printf>

    int child1 = fork();
  ae:	344000ef          	jal	ra,3f2 <fork>
    if (child1 == 0) {
  b2:	e519                	bnez	a0,c0 <main+0x28>
        int iters = count_iterations(200);
  b4:	0c800513          	li	a0,200
  b8:	f99ff0ef          	jal	ra,50 <count_iterations>
        exit(iters);
  bc:	33e000ef          	jal	ra,3fa <exit>
    }

    int child2 = fork();
  c0:	332000ef          	jal	ra,3f2 <fork>
    if (child2 == 0) {
  c4:	4491                	li	s1,4
  c6:	c93d                	beqz	a0,13c <main+0xa4>
        exit(iters);
    }

    // Parent runs work with periodic ps() snapshots
    for (int i = 0; i < 4; i++) {
        busy_work();
  c8:	f39ff0ef          	jal	ra,0 <busy_work>
        ps(0);
  cc:	4501                	li	a0,0
  ce:	3dc000ef          	jal	ra,4aa <ps>
    for (int i = 0; i < 4; i++) {
  d2:	34fd                	addiw	s1,s1,-1
  d4:	f8f5                	bnez	s1,c8 <main+0x30>
    }

    int status1, status2;
    wait(&status1);
  d6:	fdc40513          	addi	a0,s0,-36
  da:	328000ef          	jal	ra,402 <wait>
    wait(&status2);
  de:	fd840513          	addi	a0,s0,-40
  e2:	320000ef          	jal	ra,402 <wait>

    // Parent also measures its own iterations for final comparison
    // (use status from children for PASS/FAIL)
    printf("\nIterations — Child1: %d, Child2: %d\n", status1, status2);
  e6:	fd842603          	lw	a2,-40(s0)
  ea:	fdc42583          	lw	a1,-36(s0)
  ee:	00001517          	auipc	a0,0x1
  f2:	92250513          	addi	a0,a0,-1758 # a10 <malloc+0x118>
  f6:	748000ef          	jal	ra,83e <printf>

    // Check: both children should have similar iteration counts (within 30%)
    int max = status1 > status2 ? status1 : status2;
  fa:	fd842683          	lw	a3,-40(s0)
  fe:	fdc42603          	lw	a2,-36(s0)
    int min = status1 < status2 ? status1 : status2;
 102:	85b6                	mv	a1,a3
 104:	00d65363          	bge	a2,a3,10a <main+0x72>
 108:	85b2                	mv	a1,a2
 10a:	0005871b          	sext.w	a4,a1

    if (min > 0 && max * 100 / min <= 140)
 10e:	02e05d63          	blez	a4,148 <main+0xb0>
    int max = status1 > status2 ? status1 : status2;
 112:	87b6                	mv	a5,a3
 114:	00c6d363          	bge	a3,a2,11a <main+0x82>
 118:	87b2                	mv	a5,a2
    if (min > 0 && max * 100 / min <= 140)
 11a:	06400593          	li	a1,100
 11e:	02b785bb          	mulw	a1,a5,a1
 122:	02e5c5bb          	divw	a1,a1,a4
 126:	08c00793          	li	a5,140
 12a:	02b7c063          	blt	a5,a1,14a <main+0xb2>
        printf("[PASS] CPU time is fairly distributed (max/min ratio: %d%%)\n",
 12e:	00001517          	auipc	a0,0x1
 132:	90a50513          	addi	a0,a0,-1782 # a38 <malloc+0x140>
 136:	708000ef          	jal	ra,83e <printf>
 13a:	a831                	j	156 <main+0xbe>
        int iters = count_iterations(200);
 13c:	0c800513          	li	a0,200
 140:	f11ff0ef          	jal	ra,50 <count_iterations>
        exit(iters);
 144:	2b6000ef          	jal	ra,3fa <exit>
            max * 100 / min);
    else
        printf("[FAIL] CPU time is not fairly distributed (max/min ratio: %d%%)\n",
 148:	55fd                	li	a1,-1
 14a:	00001517          	auipc	a0,0x1
 14e:	92e50513          	addi	a0,a0,-1746 # a78 <malloc+0x180>
 152:	6ec000ef          	jal	ra,83e <printf>
            min > 0 ? max * 100 / min : -1);

    exit(0);
 156:	4501                	li	a0,0
 158:	2a2000ef          	jal	ra,3fa <exit>

000000000000015c <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 15c:	1141                	addi	sp,sp,-16
 15e:	e406                	sd	ra,8(sp)
 160:	e022                	sd	s0,0(sp)
 162:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 164:	f35ff0ef          	jal	ra,98 <main>
  exit(r);
 168:	292000ef          	jal	ra,3fa <exit>

000000000000016c <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 16c:	1141                	addi	sp,sp,-16
 16e:	e422                	sd	s0,8(sp)
 170:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 172:	87aa                	mv	a5,a0
 174:	0585                	addi	a1,a1,1
 176:	0785                	addi	a5,a5,1
 178:	fff5c703          	lbu	a4,-1(a1)
 17c:	fee78fa3          	sb	a4,-1(a5)
 180:	fb75                	bnez	a4,174 <strcpy+0x8>
    ;
  return os;
}
 182:	6422                	ld	s0,8(sp)
 184:	0141                	addi	sp,sp,16
 186:	8082                	ret

0000000000000188 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 188:	1141                	addi	sp,sp,-16
 18a:	e422                	sd	s0,8(sp)
 18c:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 18e:	00054783          	lbu	a5,0(a0)
 192:	cb91                	beqz	a5,1a6 <strcmp+0x1e>
 194:	0005c703          	lbu	a4,0(a1)
 198:	00f71763          	bne	a4,a5,1a6 <strcmp+0x1e>
    p++, q++;
 19c:	0505                	addi	a0,a0,1
 19e:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 1a0:	00054783          	lbu	a5,0(a0)
 1a4:	fbe5                	bnez	a5,194 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 1a6:	0005c503          	lbu	a0,0(a1)
}
 1aa:	40a7853b          	subw	a0,a5,a0
 1ae:	6422                	ld	s0,8(sp)
 1b0:	0141                	addi	sp,sp,16
 1b2:	8082                	ret

00000000000001b4 <strlen>:

uint
strlen(const char *s)
{
 1b4:	1141                	addi	sp,sp,-16
 1b6:	e422                	sd	s0,8(sp)
 1b8:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 1ba:	00054783          	lbu	a5,0(a0)
 1be:	cf91                	beqz	a5,1da <strlen+0x26>
 1c0:	0505                	addi	a0,a0,1
 1c2:	87aa                	mv	a5,a0
 1c4:	4685                	li	a3,1
 1c6:	9e89                	subw	a3,a3,a0
 1c8:	00f6853b          	addw	a0,a3,a5
 1cc:	0785                	addi	a5,a5,1
 1ce:	fff7c703          	lbu	a4,-1(a5)
 1d2:	fb7d                	bnez	a4,1c8 <strlen+0x14>
    ;
  return n;
}
 1d4:	6422                	ld	s0,8(sp)
 1d6:	0141                	addi	sp,sp,16
 1d8:	8082                	ret
  for(n = 0; s[n]; n++)
 1da:	4501                	li	a0,0
 1dc:	bfe5                	j	1d4 <strlen+0x20>

00000000000001de <memset>:

void*
memset(void *dst, int c, uint n)
{
 1de:	1141                	addi	sp,sp,-16
 1e0:	e422                	sd	s0,8(sp)
 1e2:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 1e4:	ce09                	beqz	a2,1fe <memset+0x20>
 1e6:	87aa                	mv	a5,a0
 1e8:	fff6071b          	addiw	a4,a2,-1
 1ec:	1702                	slli	a4,a4,0x20
 1ee:	9301                	srli	a4,a4,0x20
 1f0:	0705                	addi	a4,a4,1
 1f2:	972a                	add	a4,a4,a0
    cdst[i] = c;
 1f4:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 1f8:	0785                	addi	a5,a5,1
 1fa:	fee79de3          	bne	a5,a4,1f4 <memset+0x16>
  }
  return dst;
}
 1fe:	6422                	ld	s0,8(sp)
 200:	0141                	addi	sp,sp,16
 202:	8082                	ret

0000000000000204 <strchr>:

char*
strchr(const char *s, char c)
{
 204:	1141                	addi	sp,sp,-16
 206:	e422                	sd	s0,8(sp)
 208:	0800                	addi	s0,sp,16
  for(; *s; s++)
 20a:	00054783          	lbu	a5,0(a0)
 20e:	cb99                	beqz	a5,224 <strchr+0x20>
    if(*s == c)
 210:	00f58763          	beq	a1,a5,21e <strchr+0x1a>
  for(; *s; s++)
 214:	0505                	addi	a0,a0,1
 216:	00054783          	lbu	a5,0(a0)
 21a:	fbfd                	bnez	a5,210 <strchr+0xc>
      return (char*)s;
  return 0;
 21c:	4501                	li	a0,0
}
 21e:	6422                	ld	s0,8(sp)
 220:	0141                	addi	sp,sp,16
 222:	8082                	ret
  return 0;
 224:	4501                	li	a0,0
 226:	bfe5                	j	21e <strchr+0x1a>

0000000000000228 <gets>:

char*
gets(char *buf, int max)
{
 228:	711d                	addi	sp,sp,-96
 22a:	ec86                	sd	ra,88(sp)
 22c:	e8a2                	sd	s0,80(sp)
 22e:	e4a6                	sd	s1,72(sp)
 230:	e0ca                	sd	s2,64(sp)
 232:	fc4e                	sd	s3,56(sp)
 234:	f852                	sd	s4,48(sp)
 236:	f456                	sd	s5,40(sp)
 238:	f05a                	sd	s6,32(sp)
 23a:	ec5e                	sd	s7,24(sp)
 23c:	1080                	addi	s0,sp,96
 23e:	8baa                	mv	s7,a0
 240:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 242:	892a                	mv	s2,a0
 244:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 246:	4aa9                	li	s5,10
 248:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 24a:	89a6                	mv	s3,s1
 24c:	2485                	addiw	s1,s1,1
 24e:	0344d663          	bge	s1,s4,27a <gets+0x52>
    cc = read(0, &c, 1);
 252:	4605                	li	a2,1
 254:	faf40593          	addi	a1,s0,-81
 258:	4501                	li	a0,0
 25a:	1b8000ef          	jal	ra,412 <read>
    if(cc < 1)
 25e:	00a05e63          	blez	a0,27a <gets+0x52>
    buf[i++] = c;
 262:	faf44783          	lbu	a5,-81(s0)
 266:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 26a:	01578763          	beq	a5,s5,278 <gets+0x50>
 26e:	0905                	addi	s2,s2,1
 270:	fd679de3          	bne	a5,s6,24a <gets+0x22>
  for(i=0; i+1 < max; ){
 274:	89a6                	mv	s3,s1
 276:	a011                	j	27a <gets+0x52>
 278:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 27a:	99de                	add	s3,s3,s7
 27c:	00098023          	sb	zero,0(s3)
  return buf;
}
 280:	855e                	mv	a0,s7
 282:	60e6                	ld	ra,88(sp)
 284:	6446                	ld	s0,80(sp)
 286:	64a6                	ld	s1,72(sp)
 288:	6906                	ld	s2,64(sp)
 28a:	79e2                	ld	s3,56(sp)
 28c:	7a42                	ld	s4,48(sp)
 28e:	7aa2                	ld	s5,40(sp)
 290:	7b02                	ld	s6,32(sp)
 292:	6be2                	ld	s7,24(sp)
 294:	6125                	addi	sp,sp,96
 296:	8082                	ret

0000000000000298 <stat>:

int
stat(const char *n, struct stat *st)
{
 298:	1101                	addi	sp,sp,-32
 29a:	ec06                	sd	ra,24(sp)
 29c:	e822                	sd	s0,16(sp)
 29e:	e426                	sd	s1,8(sp)
 2a0:	e04a                	sd	s2,0(sp)
 2a2:	1000                	addi	s0,sp,32
 2a4:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 2a6:	4581                	li	a1,0
 2a8:	192000ef          	jal	ra,43a <open>
  if(fd < 0)
 2ac:	02054163          	bltz	a0,2ce <stat+0x36>
 2b0:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 2b2:	85ca                	mv	a1,s2
 2b4:	19e000ef          	jal	ra,452 <fstat>
 2b8:	892a                	mv	s2,a0
  close(fd);
 2ba:	8526                	mv	a0,s1
 2bc:	166000ef          	jal	ra,422 <close>
  return r;
}
 2c0:	854a                	mv	a0,s2
 2c2:	60e2                	ld	ra,24(sp)
 2c4:	6442                	ld	s0,16(sp)
 2c6:	64a2                	ld	s1,8(sp)
 2c8:	6902                	ld	s2,0(sp)
 2ca:	6105                	addi	sp,sp,32
 2cc:	8082                	ret
    return -1;
 2ce:	597d                	li	s2,-1
 2d0:	bfc5                	j	2c0 <stat+0x28>

00000000000002d2 <atoi>:

int
atoi(const char *s)
{
 2d2:	1141                	addi	sp,sp,-16
 2d4:	e422                	sd	s0,8(sp)
 2d6:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 2d8:	00054603          	lbu	a2,0(a0)
 2dc:	fd06079b          	addiw	a5,a2,-48
 2e0:	0ff7f793          	andi	a5,a5,255
 2e4:	4725                	li	a4,9
 2e6:	02f76963          	bltu	a4,a5,318 <atoi+0x46>
 2ea:	86aa                	mv	a3,a0
  n = 0;
 2ec:	4501                	li	a0,0
  while('0' <= *s && *s <= '9')
 2ee:	45a5                	li	a1,9
    n = n*10 + *s++ - '0';
 2f0:	0685                	addi	a3,a3,1
 2f2:	0025179b          	slliw	a5,a0,0x2
 2f6:	9fa9                	addw	a5,a5,a0
 2f8:	0017979b          	slliw	a5,a5,0x1
 2fc:	9fb1                	addw	a5,a5,a2
 2fe:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 302:	0006c603          	lbu	a2,0(a3)
 306:	fd06071b          	addiw	a4,a2,-48
 30a:	0ff77713          	andi	a4,a4,255
 30e:	fee5f1e3          	bgeu	a1,a4,2f0 <atoi+0x1e>
  return n;
}
 312:	6422                	ld	s0,8(sp)
 314:	0141                	addi	sp,sp,16
 316:	8082                	ret
  n = 0;
 318:	4501                	li	a0,0
 31a:	bfe5                	j	312 <atoi+0x40>

000000000000031c <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 31c:	1141                	addi	sp,sp,-16
 31e:	e422                	sd	s0,8(sp)
 320:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 322:	02b57663          	bgeu	a0,a1,34e <memmove+0x32>
    while(n-- > 0)
 326:	02c05163          	blez	a2,348 <memmove+0x2c>
 32a:	fff6079b          	addiw	a5,a2,-1
 32e:	1782                	slli	a5,a5,0x20
 330:	9381                	srli	a5,a5,0x20
 332:	0785                	addi	a5,a5,1
 334:	97aa                	add	a5,a5,a0
  dst = vdst;
 336:	872a                	mv	a4,a0
      *dst++ = *src++;
 338:	0585                	addi	a1,a1,1
 33a:	0705                	addi	a4,a4,1
 33c:	fff5c683          	lbu	a3,-1(a1)
 340:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 344:	fee79ae3          	bne	a5,a4,338 <memmove+0x1c>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 348:	6422                	ld	s0,8(sp)
 34a:	0141                	addi	sp,sp,16
 34c:	8082                	ret
    dst += n;
 34e:	00c50733          	add	a4,a0,a2
    src += n;
 352:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 354:	fec05ae3          	blez	a2,348 <memmove+0x2c>
 358:	fff6079b          	addiw	a5,a2,-1
 35c:	1782                	slli	a5,a5,0x20
 35e:	9381                	srli	a5,a5,0x20
 360:	fff7c793          	not	a5,a5
 364:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 366:	15fd                	addi	a1,a1,-1
 368:	177d                	addi	a4,a4,-1
 36a:	0005c683          	lbu	a3,0(a1)
 36e:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 372:	fee79ae3          	bne	a5,a4,366 <memmove+0x4a>
 376:	bfc9                	j	348 <memmove+0x2c>

0000000000000378 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 378:	1141                	addi	sp,sp,-16
 37a:	e422                	sd	s0,8(sp)
 37c:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 37e:	ca05                	beqz	a2,3ae <memcmp+0x36>
 380:	fff6069b          	addiw	a3,a2,-1
 384:	1682                	slli	a3,a3,0x20
 386:	9281                	srli	a3,a3,0x20
 388:	0685                	addi	a3,a3,1
 38a:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 38c:	00054783          	lbu	a5,0(a0)
 390:	0005c703          	lbu	a4,0(a1)
 394:	00e79863          	bne	a5,a4,3a4 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 398:	0505                	addi	a0,a0,1
    p2++;
 39a:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 39c:	fed518e3          	bne	a0,a3,38c <memcmp+0x14>
  }
  return 0;
 3a0:	4501                	li	a0,0
 3a2:	a019                	j	3a8 <memcmp+0x30>
      return *p1 - *p2;
 3a4:	40e7853b          	subw	a0,a5,a4
}
 3a8:	6422                	ld	s0,8(sp)
 3aa:	0141                	addi	sp,sp,16
 3ac:	8082                	ret
  return 0;
 3ae:	4501                	li	a0,0
 3b0:	bfe5                	j	3a8 <memcmp+0x30>

00000000000003b2 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 3b2:	1141                	addi	sp,sp,-16
 3b4:	e406                	sd	ra,8(sp)
 3b6:	e022                	sd	s0,0(sp)
 3b8:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 3ba:	f63ff0ef          	jal	ra,31c <memmove>
}
 3be:	60a2                	ld	ra,8(sp)
 3c0:	6402                	ld	s0,0(sp)
 3c2:	0141                	addi	sp,sp,16
 3c4:	8082                	ret

00000000000003c6 <sbrk>:

char *
sbrk(int n) {
 3c6:	1141                	addi	sp,sp,-16
 3c8:	e406                	sd	ra,8(sp)
 3ca:	e022                	sd	s0,0(sp)
 3cc:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 3ce:	4585                	li	a1,1
 3d0:	0b2000ef          	jal	ra,482 <sys_sbrk>
}
 3d4:	60a2                	ld	ra,8(sp)
 3d6:	6402                	ld	s0,0(sp)
 3d8:	0141                	addi	sp,sp,16
 3da:	8082                	ret

00000000000003dc <sbrklazy>:

char *
sbrklazy(int n) {
 3dc:	1141                	addi	sp,sp,-16
 3de:	e406                	sd	ra,8(sp)
 3e0:	e022                	sd	s0,0(sp)
 3e2:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 3e4:	4589                	li	a1,2
 3e6:	09c000ef          	jal	ra,482 <sys_sbrk>
}
 3ea:	60a2                	ld	ra,8(sp)
 3ec:	6402                	ld	s0,0(sp)
 3ee:	0141                	addi	sp,sp,16
 3f0:	8082                	ret

00000000000003f2 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 3f2:	4885                	li	a7,1
 ecall
 3f4:	00000073          	ecall
 ret
 3f8:	8082                	ret

00000000000003fa <exit>:
.global exit
exit:
 li a7, SYS_exit
 3fa:	4889                	li	a7,2
 ecall
 3fc:	00000073          	ecall
 ret
 400:	8082                	ret

0000000000000402 <wait>:
.global wait
wait:
 li a7, SYS_wait
 402:	488d                	li	a7,3
 ecall
 404:	00000073          	ecall
 ret
 408:	8082                	ret

000000000000040a <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 40a:	4891                	li	a7,4
 ecall
 40c:	00000073          	ecall
 ret
 410:	8082                	ret

0000000000000412 <read>:
.global read
read:
 li a7, SYS_read
 412:	4895                	li	a7,5
 ecall
 414:	00000073          	ecall
 ret
 418:	8082                	ret

000000000000041a <write>:
.global write
write:
 li a7, SYS_write
 41a:	48c1                	li	a7,16
 ecall
 41c:	00000073          	ecall
 ret
 420:	8082                	ret

0000000000000422 <close>:
.global close
close:
 li a7, SYS_close
 422:	48d5                	li	a7,21
 ecall
 424:	00000073          	ecall
 ret
 428:	8082                	ret

000000000000042a <kill>:
.global kill
kill:
 li a7, SYS_kill
 42a:	4899                	li	a7,6
 ecall
 42c:	00000073          	ecall
 ret
 430:	8082                	ret

0000000000000432 <exec>:
.global exec
exec:
 li a7, SYS_exec
 432:	489d                	li	a7,7
 ecall
 434:	00000073          	ecall
 ret
 438:	8082                	ret

000000000000043a <open>:
.global open
open:
 li a7, SYS_open
 43a:	48bd                	li	a7,15
 ecall
 43c:	00000073          	ecall
 ret
 440:	8082                	ret

0000000000000442 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 442:	48c5                	li	a7,17
 ecall
 444:	00000073          	ecall
 ret
 448:	8082                	ret

000000000000044a <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 44a:	48c9                	li	a7,18
 ecall
 44c:	00000073          	ecall
 ret
 450:	8082                	ret

0000000000000452 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 452:	48a1                	li	a7,8
 ecall
 454:	00000073          	ecall
 ret
 458:	8082                	ret

000000000000045a <link>:
.global link
link:
 li a7, SYS_link
 45a:	48cd                	li	a7,19
 ecall
 45c:	00000073          	ecall
 ret
 460:	8082                	ret

0000000000000462 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 462:	48d1                	li	a7,20
 ecall
 464:	00000073          	ecall
 ret
 468:	8082                	ret

000000000000046a <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 46a:	48a5                	li	a7,9
 ecall
 46c:	00000073          	ecall
 ret
 470:	8082                	ret

0000000000000472 <dup>:
.global dup
dup:
 li a7, SYS_dup
 472:	48a9                	li	a7,10
 ecall
 474:	00000073          	ecall
 ret
 478:	8082                	ret

000000000000047a <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 47a:	48ad                	li	a7,11
 ecall
 47c:	00000073          	ecall
 ret
 480:	8082                	ret

0000000000000482 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 482:	48b1                	li	a7,12
 ecall
 484:	00000073          	ecall
 ret
 488:	8082                	ret

000000000000048a <pause>:
.global pause
pause:
 li a7, SYS_pause
 48a:	48b5                	li	a7,13
 ecall
 48c:	00000073          	ecall
 ret
 490:	8082                	ret

0000000000000492 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 492:	48b9                	li	a7,14
 ecall
 494:	00000073          	ecall
 ret
 498:	8082                	ret

000000000000049a <getnice>:
.global getnice
getnice:
 li a7, SYS_getnice
 49a:	48d9                	li	a7,22
 ecall
 49c:	00000073          	ecall
 ret
 4a0:	8082                	ret

00000000000004a2 <setnice>:
.global setnice
setnice:
 li a7, SYS_setnice
 4a2:	48dd                	li	a7,23
 ecall
 4a4:	00000073          	ecall
 ret
 4a8:	8082                	ret

00000000000004aa <ps>:
.global ps
ps:
 li a7, SYS_ps
 4aa:	48e1                	li	a7,24
 ecall
 4ac:	00000073          	ecall
 ret
 4b0:	8082                	ret

00000000000004b2 <meminfo>:
.global meminfo
meminfo:
 li a7, SYS_meminfo
 4b2:	48e5                	li	a7,25
 ecall
 4b4:	00000073          	ecall
 ret
 4b8:	8082                	ret

00000000000004ba <waitpid>:
.global waitpid
waitpid:
 li a7, SYS_waitpid
 4ba:	48e9                	li	a7,26
 ecall
 4bc:	00000073          	ecall
 ret
 4c0:	8082                	ret

00000000000004c2 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 4c2:	1101                	addi	sp,sp,-32
 4c4:	ec06                	sd	ra,24(sp)
 4c6:	e822                	sd	s0,16(sp)
 4c8:	1000                	addi	s0,sp,32
 4ca:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 4ce:	4605                	li	a2,1
 4d0:	fef40593          	addi	a1,s0,-17
 4d4:	f47ff0ef          	jal	ra,41a <write>
}
 4d8:	60e2                	ld	ra,24(sp)
 4da:	6442                	ld	s0,16(sp)
 4dc:	6105                	addi	sp,sp,32
 4de:	8082                	ret

00000000000004e0 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 4e0:	715d                	addi	sp,sp,-80
 4e2:	e486                	sd	ra,72(sp)
 4e4:	e0a2                	sd	s0,64(sp)
 4e6:	fc26                	sd	s1,56(sp)
 4e8:	f84a                	sd	s2,48(sp)
 4ea:	f44e                	sd	s3,40(sp)
 4ec:	0880                	addi	s0,sp,80
 4ee:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 4f0:	c299                	beqz	a3,4f6 <printint+0x16>
 4f2:	0805c163          	bltz	a1,574 <printint+0x94>
  neg = 0;
 4f6:	4881                	li	a7,0
 4f8:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 4fc:	4781                	li	a5,0
  do{
    buf[i++] = digits[x % base];
 4fe:	00000517          	auipc	a0,0x0
 502:	5ca50513          	addi	a0,a0,1482 # ac8 <digits>
 506:	883e                	mv	a6,a5
 508:	2785                	addiw	a5,a5,1
 50a:	02c5f733          	remu	a4,a1,a2
 50e:	972a                	add	a4,a4,a0
 510:	00074703          	lbu	a4,0(a4)
 514:	00e68023          	sb	a4,0(a3)
  }while((x /= base) != 0);
 518:	872e                	mv	a4,a1
 51a:	02c5d5b3          	divu	a1,a1,a2
 51e:	0685                	addi	a3,a3,1
 520:	fec773e3          	bgeu	a4,a2,506 <printint+0x26>
  if(neg)
 524:	00088b63          	beqz	a7,53a <printint+0x5a>
    buf[i++] = '-';
 528:	fd040713          	addi	a4,s0,-48
 52c:	97ba                	add	a5,a5,a4
 52e:	02d00713          	li	a4,45
 532:	fee78423          	sb	a4,-24(a5)
 536:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
 53a:	02f05663          	blez	a5,566 <printint+0x86>
 53e:	fb840713          	addi	a4,s0,-72
 542:	00f704b3          	add	s1,a4,a5
 546:	fff70993          	addi	s3,a4,-1
 54a:	99be                	add	s3,s3,a5
 54c:	37fd                	addiw	a5,a5,-1
 54e:	1782                	slli	a5,a5,0x20
 550:	9381                	srli	a5,a5,0x20
 552:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 556:	fff4c583          	lbu	a1,-1(s1)
 55a:	854a                	mv	a0,s2
 55c:	f67ff0ef          	jal	ra,4c2 <putc>
  while(--i >= 0)
 560:	14fd                	addi	s1,s1,-1
 562:	ff349ae3          	bne	s1,s3,556 <printint+0x76>
}
 566:	60a6                	ld	ra,72(sp)
 568:	6406                	ld	s0,64(sp)
 56a:	74e2                	ld	s1,56(sp)
 56c:	7942                	ld	s2,48(sp)
 56e:	79a2                	ld	s3,40(sp)
 570:	6161                	addi	sp,sp,80
 572:	8082                	ret
    x = -xx;
 574:	40b005b3          	neg	a1,a1
    neg = 1;
 578:	4885                	li	a7,1
    x = -xx;
 57a:	bfbd                	j	4f8 <printint+0x18>

000000000000057c <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 57c:	7119                	addi	sp,sp,-128
 57e:	fc86                	sd	ra,120(sp)
 580:	f8a2                	sd	s0,112(sp)
 582:	f4a6                	sd	s1,104(sp)
 584:	f0ca                	sd	s2,96(sp)
 586:	ecce                	sd	s3,88(sp)
 588:	e8d2                	sd	s4,80(sp)
 58a:	e4d6                	sd	s5,72(sp)
 58c:	e0da                	sd	s6,64(sp)
 58e:	fc5e                	sd	s7,56(sp)
 590:	f862                	sd	s8,48(sp)
 592:	f466                	sd	s9,40(sp)
 594:	f06a                	sd	s10,32(sp)
 596:	ec6e                	sd	s11,24(sp)
 598:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 59a:	0005c903          	lbu	s2,0(a1)
 59e:	24090c63          	beqz	s2,7f6 <vprintf+0x27a>
 5a2:	8b2a                	mv	s6,a0
 5a4:	8a2e                	mv	s4,a1
 5a6:	8bb2                	mv	s7,a2
  state = 0;
 5a8:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 5aa:	4481                	li	s1,0
 5ac:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 5ae:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 5b2:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 5b6:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 5ba:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 5be:	00000c97          	auipc	s9,0x0
 5c2:	50ac8c93          	addi	s9,s9,1290 # ac8 <digits>
 5c6:	a005                	j	5e6 <vprintf+0x6a>
        putc(fd, c0);
 5c8:	85ca                	mv	a1,s2
 5ca:	855a                	mv	a0,s6
 5cc:	ef7ff0ef          	jal	ra,4c2 <putc>
 5d0:	a019                	j	5d6 <vprintf+0x5a>
    } else if(state == '%'){
 5d2:	03598263          	beq	s3,s5,5f6 <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 5d6:	2485                	addiw	s1,s1,1
 5d8:	8726                	mv	a4,s1
 5da:	009a07b3          	add	a5,s4,s1
 5de:	0007c903          	lbu	s2,0(a5)
 5e2:	20090a63          	beqz	s2,7f6 <vprintf+0x27a>
    c0 = fmt[i] & 0xff;
 5e6:	0009079b          	sext.w	a5,s2
    if(state == 0){
 5ea:	fe0994e3          	bnez	s3,5d2 <vprintf+0x56>
      if(c0 == '%'){
 5ee:	fd579de3          	bne	a5,s5,5c8 <vprintf+0x4c>
        state = '%';
 5f2:	89be                	mv	s3,a5
 5f4:	b7cd                	j	5d6 <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
 5f6:	c3c1                	beqz	a5,676 <vprintf+0xfa>
 5f8:	00ea06b3          	add	a3,s4,a4
 5fc:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 600:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 602:	c681                	beqz	a3,60a <vprintf+0x8e>
 604:	9752                	add	a4,a4,s4
 606:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 60a:	03878e63          	beq	a5,s8,646 <vprintf+0xca>
      } else if(c0 == 'l' && c1 == 'd'){
 60e:	05a78863          	beq	a5,s10,65e <vprintf+0xe2>
      } else if(c0 == 'u'){
 612:	0db78b63          	beq	a5,s11,6e8 <vprintf+0x16c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 616:	07800713          	li	a4,120
 61a:	10e78d63          	beq	a5,a4,734 <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 61e:	07000713          	li	a4,112
 622:	14e78263          	beq	a5,a4,766 <vprintf+0x1ea>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 626:	06300713          	li	a4,99
 62a:	16e78f63          	beq	a5,a4,7a8 <vprintf+0x22c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 62e:	07300713          	li	a4,115
 632:	18e78563          	beq	a5,a4,7bc <vprintf+0x240>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 636:	05579063          	bne	a5,s5,676 <vprintf+0xfa>
        putc(fd, '%');
 63a:	85d6                	mv	a1,s5
 63c:	855a                	mv	a0,s6
 63e:	e85ff0ef          	jal	ra,4c2 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 642:	4981                	li	s3,0
 644:	bf49                	j	5d6 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
 646:	008b8913          	addi	s2,s7,8
 64a:	4685                	li	a3,1
 64c:	4629                	li	a2,10
 64e:	000ba583          	lw	a1,0(s7)
 652:	855a                	mv	a0,s6
 654:	e8dff0ef          	jal	ra,4e0 <printint>
 658:	8bca                	mv	s7,s2
      state = 0;
 65a:	4981                	li	s3,0
 65c:	bfad                	j	5d6 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
 65e:	03868663          	beq	a3,s8,68a <vprintf+0x10e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 662:	05a68163          	beq	a3,s10,6a4 <vprintf+0x128>
      } else if(c0 == 'l' && c1 == 'u'){
 666:	09b68d63          	beq	a3,s11,700 <vprintf+0x184>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 66a:	03a68f63          	beq	a3,s10,6a8 <vprintf+0x12c>
      } else if(c0 == 'l' && c1 == 'x'){
 66e:	07800793          	li	a5,120
 672:	0cf68d63          	beq	a3,a5,74c <vprintf+0x1d0>
        putc(fd, '%');
 676:	85d6                	mv	a1,s5
 678:	855a                	mv	a0,s6
 67a:	e49ff0ef          	jal	ra,4c2 <putc>
        putc(fd, c0);
 67e:	85ca                	mv	a1,s2
 680:	855a                	mv	a0,s6
 682:	e41ff0ef          	jal	ra,4c2 <putc>
      state = 0;
 686:	4981                	li	s3,0
 688:	b7b9                	j	5d6 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 68a:	008b8913          	addi	s2,s7,8
 68e:	4685                	li	a3,1
 690:	4629                	li	a2,10
 692:	000bb583          	ld	a1,0(s7)
 696:	855a                	mv	a0,s6
 698:	e49ff0ef          	jal	ra,4e0 <printint>
        i += 1;
 69c:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 69e:	8bca                	mv	s7,s2
      state = 0;
 6a0:	4981                	li	s3,0
        i += 1;
 6a2:	bf15                	j	5d6 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6a4:	03860563          	beq	a2,s8,6ce <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 6a8:	07b60963          	beq	a2,s11,71a <vprintf+0x19e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 6ac:	07800793          	li	a5,120
 6b0:	fcf613e3          	bne	a2,a5,676 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6b4:	008b8913          	addi	s2,s7,8
 6b8:	4681                	li	a3,0
 6ba:	4641                	li	a2,16
 6bc:	000bb583          	ld	a1,0(s7)
 6c0:	855a                	mv	a0,s6
 6c2:	e1fff0ef          	jal	ra,4e0 <printint>
        i += 2;
 6c6:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 6c8:	8bca                	mv	s7,s2
      state = 0;
 6ca:	4981                	li	s3,0
        i += 2;
 6cc:	b729                	j	5d6 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 6ce:	008b8913          	addi	s2,s7,8
 6d2:	4685                	li	a3,1
 6d4:	4629                	li	a2,10
 6d6:	000bb583          	ld	a1,0(s7)
 6da:	855a                	mv	a0,s6
 6dc:	e05ff0ef          	jal	ra,4e0 <printint>
        i += 2;
 6e0:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 6e2:	8bca                	mv	s7,s2
      state = 0;
 6e4:	4981                	li	s3,0
        i += 2;
 6e6:	bdc5                	j	5d6 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 6e8:	008b8913          	addi	s2,s7,8
 6ec:	4681                	li	a3,0
 6ee:	4629                	li	a2,10
 6f0:	000be583          	lwu	a1,0(s7)
 6f4:	855a                	mv	a0,s6
 6f6:	debff0ef          	jal	ra,4e0 <printint>
 6fa:	8bca                	mv	s7,s2
      state = 0;
 6fc:	4981                	li	s3,0
 6fe:	bde1                	j	5d6 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 700:	008b8913          	addi	s2,s7,8
 704:	4681                	li	a3,0
 706:	4629                	li	a2,10
 708:	000bb583          	ld	a1,0(s7)
 70c:	855a                	mv	a0,s6
 70e:	dd3ff0ef          	jal	ra,4e0 <printint>
        i += 1;
 712:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 714:	8bca                	mv	s7,s2
      state = 0;
 716:	4981                	li	s3,0
        i += 1;
 718:	bd7d                	j	5d6 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 71a:	008b8913          	addi	s2,s7,8
 71e:	4681                	li	a3,0
 720:	4629                	li	a2,10
 722:	000bb583          	ld	a1,0(s7)
 726:	855a                	mv	a0,s6
 728:	db9ff0ef          	jal	ra,4e0 <printint>
        i += 2;
 72c:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 72e:	8bca                	mv	s7,s2
      state = 0;
 730:	4981                	li	s3,0
        i += 2;
 732:	b555                	j	5d6 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 734:	008b8913          	addi	s2,s7,8
 738:	4681                	li	a3,0
 73a:	4641                	li	a2,16
 73c:	000be583          	lwu	a1,0(s7)
 740:	855a                	mv	a0,s6
 742:	d9fff0ef          	jal	ra,4e0 <printint>
 746:	8bca                	mv	s7,s2
      state = 0;
 748:	4981                	li	s3,0
 74a:	b571                	j	5d6 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 74c:	008b8913          	addi	s2,s7,8
 750:	4681                	li	a3,0
 752:	4641                	li	a2,16
 754:	000bb583          	ld	a1,0(s7)
 758:	855a                	mv	a0,s6
 75a:	d87ff0ef          	jal	ra,4e0 <printint>
        i += 1;
 75e:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 760:	8bca                	mv	s7,s2
      state = 0;
 762:	4981                	li	s3,0
        i += 1;
 764:	bd8d                	j	5d6 <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
 766:	008b8793          	addi	a5,s7,8
 76a:	f8f43423          	sd	a5,-120(s0)
 76e:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 772:	03000593          	li	a1,48
 776:	855a                	mv	a0,s6
 778:	d4bff0ef          	jal	ra,4c2 <putc>
  putc(fd, 'x');
 77c:	07800593          	li	a1,120
 780:	855a                	mv	a0,s6
 782:	d41ff0ef          	jal	ra,4c2 <putc>
 786:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 788:	03c9d793          	srli	a5,s3,0x3c
 78c:	97e6                	add	a5,a5,s9
 78e:	0007c583          	lbu	a1,0(a5)
 792:	855a                	mv	a0,s6
 794:	d2fff0ef          	jal	ra,4c2 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 798:	0992                	slli	s3,s3,0x4
 79a:	397d                	addiw	s2,s2,-1
 79c:	fe0916e3          	bnez	s2,788 <vprintf+0x20c>
        printptr(fd, va_arg(ap, uint64));
 7a0:	f8843b83          	ld	s7,-120(s0)
      state = 0;
 7a4:	4981                	li	s3,0
 7a6:	bd05                	j	5d6 <vprintf+0x5a>
        putc(fd, va_arg(ap, uint32));
 7a8:	008b8913          	addi	s2,s7,8
 7ac:	000bc583          	lbu	a1,0(s7)
 7b0:	855a                	mv	a0,s6
 7b2:	d11ff0ef          	jal	ra,4c2 <putc>
 7b6:	8bca                	mv	s7,s2
      state = 0;
 7b8:	4981                	li	s3,0
 7ba:	bd31                	j	5d6 <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
 7bc:	008b8993          	addi	s3,s7,8
 7c0:	000bb903          	ld	s2,0(s7)
 7c4:	00090f63          	beqz	s2,7e2 <vprintf+0x266>
        for(; *s; s++)
 7c8:	00094583          	lbu	a1,0(s2)
 7cc:	c195                	beqz	a1,7f0 <vprintf+0x274>
          putc(fd, *s);
 7ce:	855a                	mv	a0,s6
 7d0:	cf3ff0ef          	jal	ra,4c2 <putc>
        for(; *s; s++)
 7d4:	0905                	addi	s2,s2,1
 7d6:	00094583          	lbu	a1,0(s2)
 7da:	f9f5                	bnez	a1,7ce <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 7dc:	8bce                	mv	s7,s3
      state = 0;
 7de:	4981                	li	s3,0
 7e0:	bbdd                	j	5d6 <vprintf+0x5a>
          s = "(null)";
 7e2:	00000917          	auipc	s2,0x0
 7e6:	2de90913          	addi	s2,s2,734 # ac0 <malloc+0x1c8>
        for(; *s; s++)
 7ea:	02800593          	li	a1,40
 7ee:	b7c5                	j	7ce <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 7f0:	8bce                	mv	s7,s3
      state = 0;
 7f2:	4981                	li	s3,0
 7f4:	b3cd                	j	5d6 <vprintf+0x5a>
    }
  }
}
 7f6:	70e6                	ld	ra,120(sp)
 7f8:	7446                	ld	s0,112(sp)
 7fa:	74a6                	ld	s1,104(sp)
 7fc:	7906                	ld	s2,96(sp)
 7fe:	69e6                	ld	s3,88(sp)
 800:	6a46                	ld	s4,80(sp)
 802:	6aa6                	ld	s5,72(sp)
 804:	6b06                	ld	s6,64(sp)
 806:	7be2                	ld	s7,56(sp)
 808:	7c42                	ld	s8,48(sp)
 80a:	7ca2                	ld	s9,40(sp)
 80c:	7d02                	ld	s10,32(sp)
 80e:	6de2                	ld	s11,24(sp)
 810:	6109                	addi	sp,sp,128
 812:	8082                	ret

0000000000000814 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 814:	715d                	addi	sp,sp,-80
 816:	ec06                	sd	ra,24(sp)
 818:	e822                	sd	s0,16(sp)
 81a:	1000                	addi	s0,sp,32
 81c:	e010                	sd	a2,0(s0)
 81e:	e414                	sd	a3,8(s0)
 820:	e818                	sd	a4,16(s0)
 822:	ec1c                	sd	a5,24(s0)
 824:	03043023          	sd	a6,32(s0)
 828:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 82c:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 830:	8622                	mv	a2,s0
 832:	d4bff0ef          	jal	ra,57c <vprintf>
}
 836:	60e2                	ld	ra,24(sp)
 838:	6442                	ld	s0,16(sp)
 83a:	6161                	addi	sp,sp,80
 83c:	8082                	ret

000000000000083e <printf>:

void
printf(const char *fmt, ...)
{
 83e:	711d                	addi	sp,sp,-96
 840:	ec06                	sd	ra,24(sp)
 842:	e822                	sd	s0,16(sp)
 844:	1000                	addi	s0,sp,32
 846:	e40c                	sd	a1,8(s0)
 848:	e810                	sd	a2,16(s0)
 84a:	ec14                	sd	a3,24(s0)
 84c:	f018                	sd	a4,32(s0)
 84e:	f41c                	sd	a5,40(s0)
 850:	03043823          	sd	a6,48(s0)
 854:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 858:	00840613          	addi	a2,s0,8
 85c:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 860:	85aa                	mv	a1,a0
 862:	4505                	li	a0,1
 864:	d19ff0ef          	jal	ra,57c <vprintf>
}
 868:	60e2                	ld	ra,24(sp)
 86a:	6442                	ld	s0,16(sp)
 86c:	6125                	addi	sp,sp,96
 86e:	8082                	ret

0000000000000870 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 870:	1141                	addi	sp,sp,-16
 872:	e422                	sd	s0,8(sp)
 874:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 876:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 87a:	00000797          	auipc	a5,0x0
 87e:	7867b783          	ld	a5,1926(a5) # 1000 <freep>
 882:	a805                	j	8b2 <free+0x42>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 884:	4618                	lw	a4,8(a2)
 886:	9db9                	addw	a1,a1,a4
 888:	feb52c23          	sw	a1,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 88c:	6398                	ld	a4,0(a5)
 88e:	6318                	ld	a4,0(a4)
 890:	fee53823          	sd	a4,-16(a0)
 894:	a091                	j	8d8 <free+0x68>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 896:	ff852703          	lw	a4,-8(a0)
 89a:	9e39                	addw	a2,a2,a4
 89c:	c790                	sw	a2,8(a5)
    p->s.ptr = bp->s.ptr;
 89e:	ff053703          	ld	a4,-16(a0)
 8a2:	e398                	sd	a4,0(a5)
 8a4:	a099                	j	8ea <free+0x7a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8a6:	6398                	ld	a4,0(a5)
 8a8:	00e7e463          	bltu	a5,a4,8b0 <free+0x40>
 8ac:	00e6ea63          	bltu	a3,a4,8c0 <free+0x50>
{
 8b0:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8b2:	fed7fae3          	bgeu	a5,a3,8a6 <free+0x36>
 8b6:	6398                	ld	a4,0(a5)
 8b8:	00e6e463          	bltu	a3,a4,8c0 <free+0x50>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8bc:	fee7eae3          	bltu	a5,a4,8b0 <free+0x40>
  if(bp + bp->s.size == p->s.ptr){
 8c0:	ff852583          	lw	a1,-8(a0)
 8c4:	6390                	ld	a2,0(a5)
 8c6:	02059713          	slli	a4,a1,0x20
 8ca:	9301                	srli	a4,a4,0x20
 8cc:	0712                	slli	a4,a4,0x4
 8ce:	9736                	add	a4,a4,a3
 8d0:	fae60ae3          	beq	a2,a4,884 <free+0x14>
    bp->s.ptr = p->s.ptr;
 8d4:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 8d8:	4790                	lw	a2,8(a5)
 8da:	02061713          	slli	a4,a2,0x20
 8de:	9301                	srli	a4,a4,0x20
 8e0:	0712                	slli	a4,a4,0x4
 8e2:	973e                	add	a4,a4,a5
 8e4:	fae689e3          	beq	a3,a4,896 <free+0x26>
  } else
    p->s.ptr = bp;
 8e8:	e394                	sd	a3,0(a5)
  freep = p;
 8ea:	00000717          	auipc	a4,0x0
 8ee:	70f73b23          	sd	a5,1814(a4) # 1000 <freep>
}
 8f2:	6422                	ld	s0,8(sp)
 8f4:	0141                	addi	sp,sp,16
 8f6:	8082                	ret

00000000000008f8 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 8f8:	7139                	addi	sp,sp,-64
 8fa:	fc06                	sd	ra,56(sp)
 8fc:	f822                	sd	s0,48(sp)
 8fe:	f426                	sd	s1,40(sp)
 900:	f04a                	sd	s2,32(sp)
 902:	ec4e                	sd	s3,24(sp)
 904:	e852                	sd	s4,16(sp)
 906:	e456                	sd	s5,8(sp)
 908:	e05a                	sd	s6,0(sp)
 90a:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 90c:	02051493          	slli	s1,a0,0x20
 910:	9081                	srli	s1,s1,0x20
 912:	04bd                	addi	s1,s1,15
 914:	8091                	srli	s1,s1,0x4
 916:	0014899b          	addiw	s3,s1,1
 91a:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 91c:	00000517          	auipc	a0,0x0
 920:	6e453503          	ld	a0,1764(a0) # 1000 <freep>
 924:	c515                	beqz	a0,950 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 926:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 928:	4798                	lw	a4,8(a5)
 92a:	02977f63          	bgeu	a4,s1,968 <malloc+0x70>
 92e:	8a4e                	mv	s4,s3
 930:	0009871b          	sext.w	a4,s3
 934:	6685                	lui	a3,0x1
 936:	00d77363          	bgeu	a4,a3,93c <malloc+0x44>
 93a:	6a05                	lui	s4,0x1
 93c:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 940:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 944:	00000917          	auipc	s2,0x0
 948:	6bc90913          	addi	s2,s2,1724 # 1000 <freep>
  if(p == SBRK_ERROR)
 94c:	5afd                	li	s5,-1
 94e:	a0bd                	j	9bc <malloc+0xc4>
    base.s.ptr = freep = prevp = &base;
 950:	00000797          	auipc	a5,0x0
 954:	6c078793          	addi	a5,a5,1728 # 1010 <base>
 958:	00000717          	auipc	a4,0x0
 95c:	6af73423          	sd	a5,1704(a4) # 1000 <freep>
 960:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 962:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 966:	b7e1                	j	92e <malloc+0x36>
      if(p->s.size == nunits)
 968:	02e48b63          	beq	s1,a4,99e <malloc+0xa6>
        p->s.size -= nunits;
 96c:	4137073b          	subw	a4,a4,s3
 970:	c798                	sw	a4,8(a5)
        p += p->s.size;
 972:	1702                	slli	a4,a4,0x20
 974:	9301                	srli	a4,a4,0x20
 976:	0712                	slli	a4,a4,0x4
 978:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 97a:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 97e:	00000717          	auipc	a4,0x0
 982:	68a73123          	sd	a0,1666(a4) # 1000 <freep>
      return (void*)(p + 1);
 986:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 98a:	70e2                	ld	ra,56(sp)
 98c:	7442                	ld	s0,48(sp)
 98e:	74a2                	ld	s1,40(sp)
 990:	7902                	ld	s2,32(sp)
 992:	69e2                	ld	s3,24(sp)
 994:	6a42                	ld	s4,16(sp)
 996:	6aa2                	ld	s5,8(sp)
 998:	6b02                	ld	s6,0(sp)
 99a:	6121                	addi	sp,sp,64
 99c:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 99e:	6398                	ld	a4,0(a5)
 9a0:	e118                	sd	a4,0(a0)
 9a2:	bff1                	j	97e <malloc+0x86>
  hp->s.size = nu;
 9a4:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 9a8:	0541                	addi	a0,a0,16
 9aa:	ec7ff0ef          	jal	ra,870 <free>
  return freep;
 9ae:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 9b2:	dd61                	beqz	a0,98a <malloc+0x92>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 9b4:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 9b6:	4798                	lw	a4,8(a5)
 9b8:	fa9778e3          	bgeu	a4,s1,968 <malloc+0x70>
    if(p == freep)
 9bc:	00093703          	ld	a4,0(s2)
 9c0:	853e                	mv	a0,a5
 9c2:	fef719e3          	bne	a4,a5,9b4 <malloc+0xbc>
  p = sbrk(nu * sizeof(Header));
 9c6:	8552                	mv	a0,s4
 9c8:	9ffff0ef          	jal	ra,3c6 <sbrk>
  if(p == SBRK_ERROR)
 9cc:	fd551ce3          	bne	a0,s5,9a4 <malloc+0xac>
        return 0;
 9d0:	4501                	li	a0,0
 9d2:	bf65                	j	98a <malloc+0x92>
