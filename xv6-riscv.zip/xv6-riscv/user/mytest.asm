
user/_mytest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <check>:

int passed = 0;
int failed = 0;

void check(const char *test, int actual, int expected)
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
   8:	86ae                	mv	a3,a1
  if (actual == expected) {
   a:	02c58463          	beq	a1,a2,32 <check+0x32>
    printf("[PASS] %s : got %d\n", test, actual);
    passed++;
  } else {
    printf("[FAIL] %s : expected %d, got %d\n", test, expected, actual);
   e:	85aa                	mv	a1,a0
  10:	00001517          	auipc	a0,0x1
  14:	bd850513          	addi	a0,a0,-1064 # be8 <malloc+0xf4>
  18:	223000ef          	jal	ra,a3a <printf>
    failed++;
  1c:	00002717          	auipc	a4,0x2
  20:	fe470713          	addi	a4,a4,-28 # 2000 <failed>
  24:	431c                	lw	a5,0(a4)
  26:	2785                	addiw	a5,a5,1
  28:	c31c                	sw	a5,0(a4)
  }
}
  2a:	60a2                	ld	ra,8(sp)
  2c:	6402                	ld	s0,0(sp)
  2e:	0141                	addi	sp,sp,16
  30:	8082                	ret
    printf("[PASS] %s : got %d\n", test, actual);
  32:	862e                	mv	a2,a1
  34:	85aa                	mv	a1,a0
  36:	00001517          	auipc	a0,0x1
  3a:	b9a50513          	addi	a0,a0,-1126 # bd0 <malloc+0xdc>
  3e:	1fd000ef          	jal	ra,a3a <printf>
    passed++;
  42:	00002717          	auipc	a4,0x2
  46:	fc270713          	addi	a4,a4,-62 # 2004 <passed>
  4a:	431c                	lw	a5,0(a4)
  4c:	2785                	addiw	a5,a5,1
  4e:	c31c                	sw	a5,0(a4)
  50:	bfe9                	j	2a <check+0x2a>

0000000000000052 <main>:

int main()
{
  52:	1141                	addi	sp,sp,-16
  54:	e406                	sd	ra,8(sp)
  56:	e022                	sd	s0,0(sp)
  58:	0800                	addi	s0,sp,16
  int ret;

  printf("[INFO] init(pid 1) and sh(pid 2) are created during boot.\n");
  5a:	00001517          	auipc	a0,0x1
  5e:	bb650513          	addi	a0,a0,-1098 # c10 <malloc+0x11c>
  62:	1d9000ef          	jal	ra,a3a <printf>
  printf("[INFO] mytest(pid 3) should be the current test program.\n");
  66:	00001517          	auipc	a0,0x1
  6a:	bea50513          	addi	a0,a0,-1046 # c50 <malloc+0x15c>
  6e:	1cd000ef          	jal	ra,a3a <printf>

  // ============================================================
  printf("========== Current Process State ==========\n");
  72:	00001517          	auipc	a0,0x1
  76:	c1e50513          	addi	a0,a0,-994 # c90 <malloc+0x19c>
  7a:	1c1000ef          	jal	ra,a3a <printf>
  // ============================================================
  printf("[INFO] The following processes are already running:\n");
  7e:	00001517          	auipc	a0,0x1
  82:	c4250513          	addi	a0,a0,-958 # cc0 <malloc+0x1cc>
  86:	1b5000ef          	jal	ra,a3a <printf>
  ps(0);
  8a:	4501                	li	a0,0
  8c:	61a000ef          	jal	ra,6a6 <ps>
  printf("\n");
  90:	00001517          	auipc	a0,0x1
  94:	bf850513          	addi	a0,a0,-1032 # c88 <malloc+0x194>
  98:	1a3000ef          	jal	ra,a3a <printf>

  // ============================================================
  printf("========== Testing getnice() ==========\n");
  9c:	00001517          	auipc	a0,0x1
  a0:	c5c50513          	addi	a0,a0,-932 # cf8 <malloc+0x204>
  a4:	197000ef          	jal	ra,a3a <printf>
  // ============================================================

  // pid 1 (init) exists, default nice = 20
  ret = getnice(1);
  a8:	4505                	li	a0,1
  aa:	5ec000ef          	jal	ra,696 <getnice>
  ae:	85aa                	mv	a1,a0
  check("getnice(1) - init default nice", ret, 20);
  b0:	4651                	li	a2,20
  b2:	00001517          	auipc	a0,0x1
  b6:	c7650513          	addi	a0,a0,-906 # d28 <malloc+0x234>
  ba:	f47ff0ef          	jal	ra,0 <check>

  // pid 2 (sh) exists, default nice = 20
  ret = getnice(2);
  be:	4509                	li	a0,2
  c0:	5d6000ef          	jal	ra,696 <getnice>
  c4:	85aa                	mv	a1,a0
  check("getnice(2) - sh default nice", ret, 20);
  c6:	4651                	li	a2,20
  c8:	00001517          	auipc	a0,0x1
  cc:	c8050513          	addi	a0,a0,-896 # d48 <malloc+0x254>
  d0:	f31ff0ef          	jal	ra,0 <check>

  // pid 12 does not exist → should return -1
  ret = getnice(12);
  d4:	4531                	li	a0,12
  d6:	5c0000ef          	jal	ra,696 <getnice>
  da:	85aa                	mv	a1,a0
  check("getnice(12) - no such process", ret, -1);
  dc:	567d                	li	a2,-1
  de:	00001517          	auipc	a0,0x1
  e2:	c8a50513          	addi	a0,a0,-886 # d68 <malloc+0x274>
  e6:	f1bff0ef          	jal	ra,0 <check>

  printf("\n");
  ea:	00001517          	auipc	a0,0x1
  ee:	b9e50513          	addi	a0,a0,-1122 # c88 <malloc+0x194>
  f2:	149000ef          	jal	ra,a3a <printf>

  // ============================================================
  printf("========== Testing setnice() ==========\n");
  f6:	00001517          	auipc	a0,0x1
  fa:	c9250513          	addi	a0,a0,-878 # d88 <malloc+0x294>
  fe:	13d000ef          	jal	ra,a3a <printf>
  // ============================================================

  // Set nice of pid 1 (init) to 10 → should succeed (return 0)
  ret = setnice(1, 10);
 102:	45a9                	li	a1,10
 104:	4505                	li	a0,1
 106:	598000ef          	jal	ra,69e <setnice>
 10a:	85aa                	mv	a1,a0
  check("setnice(1, 10) - valid", ret, 0);
 10c:	4601                	li	a2,0
 10e:	00001517          	auipc	a0,0x1
 112:	caa50513          	addi	a0,a0,-854 # db8 <malloc+0x2c4>
 116:	eebff0ef          	jal	ra,0 <check>

  // Verify the change
  ret = getnice(1);
 11a:	4505                	li	a0,1
 11c:	57a000ef          	jal	ra,696 <getnice>
 120:	85aa                	mv	a1,a0
  check("getnice(1) - after setnice to 10", ret, 10);
 122:	4629                	li	a2,10
 124:	00001517          	auipc	a0,0x1
 128:	cac50513          	addi	a0,a0,-852 # dd0 <malloc+0x2dc>
 12c:	ed5ff0ef          	jal	ra,0 <check>

  // Restore to default
  ret = setnice(1, 20);
 130:	45d1                	li	a1,20
 132:	4505                	li	a0,1
 134:	56a000ef          	jal	ra,69e <setnice>
 138:	85aa                	mv	a1,a0
  check("setnice(1, 20) - restore default", ret, 0);
 13a:	4601                	li	a2,0
 13c:	00001517          	auipc	a0,0x1
 140:	cbc50513          	addi	a0,a0,-836 # df8 <malloc+0x304>
 144:	ebdff0ef          	jal	ra,0 <check>

  // pid 12 does not exist → should return -1
  ret = setnice(12, 10);
 148:	45a9                	li	a1,10
 14a:	4531                	li	a0,12
 14c:	552000ef          	jal	ra,69e <setnice>
 150:	85aa                	mv	a1,a0
  check("setnice(12, 10) - no such process", ret, -1);
 152:	567d                	li	a2,-1
 154:	00001517          	auipc	a0,0x1
 158:	ccc50513          	addi	a0,a0,-820 # e20 <malloc+0x32c>
 15c:	ea5ff0ef          	jal	ra,0 <check>

  // nice value 40 is out of range (valid: 0–39) → should return -1
  ret = setnice(1, 40);
 160:	02800593          	li	a1,40
 164:	4505                	li	a0,1
 166:	538000ef          	jal	ra,69e <setnice>
 16a:	85aa                	mv	a1,a0
  check("setnice(1, 40) - invalid nice value", ret, -1);
 16c:	567d                	li	a2,-1
 16e:	00001517          	auipc	a0,0x1
 172:	cda50513          	addi	a0,a0,-806 # e48 <malloc+0x354>
 176:	e8bff0ef          	jal	ra,0 <check>

  // nice value -1 is out of range → should return -1
  ret = setnice(1, -1);
 17a:	55fd                	li	a1,-1
 17c:	4505                	li	a0,1
 17e:	520000ef          	jal	ra,69e <setnice>
 182:	85aa                	mv	a1,a0
  check("setnice(1, -1) - negative nice value", ret, -1);
 184:	567d                	li	a2,-1
 186:	00001517          	auipc	a0,0x1
 18a:	cea50513          	addi	a0,a0,-790 # e70 <malloc+0x37c>
 18e:	e73ff0ef          	jal	ra,0 <check>

  printf("\n");
 192:	00001517          	auipc	a0,0x1
 196:	af650513          	addi	a0,a0,-1290 # c88 <malloc+0x194>
 19a:	0a1000ef          	jal	ra,a3a <printf>

  // ============================================================
  printf("========== Testing ps() ==========\n");
 19e:	00001517          	auipc	a0,0x1
 1a2:	cfa50513          	addi	a0,a0,-774 # e98 <malloc+0x3a4>
 1a6:	095000ef          	jal	ra,a3a <printf>
  // ============================================================

  // ps(0) prints all processes — verify visually
  printf("[INFO] ps(0) - should print all processes (init, sh, mytest):\n");
 1aa:	00001517          	auipc	a0,0x1
 1ae:	d1650513          	addi	a0,a0,-746 # ec0 <malloc+0x3cc>
 1b2:	089000ef          	jal	ra,a3a <printf>
  ps(0);
 1b6:	4501                	li	a0,0
 1b8:	4ee000ef          	jal	ra,6a6 <ps>
  printf("\n");
 1bc:	00001517          	auipc	a0,0x1
 1c0:	acc50513          	addi	a0,a0,-1332 # c88 <malloc+0x194>
 1c4:	077000ef          	jal	ra,a3a <printf>

  // ps(1) prints only init
  printf("[INFO] ps(1) - should print only init:\n");
 1c8:	00001517          	auipc	a0,0x1
 1cc:	d3850513          	addi	a0,a0,-712 # f00 <malloc+0x40c>
 1d0:	06b000ef          	jal	ra,a3a <printf>
  ps(1);
 1d4:	4505                	li	a0,1
 1d6:	4d0000ef          	jal	ra,6a6 <ps>
  printf("\n");
 1da:	00001517          	auipc	a0,0x1
 1de:	aae50513          	addi	a0,a0,-1362 # c88 <malloc+0x194>
 1e2:	059000ef          	jal	ra,a3a <printf>

  // ps(12) — no such process, should print nothing
  printf("[INFO] ps(12) - no such process, should print nothing:\n");
 1e6:	00001517          	auipc	a0,0x1
 1ea:	d4250513          	addi	a0,a0,-702 # f28 <malloc+0x434>
 1ee:	04d000ef          	jal	ra,a3a <printf>
  ps(12);
 1f2:	4531                	li	a0,12
 1f4:	4b2000ef          	jal	ra,6a6 <ps>
  printf("[INFO] (no output expected above)\n");
 1f8:	00001517          	auipc	a0,0x1
 1fc:	d6850513          	addi	a0,a0,-664 # f60 <malloc+0x46c>
 200:	03b000ef          	jal	ra,a3a <printf>

  printf("\n");
 204:	00001517          	auipc	a0,0x1
 208:	a8450513          	addi	a0,a0,-1404 # c88 <malloc+0x194>
 20c:	02f000ef          	jal	ra,a3a <printf>

  // ============================================================
  printf("========== Testing meminfo() ==========\n");
 210:	00001517          	auipc	a0,0x1
 214:	d7850513          	addi	a0,a0,-648 # f88 <malloc+0x494>
 218:	023000ef          	jal	ra,a3a <printf>
  // ============================================================

  uint64 mem = meminfo();
 21c:	492000ef          	jal	ra,6ae <meminfo>
  if (mem > 0) {
 220:	c131                	beqz	a0,264 <main+0x212>
 222:	85aa                	mv	a1,a0
    printf("[PASS] meminfo() - free memory: %lu bytes\n", mem);
 224:	00001517          	auipc	a0,0x1
 228:	d9450513          	addi	a0,a0,-620 # fb8 <malloc+0x4c4>
 22c:	00f000ef          	jal	ra,a3a <printf>
    passed++;
 230:	00002717          	auipc	a4,0x2
 234:	dd470713          	addi	a4,a4,-556 # 2004 <passed>
 238:	431c                	lw	a5,0(a4)
 23a:	2785                	addiw	a5,a5,1
 23c:	c31c                	sw	a5,0(a4)
  } else {
    printf("[FAIL] meminfo() - expected > 0, got %lu\n", mem);
    failed++;
  }

  printf("\n");
 23e:	00001517          	auipc	a0,0x1
 242:	a4a50513          	addi	a0,a0,-1462 # c88 <malloc+0x194>
 246:	7f4000ef          	jal	ra,a3a <printf>

  // ============================================================
  printf("========== Testing waitpid() ==========\n");
 24a:	00001517          	auipc	a0,0x1
 24e:	dce50513          	addi	a0,a0,-562 # 1018 <malloc+0x524>
 252:	7e8000ef          	jal	ra,a3a <printf>
  // Note: waitpid suspends execution until a specific process terminates.
  // To test this, we use fork() to create child processes that exit immediately,
  // then verify that waitpid correctly waits for them.

  // Test 1: fork a child, then waitpid for it
  int pid1 = fork();
 256:	398000ef          	jal	ra,5ee <fork>
  if (pid1 < 0) {
 25a:	02054463          	bltz	a0,282 <main+0x230>
    printf("[FAIL] fork() failed\n");
    failed++;
  } else if (pid1 == 0) {
 25e:	e121                	bnez	a0,29e <main+0x24c>
    // child process — exit immediately
    exit(0);
 260:	396000ef          	jal	ra,5f6 <exit>
    printf("[FAIL] meminfo() - expected > 0, got %lu\n", mem);
 264:	4581                	li	a1,0
 266:	00001517          	auipc	a0,0x1
 26a:	d8250513          	addi	a0,a0,-638 # fe8 <malloc+0x4f4>
 26e:	7cc000ef          	jal	ra,a3a <printf>
    failed++;
 272:	00002717          	auipc	a4,0x2
 276:	d8e70713          	addi	a4,a4,-626 # 2000 <failed>
 27a:	431c                	lw	a5,0(a4)
 27c:	2785                	addiw	a5,a5,1
 27e:	c31c                	sw	a5,0(a4)
 280:	bf7d                	j	23e <main+0x1ec>
    printf("[FAIL] fork() failed\n");
 282:	00001517          	auipc	a0,0x1
 286:	dc650513          	addi	a0,a0,-570 # 1048 <malloc+0x554>
 28a:	7b0000ef          	jal	ra,a3a <printf>
    failed++;
 28e:	00002717          	auipc	a4,0x2
 292:	d7270713          	addi	a4,a4,-654 # 2000 <failed>
 296:	431c                	lw	a5,0(a4)
 298:	2785                	addiw	a5,a5,1
 29a:	c31c                	sw	a5,0(a4)
 29c:	a819                	j	2b2 <main+0x260>
  } else {
    // parent — wait for pid1 to terminate
    ret = waitpid(pid1);
 29e:	418000ef          	jal	ra,6b6 <waitpid>
 2a2:	85aa                	mv	a1,a0
    check("waitpid(pid1) - child exited", ret, 0);
 2a4:	4601                	li	a2,0
 2a6:	00001517          	auipc	a0,0x1
 2aa:	dba50513          	addi	a0,a0,-582 # 1060 <malloc+0x56c>
 2ae:	d53ff0ef          	jal	ra,0 <check>
  }

  // Test 2: fork another child, waitpid for it
  int pid2 = fork();
 2b2:	33c000ef          	jal	ra,5ee <fork>
  if (pid2 < 0) {
 2b6:	00054563          	bltz	a0,2c0 <main+0x26e>
    printf("[FAIL] fork() failed\n");
    failed++;
  } else if (pid2 == 0) {
 2ba:	e10d                	bnez	a0,2dc <main+0x28a>
    // child process — exit immediately
    exit(0);
 2bc:	33a000ef          	jal	ra,5f6 <exit>
    printf("[FAIL] fork() failed\n");
 2c0:	00001517          	auipc	a0,0x1
 2c4:	d8850513          	addi	a0,a0,-632 # 1048 <malloc+0x554>
 2c8:	772000ef          	jal	ra,a3a <printf>
    failed++;
 2cc:	00002717          	auipc	a4,0x2
 2d0:	d3470713          	addi	a4,a4,-716 # 2000 <failed>
 2d4:	431c                	lw	a5,0(a4)
 2d6:	2785                	addiw	a5,a5,1
 2d8:	c31c                	sw	a5,0(a4)
 2da:	a819                	j	2f0 <main+0x29e>
  } else {
    // parent — wait for pid2 to terminate
    ret = waitpid(pid2);
 2dc:	3da000ef          	jal	ra,6b6 <waitpid>
 2e0:	85aa                	mv	a1,a0
    check("waitpid(pid2) - child exited", ret, 0);
 2e2:	4601                	li	a2,0
 2e4:	00001517          	auipc	a0,0x1
 2e8:	d9c50513          	addi	a0,a0,-612 # 1080 <malloc+0x58c>
 2ec:	d15ff0ef          	jal	ra,0 <check>
  }

  // Test 3: waitpid for init (pid 1) — should fail
  // (init never exits / caller is not init's parent)
  ret = waitpid(1);
 2f0:	4505                	li	a0,1
 2f2:	3c4000ef          	jal	ra,6b6 <waitpid>
 2f6:	85aa                	mv	a1,a0
  check("waitpid(1) - not our child", ret, -1);
 2f8:	567d                	li	a2,-1
 2fa:	00001517          	auipc	a0,0x1
 2fe:	da650513          	addi	a0,a0,-602 # 10a0 <malloc+0x5ac>
 302:	cffff0ef          	jal	ra,0 <check>

  // Test 4: waitpid for non-existent pid — should fail
  ret = waitpid(99);
 306:	06300513          	li	a0,99
 30a:	3ac000ef          	jal	ra,6b6 <waitpid>
 30e:	85aa                	mv	a1,a0
  check("waitpid(99) - no such process", ret, -1);
 310:	567d                	li	a2,-1
 312:	00001517          	auipc	a0,0x1
 316:	dae50513          	addi	a0,a0,-594 # 10c0 <malloc+0x5cc>
 31a:	ce7ff0ef          	jal	ra,0 <check>

  printf("\n");
 31e:	00001517          	auipc	a0,0x1
 322:	96a50513          	addi	a0,a0,-1686 # c88 <malloc+0x194>
 326:	714000ef          	jal	ra,a3a <printf>

  // ============================================================
  printf("========== Summary ==========\n");
 32a:	00001517          	auipc	a0,0x1
 32e:	db650513          	addi	a0,a0,-586 # 10e0 <malloc+0x5ec>
 332:	708000ef          	jal	ra,a3a <printf>
  // ============================================================
  printf("Total: %d passed, %d failed\n", passed, failed);
 336:	00002617          	auipc	a2,0x2
 33a:	cca62603          	lw	a2,-822(a2) # 2000 <failed>
 33e:	00002597          	auipc	a1,0x2
 342:	cc65a583          	lw	a1,-826(a1) # 2004 <passed>
 346:	00001517          	auipc	a0,0x1
 34a:	dba50513          	addi	a0,a0,-582 # 1100 <malloc+0x60c>
 34e:	6ec000ef          	jal	ra,a3a <printf>

  exit(0);
 352:	4501                	li	a0,0
 354:	2a2000ef          	jal	ra,5f6 <exit>

0000000000000358 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 358:	1141                	addi	sp,sp,-16
 35a:	e406                	sd	ra,8(sp)
 35c:	e022                	sd	s0,0(sp)
 35e:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 360:	cf3ff0ef          	jal	ra,52 <main>
  exit(r);
 364:	292000ef          	jal	ra,5f6 <exit>

0000000000000368 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 368:	1141                	addi	sp,sp,-16
 36a:	e422                	sd	s0,8(sp)
 36c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 36e:	87aa                	mv	a5,a0
 370:	0585                	addi	a1,a1,1
 372:	0785                	addi	a5,a5,1
 374:	fff5c703          	lbu	a4,-1(a1)
 378:	fee78fa3          	sb	a4,-1(a5)
 37c:	fb75                	bnez	a4,370 <strcpy+0x8>
    ;
  return os;
}
 37e:	6422                	ld	s0,8(sp)
 380:	0141                	addi	sp,sp,16
 382:	8082                	ret

0000000000000384 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 384:	1141                	addi	sp,sp,-16
 386:	e422                	sd	s0,8(sp)
 388:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 38a:	00054783          	lbu	a5,0(a0)
 38e:	cb91                	beqz	a5,3a2 <strcmp+0x1e>
 390:	0005c703          	lbu	a4,0(a1)
 394:	00f71763          	bne	a4,a5,3a2 <strcmp+0x1e>
    p++, q++;
 398:	0505                	addi	a0,a0,1
 39a:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 39c:	00054783          	lbu	a5,0(a0)
 3a0:	fbe5                	bnez	a5,390 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 3a2:	0005c503          	lbu	a0,0(a1)
}
 3a6:	40a7853b          	subw	a0,a5,a0
 3aa:	6422                	ld	s0,8(sp)
 3ac:	0141                	addi	sp,sp,16
 3ae:	8082                	ret

00000000000003b0 <strlen>:

uint
strlen(const char *s)
{
 3b0:	1141                	addi	sp,sp,-16
 3b2:	e422                	sd	s0,8(sp)
 3b4:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 3b6:	00054783          	lbu	a5,0(a0)
 3ba:	cf91                	beqz	a5,3d6 <strlen+0x26>
 3bc:	0505                	addi	a0,a0,1
 3be:	87aa                	mv	a5,a0
 3c0:	4685                	li	a3,1
 3c2:	9e89                	subw	a3,a3,a0
 3c4:	00f6853b          	addw	a0,a3,a5
 3c8:	0785                	addi	a5,a5,1
 3ca:	fff7c703          	lbu	a4,-1(a5)
 3ce:	fb7d                	bnez	a4,3c4 <strlen+0x14>
    ;
  return n;
}
 3d0:	6422                	ld	s0,8(sp)
 3d2:	0141                	addi	sp,sp,16
 3d4:	8082                	ret
  for(n = 0; s[n]; n++)
 3d6:	4501                	li	a0,0
 3d8:	bfe5                	j	3d0 <strlen+0x20>

00000000000003da <memset>:

void*
memset(void *dst, int c, uint n)
{
 3da:	1141                	addi	sp,sp,-16
 3dc:	e422                	sd	s0,8(sp)
 3de:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 3e0:	ce09                	beqz	a2,3fa <memset+0x20>
 3e2:	87aa                	mv	a5,a0
 3e4:	fff6071b          	addiw	a4,a2,-1
 3e8:	1702                	slli	a4,a4,0x20
 3ea:	9301                	srli	a4,a4,0x20
 3ec:	0705                	addi	a4,a4,1
 3ee:	972a                	add	a4,a4,a0
    cdst[i] = c;
 3f0:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 3f4:	0785                	addi	a5,a5,1
 3f6:	fee79de3          	bne	a5,a4,3f0 <memset+0x16>
  }
  return dst;
}
 3fa:	6422                	ld	s0,8(sp)
 3fc:	0141                	addi	sp,sp,16
 3fe:	8082                	ret

0000000000000400 <strchr>:

char*
strchr(const char *s, char c)
{
 400:	1141                	addi	sp,sp,-16
 402:	e422                	sd	s0,8(sp)
 404:	0800                	addi	s0,sp,16
  for(; *s; s++)
 406:	00054783          	lbu	a5,0(a0)
 40a:	cb99                	beqz	a5,420 <strchr+0x20>
    if(*s == c)
 40c:	00f58763          	beq	a1,a5,41a <strchr+0x1a>
  for(; *s; s++)
 410:	0505                	addi	a0,a0,1
 412:	00054783          	lbu	a5,0(a0)
 416:	fbfd                	bnez	a5,40c <strchr+0xc>
      return (char*)s;
  return 0;
 418:	4501                	li	a0,0
}
 41a:	6422                	ld	s0,8(sp)
 41c:	0141                	addi	sp,sp,16
 41e:	8082                	ret
  return 0;
 420:	4501                	li	a0,0
 422:	bfe5                	j	41a <strchr+0x1a>

0000000000000424 <gets>:

char*
gets(char *buf, int max)
{
 424:	711d                	addi	sp,sp,-96
 426:	ec86                	sd	ra,88(sp)
 428:	e8a2                	sd	s0,80(sp)
 42a:	e4a6                	sd	s1,72(sp)
 42c:	e0ca                	sd	s2,64(sp)
 42e:	fc4e                	sd	s3,56(sp)
 430:	f852                	sd	s4,48(sp)
 432:	f456                	sd	s5,40(sp)
 434:	f05a                	sd	s6,32(sp)
 436:	ec5e                	sd	s7,24(sp)
 438:	1080                	addi	s0,sp,96
 43a:	8baa                	mv	s7,a0
 43c:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 43e:	892a                	mv	s2,a0
 440:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 442:	4aa9                	li	s5,10
 444:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 446:	89a6                	mv	s3,s1
 448:	2485                	addiw	s1,s1,1
 44a:	0344d663          	bge	s1,s4,476 <gets+0x52>
    cc = read(0, &c, 1);
 44e:	4605                	li	a2,1
 450:	faf40593          	addi	a1,s0,-81
 454:	4501                	li	a0,0
 456:	1b8000ef          	jal	ra,60e <read>
    if(cc < 1)
 45a:	00a05e63          	blez	a0,476 <gets+0x52>
    buf[i++] = c;
 45e:	faf44783          	lbu	a5,-81(s0)
 462:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 466:	01578763          	beq	a5,s5,474 <gets+0x50>
 46a:	0905                	addi	s2,s2,1
 46c:	fd679de3          	bne	a5,s6,446 <gets+0x22>
  for(i=0; i+1 < max; ){
 470:	89a6                	mv	s3,s1
 472:	a011                	j	476 <gets+0x52>
 474:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 476:	99de                	add	s3,s3,s7
 478:	00098023          	sb	zero,0(s3)
  return buf;
}
 47c:	855e                	mv	a0,s7
 47e:	60e6                	ld	ra,88(sp)
 480:	6446                	ld	s0,80(sp)
 482:	64a6                	ld	s1,72(sp)
 484:	6906                	ld	s2,64(sp)
 486:	79e2                	ld	s3,56(sp)
 488:	7a42                	ld	s4,48(sp)
 48a:	7aa2                	ld	s5,40(sp)
 48c:	7b02                	ld	s6,32(sp)
 48e:	6be2                	ld	s7,24(sp)
 490:	6125                	addi	sp,sp,96
 492:	8082                	ret

0000000000000494 <stat>:

int
stat(const char *n, struct stat *st)
{
 494:	1101                	addi	sp,sp,-32
 496:	ec06                	sd	ra,24(sp)
 498:	e822                	sd	s0,16(sp)
 49a:	e426                	sd	s1,8(sp)
 49c:	e04a                	sd	s2,0(sp)
 49e:	1000                	addi	s0,sp,32
 4a0:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 4a2:	4581                	li	a1,0
 4a4:	192000ef          	jal	ra,636 <open>
  if(fd < 0)
 4a8:	02054163          	bltz	a0,4ca <stat+0x36>
 4ac:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 4ae:	85ca                	mv	a1,s2
 4b0:	19e000ef          	jal	ra,64e <fstat>
 4b4:	892a                	mv	s2,a0
  close(fd);
 4b6:	8526                	mv	a0,s1
 4b8:	166000ef          	jal	ra,61e <close>
  return r;
}
 4bc:	854a                	mv	a0,s2
 4be:	60e2                	ld	ra,24(sp)
 4c0:	6442                	ld	s0,16(sp)
 4c2:	64a2                	ld	s1,8(sp)
 4c4:	6902                	ld	s2,0(sp)
 4c6:	6105                	addi	sp,sp,32
 4c8:	8082                	ret
    return -1;
 4ca:	597d                	li	s2,-1
 4cc:	bfc5                	j	4bc <stat+0x28>

00000000000004ce <atoi>:

int
atoi(const char *s)
{
 4ce:	1141                	addi	sp,sp,-16
 4d0:	e422                	sd	s0,8(sp)
 4d2:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 4d4:	00054603          	lbu	a2,0(a0)
 4d8:	fd06079b          	addiw	a5,a2,-48
 4dc:	0ff7f793          	andi	a5,a5,255
 4e0:	4725                	li	a4,9
 4e2:	02f76963          	bltu	a4,a5,514 <atoi+0x46>
 4e6:	86aa                	mv	a3,a0
  n = 0;
 4e8:	4501                	li	a0,0
  while('0' <= *s && *s <= '9')
 4ea:	45a5                	li	a1,9
    n = n*10 + *s++ - '0';
 4ec:	0685                	addi	a3,a3,1
 4ee:	0025179b          	slliw	a5,a0,0x2
 4f2:	9fa9                	addw	a5,a5,a0
 4f4:	0017979b          	slliw	a5,a5,0x1
 4f8:	9fb1                	addw	a5,a5,a2
 4fa:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 4fe:	0006c603          	lbu	a2,0(a3)
 502:	fd06071b          	addiw	a4,a2,-48
 506:	0ff77713          	andi	a4,a4,255
 50a:	fee5f1e3          	bgeu	a1,a4,4ec <atoi+0x1e>
  return n;
}
 50e:	6422                	ld	s0,8(sp)
 510:	0141                	addi	sp,sp,16
 512:	8082                	ret
  n = 0;
 514:	4501                	li	a0,0
 516:	bfe5                	j	50e <atoi+0x40>

0000000000000518 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 518:	1141                	addi	sp,sp,-16
 51a:	e422                	sd	s0,8(sp)
 51c:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 51e:	02b57663          	bgeu	a0,a1,54a <memmove+0x32>
    while(n-- > 0)
 522:	02c05163          	blez	a2,544 <memmove+0x2c>
 526:	fff6079b          	addiw	a5,a2,-1
 52a:	1782                	slli	a5,a5,0x20
 52c:	9381                	srli	a5,a5,0x20
 52e:	0785                	addi	a5,a5,1
 530:	97aa                	add	a5,a5,a0
  dst = vdst;
 532:	872a                	mv	a4,a0
      *dst++ = *src++;
 534:	0585                	addi	a1,a1,1
 536:	0705                	addi	a4,a4,1
 538:	fff5c683          	lbu	a3,-1(a1)
 53c:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 540:	fee79ae3          	bne	a5,a4,534 <memmove+0x1c>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 544:	6422                	ld	s0,8(sp)
 546:	0141                	addi	sp,sp,16
 548:	8082                	ret
    dst += n;
 54a:	00c50733          	add	a4,a0,a2
    src += n;
 54e:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 550:	fec05ae3          	blez	a2,544 <memmove+0x2c>
 554:	fff6079b          	addiw	a5,a2,-1
 558:	1782                	slli	a5,a5,0x20
 55a:	9381                	srli	a5,a5,0x20
 55c:	fff7c793          	not	a5,a5
 560:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 562:	15fd                	addi	a1,a1,-1
 564:	177d                	addi	a4,a4,-1
 566:	0005c683          	lbu	a3,0(a1)
 56a:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 56e:	fee79ae3          	bne	a5,a4,562 <memmove+0x4a>
 572:	bfc9                	j	544 <memmove+0x2c>

0000000000000574 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 574:	1141                	addi	sp,sp,-16
 576:	e422                	sd	s0,8(sp)
 578:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 57a:	ca05                	beqz	a2,5aa <memcmp+0x36>
 57c:	fff6069b          	addiw	a3,a2,-1
 580:	1682                	slli	a3,a3,0x20
 582:	9281                	srli	a3,a3,0x20
 584:	0685                	addi	a3,a3,1
 586:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 588:	00054783          	lbu	a5,0(a0)
 58c:	0005c703          	lbu	a4,0(a1)
 590:	00e79863          	bne	a5,a4,5a0 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 594:	0505                	addi	a0,a0,1
    p2++;
 596:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 598:	fed518e3          	bne	a0,a3,588 <memcmp+0x14>
  }
  return 0;
 59c:	4501                	li	a0,0
 59e:	a019                	j	5a4 <memcmp+0x30>
      return *p1 - *p2;
 5a0:	40e7853b          	subw	a0,a5,a4
}
 5a4:	6422                	ld	s0,8(sp)
 5a6:	0141                	addi	sp,sp,16
 5a8:	8082                	ret
  return 0;
 5aa:	4501                	li	a0,0
 5ac:	bfe5                	j	5a4 <memcmp+0x30>

00000000000005ae <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 5ae:	1141                	addi	sp,sp,-16
 5b0:	e406                	sd	ra,8(sp)
 5b2:	e022                	sd	s0,0(sp)
 5b4:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 5b6:	f63ff0ef          	jal	ra,518 <memmove>
}
 5ba:	60a2                	ld	ra,8(sp)
 5bc:	6402                	ld	s0,0(sp)
 5be:	0141                	addi	sp,sp,16
 5c0:	8082                	ret

00000000000005c2 <sbrk>:

char *
sbrk(int n) {
 5c2:	1141                	addi	sp,sp,-16
 5c4:	e406                	sd	ra,8(sp)
 5c6:	e022                	sd	s0,0(sp)
 5c8:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 5ca:	4585                	li	a1,1
 5cc:	0b2000ef          	jal	ra,67e <sys_sbrk>
}
 5d0:	60a2                	ld	ra,8(sp)
 5d2:	6402                	ld	s0,0(sp)
 5d4:	0141                	addi	sp,sp,16
 5d6:	8082                	ret

00000000000005d8 <sbrklazy>:

char *
sbrklazy(int n) {
 5d8:	1141                	addi	sp,sp,-16
 5da:	e406                	sd	ra,8(sp)
 5dc:	e022                	sd	s0,0(sp)
 5de:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 5e0:	4589                	li	a1,2
 5e2:	09c000ef          	jal	ra,67e <sys_sbrk>
}
 5e6:	60a2                	ld	ra,8(sp)
 5e8:	6402                	ld	s0,0(sp)
 5ea:	0141                	addi	sp,sp,16
 5ec:	8082                	ret

00000000000005ee <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 5ee:	4885                	li	a7,1
 ecall
 5f0:	00000073          	ecall
 ret
 5f4:	8082                	ret

00000000000005f6 <exit>:
.global exit
exit:
 li a7, SYS_exit
 5f6:	4889                	li	a7,2
 ecall
 5f8:	00000073          	ecall
 ret
 5fc:	8082                	ret

00000000000005fe <wait>:
.global wait
wait:
 li a7, SYS_wait
 5fe:	488d                	li	a7,3
 ecall
 600:	00000073          	ecall
 ret
 604:	8082                	ret

0000000000000606 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 606:	4891                	li	a7,4
 ecall
 608:	00000073          	ecall
 ret
 60c:	8082                	ret

000000000000060e <read>:
.global read
read:
 li a7, SYS_read
 60e:	4895                	li	a7,5
 ecall
 610:	00000073          	ecall
 ret
 614:	8082                	ret

0000000000000616 <write>:
.global write
write:
 li a7, SYS_write
 616:	48c1                	li	a7,16
 ecall
 618:	00000073          	ecall
 ret
 61c:	8082                	ret

000000000000061e <close>:
.global close
close:
 li a7, SYS_close
 61e:	48d5                	li	a7,21
 ecall
 620:	00000073          	ecall
 ret
 624:	8082                	ret

0000000000000626 <kill>:
.global kill
kill:
 li a7, SYS_kill
 626:	4899                	li	a7,6
 ecall
 628:	00000073          	ecall
 ret
 62c:	8082                	ret

000000000000062e <exec>:
.global exec
exec:
 li a7, SYS_exec
 62e:	489d                	li	a7,7
 ecall
 630:	00000073          	ecall
 ret
 634:	8082                	ret

0000000000000636 <open>:
.global open
open:
 li a7, SYS_open
 636:	48bd                	li	a7,15
 ecall
 638:	00000073          	ecall
 ret
 63c:	8082                	ret

000000000000063e <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 63e:	48c5                	li	a7,17
 ecall
 640:	00000073          	ecall
 ret
 644:	8082                	ret

0000000000000646 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 646:	48c9                	li	a7,18
 ecall
 648:	00000073          	ecall
 ret
 64c:	8082                	ret

000000000000064e <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 64e:	48a1                	li	a7,8
 ecall
 650:	00000073          	ecall
 ret
 654:	8082                	ret

0000000000000656 <link>:
.global link
link:
 li a7, SYS_link
 656:	48cd                	li	a7,19
 ecall
 658:	00000073          	ecall
 ret
 65c:	8082                	ret

000000000000065e <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 65e:	48d1                	li	a7,20
 ecall
 660:	00000073          	ecall
 ret
 664:	8082                	ret

0000000000000666 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 666:	48a5                	li	a7,9
 ecall
 668:	00000073          	ecall
 ret
 66c:	8082                	ret

000000000000066e <dup>:
.global dup
dup:
 li a7, SYS_dup
 66e:	48a9                	li	a7,10
 ecall
 670:	00000073          	ecall
 ret
 674:	8082                	ret

0000000000000676 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 676:	48ad                	li	a7,11
 ecall
 678:	00000073          	ecall
 ret
 67c:	8082                	ret

000000000000067e <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 67e:	48b1                	li	a7,12
 ecall
 680:	00000073          	ecall
 ret
 684:	8082                	ret

0000000000000686 <pause>:
.global pause
pause:
 li a7, SYS_pause
 686:	48b5                	li	a7,13
 ecall
 688:	00000073          	ecall
 ret
 68c:	8082                	ret

000000000000068e <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 68e:	48b9                	li	a7,14
 ecall
 690:	00000073          	ecall
 ret
 694:	8082                	ret

0000000000000696 <getnice>:
.global getnice
getnice:
 li a7, SYS_getnice
 696:	48d9                	li	a7,22
 ecall
 698:	00000073          	ecall
 ret
 69c:	8082                	ret

000000000000069e <setnice>:
.global setnice
setnice:
 li a7, SYS_setnice
 69e:	48dd                	li	a7,23
 ecall
 6a0:	00000073          	ecall
 ret
 6a4:	8082                	ret

00000000000006a6 <ps>:
.global ps
ps:
 li a7, SYS_ps
 6a6:	48e1                	li	a7,24
 ecall
 6a8:	00000073          	ecall
 ret
 6ac:	8082                	ret

00000000000006ae <meminfo>:
.global meminfo
meminfo:
 li a7, SYS_meminfo
 6ae:	48e5                	li	a7,25
 ecall
 6b0:	00000073          	ecall
 ret
 6b4:	8082                	ret

00000000000006b6 <waitpid>:
.global waitpid
waitpid:
 li a7, SYS_waitpid
 6b6:	48e9                	li	a7,26
 ecall
 6b8:	00000073          	ecall
 ret
 6bc:	8082                	ret

00000000000006be <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 6be:	1101                	addi	sp,sp,-32
 6c0:	ec06                	sd	ra,24(sp)
 6c2:	e822                	sd	s0,16(sp)
 6c4:	1000                	addi	s0,sp,32
 6c6:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 6ca:	4605                	li	a2,1
 6cc:	fef40593          	addi	a1,s0,-17
 6d0:	f47ff0ef          	jal	ra,616 <write>
}
 6d4:	60e2                	ld	ra,24(sp)
 6d6:	6442                	ld	s0,16(sp)
 6d8:	6105                	addi	sp,sp,32
 6da:	8082                	ret

00000000000006dc <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 6dc:	715d                	addi	sp,sp,-80
 6de:	e486                	sd	ra,72(sp)
 6e0:	e0a2                	sd	s0,64(sp)
 6e2:	fc26                	sd	s1,56(sp)
 6e4:	f84a                	sd	s2,48(sp)
 6e6:	f44e                	sd	s3,40(sp)
 6e8:	0880                	addi	s0,sp,80
 6ea:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 6ec:	c299                	beqz	a3,6f2 <printint+0x16>
 6ee:	0805c163          	bltz	a1,770 <printint+0x94>
  neg = 0;
 6f2:	4881                	li	a7,0
 6f4:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 6f8:	4781                	li	a5,0
  do{
    buf[i++] = digits[x % base];
 6fa:	00001517          	auipc	a0,0x1
 6fe:	a2e50513          	addi	a0,a0,-1490 # 1128 <digits>
 702:	883e                	mv	a6,a5
 704:	2785                	addiw	a5,a5,1
 706:	02c5f733          	remu	a4,a1,a2
 70a:	972a                	add	a4,a4,a0
 70c:	00074703          	lbu	a4,0(a4)
 710:	00e68023          	sb	a4,0(a3)
  }while((x /= base) != 0);
 714:	872e                	mv	a4,a1
 716:	02c5d5b3          	divu	a1,a1,a2
 71a:	0685                	addi	a3,a3,1
 71c:	fec773e3          	bgeu	a4,a2,702 <printint+0x26>
  if(neg)
 720:	00088b63          	beqz	a7,736 <printint+0x5a>
    buf[i++] = '-';
 724:	fd040713          	addi	a4,s0,-48
 728:	97ba                	add	a5,a5,a4
 72a:	02d00713          	li	a4,45
 72e:	fee78423          	sb	a4,-24(a5)
 732:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
 736:	02f05663          	blez	a5,762 <printint+0x86>
 73a:	fb840713          	addi	a4,s0,-72
 73e:	00f704b3          	add	s1,a4,a5
 742:	fff70993          	addi	s3,a4,-1
 746:	99be                	add	s3,s3,a5
 748:	37fd                	addiw	a5,a5,-1
 74a:	1782                	slli	a5,a5,0x20
 74c:	9381                	srli	a5,a5,0x20
 74e:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 752:	fff4c583          	lbu	a1,-1(s1)
 756:	854a                	mv	a0,s2
 758:	f67ff0ef          	jal	ra,6be <putc>
  while(--i >= 0)
 75c:	14fd                	addi	s1,s1,-1
 75e:	ff349ae3          	bne	s1,s3,752 <printint+0x76>
}
 762:	60a6                	ld	ra,72(sp)
 764:	6406                	ld	s0,64(sp)
 766:	74e2                	ld	s1,56(sp)
 768:	7942                	ld	s2,48(sp)
 76a:	79a2                	ld	s3,40(sp)
 76c:	6161                	addi	sp,sp,80
 76e:	8082                	ret
    x = -xx;
 770:	40b005b3          	neg	a1,a1
    neg = 1;
 774:	4885                	li	a7,1
    x = -xx;
 776:	bfbd                	j	6f4 <printint+0x18>

0000000000000778 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 778:	7119                	addi	sp,sp,-128
 77a:	fc86                	sd	ra,120(sp)
 77c:	f8a2                	sd	s0,112(sp)
 77e:	f4a6                	sd	s1,104(sp)
 780:	f0ca                	sd	s2,96(sp)
 782:	ecce                	sd	s3,88(sp)
 784:	e8d2                	sd	s4,80(sp)
 786:	e4d6                	sd	s5,72(sp)
 788:	e0da                	sd	s6,64(sp)
 78a:	fc5e                	sd	s7,56(sp)
 78c:	f862                	sd	s8,48(sp)
 78e:	f466                	sd	s9,40(sp)
 790:	f06a                	sd	s10,32(sp)
 792:	ec6e                	sd	s11,24(sp)
 794:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 796:	0005c903          	lbu	s2,0(a1)
 79a:	24090c63          	beqz	s2,9f2 <vprintf+0x27a>
 79e:	8b2a                	mv	s6,a0
 7a0:	8a2e                	mv	s4,a1
 7a2:	8bb2                	mv	s7,a2
  state = 0;
 7a4:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 7a6:	4481                	li	s1,0
 7a8:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 7aa:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 7ae:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 7b2:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 7b6:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 7ba:	00001c97          	auipc	s9,0x1
 7be:	96ec8c93          	addi	s9,s9,-1682 # 1128 <digits>
 7c2:	a005                	j	7e2 <vprintf+0x6a>
        putc(fd, c0);
 7c4:	85ca                	mv	a1,s2
 7c6:	855a                	mv	a0,s6
 7c8:	ef7ff0ef          	jal	ra,6be <putc>
 7cc:	a019                	j	7d2 <vprintf+0x5a>
    } else if(state == '%'){
 7ce:	03598263          	beq	s3,s5,7f2 <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 7d2:	2485                	addiw	s1,s1,1
 7d4:	8726                	mv	a4,s1
 7d6:	009a07b3          	add	a5,s4,s1
 7da:	0007c903          	lbu	s2,0(a5)
 7de:	20090a63          	beqz	s2,9f2 <vprintf+0x27a>
    c0 = fmt[i] & 0xff;
 7e2:	0009079b          	sext.w	a5,s2
    if(state == 0){
 7e6:	fe0994e3          	bnez	s3,7ce <vprintf+0x56>
      if(c0 == '%'){
 7ea:	fd579de3          	bne	a5,s5,7c4 <vprintf+0x4c>
        state = '%';
 7ee:	89be                	mv	s3,a5
 7f0:	b7cd                	j	7d2 <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
 7f2:	c3c1                	beqz	a5,872 <vprintf+0xfa>
 7f4:	00ea06b3          	add	a3,s4,a4
 7f8:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 7fc:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 7fe:	c681                	beqz	a3,806 <vprintf+0x8e>
 800:	9752                	add	a4,a4,s4
 802:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 806:	03878e63          	beq	a5,s8,842 <vprintf+0xca>
      } else if(c0 == 'l' && c1 == 'd'){
 80a:	05a78863          	beq	a5,s10,85a <vprintf+0xe2>
      } else if(c0 == 'u'){
 80e:	0db78b63          	beq	a5,s11,8e4 <vprintf+0x16c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 812:	07800713          	li	a4,120
 816:	10e78d63          	beq	a5,a4,930 <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 81a:	07000713          	li	a4,112
 81e:	14e78263          	beq	a5,a4,962 <vprintf+0x1ea>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 822:	06300713          	li	a4,99
 826:	16e78f63          	beq	a5,a4,9a4 <vprintf+0x22c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 82a:	07300713          	li	a4,115
 82e:	18e78563          	beq	a5,a4,9b8 <vprintf+0x240>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 832:	05579063          	bne	a5,s5,872 <vprintf+0xfa>
        putc(fd, '%');
 836:	85d6                	mv	a1,s5
 838:	855a                	mv	a0,s6
 83a:	e85ff0ef          	jal	ra,6be <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 83e:	4981                	li	s3,0
 840:	bf49                	j	7d2 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
 842:	008b8913          	addi	s2,s7,8
 846:	4685                	li	a3,1
 848:	4629                	li	a2,10
 84a:	000ba583          	lw	a1,0(s7)
 84e:	855a                	mv	a0,s6
 850:	e8dff0ef          	jal	ra,6dc <printint>
 854:	8bca                	mv	s7,s2
      state = 0;
 856:	4981                	li	s3,0
 858:	bfad                	j	7d2 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
 85a:	03868663          	beq	a3,s8,886 <vprintf+0x10e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 85e:	05a68163          	beq	a3,s10,8a0 <vprintf+0x128>
      } else if(c0 == 'l' && c1 == 'u'){
 862:	09b68d63          	beq	a3,s11,8fc <vprintf+0x184>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 866:	03a68f63          	beq	a3,s10,8a4 <vprintf+0x12c>
      } else if(c0 == 'l' && c1 == 'x'){
 86a:	07800793          	li	a5,120
 86e:	0cf68d63          	beq	a3,a5,948 <vprintf+0x1d0>
        putc(fd, '%');
 872:	85d6                	mv	a1,s5
 874:	855a                	mv	a0,s6
 876:	e49ff0ef          	jal	ra,6be <putc>
        putc(fd, c0);
 87a:	85ca                	mv	a1,s2
 87c:	855a                	mv	a0,s6
 87e:	e41ff0ef          	jal	ra,6be <putc>
      state = 0;
 882:	4981                	li	s3,0
 884:	b7b9                	j	7d2 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 886:	008b8913          	addi	s2,s7,8
 88a:	4685                	li	a3,1
 88c:	4629                	li	a2,10
 88e:	000bb583          	ld	a1,0(s7)
 892:	855a                	mv	a0,s6
 894:	e49ff0ef          	jal	ra,6dc <printint>
        i += 1;
 898:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 89a:	8bca                	mv	s7,s2
      state = 0;
 89c:	4981                	li	s3,0
        i += 1;
 89e:	bf15                	j	7d2 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 8a0:	03860563          	beq	a2,s8,8ca <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 8a4:	07b60963          	beq	a2,s11,916 <vprintf+0x19e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 8a8:	07800793          	li	a5,120
 8ac:	fcf613e3          	bne	a2,a5,872 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 8b0:	008b8913          	addi	s2,s7,8
 8b4:	4681                	li	a3,0
 8b6:	4641                	li	a2,16
 8b8:	000bb583          	ld	a1,0(s7)
 8bc:	855a                	mv	a0,s6
 8be:	e1fff0ef          	jal	ra,6dc <printint>
        i += 2;
 8c2:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 8c4:	8bca                	mv	s7,s2
      state = 0;
 8c6:	4981                	li	s3,0
        i += 2;
 8c8:	b729                	j	7d2 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 8ca:	008b8913          	addi	s2,s7,8
 8ce:	4685                	li	a3,1
 8d0:	4629                	li	a2,10
 8d2:	000bb583          	ld	a1,0(s7)
 8d6:	855a                	mv	a0,s6
 8d8:	e05ff0ef          	jal	ra,6dc <printint>
        i += 2;
 8dc:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 8de:	8bca                	mv	s7,s2
      state = 0;
 8e0:	4981                	li	s3,0
        i += 2;
 8e2:	bdc5                	j	7d2 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 8e4:	008b8913          	addi	s2,s7,8
 8e8:	4681                	li	a3,0
 8ea:	4629                	li	a2,10
 8ec:	000be583          	lwu	a1,0(s7)
 8f0:	855a                	mv	a0,s6
 8f2:	debff0ef          	jal	ra,6dc <printint>
 8f6:	8bca                	mv	s7,s2
      state = 0;
 8f8:	4981                	li	s3,0
 8fa:	bde1                	j	7d2 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 8fc:	008b8913          	addi	s2,s7,8
 900:	4681                	li	a3,0
 902:	4629                	li	a2,10
 904:	000bb583          	ld	a1,0(s7)
 908:	855a                	mv	a0,s6
 90a:	dd3ff0ef          	jal	ra,6dc <printint>
        i += 1;
 90e:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 910:	8bca                	mv	s7,s2
      state = 0;
 912:	4981                	li	s3,0
        i += 1;
 914:	bd7d                	j	7d2 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 916:	008b8913          	addi	s2,s7,8
 91a:	4681                	li	a3,0
 91c:	4629                	li	a2,10
 91e:	000bb583          	ld	a1,0(s7)
 922:	855a                	mv	a0,s6
 924:	db9ff0ef          	jal	ra,6dc <printint>
        i += 2;
 928:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 92a:	8bca                	mv	s7,s2
      state = 0;
 92c:	4981                	li	s3,0
        i += 2;
 92e:	b555                	j	7d2 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 930:	008b8913          	addi	s2,s7,8
 934:	4681                	li	a3,0
 936:	4641                	li	a2,16
 938:	000be583          	lwu	a1,0(s7)
 93c:	855a                	mv	a0,s6
 93e:	d9fff0ef          	jal	ra,6dc <printint>
 942:	8bca                	mv	s7,s2
      state = 0;
 944:	4981                	li	s3,0
 946:	b571                	j	7d2 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 948:	008b8913          	addi	s2,s7,8
 94c:	4681                	li	a3,0
 94e:	4641                	li	a2,16
 950:	000bb583          	ld	a1,0(s7)
 954:	855a                	mv	a0,s6
 956:	d87ff0ef          	jal	ra,6dc <printint>
        i += 1;
 95a:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 95c:	8bca                	mv	s7,s2
      state = 0;
 95e:	4981                	li	s3,0
        i += 1;
 960:	bd8d                	j	7d2 <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
 962:	008b8793          	addi	a5,s7,8
 966:	f8f43423          	sd	a5,-120(s0)
 96a:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 96e:	03000593          	li	a1,48
 972:	855a                	mv	a0,s6
 974:	d4bff0ef          	jal	ra,6be <putc>
  putc(fd, 'x');
 978:	07800593          	li	a1,120
 97c:	855a                	mv	a0,s6
 97e:	d41ff0ef          	jal	ra,6be <putc>
 982:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 984:	03c9d793          	srli	a5,s3,0x3c
 988:	97e6                	add	a5,a5,s9
 98a:	0007c583          	lbu	a1,0(a5)
 98e:	855a                	mv	a0,s6
 990:	d2fff0ef          	jal	ra,6be <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 994:	0992                	slli	s3,s3,0x4
 996:	397d                	addiw	s2,s2,-1
 998:	fe0916e3          	bnez	s2,984 <vprintf+0x20c>
        printptr(fd, va_arg(ap, uint64));
 99c:	f8843b83          	ld	s7,-120(s0)
      state = 0;
 9a0:	4981                	li	s3,0
 9a2:	bd05                	j	7d2 <vprintf+0x5a>
        putc(fd, va_arg(ap, uint32));
 9a4:	008b8913          	addi	s2,s7,8
 9a8:	000bc583          	lbu	a1,0(s7)
 9ac:	855a                	mv	a0,s6
 9ae:	d11ff0ef          	jal	ra,6be <putc>
 9b2:	8bca                	mv	s7,s2
      state = 0;
 9b4:	4981                	li	s3,0
 9b6:	bd31                	j	7d2 <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
 9b8:	008b8993          	addi	s3,s7,8
 9bc:	000bb903          	ld	s2,0(s7)
 9c0:	00090f63          	beqz	s2,9de <vprintf+0x266>
        for(; *s; s++)
 9c4:	00094583          	lbu	a1,0(s2)
 9c8:	c195                	beqz	a1,9ec <vprintf+0x274>
          putc(fd, *s);
 9ca:	855a                	mv	a0,s6
 9cc:	cf3ff0ef          	jal	ra,6be <putc>
        for(; *s; s++)
 9d0:	0905                	addi	s2,s2,1
 9d2:	00094583          	lbu	a1,0(s2)
 9d6:	f9f5                	bnez	a1,9ca <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 9d8:	8bce                	mv	s7,s3
      state = 0;
 9da:	4981                	li	s3,0
 9dc:	bbdd                	j	7d2 <vprintf+0x5a>
          s = "(null)";
 9de:	00000917          	auipc	s2,0x0
 9e2:	74290913          	addi	s2,s2,1858 # 1120 <malloc+0x62c>
        for(; *s; s++)
 9e6:	02800593          	li	a1,40
 9ea:	b7c5                	j	9ca <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 9ec:	8bce                	mv	s7,s3
      state = 0;
 9ee:	4981                	li	s3,0
 9f0:	b3cd                	j	7d2 <vprintf+0x5a>
    }
  }
}
 9f2:	70e6                	ld	ra,120(sp)
 9f4:	7446                	ld	s0,112(sp)
 9f6:	74a6                	ld	s1,104(sp)
 9f8:	7906                	ld	s2,96(sp)
 9fa:	69e6                	ld	s3,88(sp)
 9fc:	6a46                	ld	s4,80(sp)
 9fe:	6aa6                	ld	s5,72(sp)
 a00:	6b06                	ld	s6,64(sp)
 a02:	7be2                	ld	s7,56(sp)
 a04:	7c42                	ld	s8,48(sp)
 a06:	7ca2                	ld	s9,40(sp)
 a08:	7d02                	ld	s10,32(sp)
 a0a:	6de2                	ld	s11,24(sp)
 a0c:	6109                	addi	sp,sp,128
 a0e:	8082                	ret

0000000000000a10 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 a10:	715d                	addi	sp,sp,-80
 a12:	ec06                	sd	ra,24(sp)
 a14:	e822                	sd	s0,16(sp)
 a16:	1000                	addi	s0,sp,32
 a18:	e010                	sd	a2,0(s0)
 a1a:	e414                	sd	a3,8(s0)
 a1c:	e818                	sd	a4,16(s0)
 a1e:	ec1c                	sd	a5,24(s0)
 a20:	03043023          	sd	a6,32(s0)
 a24:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 a28:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 a2c:	8622                	mv	a2,s0
 a2e:	d4bff0ef          	jal	ra,778 <vprintf>
}
 a32:	60e2                	ld	ra,24(sp)
 a34:	6442                	ld	s0,16(sp)
 a36:	6161                	addi	sp,sp,80
 a38:	8082                	ret

0000000000000a3a <printf>:

void
printf(const char *fmt, ...)
{
 a3a:	711d                	addi	sp,sp,-96
 a3c:	ec06                	sd	ra,24(sp)
 a3e:	e822                	sd	s0,16(sp)
 a40:	1000                	addi	s0,sp,32
 a42:	e40c                	sd	a1,8(s0)
 a44:	e810                	sd	a2,16(s0)
 a46:	ec14                	sd	a3,24(s0)
 a48:	f018                	sd	a4,32(s0)
 a4a:	f41c                	sd	a5,40(s0)
 a4c:	03043823          	sd	a6,48(s0)
 a50:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 a54:	00840613          	addi	a2,s0,8
 a58:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 a5c:	85aa                	mv	a1,a0
 a5e:	4505                	li	a0,1
 a60:	d19ff0ef          	jal	ra,778 <vprintf>
}
 a64:	60e2                	ld	ra,24(sp)
 a66:	6442                	ld	s0,16(sp)
 a68:	6125                	addi	sp,sp,96
 a6a:	8082                	ret

0000000000000a6c <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 a6c:	1141                	addi	sp,sp,-16
 a6e:	e422                	sd	s0,8(sp)
 a70:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 a72:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 a76:	00001797          	auipc	a5,0x1
 a7a:	5927b783          	ld	a5,1426(a5) # 2008 <freep>
 a7e:	a805                	j	aae <free+0x42>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 a80:	4618                	lw	a4,8(a2)
 a82:	9db9                	addw	a1,a1,a4
 a84:	feb52c23          	sw	a1,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 a88:	6398                	ld	a4,0(a5)
 a8a:	6318                	ld	a4,0(a4)
 a8c:	fee53823          	sd	a4,-16(a0)
 a90:	a091                	j	ad4 <free+0x68>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 a92:	ff852703          	lw	a4,-8(a0)
 a96:	9e39                	addw	a2,a2,a4
 a98:	c790                	sw	a2,8(a5)
    p->s.ptr = bp->s.ptr;
 a9a:	ff053703          	ld	a4,-16(a0)
 a9e:	e398                	sd	a4,0(a5)
 aa0:	a099                	j	ae6 <free+0x7a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 aa2:	6398                	ld	a4,0(a5)
 aa4:	00e7e463          	bltu	a5,a4,aac <free+0x40>
 aa8:	00e6ea63          	bltu	a3,a4,abc <free+0x50>
{
 aac:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 aae:	fed7fae3          	bgeu	a5,a3,aa2 <free+0x36>
 ab2:	6398                	ld	a4,0(a5)
 ab4:	00e6e463          	bltu	a3,a4,abc <free+0x50>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 ab8:	fee7eae3          	bltu	a5,a4,aac <free+0x40>
  if(bp + bp->s.size == p->s.ptr){
 abc:	ff852583          	lw	a1,-8(a0)
 ac0:	6390                	ld	a2,0(a5)
 ac2:	02059713          	slli	a4,a1,0x20
 ac6:	9301                	srli	a4,a4,0x20
 ac8:	0712                	slli	a4,a4,0x4
 aca:	9736                	add	a4,a4,a3
 acc:	fae60ae3          	beq	a2,a4,a80 <free+0x14>
    bp->s.ptr = p->s.ptr;
 ad0:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 ad4:	4790                	lw	a2,8(a5)
 ad6:	02061713          	slli	a4,a2,0x20
 ada:	9301                	srli	a4,a4,0x20
 adc:	0712                	slli	a4,a4,0x4
 ade:	973e                	add	a4,a4,a5
 ae0:	fae689e3          	beq	a3,a4,a92 <free+0x26>
  } else
    p->s.ptr = bp;
 ae4:	e394                	sd	a3,0(a5)
  freep = p;
 ae6:	00001717          	auipc	a4,0x1
 aea:	52f73123          	sd	a5,1314(a4) # 2008 <freep>
}
 aee:	6422                	ld	s0,8(sp)
 af0:	0141                	addi	sp,sp,16
 af2:	8082                	ret

0000000000000af4 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 af4:	7139                	addi	sp,sp,-64
 af6:	fc06                	sd	ra,56(sp)
 af8:	f822                	sd	s0,48(sp)
 afa:	f426                	sd	s1,40(sp)
 afc:	f04a                	sd	s2,32(sp)
 afe:	ec4e                	sd	s3,24(sp)
 b00:	e852                	sd	s4,16(sp)
 b02:	e456                	sd	s5,8(sp)
 b04:	e05a                	sd	s6,0(sp)
 b06:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 b08:	02051493          	slli	s1,a0,0x20
 b0c:	9081                	srli	s1,s1,0x20
 b0e:	04bd                	addi	s1,s1,15
 b10:	8091                	srli	s1,s1,0x4
 b12:	0014899b          	addiw	s3,s1,1
 b16:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 b18:	00001517          	auipc	a0,0x1
 b1c:	4f053503          	ld	a0,1264(a0) # 2008 <freep>
 b20:	c515                	beqz	a0,b4c <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 b22:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 b24:	4798                	lw	a4,8(a5)
 b26:	02977f63          	bgeu	a4,s1,b64 <malloc+0x70>
 b2a:	8a4e                	mv	s4,s3
 b2c:	0009871b          	sext.w	a4,s3
 b30:	6685                	lui	a3,0x1
 b32:	00d77363          	bgeu	a4,a3,b38 <malloc+0x44>
 b36:	6a05                	lui	s4,0x1
 b38:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 b3c:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 b40:	00001917          	auipc	s2,0x1
 b44:	4c890913          	addi	s2,s2,1224 # 2008 <freep>
  if(p == SBRK_ERROR)
 b48:	5afd                	li	s5,-1
 b4a:	a0bd                	j	bb8 <malloc+0xc4>
    base.s.ptr = freep = prevp = &base;
 b4c:	00001797          	auipc	a5,0x1
 b50:	4c478793          	addi	a5,a5,1220 # 2010 <base>
 b54:	00001717          	auipc	a4,0x1
 b58:	4af73a23          	sd	a5,1204(a4) # 2008 <freep>
 b5c:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 b5e:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 b62:	b7e1                	j	b2a <malloc+0x36>
      if(p->s.size == nunits)
 b64:	02e48b63          	beq	s1,a4,b9a <malloc+0xa6>
        p->s.size -= nunits;
 b68:	4137073b          	subw	a4,a4,s3
 b6c:	c798                	sw	a4,8(a5)
        p += p->s.size;
 b6e:	1702                	slli	a4,a4,0x20
 b70:	9301                	srli	a4,a4,0x20
 b72:	0712                	slli	a4,a4,0x4
 b74:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 b76:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 b7a:	00001717          	auipc	a4,0x1
 b7e:	48a73723          	sd	a0,1166(a4) # 2008 <freep>
      return (void*)(p + 1);
 b82:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 b86:	70e2                	ld	ra,56(sp)
 b88:	7442                	ld	s0,48(sp)
 b8a:	74a2                	ld	s1,40(sp)
 b8c:	7902                	ld	s2,32(sp)
 b8e:	69e2                	ld	s3,24(sp)
 b90:	6a42                	ld	s4,16(sp)
 b92:	6aa2                	ld	s5,8(sp)
 b94:	6b02                	ld	s6,0(sp)
 b96:	6121                	addi	sp,sp,64
 b98:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 b9a:	6398                	ld	a4,0(a5)
 b9c:	e118                	sd	a4,0(a0)
 b9e:	bff1                	j	b7a <malloc+0x86>
  hp->s.size = nu;
 ba0:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 ba4:	0541                	addi	a0,a0,16
 ba6:	ec7ff0ef          	jal	ra,a6c <free>
  return freep;
 baa:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 bae:	dd61                	beqz	a0,b86 <malloc+0x92>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 bb0:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 bb2:	4798                	lw	a4,8(a5)
 bb4:	fa9778e3          	bgeu	a4,s1,b64 <malloc+0x70>
    if(p == freep)
 bb8:	00093703          	ld	a4,0(s2)
 bbc:	853e                	mv	a0,a5
 bbe:	fef719e3          	bne	a4,a5,bb0 <malloc+0xbc>
  p = sbrk(nu * sizeof(Header));
 bc2:	8552                	mv	a0,s4
 bc4:	9ffff0ef          	jal	ra,5c2 <sbrk>
  if(p == SBRK_ERROR)
 bc8:	fd551ce3          	bne	a0,s5,ba0 <malloc+0xac>
        return 0;
 bcc:	4501                	li	a0,0
 bce:	bf65                	j	b86 <malloc+0x92>
