
user/_ourtest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <check>:

int passed = 0;
int failed = 0;

void check(const char *test, int actual, int expected)
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
   8:	86ae                	mv	a3,a1
  if (actual == expected) {
   a:	02c58463          	beq	a1,a2,32 <check+0x32>
    printf("[PASS] %s : got %d\n", test, actual);
    passed++;
  } else {
    printf("[FAIL] %s : expected %d, got %d\n", test, expected, actual);
   e:	85aa                	mv	a1,a0
  10:	00001517          	auipc	a0,0x1
  14:	c7850513          	addi	a0,a0,-904 # c88 <malloc+0xfa>
  18:	2bd000ef          	jal	ra,ad4 <printf>
    failed++;
  1c:	00002717          	auipc	a4,0x2
  20:	fe470713          	addi	a4,a4,-28 # 2000 <failed>
  24:	431c                	lw	a5,0(a4)
  26:	2785                	addiw	a5,a5,1
  28:	c31c                	sw	a5,0(a4)
  }
}
  2a:	60a2                	ld	ra,8(sp)
  2c:	6402                	ld	s0,0(sp)
  2e:	0141                	addi	sp,sp,16
  30:	8082                	ret
    printf("[PASS] %s : got %d\n", test, actual);
  32:	862e                	mv	a2,a1
  34:	85aa                	mv	a1,a0
  36:	00001517          	auipc	a0,0x1
  3a:	c3a50513          	addi	a0,a0,-966 # c70 <malloc+0xe2>
  3e:	297000ef          	jal	ra,ad4 <printf>
    passed++;
  42:	00002717          	auipc	a4,0x2
  46:	fc270713          	addi	a4,a4,-62 # 2004 <passed>
  4a:	431c                	lw	a5,0(a4)
  4c:	2785                	addiw	a5,a5,1
  4e:	c31c                	sw	a5,0(a4)
  50:	bfe9                	j	2a <check+0x2a>

0000000000000052 <main>:

int main()
{
  52:	1101                	addi	sp,sp,-32
  54:	ec06                	sd	ra,24(sp)
  56:	e822                	sd	s0,16(sp)
  58:	e426                	sd	s1,8(sp)
  5a:	1000                	addi	s0,sp,32
  int ret;

  // ============================================================
  printf("========== Testing getnice() ==========\n");
  5c:	00001517          	auipc	a0,0x1
  60:	c5450513          	addi	a0,a0,-940 # cb0 <malloc+0x122>
  64:	271000ef          	jal	ra,ad4 <printf>
  // ============================================================

  // pid 3 (mytest2) exists, default nice = 20
  ret = getnice(3);
  68:	450d                	li	a0,3
  6a:	6c6000ef          	jal	ra,730 <getnice>
  6e:	85aa                	mv	a1,a0
  check("getnice(3) - mytest2 default nice", ret, 20);
  70:	4651                	li	a2,20
  72:	00001517          	auipc	a0,0x1
  76:	c6e50513          	addi	a0,a0,-914 # ce0 <malloc+0x152>
  7a:	f87ff0ef          	jal	ra,0 <check>

  // set to min boundary (0) and verify
  setnice(1, 0);
  7e:	4581                	li	a1,0
  80:	4505                	li	a0,1
  82:	6b6000ef          	jal	ra,738 <setnice>
  ret = getnice(1);
  86:	4505                	li	a0,1
  88:	6a8000ef          	jal	ra,730 <getnice>
  8c:	85aa                	mv	a1,a0
  check("getnice(1) - after setnice to 0 (min)", ret, 0);
  8e:	4601                	li	a2,0
  90:	00001517          	auipc	a0,0x1
  94:	c7850513          	addi	a0,a0,-904 # d08 <malloc+0x17a>
  98:	f69ff0ef          	jal	ra,0 <check>

  // set to max boundary (39) and verify
  setnice(1, 39);
  9c:	02700593          	li	a1,39
  a0:	4505                	li	a0,1
  a2:	696000ef          	jal	ra,738 <setnice>
  ret = getnice(1);
  a6:	4505                	li	a0,1
  a8:	688000ef          	jal	ra,730 <getnice>
  ac:	85aa                	mv	a1,a0
  check("getnice(1) - after setnice to 39 (max)", ret, 39);
  ae:	02700613          	li	a2,39
  b2:	00001517          	auipc	a0,0x1
  b6:	c7e50513          	addi	a0,a0,-898 # d30 <malloc+0x1a2>
  ba:	f47ff0ef          	jal	ra,0 <check>

  // restore to default
  setnice(1, 20);
  be:	45d1                	li	a1,20
  c0:	4505                	li	a0,1
  c2:	676000ef          	jal	ra,738 <setnice>

  // pid 0 does not exist → should return -1
  ret = getnice(0);
  c6:	4501                	li	a0,0
  c8:	668000ef          	jal	ra,730 <getnice>
  cc:	85aa                	mv	a1,a0
  check("getnice(0) - no such process", ret, -1);
  ce:	567d                	li	a2,-1
  d0:	00001517          	auipc	a0,0x1
  d4:	c8850513          	addi	a0,a0,-888 # d58 <malloc+0x1ca>
  d8:	f29ff0ef          	jal	ra,0 <check>

  // negative pid does not exist → should return -1
  ret = getnice(-1);
  dc:	557d                	li	a0,-1
  de:	652000ef          	jal	ra,730 <getnice>
  e2:	85aa                	mv	a1,a0
  check("getnice(-1) - negative pid", ret, -1);
  e4:	567d                	li	a2,-1
  e6:	00001517          	auipc	a0,0x1
  ea:	c9250513          	addi	a0,a0,-878 # d78 <malloc+0x1ea>
  ee:	f13ff0ef          	jal	ra,0 <check>

  printf("\n");
  f2:	00001517          	auipc	a0,0x1
  f6:	f3e50513          	addi	a0,a0,-194 # 1030 <malloc+0x4a2>
  fa:	1db000ef          	jal	ra,ad4 <printf>

  // ============================================================
  printf("========== Testing setnice() ==========\n");
  fe:	00001517          	auipc	a0,0x1
 102:	c9a50513          	addi	a0,a0,-870 # d98 <malloc+0x20a>
 106:	1cf000ef          	jal	ra,ad4 <printf>
  // ============================================================

  // min boundary 0 → should succeed
  ret = setnice(1, 0);
 10a:	4581                	li	a1,0
 10c:	4505                	li	a0,1
 10e:	62a000ef          	jal	ra,738 <setnice>
 112:	85aa                	mv	a1,a0
  check("setnice(1, 0) - min boundary", ret, 0);
 114:	4601                	li	a2,0
 116:	00001517          	auipc	a0,0x1
 11a:	cb250513          	addi	a0,a0,-846 # dc8 <malloc+0x23a>
 11e:	ee3ff0ef          	jal	ra,0 <check>

  // max boundary 39 → should succeed
  ret = setnice(1, 39);
 122:	02700593          	li	a1,39
 126:	4505                	li	a0,1
 128:	610000ef          	jal	ra,738 <setnice>
 12c:	85aa                	mv	a1,a0
  check("setnice(1, 39) - max boundary", ret, 0);
 12e:	4601                	li	a2,0
 130:	00001517          	auipc	a0,0x1
 134:	cb850513          	addi	a0,a0,-840 # de8 <malloc+0x25a>
 138:	ec9ff0ef          	jal	ra,0 <check>

  // just above max (40) → should fail
  ret = setnice(1, 40);
 13c:	02800593          	li	a1,40
 140:	4505                	li	a0,1
 142:	5f6000ef          	jal	ra,738 <setnice>
 146:	85aa                	mv	a1,a0
  check("setnice(1, 40) - just above max", ret, -1);
 148:	567d                	li	a2,-1
 14a:	00001517          	auipc	a0,0x1
 14e:	cbe50513          	addi	a0,a0,-834 # e08 <malloc+0x27a>
 152:	eafff0ef          	jal	ra,0 <check>

  // negative nice value → should fail
  ret = setnice(2, -1);
 156:	55fd                	li	a1,-1
 158:	4509                	li	a0,2
 15a:	5de000ef          	jal	ra,738 <setnice>
 15e:	85aa                	mv	a1,a0
  check("setnice(2, -1) - negative nice value", ret, -1);
 160:	567d                	li	a2,-1
 162:	00001517          	auipc	a0,0x1
 166:	cc650513          	addi	a0,a0,-826 # e28 <malloc+0x29a>
 16a:	e97ff0ef          	jal	ra,0 <check>

  // pid 0 does not exist → should fail
  ret = setnice(0, 10);
 16e:	45a9                	li	a1,10
 170:	4501                	li	a0,0
 172:	5c6000ef          	jal	ra,738 <setnice>
 176:	85aa                	mv	a1,a0
  check("setnice(0, 10) - no such process", ret, -1);
 178:	567d                	li	a2,-1
 17a:	00001517          	auipc	a0,0x1
 17e:	cd650513          	addi	a0,a0,-810 # e50 <malloc+0x2c2>
 182:	e7fff0ef          	jal	ra,0 <check>

  // negative pid does not exist → should fail
  ret = setnice(-1, 10);
 186:	45a9                	li	a1,10
 188:	557d                	li	a0,-1
 18a:	5ae000ef          	jal	ra,738 <setnice>
 18e:	85aa                	mv	a1,a0
  check("setnice(-1, 10) - negative pid", ret, -1);
 190:	567d                	li	a2,-1
 192:	00001517          	auipc	a0,0x1
 196:	ce650513          	addi	a0,a0,-794 # e78 <malloc+0x2ea>
 19a:	e67ff0ef          	jal	ra,0 <check>

  // verify nice value change with getnice
  setnice(2, 5);
 19e:	4595                	li	a1,5
 1a0:	4509                	li	a0,2
 1a2:	596000ef          	jal	ra,738 <setnice>
  ret = getnice(2);
 1a6:	4509                	li	a0,2
 1a8:	588000ef          	jal	ra,730 <getnice>
 1ac:	85aa                	mv	a1,a0
  check("getnice(2) - after setnice to 5", ret, 5);
 1ae:	4615                	li	a2,5
 1b0:	00001517          	auipc	a0,0x1
 1b4:	ce850513          	addi	a0,a0,-792 # e98 <malloc+0x30a>
 1b8:	e49ff0ef          	jal	ra,0 <check>

  // restore to default
  setnice(1, 20);
 1bc:	45d1                	li	a1,20
 1be:	4505                	li	a0,1
 1c0:	578000ef          	jal	ra,738 <setnice>
  setnice(2, 20);
 1c4:	45d1                	li	a1,20
 1c6:	4509                	li	a0,2
 1c8:	570000ef          	jal	ra,738 <setnice>

  printf("\n");
 1cc:	00001517          	auipc	a0,0x1
 1d0:	e6450513          	addi	a0,a0,-412 # 1030 <malloc+0x4a2>
 1d4:	101000ef          	jal	ra,ad4 <printf>

  // ============================================================
  printf("========== Testing ps() ==========\n");
 1d8:	00001517          	auipc	a0,0x1
 1dc:	ce050513          	addi	a0,a0,-800 # eb8 <malloc+0x32a>
 1e0:	0f5000ef          	jal	ra,ad4 <printf>
  // ============================================================

  // change nice values and verify they are reflected in ps
  setnice(1, 5);
 1e4:	4595                	li	a1,5
 1e6:	4505                	li	a0,1
 1e8:	550000ef          	jal	ra,738 <setnice>
  setnice(2, 15);
 1ec:	45bd                	li	a1,15
 1ee:	4509                	li	a0,2
 1f0:	548000ef          	jal	ra,738 <setnice>
  printf("[INFO] ps(0) - init(nice=5), sh(nice=15) should be reflected:\n");
 1f4:	00001517          	auipc	a0,0x1
 1f8:	cec50513          	addi	a0,a0,-788 # ee0 <malloc+0x352>
 1fc:	0d9000ef          	jal	ra,ad4 <printf>
  ps(0);
 200:	4501                	li	a0,0
 202:	53e000ef          	jal	ra,740 <ps>
  printf("\n");
 206:	00001517          	auipc	a0,0x1
 20a:	e2a50513          	addi	a0,a0,-470 # 1030 <malloc+0x4a2>
 20e:	0c7000ef          	jal	ra,ad4 <printf>

  // restore to default
  setnice(1, 20);
 212:	45d1                	li	a1,20
 214:	4505                	li	a0,1
 216:	522000ef          	jal	ra,738 <setnice>
  setnice(2, 20);
 21a:	45d1                	li	a1,20
 21c:	4509                	li	a0,2
 21e:	51a000ef          	jal	ra,738 <setnice>

  // ps(2) → should print only sh
  printf("[INFO] ps(2) - should print only sh:\n");
 222:	00001517          	auipc	a0,0x1
 226:	cfe50513          	addi	a0,a0,-770 # f20 <malloc+0x392>
 22a:	0ab000ef          	jal	ra,ad4 <printf>
  ps(2);
 22e:	4509                	li	a0,2
 230:	510000ef          	jal	ra,740 <ps>
  printf("\n");
 234:	00001517          	auipc	a0,0x1
 238:	dfc50513          	addi	a0,a0,-516 # 1030 <malloc+0x4a2>
 23c:	099000ef          	jal	ra,ad4 <printf>

  // ps(3) → should print only mytest2
  printf("[INFO] ps(3) - should print only mytest2:\n");
 240:	00001517          	auipc	a0,0x1
 244:	d0850513          	addi	a0,a0,-760 # f48 <malloc+0x3ba>
 248:	08d000ef          	jal	ra,ad4 <printf>
  ps(3);
 24c:	450d                	li	a0,3
 24e:	4f2000ef          	jal	ra,740 <ps>
  printf("\n");
 252:	00001517          	auipc	a0,0x1
 256:	dde50513          	addi	a0,a0,-546 # 1030 <malloc+0x4a2>
 25a:	07b000ef          	jal	ra,ad4 <printf>

  // ps(99) → no such process, should print nothing
  printf("[INFO] ps(99) - no such process, should print nothing:\n");
 25e:	00001517          	auipc	a0,0x1
 262:	d1a50513          	addi	a0,a0,-742 # f78 <malloc+0x3ea>
 266:	06f000ef          	jal	ra,ad4 <printf>
  ps(99);
 26a:	06300513          	li	a0,99
 26e:	4d2000ef          	jal	ra,740 <ps>
  printf("[INFO] (no output expected above)\n");
 272:	00001517          	auipc	a0,0x1
 276:	d3e50513          	addi	a0,a0,-706 # fb0 <malloc+0x422>
 27a:	05b000ef          	jal	ra,ad4 <printf>
  printf("\n");
 27e:	00001517          	auipc	a0,0x1
 282:	db250513          	addi	a0,a0,-590 # 1030 <malloc+0x4a2>
 286:	04f000ef          	jal	ra,ad4 <printf>

  // ============================================================
  printf("========== Testing meminfo() ==========\n");
 28a:	00001517          	auipc	a0,0x1
 28e:	d4e50513          	addi	a0,a0,-690 # fd8 <malloc+0x44a>
 292:	043000ef          	jal	ra,ad4 <printf>
  // ============================================================

  // call meminfo twice and check consistency
  uint64 mem1 = meminfo();
 296:	4b2000ef          	jal	ra,748 <meminfo>
 29a:	84aa                	mv	s1,a0
  uint64 mem2 = meminfo();
 29c:	4ac000ef          	jal	ra,748 <meminfo>
  if (mem1 == mem2) {
 2a0:	06a48563          	beq	s1,a0,30a <main+0x2b8>
 2a4:	862a                	mv	a2,a0
    printf("[PASS] meminfo() - consistent: %lu bytes\n", mem1);
    passed++;
  } else {
    printf("[FAIL] meminfo() - inconsistent: %lu vs %lu\n", mem1, mem2);
 2a6:	85a6                	mv	a1,s1
 2a8:	00001517          	auipc	a0,0x1
 2ac:	d9050513          	addi	a0,a0,-624 # 1038 <malloc+0x4aa>
 2b0:	025000ef          	jal	ra,ad4 <printf>
    failed++;
 2b4:	00002717          	auipc	a4,0x2
 2b8:	d4c70713          	addi	a4,a4,-692 # 2000 <failed>
 2bc:	431c                	lw	a5,0(a4)
 2be:	2785                	addiw	a5,a5,1
 2c0:	c31c                	sw	a5,0(a4)
  }

  // check if return value is a multiple of PGSIZE(4096)
  if (mem1 % 4096 == 0) {
 2c2:	03449793          	slli	a5,s1,0x34
 2c6:	e3ad                	bnez	a5,328 <main+0x2d6>
    printf("[PASS] meminfo() - multiple of PGSIZE(4096): %lu bytes\n", mem1);
 2c8:	85a6                	mv	a1,s1
 2ca:	00001517          	auipc	a0,0x1
 2ce:	d9e50513          	addi	a0,a0,-610 # 1068 <malloc+0x4da>
 2d2:	003000ef          	jal	ra,ad4 <printf>
    passed++;
 2d6:	00002717          	auipc	a4,0x2
 2da:	d2e70713          	addi	a4,a4,-722 # 2004 <passed>
 2de:	431c                	lw	a5,0(a4)
 2e0:	2785                	addiw	a5,a5,1
 2e2:	c31c                	sw	a5,0(a4)
  } else {
    printf("[FAIL] meminfo() - not a multiple of PGSIZE: %lu bytes\n", mem1);
    failed++;
  }

  printf("\n");
 2e4:	00001517          	auipc	a0,0x1
 2e8:	d4c50513          	addi	a0,a0,-692 # 1030 <malloc+0x4a2>
 2ec:	7e8000ef          	jal	ra,ad4 <printf>

  // ============================================================
  printf("========== Testing waitpid() ==========\n");
 2f0:	00001517          	auipc	a0,0x1
 2f4:	de850513          	addi	a0,a0,-536 # 10d8 <malloc+0x54a>
 2f8:	7dc000ef          	jal	ra,ad4 <printf>
  // ============================================================

  // fork a child and waitpid for it → should return 0
  int pid3 = fork();
 2fc:	38c000ef          	jal	ra,688 <fork>
  if (pid3 < 0) {
 300:	04054363          	bltz	a0,346 <main+0x2f4>
    printf("[FAIL] fork() failed\n");
    failed++;
  } else if (pid3 == 0) {
 304:	ed39                	bnez	a0,362 <main+0x310>
    exit(0);
 306:	38a000ef          	jal	ra,690 <exit>
    printf("[PASS] meminfo() - consistent: %lu bytes\n", mem1);
 30a:	85a6                	mv	a1,s1
 30c:	00001517          	auipc	a0,0x1
 310:	cfc50513          	addi	a0,a0,-772 # 1008 <malloc+0x47a>
 314:	7c0000ef          	jal	ra,ad4 <printf>
    passed++;
 318:	00002717          	auipc	a4,0x2
 31c:	cec70713          	addi	a4,a4,-788 # 2004 <passed>
 320:	431c                	lw	a5,0(a4)
 322:	2785                	addiw	a5,a5,1
 324:	c31c                	sw	a5,0(a4)
 326:	bf71                	j	2c2 <main+0x270>
    printf("[FAIL] meminfo() - not a multiple of PGSIZE: %lu bytes\n", mem1);
 328:	85a6                	mv	a1,s1
 32a:	00001517          	auipc	a0,0x1
 32e:	d7650513          	addi	a0,a0,-650 # 10a0 <malloc+0x512>
 332:	7a2000ef          	jal	ra,ad4 <printf>
    failed++;
 336:	00002717          	auipc	a4,0x2
 33a:	cca70713          	addi	a4,a4,-822 # 2000 <failed>
 33e:	431c                	lw	a5,0(a4)
 340:	2785                	addiw	a5,a5,1
 342:	c31c                	sw	a5,0(a4)
 344:	b745                	j	2e4 <main+0x292>
    printf("[FAIL] fork() failed\n");
 346:	00001517          	auipc	a0,0x1
 34a:	dc250513          	addi	a0,a0,-574 # 1108 <malloc+0x57a>
 34e:	786000ef          	jal	ra,ad4 <printf>
    failed++;
 352:	00002717          	auipc	a4,0x2
 356:	cae70713          	addi	a4,a4,-850 # 2000 <failed>
 35a:	431c                	lw	a5,0(a4)
 35c:	2785                	addiw	a5,a5,1
 35e:	c31c                	sw	a5,0(a4)
 360:	a819                	j	376 <main+0x324>
  } else {
    ret = waitpid(pid3);
 362:	3ee000ef          	jal	ra,750 <waitpid>
 366:	85aa                	mv	a1,a0
    check("waitpid(pid3) - child exited", ret, 0);
 368:	4601                	li	a2,0
 36a:	00001517          	auipc	a0,0x1
 36e:	db650513          	addi	a0,a0,-586 # 1120 <malloc+0x592>
 372:	c8fff0ef          	jal	ra,0 <check>
  }

  // wait for sh(pid 2) → not our child, should return -1
  ret = waitpid(2);
 376:	4509                	li	a0,2
 378:	3d8000ef          	jal	ra,750 <waitpid>
 37c:	85aa                	mv	a1,a0
  check("waitpid(2) - not our child (sh)", ret, -1);
 37e:	567d                	li	a2,-1
 380:	00001517          	auipc	a0,0x1
 384:	dc050513          	addi	a0,a0,-576 # 1140 <malloc+0x5b2>
 388:	c79ff0ef          	jal	ra,0 <check>

  // pid 0 does not exist → should return -1
  ret = waitpid(0);
 38c:	4501                	li	a0,0
 38e:	3c2000ef          	jal	ra,750 <waitpid>
 392:	85aa                	mv	a1,a0
  check("waitpid(0) - no such process", ret, -1);
 394:	567d                	li	a2,-1
 396:	00001517          	auipc	a0,0x1
 39a:	dca50513          	addi	a0,a0,-566 # 1160 <malloc+0x5d2>
 39e:	c63ff0ef          	jal	ra,0 <check>

  // negative pid does not exist → should return -1
  ret = waitpid(-1);
 3a2:	557d                	li	a0,-1
 3a4:	3ac000ef          	jal	ra,750 <waitpid>
 3a8:	85aa                	mv	a1,a0
  check("waitpid(-1) - negative pid", ret, -1);
 3aa:	567d                	li	a2,-1
 3ac:	00001517          	auipc	a0,0x1
 3b0:	dd450513          	addi	a0,a0,-556 # 1180 <malloc+0x5f2>
 3b4:	c4dff0ef          	jal	ra,0 <check>

  printf("\n");
 3b8:	00001517          	auipc	a0,0x1
 3bc:	c7850513          	addi	a0,a0,-904 # 1030 <malloc+0x4a2>
 3c0:	714000ef          	jal	ra,ad4 <printf>

  // ============================================================
  printf("========== Summary ==========\n");
 3c4:	00001517          	auipc	a0,0x1
 3c8:	ddc50513          	addi	a0,a0,-548 # 11a0 <malloc+0x612>
 3cc:	708000ef          	jal	ra,ad4 <printf>
  // ============================================================
  printf("Total: %d passed, %d failed\n", passed, failed);
 3d0:	00002617          	auipc	a2,0x2
 3d4:	c3062603          	lw	a2,-976(a2) # 2000 <failed>
 3d8:	00002597          	auipc	a1,0x2
 3dc:	c2c5a583          	lw	a1,-980(a1) # 2004 <passed>
 3e0:	00001517          	auipc	a0,0x1
 3e4:	de050513          	addi	a0,a0,-544 # 11c0 <malloc+0x632>
 3e8:	6ec000ef          	jal	ra,ad4 <printf>

  exit(0);
 3ec:	4501                	li	a0,0
 3ee:	2a2000ef          	jal	ra,690 <exit>

00000000000003f2 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 3f2:	1141                	addi	sp,sp,-16
 3f4:	e406                	sd	ra,8(sp)
 3f6:	e022                	sd	s0,0(sp)
 3f8:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 3fa:	c59ff0ef          	jal	ra,52 <main>
  exit(r);
 3fe:	292000ef          	jal	ra,690 <exit>

0000000000000402 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 402:	1141                	addi	sp,sp,-16
 404:	e422                	sd	s0,8(sp)
 406:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 408:	87aa                	mv	a5,a0
 40a:	0585                	addi	a1,a1,1
 40c:	0785                	addi	a5,a5,1
 40e:	fff5c703          	lbu	a4,-1(a1)
 412:	fee78fa3          	sb	a4,-1(a5)
 416:	fb75                	bnez	a4,40a <strcpy+0x8>
    ;
  return os;
}
 418:	6422                	ld	s0,8(sp)
 41a:	0141                	addi	sp,sp,16
 41c:	8082                	ret

000000000000041e <strcmp>:

int
strcmp(const char *p, const char *q)
{
 41e:	1141                	addi	sp,sp,-16
 420:	e422                	sd	s0,8(sp)
 422:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 424:	00054783          	lbu	a5,0(a0)
 428:	cb91                	beqz	a5,43c <strcmp+0x1e>
 42a:	0005c703          	lbu	a4,0(a1)
 42e:	00f71763          	bne	a4,a5,43c <strcmp+0x1e>
    p++, q++;
 432:	0505                	addi	a0,a0,1
 434:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 436:	00054783          	lbu	a5,0(a0)
 43a:	fbe5                	bnez	a5,42a <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 43c:	0005c503          	lbu	a0,0(a1)
}
 440:	40a7853b          	subw	a0,a5,a0
 444:	6422                	ld	s0,8(sp)
 446:	0141                	addi	sp,sp,16
 448:	8082                	ret

000000000000044a <strlen>:

uint
strlen(const char *s)
{
 44a:	1141                	addi	sp,sp,-16
 44c:	e422                	sd	s0,8(sp)
 44e:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 450:	00054783          	lbu	a5,0(a0)
 454:	cf91                	beqz	a5,470 <strlen+0x26>
 456:	0505                	addi	a0,a0,1
 458:	87aa                	mv	a5,a0
 45a:	4685                	li	a3,1
 45c:	9e89                	subw	a3,a3,a0
 45e:	00f6853b          	addw	a0,a3,a5
 462:	0785                	addi	a5,a5,1
 464:	fff7c703          	lbu	a4,-1(a5)
 468:	fb7d                	bnez	a4,45e <strlen+0x14>
    ;
  return n;
}
 46a:	6422                	ld	s0,8(sp)
 46c:	0141                	addi	sp,sp,16
 46e:	8082                	ret
  for(n = 0; s[n]; n++)
 470:	4501                	li	a0,0
 472:	bfe5                	j	46a <strlen+0x20>

0000000000000474 <memset>:

void*
memset(void *dst, int c, uint n)
{
 474:	1141                	addi	sp,sp,-16
 476:	e422                	sd	s0,8(sp)
 478:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 47a:	ce09                	beqz	a2,494 <memset+0x20>
 47c:	87aa                	mv	a5,a0
 47e:	fff6071b          	addiw	a4,a2,-1
 482:	1702                	slli	a4,a4,0x20
 484:	9301                	srli	a4,a4,0x20
 486:	0705                	addi	a4,a4,1
 488:	972a                	add	a4,a4,a0
    cdst[i] = c;
 48a:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 48e:	0785                	addi	a5,a5,1
 490:	fee79de3          	bne	a5,a4,48a <memset+0x16>
  }
  return dst;
}
 494:	6422                	ld	s0,8(sp)
 496:	0141                	addi	sp,sp,16
 498:	8082                	ret

000000000000049a <strchr>:

char*
strchr(const char *s, char c)
{
 49a:	1141                	addi	sp,sp,-16
 49c:	e422                	sd	s0,8(sp)
 49e:	0800                	addi	s0,sp,16
  for(; *s; s++)
 4a0:	00054783          	lbu	a5,0(a0)
 4a4:	cb99                	beqz	a5,4ba <strchr+0x20>
    if(*s == c)
 4a6:	00f58763          	beq	a1,a5,4b4 <strchr+0x1a>
  for(; *s; s++)
 4aa:	0505                	addi	a0,a0,1
 4ac:	00054783          	lbu	a5,0(a0)
 4b0:	fbfd                	bnez	a5,4a6 <strchr+0xc>
      return (char*)s;
  return 0;
 4b2:	4501                	li	a0,0
}
 4b4:	6422                	ld	s0,8(sp)
 4b6:	0141                	addi	sp,sp,16
 4b8:	8082                	ret
  return 0;
 4ba:	4501                	li	a0,0
 4bc:	bfe5                	j	4b4 <strchr+0x1a>

00000000000004be <gets>:

char*
gets(char *buf, int max)
{
 4be:	711d                	addi	sp,sp,-96
 4c0:	ec86                	sd	ra,88(sp)
 4c2:	e8a2                	sd	s0,80(sp)
 4c4:	e4a6                	sd	s1,72(sp)
 4c6:	e0ca                	sd	s2,64(sp)
 4c8:	fc4e                	sd	s3,56(sp)
 4ca:	f852                	sd	s4,48(sp)
 4cc:	f456                	sd	s5,40(sp)
 4ce:	f05a                	sd	s6,32(sp)
 4d0:	ec5e                	sd	s7,24(sp)
 4d2:	1080                	addi	s0,sp,96
 4d4:	8baa                	mv	s7,a0
 4d6:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 4d8:	892a                	mv	s2,a0
 4da:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 4dc:	4aa9                	li	s5,10
 4de:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 4e0:	89a6                	mv	s3,s1
 4e2:	2485                	addiw	s1,s1,1
 4e4:	0344d663          	bge	s1,s4,510 <gets+0x52>
    cc = read(0, &c, 1);
 4e8:	4605                	li	a2,1
 4ea:	faf40593          	addi	a1,s0,-81
 4ee:	4501                	li	a0,0
 4f0:	1b8000ef          	jal	ra,6a8 <read>
    if(cc < 1)
 4f4:	00a05e63          	blez	a0,510 <gets+0x52>
    buf[i++] = c;
 4f8:	faf44783          	lbu	a5,-81(s0)
 4fc:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 500:	01578763          	beq	a5,s5,50e <gets+0x50>
 504:	0905                	addi	s2,s2,1
 506:	fd679de3          	bne	a5,s6,4e0 <gets+0x22>
  for(i=0; i+1 < max; ){
 50a:	89a6                	mv	s3,s1
 50c:	a011                	j	510 <gets+0x52>
 50e:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 510:	99de                	add	s3,s3,s7
 512:	00098023          	sb	zero,0(s3)
  return buf;
}
 516:	855e                	mv	a0,s7
 518:	60e6                	ld	ra,88(sp)
 51a:	6446                	ld	s0,80(sp)
 51c:	64a6                	ld	s1,72(sp)
 51e:	6906                	ld	s2,64(sp)
 520:	79e2                	ld	s3,56(sp)
 522:	7a42                	ld	s4,48(sp)
 524:	7aa2                	ld	s5,40(sp)
 526:	7b02                	ld	s6,32(sp)
 528:	6be2                	ld	s7,24(sp)
 52a:	6125                	addi	sp,sp,96
 52c:	8082                	ret

000000000000052e <stat>:

int
stat(const char *n, struct stat *st)
{
 52e:	1101                	addi	sp,sp,-32
 530:	ec06                	sd	ra,24(sp)
 532:	e822                	sd	s0,16(sp)
 534:	e426                	sd	s1,8(sp)
 536:	e04a                	sd	s2,0(sp)
 538:	1000                	addi	s0,sp,32
 53a:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 53c:	4581                	li	a1,0
 53e:	192000ef          	jal	ra,6d0 <open>
  if(fd < 0)
 542:	02054163          	bltz	a0,564 <stat+0x36>
 546:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 548:	85ca                	mv	a1,s2
 54a:	19e000ef          	jal	ra,6e8 <fstat>
 54e:	892a                	mv	s2,a0
  close(fd);
 550:	8526                	mv	a0,s1
 552:	166000ef          	jal	ra,6b8 <close>
  return r;
}
 556:	854a                	mv	a0,s2
 558:	60e2                	ld	ra,24(sp)
 55a:	6442                	ld	s0,16(sp)
 55c:	64a2                	ld	s1,8(sp)
 55e:	6902                	ld	s2,0(sp)
 560:	6105                	addi	sp,sp,32
 562:	8082                	ret
    return -1;
 564:	597d                	li	s2,-1
 566:	bfc5                	j	556 <stat+0x28>

0000000000000568 <atoi>:

int
atoi(const char *s)
{
 568:	1141                	addi	sp,sp,-16
 56a:	e422                	sd	s0,8(sp)
 56c:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 56e:	00054603          	lbu	a2,0(a0)
 572:	fd06079b          	addiw	a5,a2,-48
 576:	0ff7f793          	andi	a5,a5,255
 57a:	4725                	li	a4,9
 57c:	02f76963          	bltu	a4,a5,5ae <atoi+0x46>
 580:	86aa                	mv	a3,a0
  n = 0;
 582:	4501                	li	a0,0
  while('0' <= *s && *s <= '9')
 584:	45a5                	li	a1,9
    n = n*10 + *s++ - '0';
 586:	0685                	addi	a3,a3,1
 588:	0025179b          	slliw	a5,a0,0x2
 58c:	9fa9                	addw	a5,a5,a0
 58e:	0017979b          	slliw	a5,a5,0x1
 592:	9fb1                	addw	a5,a5,a2
 594:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 598:	0006c603          	lbu	a2,0(a3)
 59c:	fd06071b          	addiw	a4,a2,-48
 5a0:	0ff77713          	andi	a4,a4,255
 5a4:	fee5f1e3          	bgeu	a1,a4,586 <atoi+0x1e>
  return n;
}
 5a8:	6422                	ld	s0,8(sp)
 5aa:	0141                	addi	sp,sp,16
 5ac:	8082                	ret
  n = 0;
 5ae:	4501                	li	a0,0
 5b0:	bfe5                	j	5a8 <atoi+0x40>

00000000000005b2 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 5b2:	1141                	addi	sp,sp,-16
 5b4:	e422                	sd	s0,8(sp)
 5b6:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 5b8:	02b57663          	bgeu	a0,a1,5e4 <memmove+0x32>
    while(n-- > 0)
 5bc:	02c05163          	blez	a2,5de <memmove+0x2c>
 5c0:	fff6079b          	addiw	a5,a2,-1
 5c4:	1782                	slli	a5,a5,0x20
 5c6:	9381                	srli	a5,a5,0x20
 5c8:	0785                	addi	a5,a5,1
 5ca:	97aa                	add	a5,a5,a0
  dst = vdst;
 5cc:	872a                	mv	a4,a0
      *dst++ = *src++;
 5ce:	0585                	addi	a1,a1,1
 5d0:	0705                	addi	a4,a4,1
 5d2:	fff5c683          	lbu	a3,-1(a1)
 5d6:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 5da:	fee79ae3          	bne	a5,a4,5ce <memmove+0x1c>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 5de:	6422                	ld	s0,8(sp)
 5e0:	0141                	addi	sp,sp,16
 5e2:	8082                	ret
    dst += n;
 5e4:	00c50733          	add	a4,a0,a2
    src += n;
 5e8:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 5ea:	fec05ae3          	blez	a2,5de <memmove+0x2c>
 5ee:	fff6079b          	addiw	a5,a2,-1
 5f2:	1782                	slli	a5,a5,0x20
 5f4:	9381                	srli	a5,a5,0x20
 5f6:	fff7c793          	not	a5,a5
 5fa:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 5fc:	15fd                	addi	a1,a1,-1
 5fe:	177d                	addi	a4,a4,-1
 600:	0005c683          	lbu	a3,0(a1)
 604:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 608:	fee79ae3          	bne	a5,a4,5fc <memmove+0x4a>
 60c:	bfc9                	j	5de <memmove+0x2c>

000000000000060e <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 60e:	1141                	addi	sp,sp,-16
 610:	e422                	sd	s0,8(sp)
 612:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 614:	ca05                	beqz	a2,644 <memcmp+0x36>
 616:	fff6069b          	addiw	a3,a2,-1
 61a:	1682                	slli	a3,a3,0x20
 61c:	9281                	srli	a3,a3,0x20
 61e:	0685                	addi	a3,a3,1
 620:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 622:	00054783          	lbu	a5,0(a0)
 626:	0005c703          	lbu	a4,0(a1)
 62a:	00e79863          	bne	a5,a4,63a <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 62e:	0505                	addi	a0,a0,1
    p2++;
 630:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 632:	fed518e3          	bne	a0,a3,622 <memcmp+0x14>
  }
  return 0;
 636:	4501                	li	a0,0
 638:	a019                	j	63e <memcmp+0x30>
      return *p1 - *p2;
 63a:	40e7853b          	subw	a0,a5,a4
}
 63e:	6422                	ld	s0,8(sp)
 640:	0141                	addi	sp,sp,16
 642:	8082                	ret
  return 0;
 644:	4501                	li	a0,0
 646:	bfe5                	j	63e <memcmp+0x30>

0000000000000648 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 648:	1141                	addi	sp,sp,-16
 64a:	e406                	sd	ra,8(sp)
 64c:	e022                	sd	s0,0(sp)
 64e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 650:	f63ff0ef          	jal	ra,5b2 <memmove>
}
 654:	60a2                	ld	ra,8(sp)
 656:	6402                	ld	s0,0(sp)
 658:	0141                	addi	sp,sp,16
 65a:	8082                	ret

000000000000065c <sbrk>:

char *
sbrk(int n) {
 65c:	1141                	addi	sp,sp,-16
 65e:	e406                	sd	ra,8(sp)
 660:	e022                	sd	s0,0(sp)
 662:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 664:	4585                	li	a1,1
 666:	0b2000ef          	jal	ra,718 <sys_sbrk>
}
 66a:	60a2                	ld	ra,8(sp)
 66c:	6402                	ld	s0,0(sp)
 66e:	0141                	addi	sp,sp,16
 670:	8082                	ret

0000000000000672 <sbrklazy>:

char *
sbrklazy(int n) {
 672:	1141                	addi	sp,sp,-16
 674:	e406                	sd	ra,8(sp)
 676:	e022                	sd	s0,0(sp)
 678:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 67a:	4589                	li	a1,2
 67c:	09c000ef          	jal	ra,718 <sys_sbrk>
}
 680:	60a2                	ld	ra,8(sp)
 682:	6402                	ld	s0,0(sp)
 684:	0141                	addi	sp,sp,16
 686:	8082                	ret

0000000000000688 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 688:	4885                	li	a7,1
 ecall
 68a:	00000073          	ecall
 ret
 68e:	8082                	ret

0000000000000690 <exit>:
.global exit
exit:
 li a7, SYS_exit
 690:	4889                	li	a7,2
 ecall
 692:	00000073          	ecall
 ret
 696:	8082                	ret

0000000000000698 <wait>:
.global wait
wait:
 li a7, SYS_wait
 698:	488d                	li	a7,3
 ecall
 69a:	00000073          	ecall
 ret
 69e:	8082                	ret

00000000000006a0 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 6a0:	4891                	li	a7,4
 ecall
 6a2:	00000073          	ecall
 ret
 6a6:	8082                	ret

00000000000006a8 <read>:
.global read
read:
 li a7, SYS_read
 6a8:	4895                	li	a7,5
 ecall
 6aa:	00000073          	ecall
 ret
 6ae:	8082                	ret

00000000000006b0 <write>:
.global write
write:
 li a7, SYS_write
 6b0:	48c1                	li	a7,16
 ecall
 6b2:	00000073          	ecall
 ret
 6b6:	8082                	ret

00000000000006b8 <close>:
.global close
close:
 li a7, SYS_close
 6b8:	48d5                	li	a7,21
 ecall
 6ba:	00000073          	ecall
 ret
 6be:	8082                	ret

00000000000006c0 <kill>:
.global kill
kill:
 li a7, SYS_kill
 6c0:	4899                	li	a7,6
 ecall
 6c2:	00000073          	ecall
 ret
 6c6:	8082                	ret

00000000000006c8 <exec>:
.global exec
exec:
 li a7, SYS_exec
 6c8:	489d                	li	a7,7
 ecall
 6ca:	00000073          	ecall
 ret
 6ce:	8082                	ret

00000000000006d0 <open>:
.global open
open:
 li a7, SYS_open
 6d0:	48bd                	li	a7,15
 ecall
 6d2:	00000073          	ecall
 ret
 6d6:	8082                	ret

00000000000006d8 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 6d8:	48c5                	li	a7,17
 ecall
 6da:	00000073          	ecall
 ret
 6de:	8082                	ret

00000000000006e0 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 6e0:	48c9                	li	a7,18
 ecall
 6e2:	00000073          	ecall
 ret
 6e6:	8082                	ret

00000000000006e8 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 6e8:	48a1                	li	a7,8
 ecall
 6ea:	00000073          	ecall
 ret
 6ee:	8082                	ret

00000000000006f0 <link>:
.global link
link:
 li a7, SYS_link
 6f0:	48cd                	li	a7,19
 ecall
 6f2:	00000073          	ecall
 ret
 6f6:	8082                	ret

00000000000006f8 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 6f8:	48d1                	li	a7,20
 ecall
 6fa:	00000073          	ecall
 ret
 6fe:	8082                	ret

0000000000000700 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 700:	48a5                	li	a7,9
 ecall
 702:	00000073          	ecall
 ret
 706:	8082                	ret

0000000000000708 <dup>:
.global dup
dup:
 li a7, SYS_dup
 708:	48a9                	li	a7,10
 ecall
 70a:	00000073          	ecall
 ret
 70e:	8082                	ret

0000000000000710 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 710:	48ad                	li	a7,11
 ecall
 712:	00000073          	ecall
 ret
 716:	8082                	ret

0000000000000718 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 718:	48b1                	li	a7,12
 ecall
 71a:	00000073          	ecall
 ret
 71e:	8082                	ret

0000000000000720 <pause>:
.global pause
pause:
 li a7, SYS_pause
 720:	48b5                	li	a7,13
 ecall
 722:	00000073          	ecall
 ret
 726:	8082                	ret

0000000000000728 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 728:	48b9                	li	a7,14
 ecall
 72a:	00000073          	ecall
 ret
 72e:	8082                	ret

0000000000000730 <getnice>:
.global getnice
getnice:
 li a7, SYS_getnice
 730:	48d9                	li	a7,22
 ecall
 732:	00000073          	ecall
 ret
 736:	8082                	ret

0000000000000738 <setnice>:
.global setnice
setnice:
 li a7, SYS_setnice
 738:	48dd                	li	a7,23
 ecall
 73a:	00000073          	ecall
 ret
 73e:	8082                	ret

0000000000000740 <ps>:
.global ps
ps:
 li a7, SYS_ps
 740:	48e1                	li	a7,24
 ecall
 742:	00000073          	ecall
 ret
 746:	8082                	ret

0000000000000748 <meminfo>:
.global meminfo
meminfo:
 li a7, SYS_meminfo
 748:	48e5                	li	a7,25
 ecall
 74a:	00000073          	ecall
 ret
 74e:	8082                	ret

0000000000000750 <waitpid>:
.global waitpid
waitpid:
 li a7, SYS_waitpid
 750:	48e9                	li	a7,26
 ecall
 752:	00000073          	ecall
 ret
 756:	8082                	ret

0000000000000758 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 758:	1101                	addi	sp,sp,-32
 75a:	ec06                	sd	ra,24(sp)
 75c:	e822                	sd	s0,16(sp)
 75e:	1000                	addi	s0,sp,32
 760:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 764:	4605                	li	a2,1
 766:	fef40593          	addi	a1,s0,-17
 76a:	f47ff0ef          	jal	ra,6b0 <write>
}
 76e:	60e2                	ld	ra,24(sp)
 770:	6442                	ld	s0,16(sp)
 772:	6105                	addi	sp,sp,32
 774:	8082                	ret

0000000000000776 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 776:	715d                	addi	sp,sp,-80
 778:	e486                	sd	ra,72(sp)
 77a:	e0a2                	sd	s0,64(sp)
 77c:	fc26                	sd	s1,56(sp)
 77e:	f84a                	sd	s2,48(sp)
 780:	f44e                	sd	s3,40(sp)
 782:	0880                	addi	s0,sp,80
 784:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 786:	c299                	beqz	a3,78c <printint+0x16>
 788:	0805c163          	bltz	a1,80a <printint+0x94>
  neg = 0;
 78c:	4881                	li	a7,0
 78e:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 792:	4781                	li	a5,0
  do{
    buf[i++] = digits[x % base];
 794:	00001517          	auipc	a0,0x1
 798:	a5450513          	addi	a0,a0,-1452 # 11e8 <digits>
 79c:	883e                	mv	a6,a5
 79e:	2785                	addiw	a5,a5,1
 7a0:	02c5f733          	remu	a4,a1,a2
 7a4:	972a                	add	a4,a4,a0
 7a6:	00074703          	lbu	a4,0(a4)
 7aa:	00e68023          	sb	a4,0(a3)
  }while((x /= base) != 0);
 7ae:	872e                	mv	a4,a1
 7b0:	02c5d5b3          	divu	a1,a1,a2
 7b4:	0685                	addi	a3,a3,1
 7b6:	fec773e3          	bgeu	a4,a2,79c <printint+0x26>
  if(neg)
 7ba:	00088b63          	beqz	a7,7d0 <printint+0x5a>
    buf[i++] = '-';
 7be:	fd040713          	addi	a4,s0,-48
 7c2:	97ba                	add	a5,a5,a4
 7c4:	02d00713          	li	a4,45
 7c8:	fee78423          	sb	a4,-24(a5)
 7cc:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
 7d0:	02f05663          	blez	a5,7fc <printint+0x86>
 7d4:	fb840713          	addi	a4,s0,-72
 7d8:	00f704b3          	add	s1,a4,a5
 7dc:	fff70993          	addi	s3,a4,-1
 7e0:	99be                	add	s3,s3,a5
 7e2:	37fd                	addiw	a5,a5,-1
 7e4:	1782                	slli	a5,a5,0x20
 7e6:	9381                	srli	a5,a5,0x20
 7e8:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 7ec:	fff4c583          	lbu	a1,-1(s1)
 7f0:	854a                	mv	a0,s2
 7f2:	f67ff0ef          	jal	ra,758 <putc>
  while(--i >= 0)
 7f6:	14fd                	addi	s1,s1,-1
 7f8:	ff349ae3          	bne	s1,s3,7ec <printint+0x76>
}
 7fc:	60a6                	ld	ra,72(sp)
 7fe:	6406                	ld	s0,64(sp)
 800:	74e2                	ld	s1,56(sp)
 802:	7942                	ld	s2,48(sp)
 804:	79a2                	ld	s3,40(sp)
 806:	6161                	addi	sp,sp,80
 808:	8082                	ret
    x = -xx;
 80a:	40b005b3          	neg	a1,a1
    neg = 1;
 80e:	4885                	li	a7,1
    x = -xx;
 810:	bfbd                	j	78e <printint+0x18>

0000000000000812 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 812:	7119                	addi	sp,sp,-128
 814:	fc86                	sd	ra,120(sp)
 816:	f8a2                	sd	s0,112(sp)
 818:	f4a6                	sd	s1,104(sp)
 81a:	f0ca                	sd	s2,96(sp)
 81c:	ecce                	sd	s3,88(sp)
 81e:	e8d2                	sd	s4,80(sp)
 820:	e4d6                	sd	s5,72(sp)
 822:	e0da                	sd	s6,64(sp)
 824:	fc5e                	sd	s7,56(sp)
 826:	f862                	sd	s8,48(sp)
 828:	f466                	sd	s9,40(sp)
 82a:	f06a                	sd	s10,32(sp)
 82c:	ec6e                	sd	s11,24(sp)
 82e:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 830:	0005c903          	lbu	s2,0(a1)
 834:	24090c63          	beqz	s2,a8c <vprintf+0x27a>
 838:	8b2a                	mv	s6,a0
 83a:	8a2e                	mv	s4,a1
 83c:	8bb2                	mv	s7,a2
  state = 0;
 83e:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 840:	4481                	li	s1,0
 842:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 844:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 848:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 84c:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 850:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 854:	00001c97          	auipc	s9,0x1
 858:	994c8c93          	addi	s9,s9,-1644 # 11e8 <digits>
 85c:	a005                	j	87c <vprintf+0x6a>
        putc(fd, c0);
 85e:	85ca                	mv	a1,s2
 860:	855a                	mv	a0,s6
 862:	ef7ff0ef          	jal	ra,758 <putc>
 866:	a019                	j	86c <vprintf+0x5a>
    } else if(state == '%'){
 868:	03598263          	beq	s3,s5,88c <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 86c:	2485                	addiw	s1,s1,1
 86e:	8726                	mv	a4,s1
 870:	009a07b3          	add	a5,s4,s1
 874:	0007c903          	lbu	s2,0(a5)
 878:	20090a63          	beqz	s2,a8c <vprintf+0x27a>
    c0 = fmt[i] & 0xff;
 87c:	0009079b          	sext.w	a5,s2
    if(state == 0){
 880:	fe0994e3          	bnez	s3,868 <vprintf+0x56>
      if(c0 == '%'){
 884:	fd579de3          	bne	a5,s5,85e <vprintf+0x4c>
        state = '%';
 888:	89be                	mv	s3,a5
 88a:	b7cd                	j	86c <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
 88c:	c3c1                	beqz	a5,90c <vprintf+0xfa>
 88e:	00ea06b3          	add	a3,s4,a4
 892:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 896:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 898:	c681                	beqz	a3,8a0 <vprintf+0x8e>
 89a:	9752                	add	a4,a4,s4
 89c:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 8a0:	03878e63          	beq	a5,s8,8dc <vprintf+0xca>
      } else if(c0 == 'l' && c1 == 'd'){
 8a4:	05a78863          	beq	a5,s10,8f4 <vprintf+0xe2>
      } else if(c0 == 'u'){
 8a8:	0db78b63          	beq	a5,s11,97e <vprintf+0x16c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 8ac:	07800713          	li	a4,120
 8b0:	10e78d63          	beq	a5,a4,9ca <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 8b4:	07000713          	li	a4,112
 8b8:	14e78263          	beq	a5,a4,9fc <vprintf+0x1ea>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 8bc:	06300713          	li	a4,99
 8c0:	16e78f63          	beq	a5,a4,a3e <vprintf+0x22c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 8c4:	07300713          	li	a4,115
 8c8:	18e78563          	beq	a5,a4,a52 <vprintf+0x240>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 8cc:	05579063          	bne	a5,s5,90c <vprintf+0xfa>
        putc(fd, '%');
 8d0:	85d6                	mv	a1,s5
 8d2:	855a                	mv	a0,s6
 8d4:	e85ff0ef          	jal	ra,758 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 8d8:	4981                	li	s3,0
 8da:	bf49                	j	86c <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
 8dc:	008b8913          	addi	s2,s7,8
 8e0:	4685                	li	a3,1
 8e2:	4629                	li	a2,10
 8e4:	000ba583          	lw	a1,0(s7)
 8e8:	855a                	mv	a0,s6
 8ea:	e8dff0ef          	jal	ra,776 <printint>
 8ee:	8bca                	mv	s7,s2
      state = 0;
 8f0:	4981                	li	s3,0
 8f2:	bfad                	j	86c <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
 8f4:	03868663          	beq	a3,s8,920 <vprintf+0x10e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 8f8:	05a68163          	beq	a3,s10,93a <vprintf+0x128>
      } else if(c0 == 'l' && c1 == 'u'){
 8fc:	09b68d63          	beq	a3,s11,996 <vprintf+0x184>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 900:	03a68f63          	beq	a3,s10,93e <vprintf+0x12c>
      } else if(c0 == 'l' && c1 == 'x'){
 904:	07800793          	li	a5,120
 908:	0cf68d63          	beq	a3,a5,9e2 <vprintf+0x1d0>
        putc(fd, '%');
 90c:	85d6                	mv	a1,s5
 90e:	855a                	mv	a0,s6
 910:	e49ff0ef          	jal	ra,758 <putc>
        putc(fd, c0);
 914:	85ca                	mv	a1,s2
 916:	855a                	mv	a0,s6
 918:	e41ff0ef          	jal	ra,758 <putc>
      state = 0;
 91c:	4981                	li	s3,0
 91e:	b7b9                	j	86c <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 920:	008b8913          	addi	s2,s7,8
 924:	4685                	li	a3,1
 926:	4629                	li	a2,10
 928:	000bb583          	ld	a1,0(s7)
 92c:	855a                	mv	a0,s6
 92e:	e49ff0ef          	jal	ra,776 <printint>
        i += 1;
 932:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 934:	8bca                	mv	s7,s2
      state = 0;
 936:	4981                	li	s3,0
        i += 1;
 938:	bf15                	j	86c <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 93a:	03860563          	beq	a2,s8,964 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 93e:	07b60963          	beq	a2,s11,9b0 <vprintf+0x19e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 942:	07800793          	li	a5,120
 946:	fcf613e3          	bne	a2,a5,90c <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 94a:	008b8913          	addi	s2,s7,8
 94e:	4681                	li	a3,0
 950:	4641                	li	a2,16
 952:	000bb583          	ld	a1,0(s7)
 956:	855a                	mv	a0,s6
 958:	e1fff0ef          	jal	ra,776 <printint>
        i += 2;
 95c:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 95e:	8bca                	mv	s7,s2
      state = 0;
 960:	4981                	li	s3,0
        i += 2;
 962:	b729                	j	86c <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 964:	008b8913          	addi	s2,s7,8
 968:	4685                	li	a3,1
 96a:	4629                	li	a2,10
 96c:	000bb583          	ld	a1,0(s7)
 970:	855a                	mv	a0,s6
 972:	e05ff0ef          	jal	ra,776 <printint>
        i += 2;
 976:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 978:	8bca                	mv	s7,s2
      state = 0;
 97a:	4981                	li	s3,0
        i += 2;
 97c:	bdc5                	j	86c <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 97e:	008b8913          	addi	s2,s7,8
 982:	4681                	li	a3,0
 984:	4629                	li	a2,10
 986:	000be583          	lwu	a1,0(s7)
 98a:	855a                	mv	a0,s6
 98c:	debff0ef          	jal	ra,776 <printint>
 990:	8bca                	mv	s7,s2
      state = 0;
 992:	4981                	li	s3,0
 994:	bde1                	j	86c <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 996:	008b8913          	addi	s2,s7,8
 99a:	4681                	li	a3,0
 99c:	4629                	li	a2,10
 99e:	000bb583          	ld	a1,0(s7)
 9a2:	855a                	mv	a0,s6
 9a4:	dd3ff0ef          	jal	ra,776 <printint>
        i += 1;
 9a8:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 9aa:	8bca                	mv	s7,s2
      state = 0;
 9ac:	4981                	li	s3,0
        i += 1;
 9ae:	bd7d                	j	86c <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 9b0:	008b8913          	addi	s2,s7,8
 9b4:	4681                	li	a3,0
 9b6:	4629                	li	a2,10
 9b8:	000bb583          	ld	a1,0(s7)
 9bc:	855a                	mv	a0,s6
 9be:	db9ff0ef          	jal	ra,776 <printint>
        i += 2;
 9c2:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 9c4:	8bca                	mv	s7,s2
      state = 0;
 9c6:	4981                	li	s3,0
        i += 2;
 9c8:	b555                	j	86c <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 9ca:	008b8913          	addi	s2,s7,8
 9ce:	4681                	li	a3,0
 9d0:	4641                	li	a2,16
 9d2:	000be583          	lwu	a1,0(s7)
 9d6:	855a                	mv	a0,s6
 9d8:	d9fff0ef          	jal	ra,776 <printint>
 9dc:	8bca                	mv	s7,s2
      state = 0;
 9de:	4981                	li	s3,0
 9e0:	b571                	j	86c <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 9e2:	008b8913          	addi	s2,s7,8
 9e6:	4681                	li	a3,0
 9e8:	4641                	li	a2,16
 9ea:	000bb583          	ld	a1,0(s7)
 9ee:	855a                	mv	a0,s6
 9f0:	d87ff0ef          	jal	ra,776 <printint>
        i += 1;
 9f4:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 9f6:	8bca                	mv	s7,s2
      state = 0;
 9f8:	4981                	li	s3,0
        i += 1;
 9fa:	bd8d                	j	86c <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
 9fc:	008b8793          	addi	a5,s7,8
 a00:	f8f43423          	sd	a5,-120(s0)
 a04:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 a08:	03000593          	li	a1,48
 a0c:	855a                	mv	a0,s6
 a0e:	d4bff0ef          	jal	ra,758 <putc>
  putc(fd, 'x');
 a12:	07800593          	li	a1,120
 a16:	855a                	mv	a0,s6
 a18:	d41ff0ef          	jal	ra,758 <putc>
 a1c:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 a1e:	03c9d793          	srli	a5,s3,0x3c
 a22:	97e6                	add	a5,a5,s9
 a24:	0007c583          	lbu	a1,0(a5)
 a28:	855a                	mv	a0,s6
 a2a:	d2fff0ef          	jal	ra,758 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 a2e:	0992                	slli	s3,s3,0x4
 a30:	397d                	addiw	s2,s2,-1
 a32:	fe0916e3          	bnez	s2,a1e <vprintf+0x20c>
        printptr(fd, va_arg(ap, uint64));
 a36:	f8843b83          	ld	s7,-120(s0)
      state = 0;
 a3a:	4981                	li	s3,0
 a3c:	bd05                	j	86c <vprintf+0x5a>
        putc(fd, va_arg(ap, uint32));
 a3e:	008b8913          	addi	s2,s7,8
 a42:	000bc583          	lbu	a1,0(s7)
 a46:	855a                	mv	a0,s6
 a48:	d11ff0ef          	jal	ra,758 <putc>
 a4c:	8bca                	mv	s7,s2
      state = 0;
 a4e:	4981                	li	s3,0
 a50:	bd31                	j	86c <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
 a52:	008b8993          	addi	s3,s7,8
 a56:	000bb903          	ld	s2,0(s7)
 a5a:	00090f63          	beqz	s2,a78 <vprintf+0x266>
        for(; *s; s++)
 a5e:	00094583          	lbu	a1,0(s2)
 a62:	c195                	beqz	a1,a86 <vprintf+0x274>
          putc(fd, *s);
 a64:	855a                	mv	a0,s6
 a66:	cf3ff0ef          	jal	ra,758 <putc>
        for(; *s; s++)
 a6a:	0905                	addi	s2,s2,1
 a6c:	00094583          	lbu	a1,0(s2)
 a70:	f9f5                	bnez	a1,a64 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 a72:	8bce                	mv	s7,s3
      state = 0;
 a74:	4981                	li	s3,0
 a76:	bbdd                	j	86c <vprintf+0x5a>
          s = "(null)";
 a78:	00000917          	auipc	s2,0x0
 a7c:	76890913          	addi	s2,s2,1896 # 11e0 <malloc+0x652>
        for(; *s; s++)
 a80:	02800593          	li	a1,40
 a84:	b7c5                	j	a64 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 a86:	8bce                	mv	s7,s3
      state = 0;
 a88:	4981                	li	s3,0
 a8a:	b3cd                	j	86c <vprintf+0x5a>
    }
  }
}
 a8c:	70e6                	ld	ra,120(sp)
 a8e:	7446                	ld	s0,112(sp)
 a90:	74a6                	ld	s1,104(sp)
 a92:	7906                	ld	s2,96(sp)
 a94:	69e6                	ld	s3,88(sp)
 a96:	6a46                	ld	s4,80(sp)
 a98:	6aa6                	ld	s5,72(sp)
 a9a:	6b06                	ld	s6,64(sp)
 a9c:	7be2                	ld	s7,56(sp)
 a9e:	7c42                	ld	s8,48(sp)
 aa0:	7ca2                	ld	s9,40(sp)
 aa2:	7d02                	ld	s10,32(sp)
 aa4:	6de2                	ld	s11,24(sp)
 aa6:	6109                	addi	sp,sp,128
 aa8:	8082                	ret

0000000000000aaa <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 aaa:	715d                	addi	sp,sp,-80
 aac:	ec06                	sd	ra,24(sp)
 aae:	e822                	sd	s0,16(sp)
 ab0:	1000                	addi	s0,sp,32
 ab2:	e010                	sd	a2,0(s0)
 ab4:	e414                	sd	a3,8(s0)
 ab6:	e818                	sd	a4,16(s0)
 ab8:	ec1c                	sd	a5,24(s0)
 aba:	03043023          	sd	a6,32(s0)
 abe:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 ac2:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 ac6:	8622                	mv	a2,s0
 ac8:	d4bff0ef          	jal	ra,812 <vprintf>
}
 acc:	60e2                	ld	ra,24(sp)
 ace:	6442                	ld	s0,16(sp)
 ad0:	6161                	addi	sp,sp,80
 ad2:	8082                	ret

0000000000000ad4 <printf>:

void
printf(const char *fmt, ...)
{
 ad4:	711d                	addi	sp,sp,-96
 ad6:	ec06                	sd	ra,24(sp)
 ad8:	e822                	sd	s0,16(sp)
 ada:	1000                	addi	s0,sp,32
 adc:	e40c                	sd	a1,8(s0)
 ade:	e810                	sd	a2,16(s0)
 ae0:	ec14                	sd	a3,24(s0)
 ae2:	f018                	sd	a4,32(s0)
 ae4:	f41c                	sd	a5,40(s0)
 ae6:	03043823          	sd	a6,48(s0)
 aea:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 aee:	00840613          	addi	a2,s0,8
 af2:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 af6:	85aa                	mv	a1,a0
 af8:	4505                	li	a0,1
 afa:	d19ff0ef          	jal	ra,812 <vprintf>
}
 afe:	60e2                	ld	ra,24(sp)
 b00:	6442                	ld	s0,16(sp)
 b02:	6125                	addi	sp,sp,96
 b04:	8082                	ret

0000000000000b06 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 b06:	1141                	addi	sp,sp,-16
 b08:	e422                	sd	s0,8(sp)
 b0a:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 b0c:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 b10:	00001797          	auipc	a5,0x1
 b14:	4f87b783          	ld	a5,1272(a5) # 2008 <freep>
 b18:	a805                	j	b48 <free+0x42>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 b1a:	4618                	lw	a4,8(a2)
 b1c:	9db9                	addw	a1,a1,a4
 b1e:	feb52c23          	sw	a1,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 b22:	6398                	ld	a4,0(a5)
 b24:	6318                	ld	a4,0(a4)
 b26:	fee53823          	sd	a4,-16(a0)
 b2a:	a091                	j	b6e <free+0x68>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 b2c:	ff852703          	lw	a4,-8(a0)
 b30:	9e39                	addw	a2,a2,a4
 b32:	c790                	sw	a2,8(a5)
    p->s.ptr = bp->s.ptr;
 b34:	ff053703          	ld	a4,-16(a0)
 b38:	e398                	sd	a4,0(a5)
 b3a:	a099                	j	b80 <free+0x7a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 b3c:	6398                	ld	a4,0(a5)
 b3e:	00e7e463          	bltu	a5,a4,b46 <free+0x40>
 b42:	00e6ea63          	bltu	a3,a4,b56 <free+0x50>
{
 b46:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 b48:	fed7fae3          	bgeu	a5,a3,b3c <free+0x36>
 b4c:	6398                	ld	a4,0(a5)
 b4e:	00e6e463          	bltu	a3,a4,b56 <free+0x50>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 b52:	fee7eae3          	bltu	a5,a4,b46 <free+0x40>
  if(bp + bp->s.size == p->s.ptr){
 b56:	ff852583          	lw	a1,-8(a0)
 b5a:	6390                	ld	a2,0(a5)
 b5c:	02059713          	slli	a4,a1,0x20
 b60:	9301                	srli	a4,a4,0x20
 b62:	0712                	slli	a4,a4,0x4
 b64:	9736                	add	a4,a4,a3
 b66:	fae60ae3          	beq	a2,a4,b1a <free+0x14>
    bp->s.ptr = p->s.ptr;
 b6a:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 b6e:	4790                	lw	a2,8(a5)
 b70:	02061713          	slli	a4,a2,0x20
 b74:	9301                	srli	a4,a4,0x20
 b76:	0712                	slli	a4,a4,0x4
 b78:	973e                	add	a4,a4,a5
 b7a:	fae689e3          	beq	a3,a4,b2c <free+0x26>
  } else
    p->s.ptr = bp;
 b7e:	e394                	sd	a3,0(a5)
  freep = p;
 b80:	00001717          	auipc	a4,0x1
 b84:	48f73423          	sd	a5,1160(a4) # 2008 <freep>
}
 b88:	6422                	ld	s0,8(sp)
 b8a:	0141                	addi	sp,sp,16
 b8c:	8082                	ret

0000000000000b8e <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 b8e:	7139                	addi	sp,sp,-64
 b90:	fc06                	sd	ra,56(sp)
 b92:	f822                	sd	s0,48(sp)
 b94:	f426                	sd	s1,40(sp)
 b96:	f04a                	sd	s2,32(sp)
 b98:	ec4e                	sd	s3,24(sp)
 b9a:	e852                	sd	s4,16(sp)
 b9c:	e456                	sd	s5,8(sp)
 b9e:	e05a                	sd	s6,0(sp)
 ba0:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 ba2:	02051493          	slli	s1,a0,0x20
 ba6:	9081                	srli	s1,s1,0x20
 ba8:	04bd                	addi	s1,s1,15
 baa:	8091                	srli	s1,s1,0x4
 bac:	0014899b          	addiw	s3,s1,1
 bb0:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 bb2:	00001517          	auipc	a0,0x1
 bb6:	45653503          	ld	a0,1110(a0) # 2008 <freep>
 bba:	c515                	beqz	a0,be6 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 bbc:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 bbe:	4798                	lw	a4,8(a5)
 bc0:	02977f63          	bgeu	a4,s1,bfe <malloc+0x70>
 bc4:	8a4e                	mv	s4,s3
 bc6:	0009871b          	sext.w	a4,s3
 bca:	6685                	lui	a3,0x1
 bcc:	00d77363          	bgeu	a4,a3,bd2 <malloc+0x44>
 bd0:	6a05                	lui	s4,0x1
 bd2:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 bd6:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 bda:	00001917          	auipc	s2,0x1
 bde:	42e90913          	addi	s2,s2,1070 # 2008 <freep>
  if(p == SBRK_ERROR)
 be2:	5afd                	li	s5,-1
 be4:	a0bd                	j	c52 <malloc+0xc4>
    base.s.ptr = freep = prevp = &base;
 be6:	00001797          	auipc	a5,0x1
 bea:	42a78793          	addi	a5,a5,1066 # 2010 <base>
 bee:	00001717          	auipc	a4,0x1
 bf2:	40f73d23          	sd	a5,1050(a4) # 2008 <freep>
 bf6:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 bf8:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 bfc:	b7e1                	j	bc4 <malloc+0x36>
      if(p->s.size == nunits)
 bfe:	02e48b63          	beq	s1,a4,c34 <malloc+0xa6>
        p->s.size -= nunits;
 c02:	4137073b          	subw	a4,a4,s3
 c06:	c798                	sw	a4,8(a5)
        p += p->s.size;
 c08:	1702                	slli	a4,a4,0x20
 c0a:	9301                	srli	a4,a4,0x20
 c0c:	0712                	slli	a4,a4,0x4
 c0e:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 c10:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 c14:	00001717          	auipc	a4,0x1
 c18:	3ea73a23          	sd	a0,1012(a4) # 2008 <freep>
      return (void*)(p + 1);
 c1c:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 c20:	70e2                	ld	ra,56(sp)
 c22:	7442                	ld	s0,48(sp)
 c24:	74a2                	ld	s1,40(sp)
 c26:	7902                	ld	s2,32(sp)
 c28:	69e2                	ld	s3,24(sp)
 c2a:	6a42                	ld	s4,16(sp)
 c2c:	6aa2                	ld	s5,8(sp)
 c2e:	6b02                	ld	s6,0(sp)
 c30:	6121                	addi	sp,sp,64
 c32:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 c34:	6398                	ld	a4,0(a5)
 c36:	e118                	sd	a4,0(a0)
 c38:	bff1                	j	c14 <malloc+0x86>
  hp->s.size = nu;
 c3a:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 c3e:	0541                	addi	a0,a0,16
 c40:	ec7ff0ef          	jal	ra,b06 <free>
  return freep;
 c44:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 c48:	dd61                	beqz	a0,c20 <malloc+0x92>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 c4a:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 c4c:	4798                	lw	a4,8(a5)
 c4e:	fa9778e3          	bgeu	a4,s1,bfe <malloc+0x70>
    if(p == freep)
 c52:	00093703          	ld	a4,0(s2)
 c56:	853e                	mv	a0,a5
 c58:	fef719e3          	bne	a4,a5,c4a <malloc+0xbc>
  p = sbrk(nu * sizeof(Header));
 c5c:	8552                	mv	a0,s4
 c5e:	9ffff0ef          	jal	ra,65c <sbrk>
  if(p == SBRK_ERROR)
 c62:	fd551ce3          	bne	a0,s5,c3a <malloc+0xac>
        return 0;
 c66:	4501                	li	a0,0
 c68:	bf65                	j	c20 <malloc+0x92>
