user/tni.o: user/tni.c kernel/types.h kernel/stat.h user/user.h
