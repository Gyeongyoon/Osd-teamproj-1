
user/_tvr:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <busy_work>:
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int busy_work(int duration) {
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	ec26                	sd	s1,24(sp)
   8:	e84a                	sd	s2,16(sp)
   a:	e44e                	sd	s3,8(sp)
   c:	e052                	sd	s4,0(sp)
   e:	1800                	addi	s0,sp,48
  10:	8a2a                	mv	s4,a0
    int start = uptime();
  12:	4c0000ef          	jal	ra,4d2 <uptime>
  16:	892a                	mv	s2,a0
    int x = 0, z = 20, i, j;
    while ((uptime() - start) < duration) {
  18:	6789                	lui	a5,0x2
  1a:	71078993          	addi	s3,a5,1808 # 2710 <base+0x1700>
int busy_work(int duration) {
  1e:	84ce                	mv	s1,s3
    while ((uptime() - start) < duration) {
  20:	4b2000ef          	jal	ra,4d2 <uptime>
  24:	412507bb          	subw	a5,a0,s2
  28:	0147da63          	bge	a5,s4,3c <busy_work+0x3c>
  2c:	874e                	mv	a4,s3
  2e:	a019                	j	34 <busy_work+0x34>
        for (i = 0; i < 10000; i++)
  30:	377d                	addiw	a4,a4,-1
  32:	d77d                	beqz	a4,20 <busy_work+0x20>
int busy_work(int duration) {
  34:	87a6                	mv	a5,s1
            for (j = 0; j < 10000; j++)
  36:	37fd                	addiw	a5,a5,-1
  38:	fffd                	bnez	a5,36 <busy_work+0x36>
  3a:	bfdd                	j	30 <busy_work+0x30>
                x += z * 89;
    }
    return uptime() - start;
  3c:	496000ef          	jal	ra,4d2 <uptime>
}
  40:	4125053b          	subw	a0,a0,s2
  44:	70a2                	ld	ra,40(sp)
  46:	7402                	ld	s0,32(sp)
  48:	64e2                	ld	s1,24(sp)
  4a:	6942                	ld	s2,16(sp)
  4c:	69a2                	ld	s3,8(sp)
  4e:	6a02                	ld	s4,0(sp)
  50:	6145                	addi	sp,sp,48
  52:	8082                	ret

0000000000000054 <count_iterations>:

int count_iterations(int duration) {
  54:	7179                	addi	sp,sp,-48
  56:	f406                	sd	ra,40(sp)
  58:	f022                	sd	s0,32(sp)
  5a:	ec26                	sd	s1,24(sp)
  5c:	e84a                	sd	s2,16(sp)
  5e:	e44e                	sd	s3,8(sp)
  60:	e052                	sd	s4,0(sp)
  62:	1800                	addi	s0,sp,48
  64:	89aa                	mv	s3,a0
    int start = uptime();
  66:	46c000ef          	jal	ra,4d2 <uptime>
  6a:	892a                	mv	s2,a0
    int x = 0, iterations = 0;
  6c:	4481                	li	s1,0
  6e:	3e800a13          	li	s4,1000
    while ((uptime() - start) < duration) {
  72:	a011                	j	76 <count_iterations+0x22>
        for (int i = 0; i < 1000; i++)
            x += i * 7;
        iterations++;
  74:	2485                	addiw	s1,s1,1
    while ((uptime() - start) < duration) {
  76:	45c000ef          	jal	ra,4d2 <uptime>
  7a:	412507bb          	subw	a5,a0,s2
  7e:	0137d663          	bge	a5,s3,8a <count_iterations+0x36>
  82:	87d2                	mv	a5,s4
        for (int i = 0; i < 1000; i++)
  84:	37fd                	addiw	a5,a5,-1
  86:	fffd                	bnez	a5,84 <count_iterations+0x30>
  88:	b7f5                	j	74 <count_iterations+0x20>
    }
    return iterations;
}
  8a:	8526                	mv	a0,s1
  8c:	70a2                	ld	ra,40(sp)
  8e:	7402                	ld	s0,32(sp)
  90:	64e2                	ld	s1,24(sp)
  92:	6942                	ld	s2,16(sp)
  94:	69a2                	ld	s3,8(sp)
  96:	6a02                	ld	s4,0(sp)
  98:	6145                	addi	sp,sp,48
  9a:	8082                	ret

000000000000009c <main>:

int main(int argc, char **argv) {
  9c:	7179                	addi	sp,sp,-48
  9e:	f406                	sd	ra,40(sp)
  a0:	f022                	sd	s0,32(sp)
  a2:	ec26                	sd	s1,24(sp)
  a4:	1800                	addi	s0,sp,48
    printf("=== TEST: Sleep/Wakeup Handling ===\n");
  a6:	00001517          	auipc	a0,0x1
  aa:	97a50513          	addi	a0,a0,-1670 # a20 <malloc+0xe8>
  ae:	7d0000ef          	jal	ra,87e <printf>

    int child1 = fork();
  b2:	380000ef          	jal	ra,432 <fork>
    if (child1 == 0) {
  b6:	ed11                	bnez	a0,d2 <main+0x36>
  b8:	44a9                	li	s1,10
        // Long-running child with periodic ps()
        for (int i = 0; i < 10; i++) {
            busy_work(100);
  ba:	06400513          	li	a0,100
  be:	f43ff0ef          	jal	ra,0 <busy_work>
            ps(0);
  c2:	4501                	li	a0,0
  c4:	426000ef          	jal	ra,4ea <ps>
        for (int i = 0; i < 10; i++) {
  c8:	34fd                	addiw	s1,s1,-1
  ca:	f8e5                	bnez	s1,ba <main+0x1e>
        }
        exit(1);  // marker: child1
  cc:	4505                	li	a0,1
  ce:	36c000ef          	jal	ra,43a <exit>
    }

    int child2 = fork();
  d2:	360000ef          	jal	ra,432 <fork>
    if (child2 == 0) {
  d6:	e905                	bnez	a0,106 <main+0x6a>
        for (int i = 0; i < 5; i++)
            busy_work(100);
  d8:	06400513          	li	a0,100
  dc:	f25ff0ef          	jal	ra,0 <busy_work>
  e0:	06400513          	li	a0,100
  e4:	f1dff0ef          	jal	ra,0 <busy_work>
  e8:	06400513          	li	a0,100
  ec:	f15ff0ef          	jal	ra,0 <busy_work>
  f0:	06400513          	li	a0,100
  f4:	f0dff0ef          	jal	ra,0 <busy_work>
  f8:	06400513          	li	a0,100
  fc:	f05ff0ef          	jal	ra,0 <busy_work>
        exit(2);  // marker: child2
 100:	4509                	li	a0,2
 102:	338000ef          	jal	ra,43a <exit>
    }

    // Parent sleeps waiting for first child to finish
    printf("Parent sleeping...\n");
 106:	00001517          	auipc	a0,0x1
 10a:	94250513          	addi	a0,a0,-1726 # a48 <malloc+0x110>
 10e:	770000ef          	jal	ra,87e <printf>
    int status1;
    wait(&status1);
 112:	fdc40513          	addi	a0,s0,-36
 116:	32c000ef          	jal	ra,442 <wait>
    printf("Wait finished for 1st process (id: %d)\n", status1);
 11a:	fdc42583          	lw	a1,-36(s0)
 11e:	00001517          	auipc	a0,0x1
 122:	94250513          	addi	a0,a0,-1726 # a60 <malloc+0x128>
 126:	758000ef          	jal	ra,87e <printf>

    // Parent wakes up and runs work with ps() snapshots
    for (int i = 0; i < 3; i++) {
        busy_work(100);
 12a:	06400513          	li	a0,100
 12e:	ed3ff0ef          	jal	ra,0 <busy_work>
        ps(0);
 132:	4501                	li	a0,0
 134:	3b6000ef          	jal	ra,4ea <ps>
        busy_work(100);
 138:	06400513          	li	a0,100
 13c:	ec5ff0ef          	jal	ra,0 <busy_work>
        ps(0);
 140:	4501                	li	a0,0
 142:	3a8000ef          	jal	ra,4ea <ps>
        busy_work(100);
 146:	06400513          	li	a0,100
 14a:	eb7ff0ef          	jal	ra,0 <busy_work>
        ps(0);
 14e:	4501                	li	a0,0
 150:	39a000ef          	jal	ra,4ea <ps>
    }

    int status2;
    wait(&status2);
 154:	fd840513          	addi	a0,s0,-40
 158:	2ea000ef          	jal	ra,442 <wait>
    printf("Wait finished for 2nd process (id: %d)\n", status2);
 15c:	fd842583          	lw	a1,-40(s0)
 160:	00001517          	auipc	a0,0x1
 164:	92850513          	addi	a0,a0,-1752 # a88 <malloc+0x150>
 168:	716000ef          	jal	ra,87e <printf>
    ps(0);
 16c:	4501                	li	a0,0
 16e:	37c000ef          	jal	ra,4ea <ps>

    // Verification: parent ran after wakeup (check via ps output visually)
    // Automatic check: if we reached here, parent was scheduled after wakeup
    printf("\n[PASS] Sleep/wakeup handling works correctly\n");
 172:	00001517          	auipc	a0,0x1
 176:	93e50513          	addi	a0,a0,-1730 # ab0 <malloc+0x178>
 17a:	704000ef          	jal	ra,87e <printf>
    printf("  - Parent was scheduled after wakeup\n");
 17e:	00001517          	auipc	a0,0x1
 182:	96250513          	addi	a0,a0,-1694 # ae0 <malloc+0x1a8>
 186:	6f8000ef          	jal	ra,87e <printf>
    printf("  - Verify ps() output above: vdeadline recalculated, timeslice reset\n");
 18a:	00001517          	auipc	a0,0x1
 18e:	97e50513          	addi	a0,a0,-1666 # b08 <malloc+0x1d0>
 192:	6ec000ef          	jal	ra,87e <printf>

    exit(0);
 196:	4501                	li	a0,0
 198:	2a2000ef          	jal	ra,43a <exit>

000000000000019c <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 19c:	1141                	addi	sp,sp,-16
 19e:	e406                	sd	ra,8(sp)
 1a0:	e022                	sd	s0,0(sp)
 1a2:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 1a4:	ef9ff0ef          	jal	ra,9c <main>
  exit(r);
 1a8:	292000ef          	jal	ra,43a <exit>

00000000000001ac <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 1ac:	1141                	addi	sp,sp,-16
 1ae:	e422                	sd	s0,8(sp)
 1b0:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 1b2:	87aa                	mv	a5,a0
 1b4:	0585                	addi	a1,a1,1
 1b6:	0785                	addi	a5,a5,1
 1b8:	fff5c703          	lbu	a4,-1(a1)
 1bc:	fee78fa3          	sb	a4,-1(a5)
 1c0:	fb75                	bnez	a4,1b4 <strcpy+0x8>
    ;
  return os;
}
 1c2:	6422                	ld	s0,8(sp)
 1c4:	0141                	addi	sp,sp,16
 1c6:	8082                	ret

00000000000001c8 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 1c8:	1141                	addi	sp,sp,-16
 1ca:	e422                	sd	s0,8(sp)
 1cc:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 1ce:	00054783          	lbu	a5,0(a0)
 1d2:	cb91                	beqz	a5,1e6 <strcmp+0x1e>
 1d4:	0005c703          	lbu	a4,0(a1)
 1d8:	00f71763          	bne	a4,a5,1e6 <strcmp+0x1e>
    p++, q++;
 1dc:	0505                	addi	a0,a0,1
 1de:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 1e0:	00054783          	lbu	a5,0(a0)
 1e4:	fbe5                	bnez	a5,1d4 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 1e6:	0005c503          	lbu	a0,0(a1)
}
 1ea:	40a7853b          	subw	a0,a5,a0
 1ee:	6422                	ld	s0,8(sp)
 1f0:	0141                	addi	sp,sp,16
 1f2:	8082                	ret

00000000000001f4 <strlen>:

uint
strlen(const char *s)
{
 1f4:	1141                	addi	sp,sp,-16
 1f6:	e422                	sd	s0,8(sp)
 1f8:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 1fa:	00054783          	lbu	a5,0(a0)
 1fe:	cf91                	beqz	a5,21a <strlen+0x26>
 200:	0505                	addi	a0,a0,1
 202:	87aa                	mv	a5,a0
 204:	4685                	li	a3,1
 206:	9e89                	subw	a3,a3,a0
 208:	00f6853b          	addw	a0,a3,a5
 20c:	0785                	addi	a5,a5,1
 20e:	fff7c703          	lbu	a4,-1(a5)
 212:	fb7d                	bnez	a4,208 <strlen+0x14>
    ;
  return n;
}
 214:	6422                	ld	s0,8(sp)
 216:	0141                	addi	sp,sp,16
 218:	8082                	ret
  for(n = 0; s[n]; n++)
 21a:	4501                	li	a0,0
 21c:	bfe5                	j	214 <strlen+0x20>

000000000000021e <memset>:

void*
memset(void *dst, int c, uint n)
{
 21e:	1141                	addi	sp,sp,-16
 220:	e422                	sd	s0,8(sp)
 222:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 224:	ce09                	beqz	a2,23e <memset+0x20>
 226:	87aa                	mv	a5,a0
 228:	fff6071b          	addiw	a4,a2,-1
 22c:	1702                	slli	a4,a4,0x20
 22e:	9301                	srli	a4,a4,0x20
 230:	0705                	addi	a4,a4,1
 232:	972a                	add	a4,a4,a0
    cdst[i] = c;
 234:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 238:	0785                	addi	a5,a5,1
 23a:	fee79de3          	bne	a5,a4,234 <memset+0x16>
  }
  return dst;
}
 23e:	6422                	ld	s0,8(sp)
 240:	0141                	addi	sp,sp,16
 242:	8082                	ret

0000000000000244 <strchr>:

char*
strchr(const char *s, char c)
{
 244:	1141                	addi	sp,sp,-16
 246:	e422                	sd	s0,8(sp)
 248:	0800                	addi	s0,sp,16
  for(; *s; s++)
 24a:	00054783          	lbu	a5,0(a0)
 24e:	cb99                	beqz	a5,264 <strchr+0x20>
    if(*s == c)
 250:	00f58763          	beq	a1,a5,25e <strchr+0x1a>
  for(; *s; s++)
 254:	0505                	addi	a0,a0,1
 256:	00054783          	lbu	a5,0(a0)
 25a:	fbfd                	bnez	a5,250 <strchr+0xc>
      return (char*)s;
  return 0;
 25c:	4501                	li	a0,0
}
 25e:	6422                	ld	s0,8(sp)
 260:	0141                	addi	sp,sp,16
 262:	8082                	ret
  return 0;
 264:	4501                	li	a0,0
 266:	bfe5                	j	25e <strchr+0x1a>

0000000000000268 <gets>:

char*
gets(char *buf, int max)
{
 268:	711d                	addi	sp,sp,-96
 26a:	ec86                	sd	ra,88(sp)
 26c:	e8a2                	sd	s0,80(sp)
 26e:	e4a6                	sd	s1,72(sp)
 270:	e0ca                	sd	s2,64(sp)
 272:	fc4e                	sd	s3,56(sp)
 274:	f852                	sd	s4,48(sp)
 276:	f456                	sd	s5,40(sp)
 278:	f05a                	sd	s6,32(sp)
 27a:	ec5e                	sd	s7,24(sp)
 27c:	1080                	addi	s0,sp,96
 27e:	8baa                	mv	s7,a0
 280:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 282:	892a                	mv	s2,a0
 284:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 286:	4aa9                	li	s5,10
 288:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 28a:	89a6                	mv	s3,s1
 28c:	2485                	addiw	s1,s1,1
 28e:	0344d663          	bge	s1,s4,2ba <gets+0x52>
    cc = read(0, &c, 1);
 292:	4605                	li	a2,1
 294:	faf40593          	addi	a1,s0,-81
 298:	4501                	li	a0,0
 29a:	1b8000ef          	jal	ra,452 <read>
    if(cc < 1)
 29e:	00a05e63          	blez	a0,2ba <gets+0x52>
    buf[i++] = c;
 2a2:	faf44783          	lbu	a5,-81(s0)
 2a6:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 2aa:	01578763          	beq	a5,s5,2b8 <gets+0x50>
 2ae:	0905                	addi	s2,s2,1
 2b0:	fd679de3          	bne	a5,s6,28a <gets+0x22>
  for(i=0; i+1 < max; ){
 2b4:	89a6                	mv	s3,s1
 2b6:	a011                	j	2ba <gets+0x52>
 2b8:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 2ba:	99de                	add	s3,s3,s7
 2bc:	00098023          	sb	zero,0(s3)
  return buf;
}
 2c0:	855e                	mv	a0,s7
 2c2:	60e6                	ld	ra,88(sp)
 2c4:	6446                	ld	s0,80(sp)
 2c6:	64a6                	ld	s1,72(sp)
 2c8:	6906                	ld	s2,64(sp)
 2ca:	79e2                	ld	s3,56(sp)
 2cc:	7a42                	ld	s4,48(sp)
 2ce:	7aa2                	ld	s5,40(sp)
 2d0:	7b02                	ld	s6,32(sp)
 2d2:	6be2                	ld	s7,24(sp)
 2d4:	6125                	addi	sp,sp,96
 2d6:	8082                	ret

00000000000002d8 <stat>:

int
stat(const char *n, struct stat *st)
{
 2d8:	1101                	addi	sp,sp,-32
 2da:	ec06                	sd	ra,24(sp)
 2dc:	e822                	sd	s0,16(sp)
 2de:	e426                	sd	s1,8(sp)
 2e0:	e04a                	sd	s2,0(sp)
 2e2:	1000                	addi	s0,sp,32
 2e4:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 2e6:	4581                	li	a1,0
 2e8:	192000ef          	jal	ra,47a <open>
  if(fd < 0)
 2ec:	02054163          	bltz	a0,30e <stat+0x36>
 2f0:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 2f2:	85ca                	mv	a1,s2
 2f4:	19e000ef          	jal	ra,492 <fstat>
 2f8:	892a                	mv	s2,a0
  close(fd);
 2fa:	8526                	mv	a0,s1
 2fc:	166000ef          	jal	ra,462 <close>
  return r;
}
 300:	854a                	mv	a0,s2
 302:	60e2                	ld	ra,24(sp)
 304:	6442                	ld	s0,16(sp)
 306:	64a2                	ld	s1,8(sp)
 308:	6902                	ld	s2,0(sp)
 30a:	6105                	addi	sp,sp,32
 30c:	8082                	ret
    return -1;
 30e:	597d                	li	s2,-1
 310:	bfc5                	j	300 <stat+0x28>

0000000000000312 <atoi>:

int
atoi(const char *s)
{
 312:	1141                	addi	sp,sp,-16
 314:	e422                	sd	s0,8(sp)
 316:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 318:	00054603          	lbu	a2,0(a0)
 31c:	fd06079b          	addiw	a5,a2,-48
 320:	0ff7f793          	andi	a5,a5,255
 324:	4725                	li	a4,9
 326:	02f76963          	bltu	a4,a5,358 <atoi+0x46>
 32a:	86aa                	mv	a3,a0
  n = 0;
 32c:	4501                	li	a0,0
  while('0' <= *s && *s <= '9')
 32e:	45a5                	li	a1,9
    n = n*10 + *s++ - '0';
 330:	0685                	addi	a3,a3,1
 332:	0025179b          	slliw	a5,a0,0x2
 336:	9fa9                	addw	a5,a5,a0
 338:	0017979b          	slliw	a5,a5,0x1
 33c:	9fb1                	addw	a5,a5,a2
 33e:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 342:	0006c603          	lbu	a2,0(a3)
 346:	fd06071b          	addiw	a4,a2,-48
 34a:	0ff77713          	andi	a4,a4,255
 34e:	fee5f1e3          	bgeu	a1,a4,330 <atoi+0x1e>
  return n;
}
 352:	6422                	ld	s0,8(sp)
 354:	0141                	addi	sp,sp,16
 356:	8082                	ret
  n = 0;
 358:	4501                	li	a0,0
 35a:	bfe5                	j	352 <atoi+0x40>

000000000000035c <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 35c:	1141                	addi	sp,sp,-16
 35e:	e422                	sd	s0,8(sp)
 360:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 362:	02b57663          	bgeu	a0,a1,38e <memmove+0x32>
    while(n-- > 0)
 366:	02c05163          	blez	a2,388 <memmove+0x2c>
 36a:	fff6079b          	addiw	a5,a2,-1
 36e:	1782                	slli	a5,a5,0x20
 370:	9381                	srli	a5,a5,0x20
 372:	0785                	addi	a5,a5,1
 374:	97aa                	add	a5,a5,a0
  dst = vdst;
 376:	872a                	mv	a4,a0
      *dst++ = *src++;
 378:	0585                	addi	a1,a1,1
 37a:	0705                	addi	a4,a4,1
 37c:	fff5c683          	lbu	a3,-1(a1)
 380:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 384:	fee79ae3          	bne	a5,a4,378 <memmove+0x1c>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 388:	6422                	ld	s0,8(sp)
 38a:	0141                	addi	sp,sp,16
 38c:	8082                	ret
    dst += n;
 38e:	00c50733          	add	a4,a0,a2
    src += n;
 392:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 394:	fec05ae3          	blez	a2,388 <memmove+0x2c>
 398:	fff6079b          	addiw	a5,a2,-1
 39c:	1782                	slli	a5,a5,0x20
 39e:	9381                	srli	a5,a5,0x20
 3a0:	fff7c793          	not	a5,a5
 3a4:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 3a6:	15fd                	addi	a1,a1,-1
 3a8:	177d                	addi	a4,a4,-1
 3aa:	0005c683          	lbu	a3,0(a1)
 3ae:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 3b2:	fee79ae3          	bne	a5,a4,3a6 <memmove+0x4a>
 3b6:	bfc9                	j	388 <memmove+0x2c>

00000000000003b8 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 3b8:	1141                	addi	sp,sp,-16
 3ba:	e422                	sd	s0,8(sp)
 3bc:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 3be:	ca05                	beqz	a2,3ee <memcmp+0x36>
 3c0:	fff6069b          	addiw	a3,a2,-1
 3c4:	1682                	slli	a3,a3,0x20
 3c6:	9281                	srli	a3,a3,0x20
 3c8:	0685                	addi	a3,a3,1
 3ca:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 3cc:	00054783          	lbu	a5,0(a0)
 3d0:	0005c703          	lbu	a4,0(a1)
 3d4:	00e79863          	bne	a5,a4,3e4 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 3d8:	0505                	addi	a0,a0,1
    p2++;
 3da:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 3dc:	fed518e3          	bne	a0,a3,3cc <memcmp+0x14>
  }
  return 0;
 3e0:	4501                	li	a0,0
 3e2:	a019                	j	3e8 <memcmp+0x30>
      return *p1 - *p2;
 3e4:	40e7853b          	subw	a0,a5,a4
}
 3e8:	6422                	ld	s0,8(sp)
 3ea:	0141                	addi	sp,sp,16
 3ec:	8082                	ret
  return 0;
 3ee:	4501                	li	a0,0
 3f0:	bfe5                	j	3e8 <memcmp+0x30>

00000000000003f2 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 3f2:	1141                	addi	sp,sp,-16
 3f4:	e406                	sd	ra,8(sp)
 3f6:	e022                	sd	s0,0(sp)
 3f8:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 3fa:	f63ff0ef          	jal	ra,35c <memmove>
}
 3fe:	60a2                	ld	ra,8(sp)
 400:	6402                	ld	s0,0(sp)
 402:	0141                	addi	sp,sp,16
 404:	8082                	ret

0000000000000406 <sbrk>:

char *
sbrk(int n) {
 406:	1141                	addi	sp,sp,-16
 408:	e406                	sd	ra,8(sp)
 40a:	e022                	sd	s0,0(sp)
 40c:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 40e:	4585                	li	a1,1
 410:	0b2000ef          	jal	ra,4c2 <sys_sbrk>
}
 414:	60a2                	ld	ra,8(sp)
 416:	6402                	ld	s0,0(sp)
 418:	0141                	addi	sp,sp,16
 41a:	8082                	ret

000000000000041c <sbrklazy>:

char *
sbrklazy(int n) {
 41c:	1141                	addi	sp,sp,-16
 41e:	e406                	sd	ra,8(sp)
 420:	e022                	sd	s0,0(sp)
 422:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 424:	4589                	li	a1,2
 426:	09c000ef          	jal	ra,4c2 <sys_sbrk>
}
 42a:	60a2                	ld	ra,8(sp)
 42c:	6402                	ld	s0,0(sp)
 42e:	0141                	addi	sp,sp,16
 430:	8082                	ret

0000000000000432 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 432:	4885                	li	a7,1
 ecall
 434:	00000073          	ecall
 ret
 438:	8082                	ret

000000000000043a <exit>:
.global exit
exit:
 li a7, SYS_exit
 43a:	4889                	li	a7,2
 ecall
 43c:	00000073          	ecall
 ret
 440:	8082                	ret

0000000000000442 <wait>:
.global wait
wait:
 li a7, SYS_wait
 442:	488d                	li	a7,3
 ecall
 444:	00000073          	ecall
 ret
 448:	8082                	ret

000000000000044a <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 44a:	4891                	li	a7,4
 ecall
 44c:	00000073          	ecall
 ret
 450:	8082                	ret

0000000000000452 <read>:
.global read
read:
 li a7, SYS_read
 452:	4895                	li	a7,5
 ecall
 454:	00000073          	ecall
 ret
 458:	8082                	ret

000000000000045a <write>:
.global write
write:
 li a7, SYS_write
 45a:	48c1                	li	a7,16
 ecall
 45c:	00000073          	ecall
 ret
 460:	8082                	ret

0000000000000462 <close>:
.global close
close:
 li a7, SYS_close
 462:	48d5                	li	a7,21
 ecall
 464:	00000073          	ecall
 ret
 468:	8082                	ret

000000000000046a <kill>:
.global kill
kill:
 li a7, SYS_kill
 46a:	4899                	li	a7,6
 ecall
 46c:	00000073          	ecall
 ret
 470:	8082                	ret

0000000000000472 <exec>:
.global exec
exec:
 li a7, SYS_exec
 472:	489d                	li	a7,7
 ecall
 474:	00000073          	ecall
 ret
 478:	8082                	ret

000000000000047a <open>:
.global open
open:
 li a7, SYS_open
 47a:	48bd                	li	a7,15
 ecall
 47c:	00000073          	ecall
 ret
 480:	8082                	ret

0000000000000482 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 482:	48c5                	li	a7,17
 ecall
 484:	00000073          	ecall
 ret
 488:	8082                	ret

000000000000048a <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 48a:	48c9                	li	a7,18
 ecall
 48c:	00000073          	ecall
 ret
 490:	8082                	ret

0000000000000492 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 492:	48a1                	li	a7,8
 ecall
 494:	00000073          	ecall
 ret
 498:	8082                	ret

000000000000049a <link>:
.global link
link:
 li a7, SYS_link
 49a:	48cd                	li	a7,19
 ecall
 49c:	00000073          	ecall
 ret
 4a0:	8082                	ret

00000000000004a2 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 4a2:	48d1                	li	a7,20
 ecall
 4a4:	00000073          	ecall
 ret
 4a8:	8082                	ret

00000000000004aa <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 4aa:	48a5                	li	a7,9
 ecall
 4ac:	00000073          	ecall
 ret
 4b0:	8082                	ret

00000000000004b2 <dup>:
.global dup
dup:
 li a7, SYS_dup
 4b2:	48a9                	li	a7,10
 ecall
 4b4:	00000073          	ecall
 ret
 4b8:	8082                	ret

00000000000004ba <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 4ba:	48ad                	li	a7,11
 ecall
 4bc:	00000073          	ecall
 ret
 4c0:	8082                	ret

00000000000004c2 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 4c2:	48b1                	li	a7,12
 ecall
 4c4:	00000073          	ecall
 ret
 4c8:	8082                	ret

00000000000004ca <pause>:
.global pause
pause:
 li a7, SYS_pause
 4ca:	48b5                	li	a7,13
 ecall
 4cc:	00000073          	ecall
 ret
 4d0:	8082                	ret

00000000000004d2 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 4d2:	48b9                	li	a7,14
 ecall
 4d4:	00000073          	ecall
 ret
 4d8:	8082                	ret

00000000000004da <getnice>:
.global getnice
getnice:
 li a7, SYS_getnice
 4da:	48d9                	li	a7,22
 ecall
 4dc:	00000073          	ecall
 ret
 4e0:	8082                	ret

00000000000004e2 <setnice>:
.global setnice
setnice:
 li a7, SYS_setnice
 4e2:	48dd                	li	a7,23
 ecall
 4e4:	00000073          	ecall
 ret
 4e8:	8082                	ret

00000000000004ea <ps>:
.global ps
ps:
 li a7, SYS_ps
 4ea:	48e1                	li	a7,24
 ecall
 4ec:	00000073          	ecall
 ret
 4f0:	8082                	ret

00000000000004f2 <meminfo>:
.global meminfo
meminfo:
 li a7, SYS_meminfo
 4f2:	48e5                	li	a7,25
 ecall
 4f4:	00000073          	ecall
 ret
 4f8:	8082                	ret

00000000000004fa <waitpid>:
.global waitpid
waitpid:
 li a7, SYS_waitpid
 4fa:	48e9                	li	a7,26
 ecall
 4fc:	00000073          	ecall
 ret
 500:	8082                	ret

0000000000000502 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 502:	1101                	addi	sp,sp,-32
 504:	ec06                	sd	ra,24(sp)
 506:	e822                	sd	s0,16(sp)
 508:	1000                	addi	s0,sp,32
 50a:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 50e:	4605                	li	a2,1
 510:	fef40593          	addi	a1,s0,-17
 514:	f47ff0ef          	jal	ra,45a <write>
}
 518:	60e2                	ld	ra,24(sp)
 51a:	6442                	ld	s0,16(sp)
 51c:	6105                	addi	sp,sp,32
 51e:	8082                	ret

0000000000000520 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 520:	715d                	addi	sp,sp,-80
 522:	e486                	sd	ra,72(sp)
 524:	e0a2                	sd	s0,64(sp)
 526:	fc26                	sd	s1,56(sp)
 528:	f84a                	sd	s2,48(sp)
 52a:	f44e                	sd	s3,40(sp)
 52c:	0880                	addi	s0,sp,80
 52e:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 530:	c299                	beqz	a3,536 <printint+0x16>
 532:	0805c163          	bltz	a1,5b4 <printint+0x94>
  neg = 0;
 536:	4881                	li	a7,0
 538:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 53c:	4781                	li	a5,0
  do{
    buf[i++] = digits[x % base];
 53e:	00000517          	auipc	a0,0x0
 542:	61a50513          	addi	a0,a0,1562 # b58 <digits>
 546:	883e                	mv	a6,a5
 548:	2785                	addiw	a5,a5,1
 54a:	02c5f733          	remu	a4,a1,a2
 54e:	972a                	add	a4,a4,a0
 550:	00074703          	lbu	a4,0(a4)
 554:	00e68023          	sb	a4,0(a3)
  }while((x /= base) != 0);
 558:	872e                	mv	a4,a1
 55a:	02c5d5b3          	divu	a1,a1,a2
 55e:	0685                	addi	a3,a3,1
 560:	fec773e3          	bgeu	a4,a2,546 <printint+0x26>
  if(neg)
 564:	00088b63          	beqz	a7,57a <printint+0x5a>
    buf[i++] = '-';
 568:	fd040713          	addi	a4,s0,-48
 56c:	97ba                	add	a5,a5,a4
 56e:	02d00713          	li	a4,45
 572:	fee78423          	sb	a4,-24(a5)
 576:	0028079b          	addiw	a5,a6,2

  while(--i >= 0)
 57a:	02f05663          	blez	a5,5a6 <printint+0x86>
 57e:	fb840713          	addi	a4,s0,-72
 582:	00f704b3          	add	s1,a4,a5
 586:	fff70993          	addi	s3,a4,-1
 58a:	99be                	add	s3,s3,a5
 58c:	37fd                	addiw	a5,a5,-1
 58e:	1782                	slli	a5,a5,0x20
 590:	9381                	srli	a5,a5,0x20
 592:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 596:	fff4c583          	lbu	a1,-1(s1)
 59a:	854a                	mv	a0,s2
 59c:	f67ff0ef          	jal	ra,502 <putc>
  while(--i >= 0)
 5a0:	14fd                	addi	s1,s1,-1
 5a2:	ff349ae3          	bne	s1,s3,596 <printint+0x76>
}
 5a6:	60a6                	ld	ra,72(sp)
 5a8:	6406                	ld	s0,64(sp)
 5aa:	74e2                	ld	s1,56(sp)
 5ac:	7942                	ld	s2,48(sp)
 5ae:	79a2                	ld	s3,40(sp)
 5b0:	6161                	addi	sp,sp,80
 5b2:	8082                	ret
    x = -xx;
 5b4:	40b005b3          	neg	a1,a1
    neg = 1;
 5b8:	4885                	li	a7,1
    x = -xx;
 5ba:	bfbd                	j	538 <printint+0x18>

00000000000005bc <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 5bc:	7119                	addi	sp,sp,-128
 5be:	fc86                	sd	ra,120(sp)
 5c0:	f8a2                	sd	s0,112(sp)
 5c2:	f4a6                	sd	s1,104(sp)
 5c4:	f0ca                	sd	s2,96(sp)
 5c6:	ecce                	sd	s3,88(sp)
 5c8:	e8d2                	sd	s4,80(sp)
 5ca:	e4d6                	sd	s5,72(sp)
 5cc:	e0da                	sd	s6,64(sp)
 5ce:	fc5e                	sd	s7,56(sp)
 5d0:	f862                	sd	s8,48(sp)
 5d2:	f466                	sd	s9,40(sp)
 5d4:	f06a                	sd	s10,32(sp)
 5d6:	ec6e                	sd	s11,24(sp)
 5d8:	0100                	addi	s0,sp,128
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 5da:	0005c903          	lbu	s2,0(a1)
 5de:	24090c63          	beqz	s2,836 <vprintf+0x27a>
 5e2:	8b2a                	mv	s6,a0
 5e4:	8a2e                	mv	s4,a1
 5e6:	8bb2                	mv	s7,a2
  state = 0;
 5e8:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 5ea:	4481                	li	s1,0
 5ec:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 5ee:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 5f2:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 5f6:	06c00d13          	li	s10,108
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 5fa:	07500d93          	li	s11,117
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 5fe:	00000c97          	auipc	s9,0x0
 602:	55ac8c93          	addi	s9,s9,1370 # b58 <digits>
 606:	a005                	j	626 <vprintf+0x6a>
        putc(fd, c0);
 608:	85ca                	mv	a1,s2
 60a:	855a                	mv	a0,s6
 60c:	ef7ff0ef          	jal	ra,502 <putc>
 610:	a019                	j	616 <vprintf+0x5a>
    } else if(state == '%'){
 612:	03598263          	beq	s3,s5,636 <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 616:	2485                	addiw	s1,s1,1
 618:	8726                	mv	a4,s1
 61a:	009a07b3          	add	a5,s4,s1
 61e:	0007c903          	lbu	s2,0(a5)
 622:	20090a63          	beqz	s2,836 <vprintf+0x27a>
    c0 = fmt[i] & 0xff;
 626:	0009079b          	sext.w	a5,s2
    if(state == 0){
 62a:	fe0994e3          	bnez	s3,612 <vprintf+0x56>
      if(c0 == '%'){
 62e:	fd579de3          	bne	a5,s5,608 <vprintf+0x4c>
        state = '%';
 632:	89be                	mv	s3,a5
 634:	b7cd                	j	616 <vprintf+0x5a>
      if(c0) c1 = fmt[i+1] & 0xff;
 636:	c3c1                	beqz	a5,6b6 <vprintf+0xfa>
 638:	00ea06b3          	add	a3,s4,a4
 63c:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 640:	8636                	mv	a2,a3
      if(c1) c2 = fmt[i+2] & 0xff;
 642:	c681                	beqz	a3,64a <vprintf+0x8e>
 644:	9752                	add	a4,a4,s4
 646:	00274603          	lbu	a2,2(a4)
      if(c0 == 'd'){
 64a:	03878e63          	beq	a5,s8,686 <vprintf+0xca>
      } else if(c0 == 'l' && c1 == 'd'){
 64e:	05a78863          	beq	a5,s10,69e <vprintf+0xe2>
      } else if(c0 == 'u'){
 652:	0db78b63          	beq	a5,s11,728 <vprintf+0x16c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 656:	07800713          	li	a4,120
 65a:	10e78d63          	beq	a5,a4,774 <vprintf+0x1b8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 65e:	07000713          	li	a4,112
 662:	14e78263          	beq	a5,a4,7a6 <vprintf+0x1ea>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 'c'){
 666:	06300713          	li	a4,99
 66a:	16e78f63          	beq	a5,a4,7e8 <vprintf+0x22c>
        putc(fd, va_arg(ap, uint32));
      } else if(c0 == 's'){
 66e:	07300713          	li	a4,115
 672:	18e78563          	beq	a5,a4,7fc <vprintf+0x240>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 676:	05579063          	bne	a5,s5,6b6 <vprintf+0xfa>
        putc(fd, '%');
 67a:	85d6                	mv	a1,s5
 67c:	855a                	mv	a0,s6
 67e:	e85ff0ef          	jal	ra,502 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 682:	4981                	li	s3,0
 684:	bf49                	j	616 <vprintf+0x5a>
        printint(fd, va_arg(ap, int), 10, 1);
 686:	008b8913          	addi	s2,s7,8
 68a:	4685                	li	a3,1
 68c:	4629                	li	a2,10
 68e:	000ba583          	lw	a1,0(s7)
 692:	855a                	mv	a0,s6
 694:	e8dff0ef          	jal	ra,520 <printint>
 698:	8bca                	mv	s7,s2
      state = 0;
 69a:	4981                	li	s3,0
 69c:	bfad                	j	616 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'd'){
 69e:	03868663          	beq	a3,s8,6ca <vprintf+0x10e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6a2:	05a68163          	beq	a3,s10,6e4 <vprintf+0x128>
      } else if(c0 == 'l' && c1 == 'u'){
 6a6:	09b68d63          	beq	a3,s11,740 <vprintf+0x184>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 6aa:	03a68f63          	beq	a3,s10,6e8 <vprintf+0x12c>
      } else if(c0 == 'l' && c1 == 'x'){
 6ae:	07800793          	li	a5,120
 6b2:	0cf68d63          	beq	a3,a5,78c <vprintf+0x1d0>
        putc(fd, '%');
 6b6:	85d6                	mv	a1,s5
 6b8:	855a                	mv	a0,s6
 6ba:	e49ff0ef          	jal	ra,502 <putc>
        putc(fd, c0);
 6be:	85ca                	mv	a1,s2
 6c0:	855a                	mv	a0,s6
 6c2:	e41ff0ef          	jal	ra,502 <putc>
      state = 0;
 6c6:	4981                	li	s3,0
 6c8:	b7b9                	j	616 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 6ca:	008b8913          	addi	s2,s7,8
 6ce:	4685                	li	a3,1
 6d0:	4629                	li	a2,10
 6d2:	000bb583          	ld	a1,0(s7)
 6d6:	855a                	mv	a0,s6
 6d8:	e49ff0ef          	jal	ra,520 <printint>
        i += 1;
 6dc:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 6de:	8bca                	mv	s7,s2
      state = 0;
 6e0:	4981                	li	s3,0
        i += 1;
 6e2:	bf15                	j	616 <vprintf+0x5a>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6e4:	03860563          	beq	a2,s8,70e <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 6e8:	07b60963          	beq	a2,s11,75a <vprintf+0x19e>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 6ec:	07800793          	li	a5,120
 6f0:	fcf613e3          	bne	a2,a5,6b6 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6f4:	008b8913          	addi	s2,s7,8
 6f8:	4681                	li	a3,0
 6fa:	4641                	li	a2,16
 6fc:	000bb583          	ld	a1,0(s7)
 700:	855a                	mv	a0,s6
 702:	e1fff0ef          	jal	ra,520 <printint>
        i += 2;
 706:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 708:	8bca                	mv	s7,s2
      state = 0;
 70a:	4981                	li	s3,0
        i += 2;
 70c:	b729                	j	616 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 70e:	008b8913          	addi	s2,s7,8
 712:	4685                	li	a3,1
 714:	4629                	li	a2,10
 716:	000bb583          	ld	a1,0(s7)
 71a:	855a                	mv	a0,s6
 71c:	e05ff0ef          	jal	ra,520 <printint>
        i += 2;
 720:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 722:	8bca                	mv	s7,s2
      state = 0;
 724:	4981                	li	s3,0
        i += 2;
 726:	bdc5                	j	616 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 728:	008b8913          	addi	s2,s7,8
 72c:	4681                	li	a3,0
 72e:	4629                	li	a2,10
 730:	000be583          	lwu	a1,0(s7)
 734:	855a                	mv	a0,s6
 736:	debff0ef          	jal	ra,520 <printint>
 73a:	8bca                	mv	s7,s2
      state = 0;
 73c:	4981                	li	s3,0
 73e:	bde1                	j	616 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 740:	008b8913          	addi	s2,s7,8
 744:	4681                	li	a3,0
 746:	4629                	li	a2,10
 748:	000bb583          	ld	a1,0(s7)
 74c:	855a                	mv	a0,s6
 74e:	dd3ff0ef          	jal	ra,520 <printint>
        i += 1;
 752:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 754:	8bca                	mv	s7,s2
      state = 0;
 756:	4981                	li	s3,0
        i += 1;
 758:	bd7d                	j	616 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 75a:	008b8913          	addi	s2,s7,8
 75e:	4681                	li	a3,0
 760:	4629                	li	a2,10
 762:	000bb583          	ld	a1,0(s7)
 766:	855a                	mv	a0,s6
 768:	db9ff0ef          	jal	ra,520 <printint>
        i += 2;
 76c:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 76e:	8bca                	mv	s7,s2
      state = 0;
 770:	4981                	li	s3,0
        i += 2;
 772:	b555                	j	616 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 774:	008b8913          	addi	s2,s7,8
 778:	4681                	li	a3,0
 77a:	4641                	li	a2,16
 77c:	000be583          	lwu	a1,0(s7)
 780:	855a                	mv	a0,s6
 782:	d9fff0ef          	jal	ra,520 <printint>
 786:	8bca                	mv	s7,s2
      state = 0;
 788:	4981                	li	s3,0
 78a:	b571                	j	616 <vprintf+0x5a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 78c:	008b8913          	addi	s2,s7,8
 790:	4681                	li	a3,0
 792:	4641                	li	a2,16
 794:	000bb583          	ld	a1,0(s7)
 798:	855a                	mv	a0,s6
 79a:	d87ff0ef          	jal	ra,520 <printint>
        i += 1;
 79e:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 7a0:	8bca                	mv	s7,s2
      state = 0;
 7a2:	4981                	li	s3,0
        i += 1;
 7a4:	bd8d                	j	616 <vprintf+0x5a>
        printptr(fd, va_arg(ap, uint64));
 7a6:	008b8793          	addi	a5,s7,8
 7aa:	f8f43423          	sd	a5,-120(s0)
 7ae:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 7b2:	03000593          	li	a1,48
 7b6:	855a                	mv	a0,s6
 7b8:	d4bff0ef          	jal	ra,502 <putc>
  putc(fd, 'x');
 7bc:	07800593          	li	a1,120
 7c0:	855a                	mv	a0,s6
 7c2:	d41ff0ef          	jal	ra,502 <putc>
 7c6:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 7c8:	03c9d793          	srli	a5,s3,0x3c
 7cc:	97e6                	add	a5,a5,s9
 7ce:	0007c583          	lbu	a1,0(a5)
 7d2:	855a                	mv	a0,s6
 7d4:	d2fff0ef          	jal	ra,502 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 7d8:	0992                	slli	s3,s3,0x4
 7da:	397d                	addiw	s2,s2,-1
 7dc:	fe0916e3          	bnez	s2,7c8 <vprintf+0x20c>
        printptr(fd, va_arg(ap, uint64));
 7e0:	f8843b83          	ld	s7,-120(s0)
      state = 0;
 7e4:	4981                	li	s3,0
 7e6:	bd05                	j	616 <vprintf+0x5a>
        putc(fd, va_arg(ap, uint32));
 7e8:	008b8913          	addi	s2,s7,8
 7ec:	000bc583          	lbu	a1,0(s7)
 7f0:	855a                	mv	a0,s6
 7f2:	d11ff0ef          	jal	ra,502 <putc>
 7f6:	8bca                	mv	s7,s2
      state = 0;
 7f8:	4981                	li	s3,0
 7fa:	bd31                	j	616 <vprintf+0x5a>
        if((s = va_arg(ap, char*)) == 0)
 7fc:	008b8993          	addi	s3,s7,8
 800:	000bb903          	ld	s2,0(s7)
 804:	00090f63          	beqz	s2,822 <vprintf+0x266>
        for(; *s; s++)
 808:	00094583          	lbu	a1,0(s2)
 80c:	c195                	beqz	a1,830 <vprintf+0x274>
          putc(fd, *s);
 80e:	855a                	mv	a0,s6
 810:	cf3ff0ef          	jal	ra,502 <putc>
        for(; *s; s++)
 814:	0905                	addi	s2,s2,1
 816:	00094583          	lbu	a1,0(s2)
 81a:	f9f5                	bnez	a1,80e <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 81c:	8bce                	mv	s7,s3
      state = 0;
 81e:	4981                	li	s3,0
 820:	bbdd                	j	616 <vprintf+0x5a>
          s = "(null)";
 822:	00000917          	auipc	s2,0x0
 826:	32e90913          	addi	s2,s2,814 # b50 <malloc+0x218>
        for(; *s; s++)
 82a:	02800593          	li	a1,40
 82e:	b7c5                	j	80e <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 830:	8bce                	mv	s7,s3
      state = 0;
 832:	4981                	li	s3,0
 834:	b3cd                	j	616 <vprintf+0x5a>
    }
  }
}
 836:	70e6                	ld	ra,120(sp)
 838:	7446                	ld	s0,112(sp)
 83a:	74a6                	ld	s1,104(sp)
 83c:	7906                	ld	s2,96(sp)
 83e:	69e6                	ld	s3,88(sp)
 840:	6a46                	ld	s4,80(sp)
 842:	6aa6                	ld	s5,72(sp)
 844:	6b06                	ld	s6,64(sp)
 846:	7be2                	ld	s7,56(sp)
 848:	7c42                	ld	s8,48(sp)
 84a:	7ca2                	ld	s9,40(sp)
 84c:	7d02                	ld	s10,32(sp)
 84e:	6de2                	ld	s11,24(sp)
 850:	6109                	addi	sp,sp,128
 852:	8082                	ret

0000000000000854 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 854:	715d                	addi	sp,sp,-80
 856:	ec06                	sd	ra,24(sp)
 858:	e822                	sd	s0,16(sp)
 85a:	1000                	addi	s0,sp,32
 85c:	e010                	sd	a2,0(s0)
 85e:	e414                	sd	a3,8(s0)
 860:	e818                	sd	a4,16(s0)
 862:	ec1c                	sd	a5,24(s0)
 864:	03043023          	sd	a6,32(s0)
 868:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 86c:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 870:	8622                	mv	a2,s0
 872:	d4bff0ef          	jal	ra,5bc <vprintf>
}
 876:	60e2                	ld	ra,24(sp)
 878:	6442                	ld	s0,16(sp)
 87a:	6161                	addi	sp,sp,80
 87c:	8082                	ret

000000000000087e <printf>:

void
printf(const char *fmt, ...)
{
 87e:	711d                	addi	sp,sp,-96
 880:	ec06                	sd	ra,24(sp)
 882:	e822                	sd	s0,16(sp)
 884:	1000                	addi	s0,sp,32
 886:	e40c                	sd	a1,8(s0)
 888:	e810                	sd	a2,16(s0)
 88a:	ec14                	sd	a3,24(s0)
 88c:	f018                	sd	a4,32(s0)
 88e:	f41c                	sd	a5,40(s0)
 890:	03043823          	sd	a6,48(s0)
 894:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 898:	00840613          	addi	a2,s0,8
 89c:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 8a0:	85aa                	mv	a1,a0
 8a2:	4505                	li	a0,1
 8a4:	d19ff0ef          	jal	ra,5bc <vprintf>
}
 8a8:	60e2                	ld	ra,24(sp)
 8aa:	6442                	ld	s0,16(sp)
 8ac:	6125                	addi	sp,sp,96
 8ae:	8082                	ret

00000000000008b0 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 8b0:	1141                	addi	sp,sp,-16
 8b2:	e422                	sd	s0,8(sp)
 8b4:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 8b6:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8ba:	00000797          	auipc	a5,0x0
 8be:	7467b783          	ld	a5,1862(a5) # 1000 <freep>
 8c2:	a805                	j	8f2 <free+0x42>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 8c4:	4618                	lw	a4,8(a2)
 8c6:	9db9                	addw	a1,a1,a4
 8c8:	feb52c23          	sw	a1,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 8cc:	6398                	ld	a4,0(a5)
 8ce:	6318                	ld	a4,0(a4)
 8d0:	fee53823          	sd	a4,-16(a0)
 8d4:	a091                	j	918 <free+0x68>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 8d6:	ff852703          	lw	a4,-8(a0)
 8da:	9e39                	addw	a2,a2,a4
 8dc:	c790                	sw	a2,8(a5)
    p->s.ptr = bp->s.ptr;
 8de:	ff053703          	ld	a4,-16(a0)
 8e2:	e398                	sd	a4,0(a5)
 8e4:	a099                	j	92a <free+0x7a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8e6:	6398                	ld	a4,0(a5)
 8e8:	00e7e463          	bltu	a5,a4,8f0 <free+0x40>
 8ec:	00e6ea63          	bltu	a3,a4,900 <free+0x50>
{
 8f0:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8f2:	fed7fae3          	bgeu	a5,a3,8e6 <free+0x36>
 8f6:	6398                	ld	a4,0(a5)
 8f8:	00e6e463          	bltu	a3,a4,900 <free+0x50>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8fc:	fee7eae3          	bltu	a5,a4,8f0 <free+0x40>
  if(bp + bp->s.size == p->s.ptr){
 900:	ff852583          	lw	a1,-8(a0)
 904:	6390                	ld	a2,0(a5)
 906:	02059713          	slli	a4,a1,0x20
 90a:	9301                	srli	a4,a4,0x20
 90c:	0712                	slli	a4,a4,0x4
 90e:	9736                	add	a4,a4,a3
 910:	fae60ae3          	beq	a2,a4,8c4 <free+0x14>
    bp->s.ptr = p->s.ptr;
 914:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 918:	4790                	lw	a2,8(a5)
 91a:	02061713          	slli	a4,a2,0x20
 91e:	9301                	srli	a4,a4,0x20
 920:	0712                	slli	a4,a4,0x4
 922:	973e                	add	a4,a4,a5
 924:	fae689e3          	beq	a3,a4,8d6 <free+0x26>
  } else
    p->s.ptr = bp;
 928:	e394                	sd	a3,0(a5)
  freep = p;
 92a:	00000717          	auipc	a4,0x0
 92e:	6cf73b23          	sd	a5,1750(a4) # 1000 <freep>
}
 932:	6422                	ld	s0,8(sp)
 934:	0141                	addi	sp,sp,16
 936:	8082                	ret

0000000000000938 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 938:	7139                	addi	sp,sp,-64
 93a:	fc06                	sd	ra,56(sp)
 93c:	f822                	sd	s0,48(sp)
 93e:	f426                	sd	s1,40(sp)
 940:	f04a                	sd	s2,32(sp)
 942:	ec4e                	sd	s3,24(sp)
 944:	e852                	sd	s4,16(sp)
 946:	e456                	sd	s5,8(sp)
 948:	e05a                	sd	s6,0(sp)
 94a:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 94c:	02051493          	slli	s1,a0,0x20
 950:	9081                	srli	s1,s1,0x20
 952:	04bd                	addi	s1,s1,15
 954:	8091                	srli	s1,s1,0x4
 956:	0014899b          	addiw	s3,s1,1
 95a:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 95c:	00000517          	auipc	a0,0x0
 960:	6a453503          	ld	a0,1700(a0) # 1000 <freep>
 964:	c515                	beqz	a0,990 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 966:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 968:	4798                	lw	a4,8(a5)
 96a:	02977f63          	bgeu	a4,s1,9a8 <malloc+0x70>
 96e:	8a4e                	mv	s4,s3
 970:	0009871b          	sext.w	a4,s3
 974:	6685                	lui	a3,0x1
 976:	00d77363          	bgeu	a4,a3,97c <malloc+0x44>
 97a:	6a05                	lui	s4,0x1
 97c:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 980:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 984:	00000917          	auipc	s2,0x0
 988:	67c90913          	addi	s2,s2,1660 # 1000 <freep>
  if(p == SBRK_ERROR)
 98c:	5afd                	li	s5,-1
 98e:	a0bd                	j	9fc <malloc+0xc4>
    base.s.ptr = freep = prevp = &base;
 990:	00000797          	auipc	a5,0x0
 994:	68078793          	addi	a5,a5,1664 # 1010 <base>
 998:	00000717          	auipc	a4,0x0
 99c:	66f73423          	sd	a5,1640(a4) # 1000 <freep>
 9a0:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 9a2:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 9a6:	b7e1                	j	96e <malloc+0x36>
      if(p->s.size == nunits)
 9a8:	02e48b63          	beq	s1,a4,9de <malloc+0xa6>
        p->s.size -= nunits;
 9ac:	4137073b          	subw	a4,a4,s3
 9b0:	c798                	sw	a4,8(a5)
        p += p->s.size;
 9b2:	1702                	slli	a4,a4,0x20
 9b4:	9301                	srli	a4,a4,0x20
 9b6:	0712                	slli	a4,a4,0x4
 9b8:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 9ba:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 9be:	00000717          	auipc	a4,0x0
 9c2:	64a73123          	sd	a0,1602(a4) # 1000 <freep>
      return (void*)(p + 1);
 9c6:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 9ca:	70e2                	ld	ra,56(sp)
 9cc:	7442                	ld	s0,48(sp)
 9ce:	74a2                	ld	s1,40(sp)
 9d0:	7902                	ld	s2,32(sp)
 9d2:	69e2                	ld	s3,24(sp)
 9d4:	6a42                	ld	s4,16(sp)
 9d6:	6aa2                	ld	s5,8(sp)
 9d8:	6b02                	ld	s6,0(sp)
 9da:	6121                	addi	sp,sp,64
 9dc:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 9de:	6398                	ld	a4,0(a5)
 9e0:	e118                	sd	a4,0(a0)
 9e2:	bff1                	j	9be <malloc+0x86>
  hp->s.size = nu;
 9e4:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 9e8:	0541                	addi	a0,a0,16
 9ea:	ec7ff0ef          	jal	ra,8b0 <free>
  return freep;
 9ee:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 9f2:	dd61                	beqz	a0,9ca <malloc+0x92>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 9f4:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 9f6:	4798                	lw	a4,8(a5)
 9f8:	fa9778e3          	bgeu	a4,s1,9a8 <malloc+0x70>
    if(p == freep)
 9fc:	00093703          	ld	a4,0(s2)
 a00:	853e                	mv	a0,a5
 a02:	fef719e3          	bne	a4,a5,9f4 <malloc+0xbc>
  p = sbrk(nu * sizeof(Header));
 a06:	8552                	mv	a0,s4
 a08:	9ffff0ef          	jal	ra,406 <sbrk>
  if(p == SBRK_ERROR)
 a0c:	fd551ce3          	bne	a0,s5,9e4 <malloc+0xac>
        return 0;
 a10:	4501                	li	a0,0
 a12:	bf65                	j	9ca <malloc+0x92>
